package ca.uwaterloo.ece251.ast;

public class IdExprPair extends ASTNode {
    String id;
    Expr expr;

    public IdExprPair(String id, Expr expr) {
	this.id = id; this.expr = expr;
    }

    public void accept(Visitor v) {
	v.enter(this);
	expr.accept(v);
	v.leave(this);
    }
}