#!/bin/bash

echo
echo "ECE251"
echo "SQL Lexer Tester v0.2"
echo "Wed Nov 3 16:07:26 EDT 2010"
echo "---------------------------"
echo "Note: Pass your classpath as an argument (ex. testLexer.sh /home/mehdi/A2-ece251/bin/)."
echo "      Fell free to modify the paths."
echo

passed=0
failed=0

if [ ! -d output ]; then
   echo "Creating output folder"
   mkdir output
fi

if [ ! -d output/tokenonly ]; then
   echo "Creating output/tokenonly folder"
   mkdir output/tokenonly
fi

echo
echo "Phase 1: Testing SQL Lexer..."
echo

for sql in tokenonly/*.sql
do
   output=output/${sql%.*sql}.out

   echo "Testing ${sql}"
   java -classpath $1 ca.uwaterloo.ece251.TokenDriver $sql > $output
done

echo
echo "Phase 2: Evaluating SQL Lexer..."
echo

for output in output/tokenonly/*
do
   expected=expected${output#output}
   if `diff -b -w ${expected} ${output} > /dev/null`
      then
         echo "[PASSED] $output Vs. $expected"
            passed=$((passed+1))
       else
         echo "[FAILED] $output Vs. $expected"
            failed=$((failed+1))
    fi
done

tests=$((passed+failed))
result=$(($passed * 100 / $tests))
# result=`echo "scale=2; 100 * $passed / ($passed+$failed)" | bc -l`
echo "Result: $passed/$tests ($result%) of test cases passed"
