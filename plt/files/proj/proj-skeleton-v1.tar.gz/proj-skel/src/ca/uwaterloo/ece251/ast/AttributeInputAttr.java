package ca.uwaterloo.ece251.ast;

/** Represents any other attribute for an INPUT or SELECT tag. */
public class AttributeInputAttr extends InputAttr {
    Attribute attr;

    public AttributeInputAttr(Attribute attr) {
	this.attr = attr;
    }

    public String toString() {
	return attr.toString();
    }
}

