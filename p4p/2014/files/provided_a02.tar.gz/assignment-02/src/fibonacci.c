#include <stdlib.h>
#include <stdio.h>

unsigned long int fib(int n) {
    if (n >= 2) {
        return fib(n - 1) + fib(n -2);
    }
    else {
        return n;
    }
}

int main(int argc, char *argv[])
{
    if (argc != 2) {
        printf("%s: requires an argument > 10\n", argv[0]);
        return EXIT_FAILURE;
    }
    int n = atoi(argv[1]);
    if (n <= 10) {
        printf("%s: requires an argument > 10\n", argv[0]);        
        return EXIT_FAILURE;
    }
    #pragma omp parallel
    {
        #pragma omp single
        {
            printf("fibonacci(%d) = %lu\n", n, fib(n));
        }
    }
    return EXIT_SUCCESS;
}
