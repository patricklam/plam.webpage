SELECT Customers.FirstName, Customers.LastName, Sales.SaleAmount AS SalesPerCustomer
FROM Customers JOIN Sales
ON Customers.CustomerID = Sales.CustomerID
GROUP BY Customers.FirstName, Customers.LastName;
