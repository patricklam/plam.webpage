open Abstlanguage
open Nodes
open Aabsyn

let unsome = function (Some x) -> x | None -> failwith "[deuglifyabst] tried to deoptionify None"
let d x = Tokens.getText (unsome x)

let rec value_type_from_ugly x =
  match x with
  | AIntType _ -> Types.TInt
  | AFloatType _ -> Types.TFloat
  | ABoolType _ -> Types.TBool
  | ACharType _ -> Types.TChar
  | AStringType _ -> Types.TString
  | AFormatType f -> Types.TObj (Tokens.getText (unsome f.format_type_identifier))
  | AArrayType a -> 
      let rec stackers base_type a' = 
        match a' with
        | AOneDims _ -> base_type
        | AManyDims a'' -> stackers (Types.TArray base_type) (unsome a''.many_dims_dims)
      in (Types.TArray (stackers (value_type_from_ugly (unsome a.array_type_type)) (unsome a.array_type_dims)))

let rec convert (mdl0:p_abst_module) : string abst_module = 
  match mdl0 with
  | AAbstModule mdl ->
      let mdl_name = Id.fetch_module (d mdl.abst_module_abst_module_name) in
      let rec convert_expr (exp:p_expr) : string clause = 
        match exp with
        | ALetExpr e -> LetClause (convert_set_defn (unsome e.let_expr_v),
                                   convert_expr (unsome e.let_expr_e))
        | AIffExpr e -> IffClause 
              (convert_expr (unsome e.iff_expr_l),
               convert_expr (unsome e.iff_expr_r))
        | AOrExpr e -> OrClause
              (convert_expr (unsome e.or_expr_l),
               convert_expr (unsome e.or_expr_r))
        | AAndExpr e -> AndClause
              (convert_expr (unsome e.and_expr_l),
               convert_expr (unsome e.and_expr_r))
        | ANotExpr e -> NotClause (convert_expr (unsome e.not_expr_expr))
        | AFormulaExpr e -> FormulaClause 
              (Util.trim_quotes (d e.formula_expr_string_literal))
      and convert_set_defn (ASetDefn (sd:a_set_defn)) : string set_defn =
        ((mdl_name ^ "." ^Id.fetch_var (d sd.set_defn_l)), 
         convert_set_defn_rhs (unsome sd.set_defn_r))
      and convert_set_defn_rhs (sdr:p_set_defn_rhs) : string set_defn_rhs =
        match sdr with
        | ACupSetDefnRhs crhs -> UnionForm 
              (convert_set_defn_rhs (unsome crhs.cup_set_defn_rhs_l), 
               convert_set_defn_rhs (unsome crhs.cup_set_defn_rhs_r))
        | ACapSetDefnRhs crhs -> IntersectionForm 
              (convert_set_defn_rhs (unsome crhs.cap_set_defn_rhs_l), 
               convert_set_defn_rhs (unsome crhs.cap_set_defn_rhs_r))
        | ABracedSetDefnRhs brhs -> BaseForm
            {  x = Id.fetch_var (d brhs.braced_set_defn_rhs_r);
               xt = Id.fetch_format (d brhs.braced_set_defn_rhs_rt);
               expr = (convert_expr (unsome brhs.braced_set_defn_rhs_cond)) }
        | AIdSetDefnRhs id -> 
            IdForm (Util.qualify_if_needed mdl_name
                      (d id.id_set_defn_rhs_identifier)) in
      let select_invs m = match m with
        AInvAbstMember _ -> true | _ -> false in
      let select_sets m = match m with
        ASetDefnAbstMember _ -> true 
      | _ -> false in
      let select_predvars m = match m with
        APredVarAbstMember _ -> true 
      | _ -> false in
      let select_proclists m = match m with
        AProcListAbstMember _ -> true 
      | _ -> false in
      let select_procs m = match m with
        AProcAbstMember _ -> true 
      | _ -> false in
      let select_formats m = match m with
        AFormatAbstMember _ -> true 
      | _ -> false in
      let rec convert_body (AAbstBody mdl) : string abst_body = {
        plugin = Util.trim_quotes (d mdl.abst_body_plugin);
        invariants = List.map 
          (fun x -> match x with AInvAbstMember x' -> 
            convert_expr (unsome x'.inv_abst_member_expr) 
          | _ -> failwith "filter failed")
          (List.filter select_invs mdl.abst_body_abst_member);
        set_defns = List.map
          (fun x -> match x with
            ASetDefnAbstMember x' -> 
              convert_set_defn (unsome x'.set_defn_abst_member_set_defn)
          | _ -> failwith "filter failed")
          (List.filter select_sets mdl.abst_body_abst_member);
        pred_vars = List.map
          (fun x -> match x with
            APredVarAbstMember x' -> 
              Util.qualify_if_needed mdl_name (d x'.pred_var_abst_member_identifier)
          | _ -> failwith "filter failed")
          (List.filter select_predvars
             mdl.abst_body_abst_member);
        formats = List.map
          (fun x -> match x with AFormatAbstMember x' -> 
            let convert_format_member (AFormatMember fm) = 
              List.map (fun m -> ((Id.fetch_field mdl_name (Tokens.getText m)),
                                  value_type_from_ugly (unsome fm.format_member_type)))
                fm.format_member_member in
            { Iabsyn.format_name = d x'.format_abst_member_identifier;
              Iabsyn.fields = List.concat (List.map 
                                             convert_format_member 
                                             x'.format_abst_member_format_member); }
          | _ -> failwith "filter failed")
          (List.filter select_formats mdl.abst_body_abst_member);
        procs_to_analyze = List.concat (List.map
             (fun x -> match x with
               AProcListAbstMember x' -> 
                 List.map (fun pn -> Util.qualify_if_needed mdl_name 
                     (Tokens.getText pn)) 
                   (x'.proc_list_abst_member_identifier)
             | _ -> failwith "filter failed")
                                          (List.filter select_proclists
                                             mdl.abst_body_abst_member));
        set_defining_procs = List.map
          (fun x -> match x with
            AProcAbstMember x' ->
              { 
                proc_name = 
                { 
                  Id.p_name = d x'.proc_abst_member_identifier;
                  Id.p_module = mdl_name 
                };
                proc_set_defns = List.map
                  (fun x'' -> match x'' with
                    ASetDefnAbstMember x''' -> 
                      convert_set_defn 
                        (unsome x'''.set_defn_abst_member_set_defn)
                  | _ -> failwith "filter failed")
                  x'.proc_abst_member_abst_member;
              }
          | _ -> failwith "filter failed")
          (List.filter select_procs
             mdl.abst_body_abst_member)} in
      { 
        module_name = mdl_name;
        instantiated_from = None; 
        param_subst = [];
        body = List.map convert_body mdl.abst_module_abst_module_abst_body;
      }
   | AInstAbstModule m1 ->  
       { 
         module_name = Id.fetch_module 
           (d m1.inst_abst_module_n);
         instantiated_from = Some 
           (Id.fetch_module (d m1.inst_abst_module_parent));
         param_subst = List.map (fun (ASubst x) -> 
          (Id.fetch_format (d x.subst_f),
           Id.fetch_format (d x.subst_a)))
          m1.inst_abst_module_params;
         body = [{
           plugin = "<none>";
           invariants = [];
           set_defns = [];
           pred_vars = [];
           procs_to_analyze = [];
           set_defining_procs = [];
           formats = [];
         }]
       }



