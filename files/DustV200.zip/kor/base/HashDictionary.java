// HashDictionary.java
//
// Author: Raja Vallee-Rai
//
// This file is public domain.  You can do anything you want with 
// it, all at your own risk.  Enjoy!

package kor.base;

import java.util.*;

/**
 * Provides an implementation of the Dictionary object using java.util.Hashtable.
 **/

public
class HashDictionary extends Dictionary
{
    Hashtable dictionary;

    public HashDictionary()
    {
        dictionary = new Hashtable();
    }

    public void associate(Object entry, Object associate)
    {
        dictionary.put(entry, associate);
    }
    
    public Object associateOf(Object entry)
    {
        Object obj = dictionary.get(entry);
        
        Debug.assert(obj != null);
        
        return obj;
    }

    public boolean isObjAssociated(Object entry)
    {
        Object obj = dictionary.get(entry);
    
        return obj != null;
    }

    /**
     * Returns the number of entries in the dictionary.
     */    
     
    public int numEntries()
    {
        return dictionary.size();
    }

    public DynamicList listOfEntries()
    {
        return DynamicList.ofEnumeration(dictionary.keys());
    }
    
    public DynamicList listOfAssociates()
    {
        return DynamicList.ofEnumeration(dictionary.elements());
    }
}
