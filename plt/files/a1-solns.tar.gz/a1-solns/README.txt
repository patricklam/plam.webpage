To compile this project, pass antlr3.jar to ant, e.g.

$ ant -lib antlr3.jar

