(* Formulas of predicate calculus with sets,
   equality, let-expressions, reachability expressions,
   function symbols, and cardinality constraint
   shorthands. *)

type ident = string
type propIdent = ident
type funIdent = ident
type relIdent = ident
type constIdent = ident
type varIdent = ident
type setIdent = ident

type regExp =
  | Funsym of funIdent
  | Alt of regExp list
  | Seq of regExp list
  | Star of regExp

type term =
  | Var of varIdent
  | Const of constIdent
  | Fun of int * funIdent * term list

type setTerm =
  | Constset of term list
  | Setvar of setIdent
  | Union of setTerm list
  | Inter of setTerm list
  | Diff of setTerm * setTerm

type form =
    (* atomic *)
  | True
  | False
  | Propvar of propIdent
  | Eq of term * term
  | Eqset of setTerm * setTerm
  | Subset of setTerm * setTerm
  | Elem of term * setTerm
  | Cardeq of setTerm * int
  | Cardleq of setTerm * int
  | Cardgeq of setTerm * int
  | Disjoint of setTerm list
  | Isempty of setTerm
  | Rel of int * relIdent * term list
    (* propositional *)
  | Not of form
  | And of form list
  | Or of form list
  | Impl of form * form
  | Iff of form * form
    (* binding constructs *)
  | Existsprop of propIdent * form
  | Forallprop of propIdent * form
  | Letprop of propIdent * form * form
  | Exists of varIdent * form
  | Existsone of varIdent * form
  | Existseq of int * varIdent * form
  | Existsleq of int * varIdent * form
  | Existsgeq of int * varIdent * form
  | Forall of varIdent * form
  | Let of varIdent * term * form
  | Existsset of setIdent * form
  | Forallset of setIdent * form
  | Letset of setIdent * setTerm * form
  | Letsetcompr of letsetcompr
  | Letsetregexp of letsetregexp
and letsetcompr = { 
    comprSet: setIdent;
    comprElem: varIdent;
    comprDef: form;
    comprBody: form;
  }
and letsetregexp = {
    defSet: setIdent;
    startSet: setTerm;
    letRegexp: regExp;
    regexpBody: form;
  }
