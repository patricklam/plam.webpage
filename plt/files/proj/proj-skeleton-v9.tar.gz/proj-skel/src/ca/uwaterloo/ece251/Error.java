package ca.uwaterloo.ece251;

public class Error {
    public static boolean errors = false;
    public static void error(String s) {
	System.out.println("error: "+s);
	errors = true;
    }

    public static void fatalerror(String s) {
	System.out.println("fatal error: "+s);
	errors = true;
	System.exit(-1);
    }
}
