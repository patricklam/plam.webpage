package ca.uwaterloo.ece251.ast;

import java.util.List;

/** Represents one WiG service. */
public class Service {
    List<HTML> htmls;
    List<Schema> schemas;
    List<Variable> variables;
    List<Function> functions;
    List<Session> sessions;

    public Service(List<HTML> htmls,
		   List<Schema> schemas,
		   List<Variable> variables,
		   List<Function> functions,
		   List<Session> sessions) {
	this.htmls = htmls;
	this.schemas = schemas;
	this.variables = variables;
	this.functions = functions;
	this.sessions = sessions;
    }

    public String toString() {
	return String.format("service {\n%s%s%s%s%s%s}\n",
			     Util.lines(htmls, 2), 
			     Util.lines(schemas, 2), 
			     Util.lines(variables, 2), 
			     Util.lines(functions, 2), 
			     Util.lines(sessions, 2));
    }
}

