#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include "runwig.h"

char *url;
char *sessionid;
int pc;
FILE *f;

void output_Welcome()
{
  printf("\n    Welcome!\n  ");
}

void output_Pledge()
{
  printf("\n    How much do you want to contribute?\n    ");
  printf("<input name=\"contribution\" type=\"text\" size=\"4\">\n");
}

void output_Total(char * total)
{
  printf("\n    The total is now ");
  printf(total);
  printf(".\n  ");
}

int main() {
  srand48(time(0L));
  parseFields();
  url = "http://ece251.patricklam.ca/";
  sessionid = getenv("QUERY_STRING");

  if (strcmp(sessionid, "Contribute")==0)
    goto start_Contribute;
  if (strncmp(sessionid, "Contribute$",11)==0)
    goto restart_Contribute;
  printf("Content-type: text/html\n\n");
  printf("<title>Illegal Request</title>\n");
  printf("<h1>Illegal Request: %s</h1>\n",sessionid);
  exit(1);
}
int local_Contribute_i;
