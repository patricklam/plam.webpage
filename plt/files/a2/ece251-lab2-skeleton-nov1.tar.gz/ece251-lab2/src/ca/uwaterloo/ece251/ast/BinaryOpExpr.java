package ca.uwaterloo.ece251.ast;

public class BinaryOpExpr extends Expr {
    public static final String PLUS = "+", MINUS = "-", TIMES = "*", 
	DIV="/", MOD = "%", LT = "<", LE = "<=", GT = ">", GE = ">=", EQ = "=";
    String op;
    Expr left, right;

    public BinaryOpExpr(String op, Expr left, Expr right) {
	this.op = op; this.left = left; this.right = right;
    }

    public void accept(Visitor v) {
	v.enter(this);
	left.accept(v); right.accept(v);
	v.leave(this);
    }
}
