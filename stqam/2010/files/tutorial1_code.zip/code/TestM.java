import org.junit.*;
import static org.junit.Assert.*;

/**
 * Dummy file
 */
public class TestM {

    private M m;

    public TestM() {
    }

    @Before
    public void setup() {
        m = new M();
    }

    @After
    public void tearDown() {
        m = null;
    }

    @Test
    public void testDummyMethod() {
        int expected = 0;
        int res = m.dummyMethod();
        assertTrue( (expected == res) );
    }
}
