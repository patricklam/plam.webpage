#include <stdlib.h>
#include <stdio.h>

double gr(int n) {
    if (n >= 2) {
        double f, g;

        #pragma omp task default(none) shared(f, n)
        f = gr(n-1);

        #pragma omp task default(none) shared(g, n)
        g = gr(n-1);

        #pragma omp taskwait
        return ((f+5)/g)/2;
    }
    else {
        return 2.0;
    }
}

int main(int argc, char *argv[])
{
    if (argc != 2) {
        printf("%s: requires an argument > 10\n", argv[0]);
        return EXIT_FAILURE;
    }
    int n = atoi(argv[1]);
    if (n <= 10) {
        printf("%s: requires an argument > 10\n", argv[0]);        
        return EXIT_FAILURE;
    }
    #pragma omp parallel
    {
        #pragma omp single
        {
            printf("gr(%d) = %lf\n", n, gr(n));
        }
    }
    return EXIT_SUCCESS;
}
