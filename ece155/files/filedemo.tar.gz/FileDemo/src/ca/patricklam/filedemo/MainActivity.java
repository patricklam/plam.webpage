package ca.patricklam.filedemo;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.widget.EditText;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        EditText t = (EditText) findViewById(R.id.editText1);
        t.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(Editable arg0) {
            }

            @Override
            public void beforeTextChanged(CharSequence arg0, int arg1,
                    int arg2, int arg3) {
            }

            @Override
            public void onTextChanged(CharSequence s, int arg1, int arg2,
                    int arg3) {
                String input = s.toString();
                try {
                    // internal storage:
                    FileOutputStream os = openFileOutput("internal.txt", Context.MODE_PRIVATE);
                    //FileOutputStream os = new FileOutputStream(new File(getExternalFilesDir(null), "external.txt"));
                    PrintWriter osw = new PrintWriter(new OutputStreamWriter(os));
                    osw.println(input);
                    osw.close();
                } catch (IOException e) {}
            }
        });
        
        try {
            // internal storage: 
            FileInputStream os = openFileInput("internal.txt");
            //InputStream os = new FileInputStream(new File(getExternalFilesDir(null), "external.txt"));
            BufferedReader br = new BufferedReader(new InputStreamReader(os));
            String i = br.readLine();
            if (i != null) {
                t.setText(i);
            }
            os.close();
        } catch (IOException e) {}
        
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.activity_main, menu);
        return true;
    }

}
