// TickMeasurer.java
//
// Author: Raja Vallee-Rai
//
// This file is public domain.  You can do anything you want with 
// it, all at your own risk.  Enjoy!


package kor.base;

/**
 * A TickMeasurer object measures the number of times you call the registerTick()
 * method within a window of time specified by the constructor. 
 * 
 * <p>It is useful to measure the frame rate of a display system, by sampling
 * over a given duration of time, and not just from the beginning of the display. 
 */

public
class TickMeasurer
{
    double lastTickRate;
    long idealSampleDuration;
    long numTicks;
    long sampleStartTime;
    
    /**
     * Start measuring, and the duration of each sampling window
     * is given in milliseconds.
     */
     
    public TickMeasurer(long idealSampleDuration)
    {
        this.idealSampleDuration = idealSampleDuration;
        numTicks = 0;
        sampleStartTime = System.currentTimeMillis();
    }
    
    /**
     * Register one event for the current window.
     */
     
    public void registerTick()
    {
        long sampleDuration = System.currentTimeMillis() - sampleStartTime;
        
        numTicks++;
        
        if(sampleDuration >= idealSampleDuration)
        {
            lastTickRate = (double) numTicks / sampleDuration * 1000.0;
            sampleStartTime = System.currentTimeMillis();
            numTicks = 0;
        }
    }
    
    /**
     * Returns the tick rate (in ticks/sec) of the last complete window. 
     */
     
    public double tickRate()
    {
        return lastTickRate;
    }
}
