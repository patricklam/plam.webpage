UPDATE suppliers
SET city = 'Santa Clara'
WHERE supplier_name = 'NVIDIA';
