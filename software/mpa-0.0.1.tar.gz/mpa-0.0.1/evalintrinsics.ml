open Iabsyn
open Types
open Id

exception Intrinsic_return of value option

let rec make_pairs : value list -> (value * string) list =
  fun args -> match args with
  | [] -> []
  | (Obj i)::(String s)::rest -> (Obj i, s) :: make_pairs rest
  | _ -> failwith "wrong arguments to heap_dump"

let last_event : Graphics.status option ref = ref None
let saw_eof = ref false

let eval_intrinsic : Id.proc_t -> value list -> unit =
  fun proc args ->
    if Intrinsics.is_intrinsic proc then
      match ((module_of_proc proc), (name_of_proc proc)) with
        ("System", "print_int") -> 
          List.iter (function (Int x) -> print_int x 
            | y -> failwith ("type error on print_int: got "^(string_of_value_type (value_type_of_value y)))) args; 
          raise (Intrinsic_return None)
      | ("System", "read_int") -> 
          raise (Intrinsic_return (Some (Int (read_int ()))))
      | ("System", "float_of_int") ->
          let bd = List.hd args in
          ignore (match bd with
          | Int b -> raise (Intrinsic_return (Some (Float (float_of_int b))))
          | _ -> failwith "type error on float_of_int: got "^(string_of_value_type (value_type_of_value bd)));
          raise (Intrinsic_return None)
      | ("System", "string_of_int") ->
          let bd = List.hd args in
          ignore (match bd with
          | Int b -> raise (Intrinsic_return (Some (String (string_of_int b))))
          | _ -> failwith "type error on string_of_int: got "^(string_of_value_type (value_type_of_value bd)));
          raise (Intrinsic_return None)
      | ("System", "int_of_string") ->
          let bd = List.hd args in
          ignore (match bd with
          | String b -> raise (Intrinsic_return (Some (Int (int_of_string b))))
          | _ -> failwith "type error on int_of_string: got "^(string_of_value_type (value_type_of_value bd)));
          raise (Intrinsic_return None)
      | ("System", "int_of_float") ->
          let bd = List.hd args in
          ignore (match bd with
          | Float b -> raise (Intrinsic_return (Some (Int (int_of_float b))))
          | _ -> failwith "type error on int_of_float");
          raise (Intrinsic_return None)
      | ("System", "print_string") -> 
          List.iter (function (String x) -> print_string x 
            | _ -> failwith "type error on print_string") args;
          flush stdout;
          raise (Intrinsic_return None)
      | ("System", "heap_dump") ->          
          (match args with
            String fileName :: String comment :: rest -> begin
              Intrheapdumper.dump fileName comment (make_pairs rest);
              raise (Intrinsic_return None)
            end
          | _ -> failwith "type error on heap_dump args")
      | ("System", "random") ->
          let bd = List.hd args in
          ignore (match bd with
          | Int b -> raise (Intrinsic_return (Some (Int (Random.int b))))
          | _ -> failwith "type error on random: got "^(string_of_value_type (value_type_of_value bd)));
          raise (Intrinsic_return None)
      | ("System", "srand") ->
          let bd = List.hd args in
          ignore (match bd with
          | Int b -> Random.init b;
              raise (Intrinsic_return None)
          | _ -> failwith "type error on random: got "^(string_of_value_type (value_type_of_value bd)));
          raise (Intrinsic_return None)
      | ("System", "open_in") ->
          let bd = List.hd args in
          ignore (match bd with
          | String x -> 
              saw_eof := false; 
              let fd = open_in x in
              let nobj = Intrheap.fresh_obj () in
              Intrheap.put_input_channel_mapping nobj fd;
              raise (Intrinsic_return (Some nobj))
          | _ -> failwith "type error on open_in");
      | ("System", "input_line") ->
          let bd = List.hd args in
          ignore (match bd with
          | Obj _ -> 
              saw_eof := false; 
              let fd = Intrheap.get_input_channel_mapping bd in
              let s = try input_line fd with
              | End_of_file -> saw_eof := true; "" in
              raise (Intrinsic_return (Some (String s)))
          | _ -> failwith "type error on input_line")
      | ("System", "close_in") ->
          let bd = List.hd args in
          ignore (match bd with
          | Obj n -> 
              saw_eof := false; 
              let fd = Intrheap.get_input_channel_mapping bd in
              close_in fd;
              Intrheap.clear_input_channel_mapping bd;
              raise (Intrinsic_return None)
          | _ -> failwith "type error on close_in")
      | ("System", "eof") ->
          (match args with
            [] -> Graphics.close_graph ()
          | _ -> failwith "type error for eof");
          raise (Intrinsic_return (Some (Bool !saw_eof)))
      | ("System", "time") ->
          (match args with
            [] -> raise (Intrinsic_return (Some (Float (Unix.time ()))))
          | _ -> failwith "type error for time")
      | ("System", "exit") ->
          (match args with
            [Int i] -> exit i
          | _ -> failwith "type error for time")
      | ("String", "get") -> 
          (match args with
            [String s; Int i] -> raise (Intrinsic_return (Some (Char (s.[i]))))
          | _ -> failwith "type error for String.get")
      | ("String", "string_after") -> 
          (match args with
            [String s; Int i] -> 
              raise (Intrinsic_return (Some (String (Str.string_after s i))))
          | _ -> failwith "type error for String.string_after")
      | ("String", "string_before") -> 
          (match args with
            [String s; Int i] -> 
              raise (Intrinsic_return (Some (String (Str.string_before s i))))
          | _ -> failwith "type error for String.string_before")
      | ("String", "index") -> 
          (match args with
            [String s; Char c] -> 
              raise (Intrinsic_return (Some (Int (String.index s c))))
          | _ -> failwith "type error for String.index")
      | ("String", "contains") -> 
          (match args with
            [String s; Char c] -> 
              raise (Intrinsic_return (Some (Bool (String.contains s c))))
          | _ -> failwith "type error for String.contains")
      | ("String", "length") -> 
          (match args with
            [String s] -> 
              raise (Intrinsic_return (Some (Int (String.length s))))
          | _ -> failwith "type error for String.length")
      | ("Graphics", "open_graph") -> 
          (match args with
            [String d] -> Graphics.open_graph d
          | _ -> failwith "type error for open_graph");
          raise (Intrinsic_return None)
      | ("Graphics", "close_graph") -> 
          (match args with
            [] -> Graphics.close_graph ()
          | _ -> failwith "type error for close_graph");
          raise (Intrinsic_return None)
      | ("Graphics", "colour") -> 
          raise (Intrinsic_return (Some (Int
                   (match (List.hd args) with
                   | String s -> (match s with
                     | "black" -> Graphics.black
                     | "white" -> Graphics.white
                     | "red" -> Graphics.red
                     | "green" -> Graphics.green
                     | "blue" -> Graphics.blue
                     | "yellow" -> Graphics.yellow
                     | "cyan" -> Graphics.cyan
                     | "magenta" -> Graphics.magenta
                     | _ -> failwith ("bad colour "^s))
                   | _ -> failwith "type error for colour"))))
      | ("Graphics", "set_colour") -> 
          (match args with
            [Int i] -> Graphics.set_color i
          | _ -> failwith "type error for set_colour");
          raise (Intrinsic_return None)
      | ("Graphics", "set_line_width") ->
          (match args with
            [Int i] -> Graphics.set_line_width i
          | _ -> failwith "type error for set_line_width");
          raise (Intrinsic_return None)
      | ("Graphics", "moveto") -> 
          (match args with
            [Int x; Int y] -> Graphics.moveto x y
          | _ -> failwith "type error for moveto");
          raise (Intrinsic_return None)
      | ("Graphics", "lineto") -> 
          (match args with
            [Int x; Int y] -> Graphics.lineto x y
          | _ -> failwith "type error for lineto");
          raise (Intrinsic_return None)
      | ("Graphics", "fill_rect") ->
          (match args with
            [Int x; Int y; Int w; Int h] -> Graphics.fill_rect x y w h
          | _ -> failwith "type error for fill_rect");
          raise (Intrinsic_return None)
        TVoid
      | ("Graphics", "fill_poly") ->
          (match args with
            [Array px0; Array py0] -> 
              let unint x = 
                match x with Int x' -> x' 
                | _ -> failwith "bad type for fill_poly" in
              let (px, py) = (List.map unint (Array.to_list px0), 
                              List.map unint (Array.to_list py0)) in
              let p = List.combine px py in
              Graphics.fill_poly (Array.of_list p)
          | _ -> failwith "type error for fill_poly");
          raise (Intrinsic_return None)
        TVoid
      | ("Graphics", "fill_circle") -> 
          (match args with
            [Int x; Int y; Int r] -> Graphics.fill_circle x y r
          | _ -> failwith "type error for fill_circle");
          raise (Intrinsic_return None)
      | ("Graphics", "text_size_x") -> 
          (match args with
            [String s] -> 
              raise (Intrinsic_return 
                       (Some (Int (fst (Graphics.text_size s)))))
          | _ -> failwith "type error for text_size_x")
      | ("Graphics", "text_size_y") ->
          (match args with
            [String s] -> 
              raise (Intrinsic_return 
                       (Some (Int (snd (Graphics.text_size s)))))
          | _ -> failwith "type error for text_size_y")
      | ("Graphics", "current_point_x") -> 
          (match args with
            [] -> 
              raise (Intrinsic_return 
                       (Some (Int (fst (Graphics.current_point ())))))
          | _ -> failwith "type error for text_size_x")
      | ("Graphics", "current_point_y") ->
          (match args with
            [] -> 
              raise (Intrinsic_return 
                       (Some (Int (snd (Graphics.current_point ())))))
          | _ -> failwith "type error for text_size_y")
      | ("Graphics", "draw_string") -> 
          (match args with
            [String s] -> Graphics.draw_string s
          | _ -> failwith "type error for draw_string");
          raise (Intrinsic_return None)
      | ("Graphics", "get_image") -> 
          (match args with
            [Int x; Int y; Int dx; Int dy] -> 
              let do_array ar = 
                Array (Array.map (fun x -> Int x) ar) in
              let im = Graphics.get_image x y dx dy in
              let im' = Graphics.dump_image im in
              raise (Intrinsic_return (Some (Array (Array.map do_array im'))))
          | _ -> failwith "type error for get_image")
      | ("Graphics", "draw_image") ->
          (match args with
            [Array ar; Int x; Int y] -> 
              let un_array ar0 = (match ar0 with
              | Array ar ->
                  Array.map (fun x ->
                    match x with | Int y -> y | _ -> failwith "huh_di") ar
              | _ -> failwith "huh_di2") in
              let im = Graphics.make_image (Array.map un_array ar) in
              Graphics.draw_image im x y;
              raise (Intrinsic_return None)
          | _ -> failwith "type error for draw_image");
          (* input; uses state *)
      | ("Graphics", "wait_next_event") -> 
          (match args with
            [Int t] ->
              let pr = if (t land 0x1 = 0x1) then 
                [Graphics.Key_pressed] else [] in
              let bd = if (t land 0x2 = 0x2) then 
                [Graphics.Button_down] else [] in
              let bu = if (t land 0x4 = 0x4) then
                [Graphics.Button_up] else [] in
              last_event := Some (Graphics.wait_next_event (pr @ bd @ bu));
              raise (Intrinsic_return None)
          | _ -> failwith ("type error on wait_next_event"))
      | ("Graphics", "KEY_PRESSED") ->
          raise (Intrinsic_return (Some (Int 0x1)))
      | ("Graphics", "BUTTON_DOWN") ->
          raise (Intrinsic_return (Some (Int 0x2)))
      | ("Graphics", "BUTTON_UP") -> 
          raise (Intrinsic_return (Some (Int 0x4)))
      | ("Graphics", "keypressed") -> 
          if args <> [] then
            failwith ("type error on keypressed");
          (match !last_event with
          | Some st -> 
              raise (Intrinsic_return 
                       (Some (Bool st.Graphics.keypressed)))
          | None -> failwith "keypressed without event")
      | ("Graphics", "last_key_pressed") -> 
          if args <> [] then
            failwith ("type error on last_key_pressed");
          (match !last_event with
          | Some st -> 
              raise (Intrinsic_return 
                       (Some (Char st.Graphics.key)))
          | None -> failwith "last_key_pressed without event")
      | ("Graphics", "last_click_x") -> 
          if args <> [] then
            failwith ("type error on last_click_x");
          (match !last_event with
          | Some st -> 
              raise (Intrinsic_return 
                       (Some (Int st.Graphics.mouse_x)))
          | None -> failwith "last_click_x without event")
      | ("Graphics", "last_click_y") -> 
          if args <> [] then
            failwith ("type error on last_click_y");
          (match !last_event with
          | Some st -> 
              raise (Intrinsic_return 
                       (Some (Int st.Graphics.mouse_y)))
          | None -> failwith "last_click_y event")
      | _ -> failwith ("undefined intrinsic "^Id.module_of_proc proc ^ 
                       "."^Id.name_of_proc proc^"!")
