package ca.uwaterloo.ece251;

import java.io.*;

public class LexerDriver {
    public static void main(String[] args) throws Exception {
        PushbackReader r = new PushbackReader(new BufferedReader
					      (new InputStreamReader
					       (new FileInputStream(args[0]))));
	TokenStream ts = new TokenStream(r);

	while (ts.hasMoreElements()) {
	    System.out.println("t: "+ts.nextElement());
	}
	r.close();
    }

}
