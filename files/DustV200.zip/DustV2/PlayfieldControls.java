// PlayfieldControls.java
//
// Author: Raja Vallee-Rai
//
// This file is public domain.  You can do anything you want with 
// it, all at your own risk.  Enjoy!

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

import kor.base.*;

/**
 * The PlayfieldControls object is pair with the Playfield, and handles all of the Playfield's
 * menued interface and mouse control.
 */

class PlayfieldControls extends Panel implements ActionListener, 
                                                 MouseListener,
                                                 ItemListener,
                                                 MouseMotionListener,
                                                 WindowListener
{
    static final int SELECTION = 0,
                     CHANGE_VELOCITY = 1,
                     CHANGE_POSITION = 2,
                     PLACE_PARTICLE = 3;

    static final int INITIAL_REFRESH_RATE = 20,
                     MAX_REFRESH_RATE = 30,
                     MIN_REFRESH_RATE = 1;

    static final int INITIAL_TRAIL_SIZE_IN_SECS = 5,    
                     MAX_TRAIL_SIZE_IN_SECS = 30,
                     MIN_TRAIL_SIZE_IN_SECS = 1;
                     
    static final int INITIAL_STEP_GRANULARITY = 20,
                     MAX_STEP_GRANULARITY = 30,
                     MIN_STEP_GRANULARITY = 1;

    static final int INITIAL_SIMULATION_SPEED = 40,
                     MAX_SIMULATION_SPEED = 80,
                     MIN_SIMULATION_SPEED = 1;
                                                               
    static final int MAX_SCREEN_DISTANCE_TO_CLICK = 10;

    static final int INITIAL_GRID_SIZE = 10,
                     MAX_GRID_SIZE = 500,   
                     MIN_GRID_SIZE = 1;
                          
    Playfield playfield;
    Button startButton, stopButton;
    
    boolean hasSelectedParticle;
    Particle selectedParticle;
    Label selectionLabel;

    int roleOfNextClick = SELECTION;


    boolean firstPaintCall = true;
                    
    int stepGranularity;

    Menu simulationRefreshMenu;
    ValueCheckboxMenuGroup simulationRefreshGroup;
    
    int simulationCacheSize;
    Menu simulationCacheSizeMenu;
    ValueCheckboxMenuGroup simulationCacheSizeGroup;
        
    double simulationSpeed;
    Menu simulationSpeedMenu;
    ValueCheckboxMenuGroup simulationSpeedGroup;
    
    Menu mainPopupSimulationSpeedMenu;
    ValueCheckboxMenuGroup mainPopupSimulationSpeedGroup;
    
    CheckboxMenuItem simulationSingularityWarningBox;
    
    Menu viewTrailSizeMenu;
    ValueCheckboxMenuGroup viewTrailSizeGroup;

    int trailSize;     
    int trailSizeInSecs;

    Checkbox timeLockBox;
    
    boolean hasSavedPlayfield;    
    StateOfPlayfield savedPlayfield;
    
    ValueCheckboxMenuGroup viewGridSizeGroup;
    Menu viewGridSizeMenu;

    double gridSize;

    boolean isChangingVelocity;
        
    MenuItem systemLessonItem;
    MenuItem systemClearStateItem, systemSaveStateItem, systemRestoreStateItem;
    MenuItem systemSaveStateToFileItem, systemRestoreStateFromFileItem;
    MenuItem systemEnergyItem;
    MenuItem particleAddItem;
    
    MenuItem particlePropertiesItem;
    CheckboxMenuItem particleAnchorBox, particleTrailBox;
    
    MenuItem particleDeleteItem;
        
    Menu particleChargeMenu;
    Menu particleMassMenu;
    CheckboxMenuGroup particleMassGroup;
    CheckboxMenuGroup particleChargeGroup;
            
    CheckboxMenuGroup particlePopupMassGroup;
    CheckboxMenuGroup particlePopupChargeGroup;
    Menu particlePopupChargeMenu;
    Menu particlePopupMassMenu;
    
    MenuItem simulationStartItem, simulationStopItem;

    Menu simulationPrecisionMenu;
    ValueCheckboxMenuGroup simulationPrecisionGroup;
    
    double simulationPrecision;
    MenuItem simulationCacheStatsItem;
    
    CheckboxMenuItem viewShowLabelsBox;
    MenuItem viewZoomControlItem;
    CheckboxMenuItem viewNoInfoWhileSimulatingBox;
    CheckboxMenuItem viewNoVectorsWhileSimulatingBox;
    CheckboxMenuItem viewShowChargeBox, viewShowMassBox;
    CheckboxMenuItem viewShowVelocityBox, viewShowPositionBox;
    CheckboxMenuItem viewUseGridBox;
    CheckboxMenuItem viewLockGridBox;
    MenuItem viewRecenterMap;

    CheckboxMenuGroup viewGridTypeGroup;
    Menu viewGridTypeMenu;
    
    MenuItem viewAllTrailsItem, viewNoTrailsItem, viewClearTrailsItem;
    
    Menu viewVelocityMenu;
    Menu viewForceMenu;
    Menu viewPositionMenu;
    Menu viewAccelerationMenu;
    
    CheckboxMenuGroup viewVelocityGroup, 
        viewAccelerationGroup, viewForceGroup, viewPositionGroup;
    
    ZoomControl zoomControl;
    BoundaryControl boundaryControl;
    ElectricFieldControl electricFieldControl;
    LessonControl lessonControl;
    
    EnergyViewer energyViewer;
    CacheViewer cacheViewer;
    
    Dust parentDust;

    PopupMenu mainPopupMenu;
        
    MenuItem mainPopupAddParticleItem;
    MenuItem mainPopupStartSimulationItem,
            mainPopupStopSimulationItem;
    MenuItem mainPopupSaveStateItem,
            mainPopupRestoreStateItem;

    PopupMenu particlePopupMenu;
    
    CheckboxMenuItem particlePopupAnchorBox, particlePopupTrailBox;
    MenuItem particlePopupDeleteItem;
    MenuItem particlePopupPropertiesItem;

    double displacementX,
           displacementY;

    int lastClickX,
        lastClickY;

    int preDragTicks;
    
    boolean isDraggingWorld;
    double worldDragX;
    double worldDragY;

    Menu extrasMenu;
    CheckboxMenuItem extrasShowElectricFieldBox;
    MenuItem extrasElectricFieldControlItem;
    
    Menu extrasViscosityMenu;
    ValueCheckboxMenuGroup extrasViscosityGroup;
    MenuItem extrasBoundaryControl;
    
    double extrasViscosity;

    ByteArrayOutputStream memoryStateStream;
        
    public void disposeAssociatedFrames()
    {
        electricFieldControl.dispose();
        zoomControl.dispose();
        boundaryControl.dispose();
        lessonControl.dispose();
    }
    
    public PlayfieldControls(Playfield playfield, MenuBar bar, Dust parentDust)
    {        
        this.playfield = playfield;
        this.parentDust = parentDust;
        playfield.controls = this;
        
        setBackground(Color.lightGray);
        setLayout(new BorderLayout());

        // Setup menu bars
        {
            // System menu
            {
                Menu systemMenu = new Menu("System");
            
                systemMenu.add(systemLessonItem = new MenuItem("Lessons..."));
                systemLessonItem.addActionListener(this);
                                
                systemMenu.addSeparator();
                systemMenu.add(systemSaveStateItem = new MenuItem("Save State to Memory"));
                systemSaveStateItem.addActionListener(this);
                systemMenu.add(systemRestoreStateItem = new MenuItem("Restore State from Memory"));
                systemRestoreStateItem.setEnabled(false);
                systemRestoreStateItem.addActionListener(this);
                
                systemMenu.addSeparator();
                
                systemMenu.add(systemSaveStateToFileItem = new MenuItem("Save State to File"));
                systemSaveStateToFileItem.addActionListener(this);
                
                systemMenu.add(systemRestoreStateFromFileItem = 
                    new MenuItem("Restore State from File"));
                systemRestoreStateFromFileItem.addActionListener(this);
                
                systemMenu.addSeparator();
                
                systemMenu.add(systemClearStateItem = new MenuItem("Clear System"));
                systemClearStateItem.addActionListener(this);

                systemMenu.add(systemEnergyItem = new MenuItem("System Energy..."));
                systemEnergyItem.addActionListener(this);
                
                bar.add(systemMenu);
            }
            
            // Particle menu
            {
                Menu particleMenu = new Menu("Particle");
                
                particleMenu.add(particleAddItem = new MenuItem("Add"));
                particleAddItem.addActionListener(this);
                particleMenu.addSeparator();
                                
                particleMenu.add(particleAnchorBox = 
                    new CheckboxMenuItem("Anchored", false));
                particleAnchorBox.addItemListener(this);
                
                particleMenu.add(particleTrailBox = 
                    new CheckboxMenuItem("Trail", false));
                particleTrailBox.addItemListener(this);
                
                // Charge sub-menu
                {
                    particleChargeMenu = new Menu("Charge");
                    
                    particleChargeGroup = new CheckboxMenuGroup();
                    
                    particleChargeGroup.add("-2", particleChargeMenu, this);
                    particleChargeGroup.add("-1", particleChargeMenu, this);
                    particleChargeGroup.add("0", particleChargeMenu, this);
                    particleChargeGroup.add("+1", particleChargeMenu, this);
                    particleChargeGroup.add("+2", particleChargeMenu, this);
                    particleChargeGroup.add("Custom", particleChargeMenu, this);
                    
                    particleChargeGroup.setSelected("0");
                    
                    particleMenu.add(particleChargeMenu);
                    
                }
                
                // Mass sub-menu
                {
                    particleMassMenu = new Menu("Mass");
                    
                    particleMassGroup = new CheckboxMenuGroup();
                    
                    particleMassGroup.add("1", particleMassMenu, this);
                    particleMassGroup.add("2", particleMassMenu, this);
                    particleMassGroup.add("3", particleMassMenu, this);
                    particleMassGroup.add("4", particleMassMenu, this);
                    particleMassGroup.add("1840", particleMassMenu, this);
                    particleMassGroup.add("Custom", particleMassMenu, this);
                    
                    particleMassGroup.setSelected("1");
                    particleMenu.add(particleMassMenu);
                    
                }

                particleMenu.addSeparator();
                
                particleMenu.add(particlePropertiesItem = 
                    new MenuItem("Properties..."));
                
                particlePropertiesItem.addActionListener(this);
            
                particleMenu.addSeparator();
                particleMenu.add(particleDeleteItem = new MenuItem("Delete"));
                particleDeleteItem.addActionListener(this);
                    
                bar.add(particleMenu);
            
            }
            
            // Simulation menu
            {
                Menu simulationMenu = new Menu("Simulation");
                
                simulationMenu.add(simulationStartItem = new MenuItem("Start"));
                simulationStartItem.addActionListener(this);
                
                simulationMenu.add(simulationStopItem = new MenuItem("Stop"));
                simulationStopItem.addActionListener(this);
                simulationStopItem.setEnabled(false);
                
                simulationMenu.addSeparator();
                
                // Speed sub-menu
                {
                    simulationSpeedMenu = new Menu("Speed");
                    
                    simulationSpeedGroup = new ValueCheckboxMenuGroup();
                    
                    simulationSpeedGroup.add("x0.25", 0.25, simulationSpeedMenu, this);
                    simulationSpeedGroup.add("x0.5", 0.5, simulationSpeedMenu, this);
                    simulationSpeedGroup.add("x1", 1, simulationSpeedMenu, this);
                    simulationSpeedGroup.add("x2", 2, simulationSpeedMenu, this);
                    simulationSpeedGroup.add("x4", 4, simulationSpeedMenu, this);
                    simulationSpeedGroup.add("x8", 8, simulationSpeedMenu, this);
                    
                    simulationSpeedGroup.setSelected("x1");
                    simulationSpeed = 1.0;
                    
                    simulationMenu.add(simulationSpeedMenu);                    
                }
                                
                // Precision sub-menu
                {
                    simulationPrecisionMenu = new Menu("Precision");
                    
                    simulationPrecisionGroup = new ValueCheckboxMenuGroup();
                    
                    simulationPrecisionGroup.add("Very Low (0.01)", 0.01,
                        simulationPrecisionMenu, this);
                    simulationPrecisionGroup.add("Low (0.001)", 0.001, 
                        simulationPrecisionMenu, this);
                    simulationPrecisionGroup.add("Medium (0.0001)", 0.0001,
                        simulationPrecisionMenu, this);
                    simulationPrecisionGroup.add("High (0.00001)", 0.00001,
                        simulationPrecisionMenu, this);
                    simulationPrecisionGroup.add("Very High (0.000001)", 0.000001, 
                        simulationPrecisionMenu, this);
                    
                    simulationPrecisionGroup.setSelected("Medium (0.0001)");
                    simulationPrecision = 0.0001;
                    
                    simulationMenu.add(simulationPrecisionMenu);                    
                }
                
                simulationMenu.addSeparator();
                
                // Refresh sub-menu
                {
                    simulationRefreshMenu = new Menu("Refresh Rate");
                    
                    simulationRefreshGroup = new ValueCheckboxMenuGroup();
                    
                    simulationRefreshGroup.add("6fps", 6, 
                        simulationRefreshMenu, this);
                    simulationRefreshGroup.add("12fps", 12, simulationRefreshMenu, this);
                    simulationRefreshGroup.add("18fps", 18, simulationRefreshMenu, this);
                    simulationRefreshGroup.add("24fps", 24, simulationRefreshMenu, this);
                    
                    simulationRefreshGroup.setSelected("18fps");
                    stepGranularity = 18;
                    
                    simulationMenu.add(simulationRefreshMenu);                    
                }

                simulationMenu.addSeparator();
                
                // CacheSize sub-menu
                {
                    simulationCacheSizeMenu = new Menu("Cache Size");
                    
                    simulationCacheSizeGroup = new ValueCheckboxMenuGroup();
                    
                    simulationCacheSizeGroup.add("15secs", 15.0,
                        simulationCacheSizeMenu, this);
                    simulationCacheSizeGroup.add("30secs", 30.0, simulationCacheSizeMenu, this);
                    simulationCacheSizeGroup.add("60secs", 60.0, simulationCacheSizeMenu, this);
                    
                    simulationCacheSizeGroup.setSelected("15secs");
                    simulationCacheSize = 15;
                    
                    simulationMenu.add(simulationCacheSizeMenu);                    
                }
                
                simulationMenu.add(simulationCacheStatsItem = 
                    new MenuItem("Cache Statistics..."));
                simulationCacheStatsItem.addActionListener(this);
                
                simulationMenu.addSeparator();
                simulationMenu.add(simulationSingularityWarningBox = 
                    new CheckboxMenuItem("Warn About Singularities", true)); 
                                                    
                bar.add(simulationMenu);
            }

            // Grid menu
            {
                Menu gridMenu = new Menu("Grid");
                
                gridMenu.add(viewRecenterMap = new MenuItem("Recenter View"));
                viewRecenterMap.addActionListener(this);
                         
                gridMenu.addSeparator();
                
                gridMenu.add(viewUseGridBox = new CheckboxMenuItem("Use Grid", true));
                viewUseGridBox.addItemListener(this);
                
                gridMenu.add(viewLockGridBox = new CheckboxMenuItem("Snap Clicks To Grid", true));
                
                // GridType sub-menu
                {
                    viewGridTypeMenu = new Menu("Grid Type");
                    
                    viewGridTypeGroup = new CheckboxMenuGroup();
                    
                    viewGridTypeGroup.add("Points", viewGridTypeMenu, this);
                    viewGridTypeGroup.add("Lines", viewGridTypeMenu, this);
                    
                    viewGridTypeGroup.setSelected("Lines");
                    
                    gridMenu.add(viewGridTypeMenu);
                }

                

                // GridSize sub-menu
                {
                    viewGridSizeMenu = new Menu("Grid Size");
                    
                    viewGridSizeGroup = new ValueCheckboxMenuGroup();
                    
                    viewGridSizeGroup.add("0.25", 0.25, viewGridSizeMenu, this);
                    viewGridSizeGroup.add("0.5", 0.5, viewGridSizeMenu, this);
                    viewGridSizeGroup.add("1.0", 1.0, viewGridSizeMenu, this);
                    viewGridSizeGroup.add("2.0", 2.0, viewGridSizeMenu, this);
                    viewGridSizeGroup.add("4.0", 4.0, viewGridSizeMenu, this);
                    viewGridSizeGroup.add("8.0", 8.0, viewGridSizeMenu, this);
                    
                    viewGridSizeGroup.setSelected("1.0");
                    gridSize = 1.0;
                    
                    gridMenu.add(viewGridSizeMenu);                    
                }

                gridMenu.addSeparator();
                
                gridMenu.add(viewZoomControlItem = new MenuItem("Zoom Control..."));
                viewZoomControlItem.addActionListener(this);
       
                bar.add(gridMenu);
            }
                    
            // Vectors menu
            {
                Menu vectorsMenu = new Menu("Vectors");

                // Position sub-menu
                {
                    viewPositionMenu = new Menu("Position");
                    
                    viewPositionGroup = new CheckboxMenuGroup();
                    
                    viewPositionGroup.add("Off", viewPositionMenu, this);
                    viewPositionGroup.add("On", viewPositionMenu, this);
                    viewPositionGroup.add("Unit", viewPositionMenu, this);
                    
                    viewPositionGroup.setSelected("Off");
                    
                    vectorsMenu.add(viewPositionMenu);
                }
                
                // Velocity sub-menu
                {
                    viewVelocityMenu = new Menu("Velocity");
                    
                    viewVelocityGroup = new CheckboxMenuGroup();
                    
                    viewVelocityGroup.add("Off", viewVelocityMenu, this);
                    viewVelocityGroup.add("On", viewVelocityMenu, this);
                    viewVelocityGroup.add("Unit", viewVelocityMenu, this);
                    
                    viewVelocityGroup.setSelected("On");
                    
                    vectorsMenu.add(viewVelocityMenu);
                }

                // Acceleration sub-menu
                {
                    viewAccelerationMenu = new Menu("Acceleration");
                    
                    viewAccelerationGroup = new CheckboxMenuGroup();
                    
                    viewAccelerationGroup.add("Off", viewAccelerationMenu, this);
                    viewAccelerationGroup.add("On", viewAccelerationMenu, this);
                    viewAccelerationGroup.add("Unit", viewAccelerationMenu, this);
                    
                    viewAccelerationGroup.setSelected("Off");
                    
                    vectorsMenu.add(viewAccelerationMenu);
                }
                                
                // Force sub-menu
                {
                    viewForceMenu = new Menu("Force");
                    
                    viewForceGroup = new CheckboxMenuGroup();
                    
                    viewForceGroup.add("Off", viewForceMenu, this);
                    viewForceGroup.add("On", viewForceMenu, this);
                    viewForceGroup.add("Unit", viewForceMenu, this);
                    
                    viewForceGroup.setSelected("Off");
                    
                    vectorsMenu.add(viewForceMenu);
                }
                
                
                vectorsMenu.addSeparator();
                
                vectorsMenu.add(viewNoVectorsWhileSimulatingBox = new CheckboxMenuItem(
                    "Hide Vectors While Simulating", true));
                    
                bar.add(vectorsMenu); 
            }
            
            // Trails menu
            {
                Menu trailsMenu = new Menu("Trails");
                
                trailsMenu.add(viewAllTrailsItem = new MenuItem("Enable All Trails"));
                viewAllTrailsItem.addActionListener(this);
                
                trailsMenu.add(viewNoTrailsItem = new MenuItem("Disable All Trails"));
                viewNoTrailsItem.addActionListener(this);
                
                trailsMenu.add(viewClearTrailsItem = new MenuItem("Reset Trails"));
                viewClearTrailsItem.addActionListener(this);

                // TrailSize sub-menu
                {
                    viewTrailSizeMenu = new Menu("Trail Length");
                    
                    viewTrailSizeGroup = new ValueCheckboxMenuGroup();
                    
                    viewTrailSizeGroup.add("1s", 1, viewTrailSizeMenu, this);
                    viewTrailSizeGroup.add("2s", 2, viewTrailSizeMenu, this);
                    viewTrailSizeGroup.add("4s", 4, viewTrailSizeMenu, this);
                    viewTrailSizeGroup.add("8s", 8, viewTrailSizeMenu, this);
                    
                    viewTrailSizeGroup.setSelected("1s");
                    trailSizeInSecs = 1;

                    trailSize = trailSizeInSecs * stepGranularity;
                    trailsMenu.add(viewTrailSizeMenu);                    
                }
            
                bar.add(trailsMenu);
            }
            
            // Labels menu
            {
                Menu labelsMenu = new Menu("Labels");
                
                labelsMenu.add(viewShowLabelsBox = new CheckboxMenuItem("Show Name", false));
                viewShowLabelsBox.addItemListener(this);
                
                labelsMenu.add(viewShowChargeBox = new CheckboxMenuItem("Show Charge", true));
                viewShowChargeBox.addItemListener(this);
                
                labelsMenu.add(viewShowMassBox = new CheckboxMenuItem("Show Mass", false));
                viewShowMassBox.addItemListener(this);

                labelsMenu.add(viewShowPositionBox = new CheckboxMenuItem("Show Position", 
                    false));
                viewShowPositionBox.addItemListener(this);
                
                labelsMenu.add(viewShowVelocityBox = new CheckboxMenuItem("Show Velocity", 
                    false));
                viewShowVelocityBox.addItemListener(this);
                
                labelsMenu.addSeparator();
                
                labelsMenu.add(viewNoInfoWhileSimulatingBox = new CheckboxMenuItem(
                    "Hide Info While Simulating", true));
                                                                
                bar.add(labelsMenu);
            }
            
            // Extras menu.
            {
                extrasMenu = new Menu("Extras");
                
                extrasMenu.add(extrasShowElectricFieldBox = new CheckboxMenuItem(
                    "Show Electric Field", false));
                extrasShowElectricFieldBox.addItemListener(this);
                
                extrasMenu.add(extrasElectricFieldControlItem = new MenuItem(
                    "External Field Control..."));
                extrasElectricFieldControlItem.addActionListener(this);
                
                extrasMenu.addSeparator();
                
                // Viscosity sub-menu.
                {
                    extrasViscosityMenu = new Menu("Viscosity");
                    
                    extrasViscosityGroup = new ValueCheckboxMenuGroup();
                    
                    extrasViscosityGroup.add("None", 0.0, extrasViscosityMenu, this);
                    extrasViscosityGroup.add("Very Low (0.00015625)", 0.00015625, 
                        extrasViscosityMenu, this);
                    extrasViscosityGroup.add("Low (0.000625)", 0.000625, extrasViscosityMenu, 
                        this);
                    extrasViscosityGroup.add("Medium (0.0025)", 0.0025, extrasViscosityMenu, 
                        this);
                    extrasViscosityGroup.add("High (0.01)", 0.01, extrasViscosityMenu, this);
                    extrasViscosityGroup.add("Very High (0.04)", 0.04, extrasViscosityMenu, this);
                    
                    extrasViscosityGroup.setSelected("None");
                    extrasViscosity = 0.0;
                    
                    extrasMenu.add(extrasViscosityMenu);
                }
                
                extrasMenu.add(extrasBoundaryControl = new MenuItem(
                    "Boundary Control..."));
                extrasBoundaryControl.addActionListener(this);
                
                bar.add(extrasMenu);
            }
        }
        
        electricFieldControl = new ElectricFieldControl(playfield);
        zoomControl = new ZoomControl(playfield);
        boundaryControl = new BoundaryControl(playfield);
        energyViewer = new EnergyViewer(playfield);
        cacheViewer = new CacheViewer(playfield);
        lessonControl = new LessonControl(playfield);
        
        // Main popup menu.
        {
            mainPopupMenu = new PopupMenu();
            
            mainPopupMenu.add(mainPopupAddParticleItem = new MenuItem("Add Particle"));
            mainPopupAddParticleItem.addActionListener(this);
            
            mainPopupMenu.addSeparator();
            
            mainPopupMenu.add(mainPopupStartSimulationItem = new MenuItem("Start Simulation"));
            mainPopupStartSimulationItem.addActionListener(this);
            
            mainPopupMenu.add(mainPopupStopSimulationItem = new MenuItem("Stop Simulation"));
            mainPopupStopSimulationItem.addActionListener(this);
            mainPopupStopSimulationItem.setEnabled(false);
            
            // Simulation Speed sub-menu
            {
                mainPopupSimulationSpeedMenu = new Menu("Speed");
                    
                mainPopupSimulationSpeedGroup = new ValueCheckboxMenuGroup();
                    
                mainPopupSimulationSpeedGroup.add("x0.25", 0.25, 
                    mainPopupSimulationSpeedMenu, this);
                mainPopupSimulationSpeedGroup.add("x0.5", 0.5, mainPopupSimulationSpeedMenu, this);
                mainPopupSimulationSpeedGroup.add("x1", 1, mainPopupSimulationSpeedMenu, this);
                mainPopupSimulationSpeedGroup.add("x2", 2, mainPopupSimulationSpeedMenu, this);
                mainPopupSimulationSpeedGroup.add("x4", 4, mainPopupSimulationSpeedMenu, this);
                mainPopupSimulationSpeedGroup.add("x8", 8, mainPopupSimulationSpeedMenu, this);
                
                mainPopupSimulationSpeedGroup.setSelected("x1");
                
                mainPopupMenu.add(mainPopupSimulationSpeedMenu);                    
            }
            
                
            mainPopupMenu.addSeparator();
            
            mainPopupMenu.add(mainPopupSaveStateItem = new MenuItem("Save State To Memory"));
            mainPopupSaveStateItem.addActionListener(this);
            
            mainPopupMenu.add(mainPopupRestoreStateItem = new 
                MenuItem("Restore State From Memory"));
            mainPopupRestoreStateItem.addActionListener(this);
            mainPopupRestoreStateItem.setEnabled(false);

            
                            
            // mainPopupMenu is added to the viewer component when the playfield viewer is
            //      constructed
        }                        
        
        // Particle popup menu.
        {
            particlePopupMenu = new PopupMenu();
            
            // Charge sub-menu
            {
                particlePopupChargeMenu = new Menu("Charge");
                
                particlePopupChargeGroup = new CheckboxMenuGroup();
                
                particlePopupChargeGroup.add("-2", particlePopupChargeMenu, this);
                particlePopupChargeGroup.add("-1", particlePopupChargeMenu, this);
                particlePopupChargeGroup.add("0", particlePopupChargeMenu, this);
                particlePopupChargeGroup.add("+1", particlePopupChargeMenu, this);
                particlePopupChargeGroup.add("+2", particlePopupChargeMenu, this);
                particlePopupChargeGroup.add("Custom", particlePopupChargeMenu, this);
                
                particlePopupChargeGroup.setSelected("0");
                
                particlePopupMenu.add(particlePopupChargeMenu);
            }
        
            // Mass sub-menu
            {
                particlePopupMassMenu = new Menu("Mass");
                
                particlePopupMassGroup = new CheckboxMenuGroup();
                
                particlePopupMassGroup.add("1", particlePopupMassMenu, this);
                particlePopupMassGroup.add("2", particlePopupMassMenu, this);
                particlePopupMassGroup.add("3", particlePopupMassMenu, this);
                particlePopupMassGroup.add("4", particlePopupMassMenu, this);
                particlePopupMassGroup.add("1840", particlePopupMassMenu, this);
                particlePopupMassGroup.add("Custom", particlePopupMassMenu, this);
                
                particlePopupMassGroup.setSelected("1");
                particlePopupMenu.add(particlePopupMassMenu);
            }

            particlePopupMenu.add(particlePopupAnchorBox = 
                    new CheckboxMenuItem("Anchored", false));
            particlePopupAnchorBox.addItemListener(this);

            particlePopupMenu.add(particlePopupTrailBox = 
                    new CheckboxMenuItem("Trail", false));
            particlePopupTrailBox.addItemListener(this);

            particlePopupMenu.addSeparator();
            
            particlePopupMenu.add(particlePopupPropertiesItem =
                    new MenuItem("Properties..."));
            particlePopupPropertiesItem.addActionListener(this);
            
            particlePopupMenu.addSeparator();
            
            particlePopupMenu.add(particlePopupDeleteItem = new MenuItem("Delete"));
            particlePopupDeleteItem.addActionListener(this);
            
            // added when the playfield viewer is constructed
        }
        
        unselectParticle();
    }

    
    public
    void paint(Graphics g)
    {
        super.paint(g);
    }
        
    private
    void boldComponentText(Component c)
    {
        Font f = c.getFont();
        c.setFont(new Font(f.getFamily(), Font.BOLD, f.getSize()));
    }
    
    private
    void unboldComponentText(Component c)
    {
        Font f = c.getFont();
        c.setFont(new Font(f.getFamily(), Font.PLAIN, f.getSize()));
    }
    
    /**
     * Disables all the buttons which should be unavailable when no particle has been selected 
     */    
     
    void unselectParticle()
    {
        if(hasSelectedParticle)
            selectedParticle.setSelected(false);
    
        particlePropertiesItem.setEnabled(false);
        
        particleAnchorBox.setEnabled(false);
        particleAnchorBox.setState(false);

        particleTrailBox.setEnabled(false);
        particleTrailBox.setState(false);

        particleDeleteItem.setEnabled(false);
        
        particleChargeMenu.setEnabled(false);
        particleMassMenu.setEnabled(false);
        
        hasSelectedParticle = false;
    }

    /**
     * Converts a double to its string representation, but removes the trailing .0 if it its
     * actually an integer
     */
     
    static
    String niceStringOfDouble(double d)
    {
        if(d == (double) ((int) d))
            return new Integer((int) d).toString();
        else
            return new Double(d).toString();
    }
    
    void selectFirst()
    {
        if(hasSelectedParticle)
            unselectParticle();
        
        synchronized(playfield)
        {
            if(playfield.particles.size() != 0)
                selectParticle((Particle) playfield.particles.firstElement());
        }
    }
        
    void selectParticle(Particle p)
    {
        if(hasSelectedParticle)
            unselectParticle();
            
        selectedParticle = p;
        hasSelectedParticle = true;
        
        particlePropertiesItem.setEnabled(true);
        
        particleAnchorBox.setEnabled(true);
        particleAnchorBox.setState(selectedParticle.isAnchored);

        particleTrailBox.setEnabled(true);
        particleTrailBox.setState(selectedParticle.hasTrail);

        if(particlePopupAnchorBox.getState() != selectedParticle.isAnchored)
        {
            // It does not indescriminately set it to try to correct a JDK bug
            // which causes it to screw up when you set the state artificially
            
            particlePopupAnchorBox.setState(selectedParticle.isAnchored);
        }
        
        if(particlePopupTrailBox.getState() != selectedParticle.hasTrail)
            particlePopupTrailBox.setState(selectedParticle.hasTrail);
        
        particleDeleteItem.setEnabled(true);
                        
        // Get the charge Menus ready
        {
            particleChargeMenu.setEnabled(true);
        
            if(selectedParticle.charge == -2 ||
                selectedParticle.charge == -1 ||
                selectedParticle.charge == 0)
            {
                String s = new Integer((int) selectedParticle.charge).toString();
                
                particleChargeGroup.setSelected(s);
                particlePopupChargeGroup.setSelected(s);
            }
            else if(selectedParticle.charge == 1 ||
                selectedParticle.charge == 2)
            {
                String s = "+" + new Integer((int) selectedParticle.charge).toString();
                
                particleChargeGroup.setSelected(s);
                particlePopupChargeGroup.setSelected(s);
            }
            else 
            {
                particleChargeGroup.setSelected("Custom");
                particlePopupChargeGroup.setSelected("Custom");
            }
        }
        
        // Get the mass Menus ready
        {
            particleMassMenu.setEnabled(true);
        
            if(selectedParticle.mass == 1 ||
                selectedParticle.mass == 2 ||
                selectedParticle.mass == 3 ||
                selectedParticle.mass == 4 ||
                selectedParticle.mass == 1840)
            {
                String s = new Integer((int) selectedParticle.mass).toString();
                
                particleMassGroup.setSelected(s);
                particlePopupMassGroup.setSelected(s);
            }
            else
            {
                particleMassGroup.setSelected("Custom");
                particlePopupMassGroup.setSelected("Custom");
            }
        }
        
        p.setSelected(true);
    }
    
    public void notifyOfDeletion(Particle particle)
    {
        if(hasSelectedParticle && selectedParticle == particle)
            unselectParticle();
    }

    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource() == systemLessonItem)
        {
            lessonControl.toFront();
            lessonControl.setVisible(true);
        }
        else if(e.getSource() == systemClearStateItem)
        {
            playfield.stopSimulatingIfNecessary();
            playfield.removeAllParticles();
            playfield.restartSimulatingIfNecessary();
            playfield.refreshViewers();
        } 
        else if(e.getSource() == particlePropertiesItem || 
            e.getSource() == particlePopupPropertiesItem)
        {
            if(!selectedParticle.hasViewer)
                new ParticleViewer(playfield, selectedParticle);
            else if(selectedParticle.hasViewer)
                selectedParticle.viewer.toFront();
            
            playfield.refreshViewers();
        }
        
        if(e.getSource() == simulationCacheStatsItem)
        {
            cacheViewer.setVisible(true);
            cacheViewer.toFront();
        }
        else if(e.getSource() == systemEnergyItem)
        {
            playfield.stopSimulatingIfNecessary();
            
            energyViewer.setVisible(true);
            energyViewer.toFront();
            
            playfield.updateForces();
            playfield.refreshViewers();
            playfield.restartSimulatingIfNecessary();
        }
        else if(e.getSource() == viewZoomControlItem)
        {
            zoomControl.setVisible(true);
            zoomControl.toFront();
        }
        else if(e.getSource() == extrasElectricFieldControlItem)
        {
            electricFieldControl.setVisible(true);
            electricFieldControl.toFront();
        }
        else if(e.getSource() == extrasBoundaryControl)
        {
            boundaryControl.setVisible(true);
            boundaryControl.toFront();
        }
        else if(e.getSource() == simulationStartItem || 
            e.getSource() == mainPopupStartSimulationItem)
        {
            handleStartSimulationClick();
            playfield.refreshViewers();
        }
        else if(e.getSource() == viewRecenterMap)
        {
            displacementX = 0;
            displacementY = 0;
            playfield.refreshViewers();
        }       
        else if(e.getSource() == viewAllTrailsItem)
        {
            playfield.setAllTrails(true);
            playfield.refreshViewers();
        }
        else if(e.getSource() == viewNoTrailsItem)
        {
            playfield.setAllTrails(false);
            playfield.refreshViewers();
        }
        else if(e.getSource() == viewClearTrailsItem)
        {
            playfield.clearTrails();
            playfield.refreshViewers();
        }
        else if(e.getSource() == simulationStopItem || 
            e.getSource() == mainPopupStopSimulationItem)
        {
            handleStopSimulationClick();
            playfield.refreshViewers();
        }
        else if(e.getSource() == particleAddItem || e.getSource() == mainPopupAddParticleItem)
        {
            Particle p = playfield.addParticle();
            
            selectParticle(p);
            roleOfNextClick = PLACE_PARTICLE;
            playfield.refreshViewers();
        }
        else if(e.getSource() == systemSaveStateItem || e.getSource() == mainPopupSaveStateItem)
        {
            hasSavedPlayfield = true;

            memoryStateStream = new ByteArrayOutputStream();
            
            playfield.saveStateToStream(new OutputStreamWriter(memoryStateStream));
               
            systemRestoreStateItem.setEnabled(true);
            mainPopupRestoreStateItem.setEnabled(true);
        }
        else if(e.getSource() == systemSaveStateToFileItem)
        {
            FileDialog dialog = new FileDialog(parentDust, 
                "Save state as?", FileDialog.SAVE);
            
            dialog.setDirectory("StateFiles");
            dialog.show();
            
            String file = dialog.getFile();
            
            if(file != null)
            {
                try {
                    FileOutputStream out = new FileOutputStream(dialog.getDirectory() + file);
             
                    if(dialog.getDirectory().endsWith("Lessons" + File.separator))
                    {
                        playfield.saveStateToStream(new OutputStreamWriter(out), true);
                    }
                    else 
                        playfield.saveStateToStream(new OutputStreamWriter(out));

                    out.close();
                } catch(IOException exc)
                {
                    new OkayDialog(parentDust, "Error", "Could not open output file '" + file + 
                        "'.", "Okay");
                }
                
            }
        }
        else if(e.getSource() == systemRestoreStateFromFileItem)
        {
            FileDialog dialog = new FileDialog(parentDust, 
                "Restore state from?", FileDialog.LOAD);
            
            dialog.setDirectory("StateFiles");
            dialog.show();
            
            String fileName = dialog.getFile();
            
            if(fileName != null)
            {
                try { 
                    FileReader in = new FileReader(dialog.getDirectory() + fileName);
                    
                    unselectParticle();
                    playfield.restoreStateFromStream(in);
                    playfield.refreshViewers();
                
                } catch(IOException exc)
                {
                    new OkayDialog(parentDust, "Error", "Could not open input file '" + fileName + 
                        "'.", "Okay");       
                }
        
            }
        }
        else if(e.getSource() == systemRestoreStateItem || 
            e.getSource() == mainPopupRestoreStateItem)
        {
            unselectParticle();
            playfield.restoreStateFromStream(new InputStreamReader(new 
                ByteArrayInputStream(memoryStateStream.toByteArray())));
            playfield.refreshViewers();
        }
        else if(e.getSource() == particleDeleteItem || e.getSource() == particlePopupDeleteItem)
        {
            Particle toDelete = selectedParticle;
            
            notifyOfDeletion(toDelete);
            playfield.deleteParticle(toDelete);
            playfield.refreshViewers();
            
        }
    }

    public void itemStateChanged(ItemEvent e)
    {
        if(e.getSource() == viewUseGridBox || e.getSource() == viewShowLabelsBox ||
            viewGridTypeGroup.contains(e.getSource()) || e.getSource() == viewShowChargeBox ||
                e.getSource() == viewShowMassBox || e.getSource() == viewShowPositionBox ||
                e.getSource() == viewShowVelocityBox)
            playfield.refreshViewers();
        else if(e.getSource() == extrasShowElectricFieldBox)
            playfield.refreshViewers();
        else if(viewPositionGroup.contains(e.getSource()) ||
            viewVelocityGroup.contains(e.getSource()) ||
            viewAccelerationGroup.contains(e.getSource()) ||
            viewForceGroup.contains(e.getSource()))
        {
            playfield.refreshViewers();
        }
        else if(simulationSpeedGroup.contains(e.getSource()))
        {
            String label = ((MenuItem) e.getSource()).getLabel();
            
            playfield.stopSimulatingIfNecessary();
            playfield.controls.simulationSpeed = simulationSpeedGroup.valueOfItem(label);
            playfield.controls.mainPopupSimulationSpeedGroup.setSelected(label);
            playfield.restartSimulatingIfNecessary();
        }
        else if(mainPopupSimulationSpeedGroup.contains(e.getSource()))
        {
            String label = ((MenuItem) e.getSource()).getLabel();
            
            playfield.stopSimulatingIfNecessary();
            playfield.controls.simulationSpeed = mainPopupSimulationSpeedGroup.valueOfItem(label);
            playfield.controls.simulationSpeedGroup.setSelected(label);
            playfield.restartSimulatingIfNecessary();
        }
        else if(viewGridSizeGroup.contains(e.getSource()))
        {
            String label = ((MenuItem) e.getSource()).getLabel();
            
            playfield.stopSimulatingIfNecessary();

            playfield.controls.gridSize = viewGridSizeGroup.valueOfItem(label);
            
            playfield.restartSimulatingIfNecessary();
            playfield.refreshViewers();
        }
        else if(viewTrailSizeGroup.contains(e.getSource()))
        {
            String label = ((MenuItem) e.getSource()).getLabel();
            
            playfield.stopSimulatingIfNecessary();
            
            playfield.controls.trailSizeInSecs = (int) viewTrailSizeGroup.valueOfItem(label);
            
            playfield.controls.trailSize = playfield.controls.trailSizeInSecs * stepGranularity;
            playfield.resizeTrails();
            playfield.restartSimulatingIfNecessary();
            playfield.refreshViewers();
        }
        else if(simulationRefreshGroup.contains(e.getSource()))
        {
            String label = ((MenuItem) e.getSource()).getLabel();
            
            playfield.stopSimulatingIfNecessary();
            
            playfield.controls.stepGranularity = (int) simulationRefreshGroup.valueOfItem(label);
            playfield.controls.trailSize = playfield.controls.trailSizeInSecs * stepGranularity;

            playfield.restartSimulatingIfNecessary();
        }
        else if(simulationCacheSizeGroup.contains(e.getSource()))
        {
            String label = ((MenuItem) e.getSource()).getLabel();
            
            playfield.stopSimulatingIfNecessary();
            playfield.controls.simulationCacheSize = (int) 
                simulationCacheSizeGroup.valueOfItem(label);
            playfield.restartSimulatingIfNecessary();
        }
        else if(extrasViscosityGroup.contains(e.getSource()))
        {
            String label = ((MenuItem) e.getSource()).getLabel();
            
            playfield.stopSimulatingIfNecessary();
            
            extrasViscosity = extrasViscosityGroup.valueOfItem(label);
                
            playfield.refreshViewers();
            playfield.updateForces();

            playfield.restartSimulatingIfNecessary();
        }
        else if(simulationPrecisionGroup.contains(e.getSource()))
        {
            String label = ((MenuItem) e.getSource()).getLabel();
            
            playfield.stopSimulatingIfNecessary();
            simulationPrecision = simulationPrecisionGroup.valueOfItem(label);                
            playfield.restartSimulatingIfNecessary();
        }
        else if(particleChargeGroup.contains(e.getSource()) ||
            particlePopupChargeGroup.contains(e.getSource()))
        {
            String label = ((MenuItem) e.getSource()).getLabel();
                        
            if(particleChargeGroup.contains(e.getSource()))
                particlePopupChargeGroup.setSelected(label);
            else
                particleChargeGroup.setSelected(label);
            
            if(label.equals("Custom"))
            {
                if(selectedParticle.hasViewer)
                    selectedParticle.viewer.toFront();
                else
                {
                    new ParticleViewer(playfield, selectedParticle);
                }
            
                selectedParticle.viewer.chargeText.requestFocus();
            }
            else
                selectedParticle.setCharge(new Double(label).doubleValue());
                
            playfield.refreshViewers();
        }
        else if(particleMassGroup.contains(e.getSource()) ||
            particlePopupMassGroup.contains(e.getSource()))
        {
            String label = ((MenuItem) e.getSource()).getLabel();
            
            if(particleMassGroup.contains(e.getSource()))
                particlePopupMassGroup.setSelected(label);
            else
                particleMassGroup.setSelected(label);
                
            if(label.equals("Custom"))
            {
                if(selectedParticle.hasViewer)
                    selectedParticle.viewer.toFront();
                else
                    new ParticleViewer(playfield, selectedParticle);
                
                selectedParticle.viewer.massText.requestFocus();
            }
            else
                selectedParticle.setMass(new Double(label).doubleValue());
                
            playfield.refreshViewers();
        }
        else if(e.getSource() == particleAnchorBox || e.getSource() == particlePopupAnchorBox)
        {
            if(e.getSource() == particleAnchorBox)
                particlePopupAnchorBox.setState(particleAnchorBox.getState());
            else {
                // System.out.println("Popup state: " + particlePopupAnchorBox.getState());
                particleAnchorBox.setState(particlePopupAnchorBox.getState());
            }    

            // System.out.println("main state: " + particleAnchorBox.getState());
            selectedParticle.setAnchored(particleAnchorBox.getState());
            

            if(selectedParticle.isAnchored)
            {
                selectedParticle.setVelocity(0, 0);

                if(selectedParticle.hasViewer)
                {
                    selectedParticle.viewer.velocityXText.setEnabled(false);
                    selectedParticle.viewer.velocityYText.setEnabled(false);
                }
            }
            else {
                if(selectedParticle.hasViewer)
                {
                    selectedParticle.viewer.velocityXText.setEnabled(true);
                    selectedParticle.viewer.velocityYText.setEnabled(true);
                }
            }
            
            playfield.refreshViewers();
        }
        else if(e.getSource() == particleTrailBox || e.getSource() == particlePopupTrailBox)
        {
            if(e.getSource() == particleTrailBox)
                particlePopupTrailBox.setState(particleTrailBox.getState());
            else
                particleTrailBox.setState(particlePopupTrailBox.getState()); 

            selectedParticle.setTrail(particleTrailBox.getState());
            
            playfield.refreshViewers();
        }
    }

    
    void handleStartSimulationClick()
    {
        playfield.startSimulating();
        simulationStartItem.setEnabled(false);
        simulationStopItem.setEnabled(true);
            
        mainPopupStartSimulationItem.setEnabled(false);
        mainPopupStopSimulationItem.setEnabled(true);
        
        lessonControl.simButton.setLabel("Stop Simulation");    
    }
    
    void handleStopSimulationClick()
    {
        playfield.stopSimulating();
            
        simulationStartItem.setEnabled(true);
        simulationStopItem.setEnabled(false);
            
        mainPopupStartSimulationItem.setEnabled(true);
        mainPopupStopSimulationItem.setEnabled(false);
        
        lessonControl.simButton.setLabel("Start Simulation");    
    }

    public void mouseClicked(MouseEvent e)
    {
    }
    
    public void mouseEntered(MouseEvent e)
    {
    }
    
    public void mouseExited(MouseEvent e)
    {
    }
    
    public void mousePressed(MouseEvent e)
    {
        if(e.isPopupTrigger())
        {
            if(isClickOnParticle(e.getX(), e.getY()))
                particlePopupMenu.show(playfield.viewer, e.getX(), e.getY());
            else
                mainPopupMenu.show(playfield.viewer, e.getX(), e.getY());
        }
        
        if(e.isShiftDown() && hasSelectedParticle)
        {
            int oldRole = roleOfNextClick;
            
            roleOfNextClick = CHANGE_VELOCITY;
            handleViewerClickAt(e.getX(), e.getY());
            
            roleOfNextClick = oldRole;
            isChangingVelocity = true;
        }
        else { 
            handleViewerClickAt(e.getX(), e.getY());
        }
        
        lastClickX = e.getX();
        lastClickY = e.getY();    
        
        preDragTicks = 0;
    }
    
    public void mouseReleased(MouseEvent e)
    {
        if(isChangingVelocity)
            isChangingVelocity = false;
           
        if(isDraggingWorld)
        {
            worldDragX = 0;
            worldDragY = 0;
            
            isDraggingWorld = false;
        }
        
        preDragTicks = 0;
    }
    
    public void mouseDragged(MouseEvent e)
    {
        if(hasSelectedParticle)
        {
            if(e.isShiftDown())
            {
                int oldRole = roleOfNextClick;
                    
                roleOfNextClick = CHANGE_VELOCITY;
                handleViewerClickAt(e.getX(), e.getY());
                
                roleOfNextClick = oldRole;
            }
            else if(!isChangingVelocity)
            {
                // if the first click is with a shift, then until the mouse button is released
                // will not allow any drags for undesirable effects
                
                preDragTicks++;
                
                if(preDragTicks > 3)
                {
                    int oldRole = roleOfNextClick;
                    
                    roleOfNextClick = CHANGE_POSITION;
                    handleViewerClickAt(e.getX(), e.getY());
                    
                    roleOfNextClick = oldRole;
                }
            }
        }
        else
        {
            if(!isDraggingWorld)
            {
                preDragTicks++;
                
                if(preDragTicks > 5)
                    isDraggingWorld = true;
            }
            
            if(isDraggingWorld)
            {
                int screenDeltaX = e.getX() - lastClickX, 
                    screenDeltaY = e.getY() - lastClickY;
            
                displacementX -= worldDragX;
                displacementY -= worldDragY;
                
                worldDragX = -playfield.viewer.worldDistanceOfScreenDistance(screenDeltaX);
                worldDragY = playfield.viewer.worldDistanceOfScreenDistance(screenDeltaY);
                
                displacementX += worldDragX;
                displacementY += worldDragY;
                
                playfield.refreshViewers();
            }
        }
    }
    
    public void mouseMoved(MouseEvent e)
    {
        if(roleOfNextClick == PLACE_PARTICLE)
        {
            roleOfNextClick = CHANGE_POSITION;
            handleViewerClickAt(e.getX(), e.getY());
            roleOfNextClick = PLACE_PARTICLE;
        }
    }
    
    boolean isClickOnParticle(int x, int y)
    {
        DoublePair pair = playfield.viewer.worldCoordsOfScreen(x, y);
        double worldX = pair.x,
               worldY = pair.y;
        
        if(!playfield.containsParticles())
            return false;
                    
        Particle p = playfield.nearestParticleTo(worldX, worldY);
                
        boolean nearParticle = 
            playfield.viewer.screenDistanceOfWorldDistance(p.distanceTo(worldX, worldY)) < 
            MAX_SCREEN_DISTANCE_TO_CLICK;
        
        return nearParticle;    
    }
    
    public void handleViewerClickAt(int x, int y)
    {
        DoublePair pair = playfield.viewer.worldCoordsOfScreen(x, y);
        double worldX = pair.x,
               worldY = pair.y;
               
        if(!hasSelectedParticle)
            roleOfNextClick = SELECTION;
            
        // adjust click if the grid is on
        {
            if((roleOfNextClick == CHANGE_POSITION || roleOfNextClick == CHANGE_VELOCITY ||
                roleOfNextClick == PLACE_PARTICLE) &&
                viewUseGridBox.getState() && viewLockGridBox.getState())
            {
                worldX = Math.round(worldX / gridSize) * gridSize;
                worldY = Math.round(worldY / gridSize) * gridSize;
            }
        }
        
        switch(roleOfNextClick)
        {
            case PLACE_PARTICLE:
            {    
                roleOfNextClick = SELECTION;
                break;
            }
            
            case SELECTION:
            {
                if(!playfield.containsParticles())
                    return;
                    
                Particle p = playfield.nearestParticleTo(worldX, worldY);
                
                if(playfield.viewer.screenDistanceOfWorldDistance(p.distanceTo(worldX, worldY)) < 
                    MAX_SCREEN_DISTANCE_TO_CLICK)
                {
                    selectParticle(p);
                    playfield.refreshViewers();
                }
                else {
                    unselectParticle();
                    playfield.refreshViewers();
                }
                break;
            }
                           
            case CHANGE_VELOCITY:
            {
                selectedParticle.setVelocity((worldX - selectedParticle.posX),
                    (worldY - selectedParticle.posY));
                playfield.refreshViewers();
                roleOfNextClick = SELECTION;
                break;
            }
                
            case CHANGE_POSITION:
            {
                selectedParticle.moveTo(worldX, worldY);
                playfield.refreshViewers();
                roleOfNextClick = SELECTION;   
                break;
            }    
            default:
                Debug.trap();
                break;
        }
        
    }    
    
    void handleClickToClose()
    {
        playfield.stopSimulatingIfNecessary();
        parentDust.stop();
    }
    
    public void windowClosing(WindowEvent e)
    {
        if(e.getSource() == parentDust)
            handleClickToClose();
    }
     
    public void windowOpened(WindowEvent e)
    {
    }
     
    public void windowIconified(WindowEvent e)
    {
    }
     
    public void windowDeiconified(WindowEvent e)
    {
    }
     
    public void windowClosed(WindowEvent e)
    {
    }
     
    public void windowActivated(WindowEvent e)
    {
    }
     
    public void windowDeactivated(WindowEvent e) 
    {
    }
}









