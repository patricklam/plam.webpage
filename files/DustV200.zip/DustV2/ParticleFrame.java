// ParticleFrame.java
//
// Author: Raja Vallee-Rai
//
// This file is public domain.  You can do anything you want with 
// it, all at your own risk.  Enjoy!

/**
 * The ParticleFrame contains all the state information which changes when the simulation
 * is being performed.
 */

class ParticleFrame
{
    double posX, posY;
    double velX, velY;
    double accX, accY;
    double forceX, forceY;

    public ParticleFrame(Particle p)
    {
        posX = p.workPosX;
        posY = p.workPosY;
        
        velX = p.workVelX;
        velY = p.workVelY;
        
        accX = p.workAccX;
        accY = p.workAccY;
        
        forceX = p.workForceX;
        forceY = p.workForceY;
    }
}