(* Initial syntax trees obtained from parser *)

let spec_ast : Speclanguage.Nodes.node ref = 
  ref Speclanguage.Nodes.Null_Node
let abst_ast : Abstlanguage.Nodes.node ref = 
  ref Abstlanguage.Nodes.Null_Node
let impl_ast : Formatlanguage.Nodes.node ref =
  ref Formatlanguage.Nodes.Null_Node
let impl_to_fn : (Formatlanguage.Nodes.node, string) Hashtbl.t = 
  Hashtbl.create 0

let unsome = function (Some x) -> x | None -> failwith "tried to deoptionify None"

open Speclanguage
open Nodes

let fetch_spec_ast n = 
  let l = Util.phase ("Lexing file "^n) 
      Speclanguage.Lexer.create n (open_in n) in
  let p = Speclanguage.Parser.create l in
  Util.phase "Parsing" Speclanguage.Parser.parse p

let parse_spec_asts source_names =
  let name2frag = Hashtbl.create 1 in
  let frags_so_far = ref [] in
  let parse n = 
    Util.phase ("module " ^ n)
      (Hashtbl.add name2frag n 
        (let ast_fragment = fetch_spec_ast n in
        (match ast_fragment with 
          Start (PFile (ASpecFile af), _) ->
            frags_so_far := (List.map (fun x -> P 
                (PSpecModule x)) 
                               af.spec_file_spec_module) @ 
              !frags_so_far
        | _ -> failwith "bad AST");
        ast_fragment))
  in begin
    List.iter parse source_names;
    (name2frag, P (PFile (ASpecFile (Nodes.a_spec_file !frags_so_far))))
  end

let d x = Tokens.getText (unsome x)

let fetch_spec_module m =
  let f = match !spec_ast with
    P (PFile (ASpecFile n)) -> n.spec_file_spec_module
  | _ -> failwith "bad AST" in
  List.find (fun m0 ->
    match m0 with
    | AModSpecModule m' -> m = d m'.mod_spec_module_identifier
    | AInstSpecModule m' -> m = (d m'.inst_spec_module_n)) f

let fetch_spec_module_names m =
  let f = match !spec_ast with
    P (PFile (ASpecFile n)) -> n.spec_file_spec_module
  | _ -> failwith "bad AST" in
  List.map (fun m0 ->
    match m0 with 
    | AModSpecModule m' -> d m'.mod_spec_module_identifier
    | AInstSpecModule m' -> d m'.inst_spec_module_n) f

open Abstlanguage
open Nodes

(* Note that this is different from the other d. *)
let d x = Tokens.getText (unsome x)

let fetch_abst_ast n = 
  let l = Util.phase ("Lexing file "^n) 
      Abstlanguage.Lexer.create n (open_in n) in
  let p = Abstlanguage.Parser.create l in
  Util.phase "Parsing" Abstlanguage.Parser.parse p

let parse_abst_asts source_names =
  let name2frag = Hashtbl.create 1 in
  let frags_so_far = ref [] in
  List.iter (function n -> 
    Util.phase ("module " ^ n)
      (Hashtbl.add name2frag n 
         (let ast_fragment = fetch_abst_ast n in
         (match ast_fragment with 
           Start (PFile (AFile af), _) ->
             frags_so_far := (List.map (fun x -> P (PAbstModule x)) 
                                af.file_abst_module) @ 
          !frags_so_far
         | _ -> failwith "bad AST");
         ast_fragment))) 
            source_names;
  (name2frag, P (PFile (AFile (Nodes.a_file !frags_so_far))))

let fetch_abst_module m =
  let f = match !abst_ast with
    P (PFile (AFile n)) -> n.file_abst_module
  | _ -> failwith "bad AST" in
  List.find (fun m0 -> match m0 with
  | AAbstModule m' -> m = (d m'.abst_module_abst_module_name)
  | AInstAbstModule m' -> m = (d m'.inst_abst_module_n)) f

let fetch_abst_module_names m =
  let f = match !abst_ast with
    P (PFile (AFile n)) -> n.file_abst_module
  | _ -> failwith "bad AST" in
  List.map (fun m0 -> match m0 with
  | AAbstModule m' -> d m'.abst_module_abst_module_name
  | AInstAbstModule m' -> d m'.inst_abst_module_n) f

open Formatlanguage
open Nodes

let d x = Tokens.getText (unsome x)


(* I can't figure out how to make CST -> AST transformations in SableCC
   generate AFieldAccessExpr instead of AQualifiedNameExpr, 
   so transform here. *)
let rec convert_qualified_to_field_expr x =
  (AFieldAccessExpr (Nodes.a_field_access_expr 
                       (match unsome x.qualified_name_expr_m with
                       | ASimpleNameExpr m -> 
                           (P (PExpr (ASimpleNameExpr m)))
                       | AFieldAccessExpr m ->
                           (P (PExpr (AFieldAccessExpr m)))
                       | AQualifiedNameExpr m -> 
                           (P (PExpr (convert_qualified_to_field_expr m)))
                       | _ -> failwith "badly formed qualified name expr")
                       (T (unsome x.qualified_name_expr_n)))) 

let rec qualified_to_field_transformer = {
  Analysis.override = (fun parent n -> n);
     Analysis.enter = (fun parent n -> match (parent, n) with
     | (P (PExpr (AInvokeExpr i)), P (PExpr e)) 
       when i.invoke_expr_expr = (Some e) -> 
         Analysis.dummy_visitor
     | _ -> qualified_to_field_transformer);
     Analysis.leave = (fun parent old_child child v -> 
       match child with
     | P (PExpr (AQualifiedNameExpr m)) -> 
         P (PExpr (convert_qualified_to_field_expr m))
     | _ -> child);
     Analysis.start = (fun () -> qualified_to_field_transformer);
    Analysis.finish = (fun n -> ());
}

let fetch_impl_ast n = 
  let l = Util.phase ("Lexing file "^n) Lexer.create n (open_in n) in
  let p = Parser.create l in
  let pt = Util.phase "Parsing" Parser.parse p in
  (Analysis.visit_edge qualified_to_field_transformer
     Nodes.Null_Node pt)

let parse_impl_asts source_names =
  (* Engage in some wizardry to put all ASTs together. *)
  let frags_so_far = ref [] in
  List.iter (function n -> 
    Util.phase ("module " ^ n)
      ignore (let ast_fragment0 = fetch_impl_ast n in
      let ast_fragment = Analysis.visit_edge 
          qualified_to_field_transformer
          Nodes.Null_Node ast_fragment0 in
      (match ast_fragment with 
        Start (PFile (AFile af), _) ->
          frags_so_far := (List.map (fun x -> 
            let x' = P (PImplModule x) in
            Hashtbl.add impl_to_fn x' n;
            x') af.file_impl_module) @ !frags_so_far
      | _ -> failwith "bad AST");
      ast_fragment))
    source_names;
  P (PFile (AFile (Nodes.a_file !frags_so_far)))

let fetch_impl_module m =
  let f = match !impl_ast with
    P (PFile (AFile n)) -> n.file_impl_module
  | _ -> failwith "bad AST" in
  List.find (fun m0 ->
    match m0 with
    | AModuleImplModule m' -> 
        m = d m'.module_impl_module_identifier 
    | AInstImplModule m' ->
        m = d m'.inst_impl_module_n) f

let fetch_impl_module_names m =
  let f = match !impl_ast with
    P (PFile (AFile n)) -> n.file_impl_module
  | _ -> failwith "bad AST" in
  List.map (fun m0 ->
    match m0 with
    | AModuleImplModule m' -> d m'.module_impl_module_identifier
    | AInstImplModule m' -> d m'.inst_impl_module_n) f
