// Math2DVector.java
//
// Author: Raja Vallee-Rai
//
// This file is public domain.  You can do anything you want with 
// it, all at your own risk.  Enjoy!


package kor.base;

/**
 * A math2DVector is a pair of doubles for which are defined useful vector like operations.
 */

public 
class Math2DVector
{
    public
    double x, y;
    
    public Math2DVector(double x, double y)
    {
        this.x = x;
        this.y = y;
    }

    /**
     * Returns the normalized form of the vector (1.0 magnitude), or 0 if the 
     * vector is 0.
     */    

    public Math2DVector normalize()
    {
        double magnitude;
        
        magnitude = Math.sqrt(x*x + y*y);
        
        if(magnitude != 0.0)
            return new Math2DVector(x / magnitude, y / magnitude);
        else
            return new Math2DVector(0, 0);
    }

    /**
     * Adds to <b>this</b> a vector
     */
     
    
    public void addOn(Math2DVector other)
    {
        x += other.x;
        y += other.y;
    }
    
    /**
     * Adds to <b>this</b> a vector given explicitly.
     */
     
    public void addOn(double otherX, double otherY)
    {
        x += otherX;
        y += otherY;
    }
    
    /**
     * Substracts from <b>this</b> a vector.
     */
     
    public void substractOff(Math2DVector other)
    {
        x -= other.x;
        y -= other.y;
    }
    
    /**
     * Substracts from <b>this</b> a vector, given explicitly.
     */
     
    public void substractOff(double otherX, double otherY)
    {
        x -= otherX;
        y -= otherY;
    }
    
    /**
     * Multiplies <b>this</b> by a scalar
     */
     
    public void multiplyBy(double scalar)
    {
        x *= scalar;
        y *= scalar;
    }

    /**
     * Produces an object copy of this vector
     */
     
    public Math2DVector copy()
    {
        return new Math2DVector(x, y);
    }
  
    /**
     * Returns the scalar multiplication of <b>this</b> with a vector
     */
      
    public Math2DVector factorOf(double scalar)
    {
        return new Math2DVector(x * scalar, y * scalar);
    }
    
    /**
     * Returns the sum of <b>this</b> with a vector.
     */
     
    public Math2DVector sumOf(Math2DVector other)
    {
        return new Math2DVector(x + other.x, y + other.y);
    }
    
    /**
     * Returns the difference of <b>this</b> with a vector
     */
     
    public Math2DVector diffOf(Math2DVector other)
    {
        return new Math2DVector(x - other.x, y - other.y);
    }
    
    /**
     * Returns the sum of <b>this</b> with a vector, given explicitly.
     */
     
    public Math2DVector sumOf(double otherX, double otherY)
    {
        return new Math2DVector(x + otherX, y + otherY);
    }
    
    /**
     * Returns the difference of <b>this</b> with a vector, given explicitly.
     */
     
    public Math2DVector diffOf(double otherX, double otherY)
    {
        return new Math2DVector(x - otherX, y - otherY);
    }
    
    /**
     * Sets the value of <b>this</b> vector to that of another vector.
     */
     
    public void setTo(Math2DVector other)
    {
        x = other.x;
        y = other.y;
    }
    
    /**
     * Sets the value of <b>this</b> vector to another vector, given explicitly.
     */
     
    public void setTo(double otherX, double otherY)
    {
        x = otherX;
        y = otherY;
    }
    
    /**
     * Rotates <b>this</b> vector by an angle theta.
     */
     
    public void rotateBy(double theta)
    {
        double sinOfTheta, cosOfTheta;
        
        sinOfTheta = Math.sin(theta);
        cosOfTheta = Math.cos(theta);
        
        this.setTo(this.x * cosOfTheta - this.y * sinOfTheta,
            this.x * sinOfTheta + this.y * cosOfTheta);
    }
}
