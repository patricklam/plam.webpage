Suneet Saldanha
20301660 - s2saldan
These test cases were written completely on my own.

There are 6 ADL files. Each ADL file has its own input files and 
corresponding output files

s2saldan_1.adl - tests sort & filter functionality of all 3 data types
s2saldan_2.adl - tests *order functionality for all 3 data types
s2saldan_3.adl - tests map functionality for all 3 data types
s2saldan_4.adl - tests reduce functionality for all 3 data types
s2saldan_5.adl - tests truncate functionality for all 3 data types
s2saldan_6.adl - contains a bunch of complex combinations of functions on
                 different data types