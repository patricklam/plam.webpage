(* uses all spec modules (to get callees), scope information *)
let expand_modifies_clauses all_sb (ms:Sabsyn.spec_module) = 
  let all_unmodified_sets p = 
    List.filter (fun x -> not (List.mem x p.Sabsyn.modifies)) all_sb.Spec.s in
  let all_unmodified_bools p = 
    List.filter (fun x -> not (List.mem x p.Sabsyn.modifies)) all_sb.Spec.b in
  let expand_proc p = 
    let fram = 
      List.map (fun x -> Sabsyn.Atom 
        (Sabsyn.Eq (Sabsyn.Prevar x, Sabsyn.Postvar x))) 
        (all_unmodified_sets p) @
      List.map (fun x -> Sabsyn.Iff (Sabsyn.Atom (Sabsyn.Propvar x), 
                                     Sabsyn.Atom (Sabsyn.Propvarpost x)))
        (all_unmodified_bools p) in
    {
     Sabsyn.proc_name  = p.Sabsyn.proc_name;
     Sabsyn.formals    = p.Sabsyn.formals;
     Sabsyn.ret_val    = p.Sabsyn.ret_val;
     Sabsyn.requires   = p.Sabsyn.requires;
     Sabsyn.modifies   = [];
     Sabsyn.frame_cond = Sabsyn.And fram;
     Sabsyn.calls      = p.Sabsyn.calls;
     Sabsyn.ensures    = Sabsyn.And (List.concat [[p.Sabsyn.ensures]; fram]);
   } in {
  Sabsyn.module_name = ms.Sabsyn.module_name;
  Sabsyn.instantiated_from = ms.Sabsyn.instantiated_from;
  Sabsyn.param_subst = ms.Sabsyn.param_subst;
  Sabsyn.properties  = ms.Sabsyn.properties;
  Sabsyn.formats     = ms.Sabsyn.formats;
  Sabsyn.sets        = ms.Sabsyn.sets;
  Sabsyn.procs       = List.map expand_proc ms.Sabsyn.procs;
  Sabsyn.pred_vars   = ms.Sabsyn.pred_vars;
  }

open Sabsyn
open Types

let instantiate_templates ast = 
  let actuals = List.map snd ast.param_subst in
  let a_no_dups = Util.remove_dups actuals in
  if a_no_dups <> actuals then Util.err "[module instantiation]" ("Duplicated type parameter in spec module "^ast.module_name);
  match ast.instantiated_from with
  | None -> ast
  | Some parent ->
      let pmod = Ast.fetch_spec parent in
      let sl = ast.param_subst in
      let subst_type_fmts t1 = 
        if List.mem_assoc t1 sl then
          List.assoc t1 sl else t1 in
      let subst_pair_fmts (x, y) = (x, subst_type_fmts y) in
      let rec subst_type t = 
        match t with
        | TArray t1 -> TArray (subst_type t1)
        | TObj t1 -> 
            if List.mem_assoc t1 sl then
              TObj (List.assoc t1 sl) else (TObj t1)
        | _ -> t in
      let subst_pair (x, y) = (x, subst_type y) in
      let subst_var v = 
        try let d = String.index v '.' + 1 in
        (ast.module_name ^ "." ^ (Str.string_after v d))
        with Not_found -> v in
      let rec subst_setexp (se:setExp) =
        match se with
        | Prevar id -> Prevar (subst_var id)
        | Postvar id -> Postvar (subst_var id)
        | Emptyset -> se
        | Union us -> Union (List.map subst_setexp us)
        | Inter is -> Inter (List.map subst_setexp is)
        | Diff (d1, d2) -> Diff (subst_setexp d1, subst_setexp d2) in
      let rec subst_atom_form (af:atomForm) : atomForm =
        match af with
        | Eq (l,r) -> Eq (subst_setexp l, subst_setexp r)
        | Neq (l,r) -> Neq (subst_setexp l, subst_setexp r)
        | Sub (l,r) -> Sub (subst_setexp l, subst_setexp r)
        | True -> True
        | False -> False
        | Cardeq (se, i)  -> Cardeq ((subst_setexp se), i)
        | Cardleq (se, i) -> Cardleq ((subst_setexp se), i)
        | Cardgeq (se, i) -> Cardgeq ((subst_setexp se), i)
        | Disjoint ss -> Disjoint (List.map subst_setexp ss) 
        | Propvar id -> Propvar (subst_var id)
        | Propvarpost id -> Propvarpost (subst_var id)
      in
      let rec subst_form (f:form) = 
        match f with
        | Atom af -> Atom (subst_atom_form af)
        | Not n -> Not (subst_form n)
        | And cs -> And (List.map subst_form cs)
        | Or ds -> Or (List.map subst_form ds)
        | Impl (ante, conseq) -> 
            Impl ((subst_form ante), (subst_form conseq))
        | Iff (p, q) -> Iff ((subst_form p), (subst_form q))
        | ExistsOne (vd, f) -> ExistsOne (vd, subst_form f)
        | ForallOne (vd, f) -> ForallOne (vd, subst_form f)
        | ExistsSet (vd, f) -> ExistsSet (vd, subst_form f)
        | ForallSet (vd, f) -> ForallSet (vd, subst_form f) in
      let subst_proc p = {
        proc_name = Id.fetch_proc ast.module_name (Id.name_of_proc p.proc_name);
        formals = List.map subst_pair p.formals;
        ret_val = (match p.ret_val with None -> None
        | Some x -> Some (subst_pair x));
        requires = subst_form p.requires;
        modifies = List.map subst_var p.modifies;
        frame_cond = subst_form p.frame_cond;
        calls    = p.calls;
        ensures  = subst_form p.ensures;
      } in
      { 
        module_name = ast.module_name;
        instantiated_from = ast.instantiated_from;
        param_subst = ast.param_subst;
        properties = pmod.properties;
        formats = List.map subst_type_fmts pmod.formats;
        sets = List.map subst_pair_fmts pmod.sets;
        procs = List.map subst_proc pmod.procs;
        pred_vars = pmod.Sabsyn.pred_vars;
      }

