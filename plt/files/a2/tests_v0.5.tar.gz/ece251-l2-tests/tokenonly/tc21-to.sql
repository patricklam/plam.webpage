TRUE
FALSE
>=
<=
"hey "" hey hey"
'and again'''
_
2E+3
