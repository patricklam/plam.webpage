package ca.uwaterloo.ece251;

import ca.uwaterloo.ece251.ast.*;
import java.util.List;
import java.util.LinkedList;

public class Parser {
    TokenStream ts;
    Token current;

    /** Create a parser which consumes the given <code>TokenStream</code>. */
    public Parser(TokenStream ts) {
	this.ts = ts; 
	// prime the pump
	current = ts.nextElement();
    }

    public Stmt stmt() {
	// put your recursive descent parser here
    }
}
