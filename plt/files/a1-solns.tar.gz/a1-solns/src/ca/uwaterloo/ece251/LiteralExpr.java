package ca.uwaterloo.ece251;

/** AST representation of a literal (e.g. "5"). */
public class LiteralExpr implements Expr {
    AtomValue v;

    /** Construct the literal from its string representation. 
     *
     * My implementation constructs the <code>Value</code> in the
     * constructor and stashes it in a field. */
    public LiteralExpr(String s) {
      this.v = new AtomValue(s, true);
    }

    /** Return the stashed <code>Value</code> for this literal. */
    public Value eval(Interp interp) {
	return v;
    }
}