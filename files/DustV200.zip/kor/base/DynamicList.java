// DynamicList.java
//
// Author: Raja Vallee-Rai
//
// This file is public domain.  You can do anything you want with 
// it, all at your own risk.  Enjoy!


package kor.base;

import java.util.*;

/**
 * The DynamicList object provides an alternative to dealing with enumerations which are
 * generated from set like objects.  The word Dynamic is a reminder that as you are
 * going through the list, the list may change if you affect the object which yielded
 * the list.
 *
 * <p> The methods used to access the elements are also less cumbersome than the Enumeration's.
 */

public
class DynamicList
{
    public
    Enumeration enumeration;
    
    public DynamicList()
    {
    }

    private DynamicList(Enumeration e)
    {
        this.enumeration = e;
    }
    
    /**
     * Returns the next element of this list.
     */
     
    public Object next()
    {
        return enumeration.nextElement();
    }

    /**
     * Is the list empty?
     */
     
    public boolean isEmpty()
    {
        return !enumeration.hasMoreElements();
    }

    /**
     * Converts an enumeration to a DynamicList.
     */
     
    static
    public DynamicList ofEnumeration(Enumeration e)
    {
        return new DynamicList(e);
    }

    /**
     * Creates a list from an array of objects.
     */
     
    static
    public DynamicList listOfArray(Object[] array)
    {
        return new DynamicList(new ElementsOfArray(array));
    }

    /**
     * Returns a list of the first x elements in the array.
     *
     * @param length    how many elements to return
     */
    static
    public DynamicList listOfArray(Object[] array, int length)
    {
        return new DynamicList(new ElementsOfArray(array, length));
    }
}

class ElementsOfArray implements Enumeration
{
    Object[] array;
    int index;
    int length;

    public ElementsOfArray(Object[] array, int length)
    {
        this.array = array;
        this.length = length;
    }

    public ElementsOfArray(Object[] array)
    {
        this.array = array; 
        length = array.length;
    }
    
    public boolean hasMoreElements()
    {
        return index < length;
    }
    
    public Object nextElement()
    {
        return array[index++];
    }
}
