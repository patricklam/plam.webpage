#!/usr/bin/perl

my $n;
open my $c, ">all.scope" || die "couldn't open scopes file";
open my $s, ">specs.sl";
open my $i, ">impls.fl";

for ($n = 0; $n < 20; ++$n) {
    my $ns = sprintf "%02d", $n;
    my $nn = $n + 1;
    my $nns = sprintf "%02d", $nn;
    open my $apub, ">abst$ns"."pub.al";
    open my $aprv, ">abst$ns"."prv.al";
    print $c "scope C$ns { modules M$ns"."Priv, M$ns"."Pub; exports M$ns"."Pub; invariant M$ns"."Priv.A = M$ns"."Priv.B; }\n";
    print $s "spec module M$ns"."Pub { proc e() requires true calls M$ns"."Priv ensures true; }\n";
    print $s "spec module M$ns"."Priv { sets A,B:T; format T; proc p() requires A = B calls M$nns"."Pub ensures true; }\n";
    print $i "impl module M$ns"."Pub { proc e() { M$ns"."Priv.p(); } }\n";
    print $i "impl module M$ns"."Priv { proc p() { M$nns"."Pub.e(); } }\n";
    print $apub "abst module M$ns"."Pub { use plugin \"flags\"; }\n";
    print $aprv "abst module M$ns"."Priv { use plugin \"flags\"; }\n";
    close $apub;
    close $aprv;
}

my $ns = sprintf "%02d", $n;
my $nn = $n + 1;
my $nns = sprintf "%02d", $nn;
print $c "scope C$ns { modules M$ns"."Priv; exports M$ns"."Pub; invariant M$ns"."Priv.A = M$ns"."Priv.B; }\n";
print $s "spec module M$ns"."Pub { proc e() requires true calls M$ns"."Priv ensures true; }\n";
print $s "spec module M$ns"."Priv { sets A,B:T; format T; proc p() requires A = B ensures true; }\n";
print $i "impl module M$ns"."Pub { proc e() { M$ns"."Priv.p(); } }\n";
print $i "impl module M$ns"."Priv { proc p() { } }\n";

close $c;
close $s;
close $i;
close $a;

