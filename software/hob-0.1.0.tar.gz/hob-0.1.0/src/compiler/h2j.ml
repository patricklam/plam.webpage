(* TODO: convert Hob's arrays-by-value to Java's passing-arrays-by-ref *)

open Iabsyn

(**************************************************************)
(* Some general-purpose functions                             *)

let unsome : 'a option -> 'a = 
function
  | Some x -> x
  | None   -> failwith "tried to deoptionify None"

let rec string_of_value_type x =
  match x with
  | Types.TInt -> "int"
  | Types.TBool -> "boolean"
  | Types.TFloat -> "double"
  | Types.TString -> "String"
  | Types.TChar -> "char"
  | Types.TByte -> "byte"
  | Types.TObj y -> y^(if ((y = "StringBuffer") || ((String.length y > 5) && (Str.string_before y 5 = "java."))) then "" else "_fmt")
  | Types.TVoid -> "void"
  | Types.TArray y -> ((string_of_value_type y)^"[]")
  | Types.TTuple y -> (List.fold_left 
      (fun x1 x2 -> x1 ^ "*" ^ (string_of_value_type x2)) "" y)
  | Types.TSet y -> (string_of_value_type y)^" set"

(**************************************************************)

let speclist = [("-v", Arg.Set Util.verbose, "Verbose; display verbose debugging messages.")]
let source_names = ref []

let format_defs : (Id.format_t,
     (Id.module_t, (Id.field_t, Types.value_type) Hashtbl.t) Hashtbl.t) Hashtbl.t ref = ref (Hashtbl.create 0)

let translate_type_to_j t = t

let write_format_defs (fd:(Id.format_t, (Id.module_t, (Id.field_t, Types.value_type) Hashtbl.t) Hashtbl.t) Hashtbl.t) =
  let wr s = print_string s in
  (* system fields for file_descr_fmt *)
  let fdf = try Hashtbl.find fd "file_descr" with Not_found -> Hashtbl.create 2 in
  let sysf = Hashtbl.create 2 in
  Hashtbl.add sysf (Id.fetch_field "" "r") (Types.TObj "java.io.FileReader");
  Hashtbl.add sysf (Id.fetch_field "" "w") (Types.TObj "java.io.OutputStream");
  Hashtbl.add sysf (Id.fetch_field "" "f") (Types.TObj "java.io.File");
  Hashtbl.add sysf (Id.fetch_field "" "ss") (Types.TObj "java.net.ServerSocket");
  Hashtbl.add sysf (Id.fetch_field "" "s") (Types.TObj "java.net.Socket");
  Hashtbl.add fdf "System" sysf;
(*  Hashtbl.replace fd "file_descr_fmt" fdf;*)
  Hashtbl.iter (fun fmt fmt_fd ->
    wr ("class "^fmt^"_fmt {\n");
    Hashtbl.iter (fun mdl f_t -> 
      Hashtbl.iter (fun field t ->
        wr ("\t" ^ (string_of_value_type t) ^ " " ^ (Id.module_of_field field) ^ "_" ^ (Id.name_of_field field) ^ ";\n")) f_t) fmt_fd;
    wr "}\n") fd

let string_of_value x =
  match x with
  | Int i -> string_of_int i
  | Bool true -> "true"
  | Bool false -> "false"
  | Float f -> string_of_float f
  | String s -> "\"" ^ (String.escaped s) ^ "\""
  | Char c
  | Byte c -> "'" ^ (String.make 1 c) ^ "'"
  | Obj 0 -> "null"
  | Array _ -> "<array>"
  | Obj _ -> "<obj>"

let translate_intrinsic (p, e) =
  match ((Id.module_of_proc p), (Id.name_of_proc p)) with
  | ("System", "random") -> (Id.fetch_proc "HobUtil" "random", e)
  | ("System", "hash_code") -> (Id.fetch_proc "HobUtil" "hash_code", e)
  | ("System", "print_int") -> (Id.fetch_proc "System.out" "print", e)
  | ("System", "print_float") -> (Id.fetch_proc "System.out" "print", e)
  | ("System", "print_string") -> (Id.fetch_proc "System.out" "print", e)
  | ("System", "print_stringbuffer") -> (Id.fetch_proc "HobUtil" "print_stringbuffer", e)
  | ("System", "int_of_string") -> (Id.fetch_proc "HobUtil" "int_of_string", e)
  | ("System", "char_of_int") -> (Id.fetch_proc "HobUtil" "char_of_int", e)
  | ("System", "byte_of_int") -> (Id.fetch_proc "HobUtil" "byte_of_int", e)
  | ("System", "string_of_int") -> (Id.fetch_proc "HobUtil" "string_of_int", e)
  | ("System", "string_of_stringbuffer") -> (Id.fetch_proc "HobUtil" "string_of_stringbuffer", e)
  | ("System", "byte_array_of_string") -> (Id.fetch_proc "HobUtil" "byte_array_of_string", e)
  | ("System", "arraycopy") -> (Id.fetch_proc "HobUtil" "arraycopy", e)
  | ("System", "time") -> (Id.fetch_proc "HobUtil" "time", e)
  | ("System", "mime_time") -> (Id.fetch_proc "HobUtil" "mime_time", e)
  | ("System", "unmime_time") -> (Id.fetch_proc "HobUtil" "unmime_time", e)
  | ("System", "errno") -> (Id.fetch_proc "HobUtil" "errno", e)
  | ("System", "openfile") -> (Id.fetch_proc "HobUtil" "openfile", e)
  | ("System", "in_channel_of_file_descr") -> (Id.fetch_proc "HobUtil" "in_channel_of_file_descr", e)
  | ("System", "out_channel_of_file_descr") -> (Id.fetch_proc "HobUtil" "out_channel_of_file_descr", e)
  | ("System", "input_line") -> (Id.fetch_proc "HobUtil" "input_line", e)
  | ("System", "read") -> (Id.fetch_proc "HobUtil" "read", e)
  | ("System", "close") -> (Id.fetch_proc "HobUtil" "close", e)
  | ("System", "flush") -> (Id.fetch_proc "HobUtil" "flush", e)
  | ("System", "output") -> (Id.fetch_proc "HobUtil" "output", e)
  | ("System", "output_string") -> (Id.fetch_proc "HobUtil" "output_string", e)
  | ("System", "EACCES") -> (Id.fetch_proc "HobUtil" "EACCES", e)
  | ("System", "ENOTDIR") -> (Id.fetch_proc "HobUtil" "ENOTDIR", e)
  | ("System", "ELOOP") -> (Id.fetch_proc "HobUtil" "ELOOP", e)
  | ("System", "O_RDONLY") -> (Id.fetch_proc "HobUtil" "O_RDONLY", e)
  | ("System", "O_WRONLY") -> (Id.fetch_proc "HobUtil" "O_WRONLY", e)
  | ("System", "O_RDWR") -> (Id.fetch_proc "HobUtil" "O_RDWR", e)
  | ("System", "O_APPEND") -> (Id.fetch_proc "HobUtil" "O_APPEND", e)
  | ("System", "fstat") -> (Id.fetch_proc "HobUtil" "fstat", e)
  | ("System", "S_REG") -> (Id.fetch_proc "HobUtil" "S_REG", e)
  | ("System", "st_kind") -> (Id.fetch_proc "HobUtil" "st_kind", e)
  | ("System", "st_mtime") -> (Id.fetch_proc "HobUtil" "st_mtime", e)
  | ("System", "st_size") -> (Id.fetch_proc "HobUtil" "st_size", e)
  | ("String", "index") -> (Id.fetch_proc "HobUtil" "indexOf", e)
  | ("String", "rindex") -> (Id.fetch_proc "HobUtil" "lastIndexOf", e)
  | ("String", "get") -> (Id.fetch_proc "HobUtil" "charAt", e)
  | ("String", "string_before") -> (Id.fetch_proc "HobUtil" "string_before", e)
  | ("String", "string_after") -> (Id.fetch_proc "HobUtil" "string_after", e)
  | ("String", "length") -> (Id.fetch_proc "HobUtil" "length", e)
  | ("String", "make") -> (Id.fetch_proc "HobUtil" "make", e)
  | ("String", "chr") -> (Id.fetch_proc "HobUtil" "chr", e)
  | ("Sockets", "socket") -> (Id.fetch_proc "HobUtil" "socket", e)
  | ("Sockets", "accept") -> (Id.fetch_proc "HobUtil" "accept", e)
  | ("Sockets", "string_of_inet_addr_of_socket") -> (Id.fetch_proc "HobUtil" "string_of_inet_addr_of_socket", e)
  | ("CRC", "reset") -> (Id.fetch_proc "HobUtil" "cReset", e)
  | ("CRC", "getValue") -> (Id.fetch_proc "HobUtil" "cGetValue", e)
  | ("CRC", "update") -> (Id.fetch_proc "HobUtil" "cUpdate", e)
  | ("Zip", "set_input") -> (Id.fetch_proc "HobUtil" "zSetInput", e)
  | ("Zip", "needs_input") -> (Id.fetch_proc "HobUtil" "zNeedsInput", e)
  | ("Zip", "finish") -> (Id.fetch_proc "HobUtil" "zFinish", e)
  | ("Zip", "deflate") -> (Id.fetch_proc "HobUtil" "zDeflate", e)
  | ("Zip", "adler") -> (Id.fetch_proc "HobUtil" "zAdler", e)
  | ("Zip", "reset") -> (Id.fetch_proc "HobUtil" "zReset", e)
  | ("Zip", "end") -> (Id.fetch_proc "HobUtil" "zEnd", e)
  | _ -> (p, e)

(* TODO: precedence *)
let rec translate_lvalue lv =
  match lv with
    LocalLvalue lv -> lv
  | RefLvalue rv -> rv
  | FieldLvalue (e, f) -> 
      translate_expr e ^ 
      "." ^ (Id.module_of_field f) ^ "_" ^ (Id.name_of_field f)
  | ArrayLvalue (b, e) ->
      translate_expr b ^ "[" ^ translate_expr e ^ "]"
and translate_expr e = 
  match e with
    LiteralExpr le -> string_of_value le
  | VarExpr lv -> translate_lvalue lv
  | FieldAccessExpr (e, f) -> 
      translate_expr e ^ 
      "." ^ (Id.module_of_field f) ^ "_" ^ (Id.name_of_field f)
  | ArrayAccessExpr (b, e) -> translate_expr b ^ "[" ^ translate_expr e ^ "]"
  | ArrayLengthExpr b -> translate_expr b ^ ".length"
  | NewExpr t -> "new "^t^(if t = "StringBuffer" then "" else "_fmt")^"()"
  | NewArrayExpr (t, e, v) -> "new "^Types.string_of_value_type t^"[" ^ (translate_expr (List.hd e)) ^ "]"
  | InvokeExpr (p0, e0) -> 
      let (p, e) = translate_intrinsic (p0, e0) in
      Id.module_of_proc p ^ "." ^ Id.name_of_proc p ^ "(" ^
      (match e with
      | [] -> "" 
      | [v] -> translate_expr v
      | v::hs -> 
          List.fold_left 
            (fun s v' -> (s^", "^translate_expr v'))
            (translate_expr v) hs) ^ ")"
  | AssignExpr (lv, e) -> translate_lvalue lv ^ " = " ^ translate_expr e
  | PreIncExpr e -> "++" ^ translate_lvalue e
  | PostIncExpr e -> translate_lvalue e ^ "++"
  | PreDecExpr e -> "--" ^ translate_lvalue e
  | PostDecExpr e -> translate_lvalue e ^ "--"
  | NegExpr e -> "-" ^ translate_expr e
  | PlusExpr (l, r) -> translate_expr l ^ " + " ^ translate_expr r
  | MinusExpr (l, r) -> translate_expr l ^ " - " ^ translate_expr r
  | MultExpr (l, r) -> translate_expr l ^ " * " ^ translate_expr r
  | DivExpr (l, r) -> translate_expr l ^ " / " ^ translate_expr r
  | ModExpr (l, r) -> translate_expr l ^ " % " ^ translate_expr r
  | AndExpr (l, r) -> translate_expr l ^ " && " ^ translate_expr r
  | OrExpr (l, r) -> translate_expr l ^ " || " ^ translate_expr r
  | NotExpr e -> "!" ^ translate_expr e
  | EqExpr (l, r) -> 
      (try 
        let lt = Exprtbl.find Typechecker.typeof l in
        let rt = Exprtbl.find Typechecker.typeof r in
        if lt = Types.TString && rt = Types.TString then
          (translate_expr l ^ ".equals(" ^ translate_expr r ^ ")")
        else
          (translate_expr l ^ " == " ^ translate_expr r)
      with Not_found -> (translate_expr l ^ " == " ^ translate_expr r))
  | NeqExpr (l, r) -> 
      (try 
        let lt = Exprtbl.find Typechecker.typeof l in
        let rt = Exprtbl.find Typechecker.typeof r in
        if lt = Types.TString && rt = Types.TString then
          ("!"^translate_expr l ^ ".equals(" ^ translate_expr r ^ ")")
        else
          (translate_expr l ^ " != " ^ translate_expr r)
      with Not_found -> (translate_expr l ^ " != " ^ translate_expr r))
  | LtExpr (l, r) -> translate_expr l ^ " < " ^ translate_expr r
  | GtExpr (l, r) -> translate_expr l ^ " > " ^ translate_expr r
  | LteqExpr (l, r) -> translate_expr l ^ " <= " ^ translate_expr r
  | GteqExpr (l, r) -> translate_expr l ^ " >= " ^ translate_expr r
  | BitAndExpr (l, r) -> translate_expr l ^ " & " ^ translate_expr r
  | BitOrExpr (l, r) -> translate_expr l ^ " | " ^ translate_expr r
  | BitXorExpr (l, r) -> translate_expr l ^ " ^ " ^ translate_expr r
  | ShiftLeftExpr (l, r) -> translate_expr l ^ " << " ^ translate_expr r
  | SignedShiftRightExpr (l, r) -> translate_expr l ^ " >> " ^ translate_expr r
  | UnsignedShiftRightExpr (l, r) -> translate_expr l ^ " >>> " ^ translate_expr r


(* really we should indent a single statement further in, but not a cpdstmt *)
let rec write_stmt wr (s:'a Iabsyn.stmt) =
  match s with
  | EmptyStmt -> wr ";\n"
  | CompoundStmt ss -> 
      wr "{\n";
      List.iter (fun st -> write_stmt (fun s -> wr ("\t"^s)) st) ss;
      wr "}\n"
  | ChoiceStmt _ -> Util.error "can't translate choice into Java"
  | AssertStmt _ -> Util.error "can't translate assert into Java"
  | AssumeStmt _ -> wr ("/* missing assume */\n")
  | HavocStmt _ -> Util.error "can't translate havoc into Java"
  | LocalDeclStmt (v, t, e) ->
      wr ((string_of_value_type t) ^ " " ^ v ^ " = " ^ 
          (if t = Types.TObj "StringBuffer" then
            "new StringBuffer()" else (translate_expr e)) ^ ";\n")
  | ExprStmt e -> wr ((translate_expr e) ^ ";\n")
  | ReturnStmt None -> wr ("return;\n")
  | ReturnStmt (Some re) -> wr ("return " ^ (translate_expr re) ^ ";\n")
  | WhileStmt (_, e, b) -> 
      wr ("while ("^translate_expr e^")\n");
      write_stmt wr b
  | PragmaStmt s -> wr ("/* pragma: "^s^" */\n")
  | IfStmt (e, t, EmptyStmt) ->
      wr ("if ("^translate_expr e^")\n");
      write_stmt wr t
  | IfStmt (e, t, f) ->
      wr ("if ("^translate_expr e^")\n");
      write_stmt wr t;
      wr ("else\n");
      write_stmt wr f

let write_proc wr (pi:'a Iabsyn.proc_def) =
  let pn = (Id.name_of_proc pi.proc_id) in
  wr ("\tpublic static "^
      (match pi.ret_val with 
      | None -> "void" | Some (_, t) -> (string_of_value_type t)) ^ 
      " " ^ pn ^ "(" ^
      (* vile hack *)
      (if (pn = "main") then "String argv[]" else
      (match pi.formals with
      | [] -> "" 
      | [(v, t)] -> (string_of_value_type t) ^ " " ^ v
      | (v, t)::hs -> 
          List.fold_left 
            (fun s (v', t') -> (s^", "^(string_of_value_type t')^" " ^ v'))
            ((string_of_value_type t) ^ " " ^ v) hs)) ^ ")\n");
  write_stmt (fun s -> wr ("\t"^s)) pi.proc_body

let write_class (mi:'a Iabsyn.impl_module) = 
  let wr s = print_string s in
  wr ("class "^mi.module_name^" {\n");
  List.iter (fun (refn, t) ->
    wr ("\tstatic " ^ (string_of_value_type t)^" "^refn^";\n")) mi.references;
  List.iter (write_proc wr) mi.procs;
  wr "}\n"

let write_util_class = 
  let wr s = print_string s in
  wr "class file_stats_fmt { java.io.File f; }\n\n";
  wr "class in_channel_fmt { java.io.BufferedReader r; }\n";
  wr "class out_channel_fmt { java.io.OutputStream w; }\n";
  wr "class HobUtil {\n";
  wr "    static int errno = 0;\n";
  wr "    static java.util.Random rnd = new java.util.Random();\n";
  wr "    static java.text.DateFormat df822 = new java.text.SimpleDateFormat(\"EEE, dd MMM yyyy hh:mm:ss zzz\");\n";
  wr "    static java.text.DateFormat df850 = new java.text.SimpleDateFormat(\"EEEE, dd-MMM-yy hh:mm:ss zzz\");\n";
  wr "    static java.text.DateFormat dfasc = new java.text.SimpleDateFormat(\"EEE MMM dd hh:mm:ss yyyy\");\n";
  wr "    static java.util.zip.Deflater zInstance = new java.util.zip.Deflater(java.util.zip.Deflater.DEFAULT_COMPRESSION, true);\n";
  wr "    static java.util.zip.CRC32 cInstance = new java.util.zip.CRC32();\n";
  wr "    static public void zSetInput (byte[] s) { zInstance.setInput(s); }\n";
  wr "    static public boolean zNeedsInput () { return zInstance.needsInput(); }\n";
  wr "    static public void zFinish () { zInstance.finish(); }\n";
  wr "    static public int zDeflate (byte[] s, int off, int len) { int c = 0; c = zInstance.deflate(s, off, len); return c; }\n";
  wr "    static public int zAdler () { return zInstance.getAdler(); }\n";
  wr "    static public void zReset () { zInstance.reset(); }\n";
  wr "    static public void zEnd () { zInstance.end(); }\n";
  wr "    static public void cReset () { cInstance.reset(); }\n";
  wr "    static public void cUpdate (byte[] c) { cInstance.update(c); }\n";
  wr "    static public int cGetValue () { return (int) (cInstance.getValue() & 0xffffffff); }\n";
  wr "    static public int random(int n) { return rnd.nextInt(n); }\n";
  wr "    static public int hash_code(String s) { return s.hashCode(); }\n";
  wr "    static public int indexOf(String s, int ch) { return s.indexOf(ch); }\n";
  wr "    static public int lastIndexOf(String s, int ch) { return s.lastIndexOf(ch); }\n";
  wr "    static public char charAt(String s, int i) { return s.charAt(i); }\n";
  wr "    static public String string_before(String s, int i) { return s.substring(0, i); }\n";
  wr "    static public String string_after(String s, int i) { return s.substring(i, s.length()); }\n";
  wr "    static public void print_stringbuffer(StringBuffer s) { System.out.print(s.toString()); }\n";
  wr "    static public int length(String s) { return s.length(); }\n";
  wr "    static public String make(int c, char ch) { char[] ca = new char[c]; for (int i = 0; i < c; i++) ca[i] = ch; return new String(ca); }\n";
  wr "    static public String chr(int ch) { char[] ca = new char[1]; ca[0] = (char)ch; return new String(ca); }\n";
  wr "    static int int_of_string(String s) { return Integer.parseInt(s); }\n";
  wr "    static char char_of_int(int i) { return (char)i; }\n";
  wr "    static byte byte_of_int(int i) { return (byte)i; }\n";
  wr "    static String string_of_int(int i) { return new Integer(i).toString(); }\n";
  wr "    static String string_of_stringbuffer(StringBuffer s) { return s.toString(); }\n";
  wr "    static byte[] byte_array_of_string (String s) { return s.getBytes(); }\n";
  wr "    static void arraycopy (Object src, int srcPos, Object dest, int destPos, int length) { System.arraycopy (src, srcPos, dest, destPos, length); }\n";
  wr "    static float time() { return (float)System.currentTimeMillis(); }\n";
  wr "    static String mime_time(double t) { df822.setTimeZone(java.util.TimeZone.getTimeZone(\"GMT\")); return df822.format(new java.util.Date((long)t)); }\n";
  wr "    static double unmime_time(String t) { double tt = 0; try { tt = df822.parse(t).getTime(); } catch (java.text.ParseException p) { } if (tt == 0) { try { tt = df850.parse(t).getTime(); } catch (java.text.ParseException p) { }} if (tt == 0) { try { tt = dfasc.parse(t).getTime(); } catch (java.text.ParseException p) { } } return tt; }\n";
  wr "    static int errno() { return errno; }\n";
  wr "    static int EACCES() { return 13; }\n";
  wr "    static int ENOTDIR() { return 20; }\n";
  wr "    static int ELOOP() { return 40; }\n";
  wr "    static int O_RDONLY() { return 1; }\n";
  wr "    static int O_WRONLY() { return 2; }\n";
  wr "    static int O_RDWR() { return 3; }\n";
  wr "    static int O_APPEND() { return 1024; }\n";
  wr "    static file_descr_fmt openfile(String n, int attr, int perm) {\n";
  wr "        errno = 0;\n";
  wr "        file_descr_fmt fd = new file_descr_fmt();\n";
  wr "        boolean append = false;\n";
  wr "        fd._f = new java.io.File(n);\n";
  wr "        try { if ((attr & O_RDONLY()) == O_RDONLY()) fd._r = new java.io.FileReader(fd._f);\n";
  wr "        if ((attr & O_APPEND()) == O_APPEND()) append = true;\n";
  wr "        if ((attr & O_WRONLY()) == O_WRONLY()) fd._w = new java.io.BufferedOutputStream(new java.io.FileOutputStream (fd._f, append));\n";
  wr "        } catch (java.io.IOException e) { if (e.getMessage().endsWith(\"Permission denied)\")) errno = EACCES(); else if (e.getMessage().endsWith(\"Too many levels of symbolic links)\")) errno = ELOOP(); else if (e.getMessage().endsWith(\"Not a directory)\")) errno = ENOTDIR(); fd = null; } return fd;\n";
  wr "    }\n";
  wr "    static in_channel_fmt in_channel_of_file_descr(file_descr_fmt f) { in_channel_fmt ic = new in_channel_fmt(); try { if (f._r != null) ic.r = new java.io.BufferedReader(f._r); else if (f._s != null) ic.r = new java.io.BufferedReader(new java.io.InputStreamReader(f._s.getInputStream())); } catch (java.io.IOException e) {} return ic; }\n";
  wr "    static out_channel_fmt out_channel_of_file_descr(file_descr_fmt f) { out_channel_fmt oc = new out_channel_fmt(); oc.w = f._w; try { if (f._s != null) oc.w = f._s.getOutputStream(); } catch (java.io.IOException e) {} return oc; }\n";
  wr "    static String input_line(in_channel_fmt ic) { String s = \"\"; try { s = ic.r.readLine(); } catch (java.io.IOException e) {} return s; }\n";
  wr "    static void flush(out_channel_fmt oc) { try { oc.w.flush();} catch (java.io.IOException e) {} }\n";
  wr "    static void output_string(out_channel_fmt oc, String s) { try { oc.w.write(s.getBytes());} catch (java.io.IOException e) {} }\n";
  wr "    static void output(out_channel_fmt oc, byte[] b, int off, int len) { try { oc.w.write(b, off, len);} catch (java.io.IOException e) {} }\n";
  wr "    static int read(file_descr_fmt fd, StringBuffer s, int off, int len) {\n";
  wr "        char[] bytes = new char[(int)len]; int c = 0;\n";
  wr "        try { c = fd._r.read(bytes, off, len);} catch (java.io.IOException e) {}\n";
  wr "        s.setLength(0);\n";
  wr "        s.append(new String(bytes));\n";
  wr "        return c;\n";
  wr "    }\n";
  wr "    static void close(file_descr_fmt fd) {\n";
  wr "        try { if (fd._r != null) fd._r.close();\n";
  wr "        if (fd._s != null) fd._s.close();\n";
  wr "        if (fd._w != null) fd._w.close(); } catch (java.io.IOException e) {}\n";
  wr "    }\n";
  wr "    static file_stats_fmt fstat(file_descr_fmt fd) { file_stats_fmt ff = new file_stats_fmt(); ff.f = fd._f; return ff; }\n";
  wr "    static int S_REG() { return 1; }\n";
  wr "    static int st_kind(file_stats_fmt ff) { if (ff.f.isFile()) return S_REG(); else return 0; }\n";
  wr "    static double st_mtime(file_stats_fmt ff) { return (double)ff.f.lastModified(); }\n";
  wr "    static int st_size(file_stats_fmt ff) { return (int)ff.f.length(); }\n";
  wr "    static file_descr_fmt socket(int port) { file_descr_fmt fd = new file_descr_fmt(); try { fd._ss = new java.net.ServerSocket(port); } catch (java.io.IOException e) {} return fd; }\n";
  wr "    static file_descr_fmt accept(file_descr_fmt fd) { file_descr_fmt s = new file_descr_fmt(); try { fd._s = fd._ss.accept(); } catch (java.io.IOException e) {} return fd; }\n";
  wr "    static String string_of_inet_addr_of_socket(file_descr_fmt fd) { return fd._s.getInetAddress().getHostAddress(); }\n";
  wr "}\n"

let _ =
  let usage_msg=("Usage:\n  "^Sys.argv.(0)^" [-v] [-d <outputdir>] <input filenames>\n") in
  Arg.parse speclist (fun x -> source_names := x :: !source_names) usage_msg;
  if List.length !source_names = 0 then 
    begin Arg.usage speclist usage_msg; exit 1 end;
  Uglyast.impl_ast := Uglyast.parse_impl_asts !source_names;
  let impl_module_names = Uglyast.fetch_impl_module_names !Uglyast.impl_ast in
  Ast.impl := List.map 
      (fun x -> Deuglifyimpl.convert (Uglyast.fetch_impl_module x)) 
      impl_module_names;
  Ast.impl := Util.phase "Instantiating templates" 
      (List.map (Itrans.instantiate_templates true)) !Ast.impl;
  let r = Typechecker.declaration_checker true !Ast.impl in
  Ast.impl := Util.phase "Local-ref conversion " 
      List.map (Itrans.transform_local_to_ref_lvalues r) !Ast.impl;
  Assembler.populate_format_definitions !format_defs;
  Util.phase "Typechecking" Typechecker.verify !Ast.impl;

  write_format_defs !format_defs;
  write_util_class;
  List.iter write_class !Ast.impl;
