// ExtDouble.java
//
// Author: Raja Vallee-Rai
//
// This file is public domain.  You can do anything you want with 
// it, all at your own risk.  Enjoy!

package kor.base;

/**
 * This class provides some static methods which do some rather essential 
 * things to doubles, like truncation.
 */
 
public
class ExtDouble
{
    /**
     * Return the truncated version of the double supplied.
     *
     * @param numDigits the number of digits after the decimal point to keep 
     */
     
    static
    public double truncatedOf(double d, int numDigits)
    {
        double multiplier = 1;
        
        for(int i = 0; i < numDigits; i++)
            multiplier *= 10;
            
        return ((long) (d * multiplier)) / multiplier;
    }
}
