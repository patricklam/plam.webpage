package ca.uwaterloo.ece251.ast;

import java.util.*;

public class InsertStmt extends Stmt {
    boolean insert, replace; /* at most one of these true */
    QualifiedTableName tn;
    List<String> columns;
    List<Expr> values;
    SelectStmt selectStmt;
    boolean defaultValues;

    public InsertStmt(boolean insert, boolean replace,
		      QualifiedTableName tn,
		      List<String> columns,
		      List<Expr> values,
		      SelectStmt selectStmt,
		      boolean defaultValues) {
	this.insert = insert; this.replace = replace;
	this.tn = tn;
	this.columns = columns; this.values = values;
	this.selectStmt = selectStmt;
	this.defaultValues = defaultValues;
    }

    public void accept(Visitor v) {
	v.enter(this);
	if (values != null) {
	    for (Expr e : values)
		e.accept(v);
	}
	if (selectStmt != null)
	    selectStmt.accept(v);
	v.leave(this);
    }
}
