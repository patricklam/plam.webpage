package ca.uwaterloo.ece251.ast;

import java.util.List;

/** Literal for tuples. */
public class TupleExp extends Exp {
    List<Id> fields;
    List<Exp> values;

    public TupleExp(List<Id> fields, List<Exp> values) {
	this.fields = fields; this.values = values; 
    }

    public String toString() {
	StringBuffer sb = new StringBuffer();
	sb.append(Util.interleave(fields, values, " ", ", "));
	return sb.toString();
    }
}
