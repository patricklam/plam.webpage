package ca.uwaterloo.a10_userid;

import java.util.Arrays;

public class Player {

	public String hand;
	public int value;
	public boolean hasAce;
	
	public Player()
	{
		value = 0;
		hand = "";
	}
	
	public boolean isBust() {
		return value > 21;
	}
	
	public String getVisibleCards()
	{
		String [] playerCards = hand.split(" ");
		String visibleCards = "";
		for (int i = 0; i < playerCards.length; i++) {
			if (i == 0)
				visibleCards += playerCards[i];
			else
				visibleCards += " " + playerCards[i];
		}
		return visibleCards;
	}
	
	public int getVisibleValue()
	{
		String firstCard = hand.substring(0, 2);
		if (firstCard.equals("10"))
			return value - 10;
		else {
			firstCard = hand.substring(0, 1);
			return value - (Arrays.asList(BlackJackClass.cards).indexOf(firstCard) + 1);
		}
		
	}

}
