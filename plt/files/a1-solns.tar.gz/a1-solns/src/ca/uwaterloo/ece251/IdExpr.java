package ca.uwaterloo.ece251;

/** AST representation of an identifier (e.g. "v"). */
public class IdExpr implements Expr {
    String id;

    public IdExpr(String id) {
	this.id = id;
    }

    /** Consult the store to retrieve the value of <code>id</code>. */
    public Value eval(Interp interp) {
	return (Value)interp.store.get(id).clone();
    }
}