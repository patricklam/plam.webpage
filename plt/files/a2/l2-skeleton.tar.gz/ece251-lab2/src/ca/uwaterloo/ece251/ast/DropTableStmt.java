package ca.uwaterloo.ece251.ast;

public class DropTableStmt extends Stmt {
    boolean ifExists;
    QualifiedTableName tn;

    public DropTableStmt(boolean ifExists, QualifiedTableName tn) {
	this.ifExists = ifExists;
	this.tn = tn;
    }

    public void accept(Visitor v) {
	v.enter(this);
	v.leave(this);
    }
}

