package ca.uwaterloo.ece251.ast;

public class BooleanLiteral extends Literal {
    public static final String TRUE = "TRUE";
    public static final String FALSE = "FALSE";
    boolean v;
    public BooleanLiteral(String n) {
	if (n.equals(TRUE)) this.v = true;
	if (n.equals(FALSE)) this.v = false;
    }

    public String toString() {
	return String.valueOf(v);
    }
}
