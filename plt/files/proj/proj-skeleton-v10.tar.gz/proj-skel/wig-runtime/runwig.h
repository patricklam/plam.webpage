/* Courtesy of Prof. Laurie Hendren, from COMP 520 materials. */

typedef struct FIELDS {
  char *name;
  char *value;
  struct FIELDS *next;
} FIELDS;

void parseFields();
char *getField(char *name);

char *randomString(char *name,int size);

int getGlobalInt(char *name);
void putGlobalInt(char *name,int value);

char *itoa(int i);
