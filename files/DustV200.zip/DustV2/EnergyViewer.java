// EnergyViewer.java
//
// Author: Raja Vallee-Rai
//
// This file is public domain.  You can do anything you want with 
// it, all at your own risk.  Enjoy!

import java.awt.*;
import java.awt.event.*;

import kor.base.*;

/**
 * This frame simply displays the kinetic, potential, and total energy of the system.
 */
 
class EnergyViewer extends Frame implements Viewer,
                                            WindowListener,
                                            ActionListener
{
    Playfield playfield;
    
    Label potentialEnergyLabel,
        kineticEnergyLabel,
        totalEnergyLabel;
        
    Button dismissButton;
    
    public EnergyViewer(Playfield playfield)
    {
        super("System Energy");
        
        addWindowListener(this);
        
        this.playfield = playfield;
        
        setSize(new Dimension(200, 150));
        setLayout(new BorderLayout());
        
        // Top Panel
        {
            Panel p = new Panel();
                
            p.setLayout(new GridLayout(0, 2));
           
            p.add(new Label("Potential Energy"));
            p.add(potentialEnergyLabel = new Label("         "));
            
            p.add(new Label("Kinetic Energy"));
            p.add(kineticEnergyLabel = new Label("         "));
            
            p.add(new Label("Total Energy"));
            p.add(totalEnergyLabel = new Label("         "));
            
            add(p, "Center");
        }
        
        // Bottom panel.
        {
            Panel p = new Panel();
            
            p.setLayout(new FlowLayout());
            
            p.add(dismissButton = new Button("Dismiss"));
            dismissButton.addActionListener(this);
            
            add(p, "South");
        }
        
        refreshView();
        WindowPlacer.placeWindowAt(this, "Southeast");
    } 
    
    public void setVisible(boolean visible)
    {
        if(visible)
        {
            playfield.viewers.add(this);
            super.setVisible(true);
        }
        else {
            playfield.viewers.remove(this);
            super.setVisible(false);
        }
    }
    
    public void refreshView()
    {
        playfield.calculateEnergyOfSystem();
        
        potentialEnergyLabel.setText(ExtString.paddedLeftOf(new Double(ExtDouble.truncatedOf(
            playfield.potentialEnergy, 5)).toString(), 10));
        
        kineticEnergyLabel.setText(ExtString.paddedLeftOf(new Double(ExtDouble.truncatedOf(
            playfield.kineticEnergy, 5)).toString(), 10));
            
        totalEnergyLabel.setText(ExtString.paddedLeftOf(new Double(ExtDouble.truncatedOf(
            playfield.kineticEnergy + playfield.potentialEnergy, 8)).toString(), 10));
    }
    
    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource() == dismissButton)
            handleClickToClose();
    }
    
    void handleClickToClose()
    {
        setVisible(false);
    }
                
    public void windowClosing(WindowEvent e)
    {
        handleClickToClose();
    }
     
    public void windowOpened(WindowEvent e)
    {
    }
     
    public void windowIconified(WindowEvent e)
    {
    }
     
    public void windowDeiconified(WindowEvent e)
    {
    }
     
    public void windowClosed(WindowEvent e)
    {
    }
     
    public void windowActivated(WindowEvent e)
    {
    }
     
    public void windowDeactivated(WindowEvent e) 
    {
    }
}

