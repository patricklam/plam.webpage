package ca.uwaterloo.ece251.ast;

import java.util.List;

/** Represents a document to send with variable substitutions. */
public class PlugDocument extends Document {
    List<Id> plugIds;
    List<Exp> plugContents;

    public PlugDocument(Id id, List<Id> plugIds, List<Exp> plugContents) {
	super(id);
	this.plugIds = plugIds;
	this.plugContents = plugContents;
    }

    public String toString() {
	return String.format("plug %s[%s]", id.toString(),
			     Util.interleave(plugIds, plugContents, "=", ", "));
    }
}
