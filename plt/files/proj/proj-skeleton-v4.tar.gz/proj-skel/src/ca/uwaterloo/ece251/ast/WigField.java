package ca.uwaterloo.ece251.ast;

/** Represents a field. */
public class WigField {
    Type t;
    Id id;

    public WigField(Type t, Id id) {
	this.t = t;
	this.id = id;
    }

    public String toString() {
	return t + " " + id + ";";
    }
}
