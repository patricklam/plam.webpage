select z , ra , dec from specObj AS book where zConf > 0.35;
