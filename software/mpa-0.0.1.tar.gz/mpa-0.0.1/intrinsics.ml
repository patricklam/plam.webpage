open Iabsyn
open Types
open Id

let is_intrinsic : Id.proc_t -> bool =
  fun proc ->
    match ((module_of_proc proc), (name_of_proc proc)) with
          (* io *)
    | ("System", "print_int") -> true
    | ("System", "print_string") -> true
    | ("System", "float_of_int") -> true
    | ("System", "string_of_int") -> true
    | ("System", "int_of_string") -> true
    | ("System", "int_of_float") -> true
    | ("System", "read_int") -> true
    | ("System", "open_in") -> true
    | ("System", "input_line") -> true
    | ("System", "close_in") -> true
    | ("System", "eof") -> true
    | ("System", "time") -> true
    | ("System", "exit") -> true
          (* string routines *)
    | ("String", "get") -> true
    | ("String", "string_after") -> true
    | ("String", "string_before") -> true
    | ("String", "index") -> true
    | ("String", "contains") -> true
    | ("String", "length") -> true
          (* diagnostic *)
    | ("System", "heap_dump") -> true
          (* rng *)
    | ("System", "random") -> true
    | ("System", "srand") -> true
    | ("Graphics", "open_graph") -> true
    | ("Graphics", "close_graph") -> true
    | ("Graphics", "colour") -> true
    | ("Graphics", "set_colour") -> true
    | ("Graphics", "set_line_width") -> true
    | ("Graphics", "moveto") -> true
    | ("Graphics", "lineto") -> true
    | ("Graphics", "fill_circle") -> true
    | ("Graphics", "fill_rect") -> true
    | ("Graphics", "fill_poly") -> true
    | ("Graphics", "text_size_x") -> true
    | ("Graphics", "text_size_y") -> true
    | ("Graphics", "current_point_x") -> true
    | ("Graphics", "current_point_y") -> true
    | ("Graphics", "draw_string") -> true
    | ("Graphics", "get_image") -> true
    | ("Graphics", "draw_image") -> true
    (* input *)
    | ("Graphics", "wait_next_event") -> true
    | ("Graphics", "KEY_PRESSED") -> true
    | ("Graphics", "BUTTON_DOWN") -> true
    | ("Graphics", "BUTTON_UP") -> true
    | ("Graphics", "button_down") -> true
    | ("Graphics", "button_up") -> true
    | ("Graphics", "key_pressed") -> true
    | ("Graphics", "keypressed") -> true
    | ("Graphics", "last_key_pressed") -> true
    | ("Graphics", "last_click_x") -> true
    | ("Graphics", "last_click_y") -> true
    | _ -> false

let rec check_arg_types args = match args with
| [] -> ()
| TObj _ :: TString :: rest -> check_arg_types rest
| _ -> failwith "heap dump arguments must be: string string (object string)*"

let type_check_intrinsics : Id.proc_t -> 
  value_type list -> value_type =
  fun proc args ->
    if not (is_intrinsic proc) then
      failwith "why did you give me a non-intrinsic?";
    match ((module_of_proc proc), (name_of_proc proc)) with
      ("System", "print_int") -> 
        List.iter (function (TInt) -> ()
          | y -> failwith ("type error on print_int: got "^(string_of_value_type y))) args; 
        TVoid
    | ("System", "read_int") -> 
        if args <> [] then
          failwith ("type error on read_int: got some args");
        TInt
    | ("System", "print_string") -> 
        List.iter (function (TString) -> ()
          | _ -> failwith "type error on print_string") args;
        TVoid
    | ("System", "float_of_int") ->
        if args <> [TInt] then
          failwith ("type error on float_of_int");
        TFloat
    | ("System", "int_of_float") ->
        if args <> [TFloat] then
          failwith ("type error on int_of_float");
        TInt
    | ("System", "string_of_int") ->
        if args <> [TInt] then
          failwith ("type error on string_of_int");
        TString
    | ("System", "int_of_string") ->
        if args <> [TString] then
          failwith ("type error on int_of_string");
        TInt
    | ("System", "open_in") -> 
        if args <> [TString] then
          failwith ("type error on open_in");
        TObj "in_channel"
    | ("System", "input_line") -> 
        if args <> [TObj "in_channel"] then
          failwith ("type error on input_line");
        TString
    | ("System", "close_in") -> 
        if args <> [TObj "in_channel"] then
          failwith ("type error on close_in");
        TVoid
    | ("System", "eof") ->
        if args <> [] then
          failwith ("type error on eof");
        TBool
    | ("System", "time") ->
        if args <> [] then
          failwith ("type error on time");
        TFloat
    | ("System", "exit") ->
        if args <> [TInt] then
          failwith ("type error on exit");
        TVoid
    | ("System", "heap_dump") ->
        if (List.length args < 4) then 
          failwith "not enough args for heap_dump";
        (match args with
        | TString :: TString :: rest -> check_arg_types rest
        | _ -> failwith "type error on heap_dump args 1, 2");
        TVoid
    | ("System", "random") -> 
        if args <> [TInt] then
          failwith ("type error on random");
        TInt
    | ("System", "srand") -> 
        if args <> [TInt] then
          failwith ("type error on srand");
        TVoid
    | ("String", "get") -> 
        (match args with
          [TString; TInt] -> TChar
        | _ -> failwith "type error for String.get")
    | ("String", "string_after") -> 
        (match args with
          [TString; TInt] -> TString
        | _ -> failwith "type error for String.string_after")
    | ("String", "string_before") -> 
        (match args with
          [TString; TInt] -> TString
        | _ -> failwith "type error for String.string_before")
    | ("String", "index") ->
        (match args with
          [TString; TChar] -> TInt
        | _ -> failwith "type error for String.index")
    | ("String", "contains") -> 
        (match args with
          [TString; TChar] -> TBool
        | _ -> failwith "type error for String.contains")
    | ("String", "length") -> 
        (match args with
          [TString] -> TInt
        | _ -> failwith "type error for String.length")
    | ("Graphics", "open_graph") ->
        if args <> [TString] then
          failwith ("type error on open_graph");
        TVoid
    | ("Graphics", "close_graph") ->
        if args <> [] then
          failwith ("type error on close_graph");
        TVoid
    | ("Graphics", "colour") ->
        if args <> [TString] then
          failwith ("type error on colour");
        TInt
    | ("Graphics", "set_colour") ->
        if args <> [TInt] then
          failwith ("type error on set_colour");
        TVoid
    | ("Graphics", "set_line_width") ->
        if args <> [TInt] then
          failwith ("type error on set_line_width");
        TVoid
    | ("Graphics", "moveto") -> 
        if args <> [TInt; TInt] then
          failwith ("type error on moveto");
        TVoid
    | ("Graphics", "lineto") ->
        if args <> [TInt; TInt] then
          failwith ("type error on lineto");
        TVoid
    | ("Graphics", "fill_circle") ->
        if args <> [TInt; TInt; TInt] then
          failwith ("type error on fill_circle");
        TVoid
    | ("Graphics", "fill_rect") ->
        if args <> [TInt; TInt; TInt; TInt] then
          failwith ("type error on fill_rect");
        TVoid
    | ("Graphics", "fill_poly") ->
        if args <> [TArray TInt; TArray TInt] then
          failwith ("type error on fill_poly");
        TVoid
    | ("Graphics", "text_size_x") ->
        if args <> [TString] then
          failwith ("type error on text_size_x");
        TInt
    | ("Graphics", "text_size_y") ->
        if args <> [TString] then
          failwith ("type error on text_size_y");
        TInt
    | ("Graphics", "current_point_x") ->
        if args <> [] then
          failwith ("type error on current_point_x");
        TInt
    | ("Graphics", "current_point_y") ->
        if args <> [] then
          failwith ("type error on current_point_y");
        TInt
    | ("Graphics", "draw_string") -> 
        if args <> [TString] then
          failwith ("type error on draw_string");
        TVoid
    | ("Graphics", "get_image") -> 
        if args <> [TInt; TInt; TInt; TInt] then
          failwith ("type error on get_image");
        TArray (TArray TInt)
    | ("Graphics", "draw_image") -> 
        if args <> [TArray (TArray TInt); TInt; TInt] then
          failwith ("type error on draw_image");
        TVoid
    (* input; uses state *)
    | ("Graphics", "wait_next_event") -> 
        if args <> [TInt] then
          failwith ("type error on wait_next_event");
        TVoid
    | ("Graphics", "KEY_PRESSED") ->
        if args <> [] then
          failwith ("type error on KEY_PRESSED");
        TInt
    | ("Graphics", "BUTTON_DOWN") ->
        if args <> [] then
          failwith ("type error on BUTTON_DOWN");
        TInt
    | ("Graphics", "BUTTON_UP") -> 
        if args <> [] then
          failwith ("type error on BUTTON_UP");
        TInt
    | ("Graphics", "keypressed") -> 
        if args <> [] then
          failwith ("type error on keypressed");
        TBool
    | ("Graphics", "last_key_pressed") -> 
        if args <> [] then
          failwith ("type error on last_key_pressed");
        TChar
    | ("Graphics", "last_click_x") -> 
        if args <> [] then
          failwith ("type error on last_click_x");
        TInt
    | ("Graphics", "last_click_y") -> 
        if args <> [] then
          failwith ("type error on last_click_y");
        TInt
    | _ -> failwith "undefined intrinsic!"
