open Iabsyn
open Types
open Id

let modules = ["System"; "Sockets"; "Graphics"; "CRC"; "Zip"; "String"; "Math"]

let is_noarg_intrinsic (proc:Id.proc_t) : bool =
  match ((module_of_proc proc), (name_of_proc proc)) with
  | ("System", "read_int")
  | ("System", "read_float")
  | ("System", "errno")
  | ("System", "eof")
  | ("System", "time")
  | ("System", "O_RDONLY")
  | ("System", "O_WRONLY")
  | ("System", "O_RDWR")
  | ("System", "O_NONBLOCK")
  | ("System", "O_APPEND")
  | ("System", "O_CREAT")
  | ("System", "O_TRUNC")
  | ("System", "O_EXCL")
  | ("System", "O_NOCTTY")
  | ("System", "O_DSYNC")
  | ("System", "O_SYNC")
  | ("System", "O_RSYNC")
  | ("System", "S_REG")
  | ("System", "S_DIR")
  | ("System", "S_CHR")
  | ("System", "S_BLK")
  | ("System", "S_LNK")
  | ("System", "S_FIFO")
  | ("System", "S_SOCK")
  | ("System", "EACCES")
  | ("System", "ENOTDIR")
  | ("System", "ELOOP")
  | ("Sockets", "PF_UNIX")
  | ("Sockets", "PF_INET")
  | ("Sockets", "SOCK_STREAM")
  | ("Sockets", "SOCK_DGRAM")
  | ("Sockets", "SOCK_SEQPACKET")
  | ("Sockets", "SOCK_RAW")
  | ("Graphics", "KEY_PRESSED")
  | ("Graphics", "BUTTON_DOWN")
  | ("Graphics", "BUTTON_UP")
  | ("Graphics", "close_graph")
  | ("Graphics", "current_point_x")
  | ("Graphics", "current_point_y")
  | ("Graphics", "key_pressed")
  | ("Graphics", "keypressed")
  | ("Graphics", "last_key_pressed")
  | ("Graphics", "last_click_x")
  | ("Graphics", "last_click_y") 
  | ("CRC", "reset")
  | ("CRC", "getValue")
  | ("Zip", "needs_input")
  | ("Zip", "finish")
  | ("Zip", "adler")
  | ("Zip", "reset")
  | ("Zip", "end") -> true
  | _ -> false

let is_intrinsic (proc:Id.proc_t) : bool =
  is_noarg_intrinsic proc or
  match ((module_of_proc proc), (name_of_proc proc)) with
    (* io *)
  | ("System", "print_int")
  | ("System", "print_float")
  | ("System", "print_string")
  | ("System", "print_stringbuffer")
  | ("System", "output_string")
  | ("System", "output")
  | ("System", "in_channel_of_file_descr")
  | ("System", "out_channel_of_file_descr")
  | ("System", "float_of_int")
  | ("System", "string_of_int")
  | ("System", "string_of_stringbuffer")
  | ("System", "int_of_string")
  | ("System", "float_of_string")
  | ("System", "int_of_float")
  | ("System", "char_of_int")
  | ("System", "byte_of_int")
  | ("System", "byte_array_of_string")
  | ("System", "arraycopy")
  | ("System", "open_in")
  | ("System", "input_line")
  | ("System", "close_in") (* in_channel *)
  | ("System", "close_out")
  | ("System", "flush")
  | ("System", "exit")
  | ("System", "hash_code")
  | ("System", "mime_time")
  | ("System", "unmime_time")
        (* file_descr routines *)
  | ("System", "openfile")
  | ("System", "fstat")
  | ("System", "st_kind")
  | ("System", "st_size")
  | ("System", "st_mtime")
  | ("System", "read")
  | ("System", "write")
  | ("System", "close")
        (* string routines *)
  | ("String", "get")
  | ("String", "string_after")
  | ("String", "string_before")
  | ("String", "rindex")
  | ("String", "index")
  | ("String", "contains")
  | ("String", "length")
  | ("String", "make")
  | ("String", "chr")
        (* diagnostic *)
  | ("System", "heap_dump")
        (* rng *)
  | ("System", "random")
  | ("System", "srand")
        (* math *)
  | ("Math", "abs")
  | ("Math", "exp")
  | ("Math", "pow")
  | ("Math", "sqrt")
  | ("Math", "sin")
  | ("Math", "cos")
  | ("Math", "acos")
        (* sockets *)
  | ("Sockets", "socket")
  | ("Sockets", "bind")
  | ("Sockets", "listen")
  | ("Sockets", "accept")
  | ("Sockets", "string_of_inet_addr_of_socket")
        (* graphics *)
  | ("Graphics", "open_graph")
  | ("Graphics", "colour")
  | ("Graphics", "set_colour")
  | ("Graphics", "set_line_width")
  | ("Graphics", "moveto")
  | ("Graphics", "lineto")
  | ("Graphics", "fill_circle")
  | ("Graphics", "fill_rect")
  | ("Graphics", "fill_poly")
  | ("Graphics", "text_size_x")
  | ("Graphics", "text_size_y")
  | ("Graphics", "draw_string")
  | ("Graphics", "get_image")
  | ("Graphics", "draw_image")
        (* input *)
  | ("Graphics", "wait_next_event")
  | ("CRC", "update")
  | ("Zip", "set_input")
  | ("Zip", "deflate") -> true
  | _ -> false

let lookup_noarg_intrinsic_ret_val (proc:Id.proc_t) =
  match ((module_of_proc proc), (name_of_proc proc)) with
  | ("System", "time")
  | ("System", "read_float") -> TFloat
  | ("System", "read_int") 
  | ("System", "errno") -> TInt
  | ("System", "eof") -> TBool
  | ("System", "O_RDONLY")
  | ("System", "O_WRONLY")
  | ("System", "O_RDWR")
  | ("System", "O_NONBLOCK")
  | ("System", "O_APPEND")
  | ("System", "O_CREAT")
  | ("System", "O_TRUNC")
  | ("System", "O_EXCL")
  | ("System", "O_NOCTTY")
  | ("System", "O_DSYNC")
  | ("System", "O_SYNC")
  | ("System", "O_RSYNC") -> TInt
  | ("System", "S_REG")
  | ("System", "S_DIR")
  | ("System", "S_CHR")
  | ("System", "S_BLK")
  | ("System", "S_LNK")
  | ("System", "S_FIFO")
  | ("System", "S_SOCK") -> TInt
  | ("System", "EACCES")
  | ("System", "ENOTDIR")
  | ("System", "ELOOP") -> TInt
  | ("Sockets", "PF_UNIX")
  | ("Sockets", "PF_INET")
  | ("Sockets", "SOCK_STREAM")
  | ("Sockets", "SOCK_DGRAM")
  | ("Sockets", "SOCK_SEQPACKET")
  | ("Sockets", "SOCK_RAW")
  | ("Graphics", "KEY_PRESSED")
  | ("Graphics", "BUTTON_DOWN")
  | ("Graphics", "BUTTON_UP") -> TInt
  | ("Graphics", "close_graph") -> TVoid
  | ("Graphics", "current_point_x")
  | ("Graphics", "current_point_y") -> TInt
  | ("Graphics", "key_pressed")
  | ("Graphics", "keypressed") -> TBool
  | ("Graphics", "last_key_pressed") -> TChar
  | ("Graphics", "last_click_x")
  | ("Graphics", "last_click_y") -> TInt
  | ("CRC", "reset") -> TVoid
  | ("CRC", "getValue") -> TInt
  | ("Zip", "needs_input") -> TBool
  | ("Zip", "adler") -> TInt
  | ("Zip", "finish")
  | ("Zip", "reset")
  | ("Zip", "end") -> TVoid
  | _ -> failwith "inconsistent state"
        
let type_check_intrinsics (proc:Id.proc_t) (args:value_type list):value_type =
  if not (is_intrinsic proc) then
    failwith "why did you give me a non-intrinsic?";
  let punt () = failwith ("type error on "^(module_of_proc proc)^"."^(name_of_proc proc)) in
  if (is_noarg_intrinsic proc) then
    begin
      if args <> [] then
        punt();
      lookup_noarg_intrinsic_ret_val proc
    end
  else
    match ((module_of_proc proc), (name_of_proc proc)) with
      ("System", "print_int") -> 
        List.iter (function (TInt) -> ()
          | y -> failwith ("type error on print_int: got "^(string_of_value_type y))) args; 
        TVoid
    | ("System", "print_string") -> 
        List.iter (function (TString) -> ()
          | _ -> punt()) args;
        TVoid
    | ("System", "print_stringbuffer") -> 
        List.iter (function (TObj "StringBuffer") -> ()
          | _ -> punt()) args;
        TVoid
    | ("System", "output_string") -> 
        if args <> [TObj "out_channel"; TString] then
          punt();
        TVoid
    | ("System", "output") -> 
        if args <> [TObj "out_channel"; TArray TByte; TInt; TInt] then
          punt();
        TVoid
    | ("System", "in_channel_of_file_descr") -> 
        if args <> [TObj "file_descr"] then
          punt();
        TObj "in_channel"
    | ("System", "out_channel_of_file_descr") -> 
        if args <> [TObj "file_descr"] then
          punt();
        TObj "out_channel"
    | ("System", "print_float") -> 
        List.iter (function (TFloat) -> ()
          | _ -> punt()) args;
        TVoid
    | ("System", "float_of_int") ->
        if args <> [TInt] then
          punt();
        TFloat
    | ("System", "int_of_float") ->
        if args <> [TFloat] then
          punt();
        TInt
    | ("System", "char_of_int") ->
        if args <> [TInt] then
          punt();
        TChar
    | ("System", "byte_of_int") ->
        if args <> [TInt] then
          punt();
        TByte
    | ("System", "string_of_int") ->
        if args <> [TInt] then
          punt();
        TString
    | ("System", "byte_array_of_string") ->
        if args <> [TString] then
          punt();
        TArray TByte
    | ("System", "arraycopy") ->
        (match args with
        | [TArray a; TInt; TArray b; TInt; TInt] when a = b -> TVoid
        | _ -> punt ())
    | ("System", "string_of_stringbuffer") ->
        if args <> [TObj "StringBuffer"] then
          punt();
        TString
    | ("System", "int_of_string") ->
        if args <> [TString] then
          punt();
        TInt
    | ("System", "float_of_string") ->
        if args <> [TString] then
          punt();
        TFloat
    | ("System", "open_in") -> 
        if args <> [TString] then
          punt();
        TObj "in_channel"
    | ("System", "input_line") -> 
        if args <> [TObj "in_channel"] then
          punt();
        TString
    | ("System", "close_in") -> 
        if args <> [TObj "in_channel"] then
          punt();
        TVoid
    | ("System", "close_out") -> 
        if args <> [TObj "out_channel"] then
          punt();
        TVoid
    | ("System", "flush") -> 
        if args <> [TObj "out_channel"] then
          punt();
        TVoid
    | ("System", "exit") ->
        if args <> [TInt] then
          punt();
        TVoid
    | ("System", "hash_code") ->
        (match (List.hd args) with
        | TObj _ -> TInt
        | _ -> punt())
    | ("System", "mime_time") ->
        (match args with
          [TFloat] -> TString
        | _ -> punt())
    | ("System", "unmime_time") ->
        (match args with
          [TString] -> TFloat
        | _ -> punt())
    | ("System", "read") ->
        (match args with
        | [TObj "file_descr"; TObj "StringBuffer"; TInt; TInt] -> TInt
        | _ -> punt())
    | ("System", "write") ->
        (match args with
        | [TObj "file_descr"; TString; TInt; TInt] -> TInt
        | _ -> punt())
    | ("System", "openfile") ->
        (match args with 
        | [TString; TInt; TInt] ->
            TObj "file_descr" 
        | _ -> punt())
    | ("System", "fstat") ->
        (match (List.hd args) with
        | TObj "file_descr" -> TObj "file_stats"
        | _ -> punt())
    | ("System", "st_size")
    | ("System", "st_kind") ->
        (match (List.hd args) with
        | TObj "file_stats" -> TInt
        | _ -> punt())
    | ("System", "st_mtime") ->
        (match (List.hd args) with
        | TObj "file_stats" -> TFloat
        | _ -> punt())
    | ("System", "close") ->
        (match (List.hd args) with
        | TObj "file_descr" -> TVoid
        | _ -> punt())
    | ("System", "heap_dump") ->
        if (List.length args < 4) then 
          failwith "not enough args for heap_dump";
        let rec heapdump_check_arg_types args = match args with
        | [] -> ()
        | TObj _ :: TString :: rest -> heapdump_check_arg_types rest
        | _ -> 
            failwith 
              "heap dump arguments must be: string string (object string)*" in
        (match args with
        | TString :: TString :: rest -> heapdump_check_arg_types rest
        | _ -> failwith "type error on heap_dump args 1, 2");
        TVoid
    | ("System", "random") -> 
        if args <> [TInt] then
          punt();
        TInt
    | ("System", "srand") -> 
        if args <> [TInt] then
          punt();
        TVoid
    | ("Math", "abs") -> 
        (match args with
          [TFloat] -> TFloat
        | _ -> punt())
    | ("Math", "exp") -> 
        (match args with
          [TFloat] -> TFloat
        | _ -> punt())
    | ("Math", "pow") -> 
        (match args with
          [TFloat; TFloat] -> TFloat
        | _ -> punt())
    | ("Math", "sqrt") -> 
        (match args with
          [TFloat] -> TFloat
        | _ -> punt())
    | ("Math", "sin") -> 
        (match args with
          [TFloat] -> TFloat
        | _ -> punt())
    | ("Math", "cos") -> 
        (match args with
          [TFloat] -> TFloat
        | _ -> punt())
    | ("Math", "acos") -> 
        (match args with
          [TFloat] -> TFloat
        | _ -> punt())
    | ("String", "get") -> 
        (match args with
          [TString; TInt] -> TChar
        | _ -> punt())
    | ("String", "string_after") -> 
        (match args with
          [TString; TInt] -> TString
        | _ -> punt())
    | ("String", "string_before") -> 
        (match args with
          [TString; TInt] -> TString
        | _ -> punt())
    | ("String", "index") 
    | ("String", "rindex") ->
        (match args with
          [TString; TChar] -> TInt
        | _ -> punt())
    | ("String", "contains") -> 
        (match args with
          [TString; TChar] -> TBool
        | _ -> punt())
    | ("String", "length") -> 
        (match args with
          [TString] -> TInt
        | _ -> punt())
    | ("String", "make") -> 
        (match args with
          [TInt; TChar] -> TString
        | _ -> punt())
    | ("String", "chr") -> 
        (match args with
          [TInt] -> TString
        | _ -> punt())
    | ("Sockets", "socket") -> 
        if args <> [TInt] then
          punt();
        TObj "file_descr"
    | ("Sockets", "bind") -> 
        if args <> [TObj "file_descr"; TInt] then
          punt();
        TVoid
    | ("Sockets", "listen") -> 
        if args <> [TObj "file_descr"; TInt] then
          punt();
        TInt
    | ("Sockets", "accept") -> 
        if args <> [TObj "file_descr"] then
          punt();
        TObj "file_descr"
    | ("Sockets", "string_of_inet_addr_of_socket") -> 
        if args <> [TObj "file_descr"] then
          punt();
        TString
    | ("Graphics", "open_graph") ->
        if args <> [TString] then
          punt();
        TVoid
    | ("Graphics", "colour") ->
        if args <> [TString] then
          punt();
        TInt
    | ("Graphics", "set_colour") ->
        if args <> [TInt] then
          punt();
        TVoid
    | ("Graphics", "set_line_width") ->
        if args <> [TInt] then
          punt();
        TVoid
    | ("Graphics", "moveto") -> 
        if args <> [TInt; TInt] then
          punt();
        TVoid
    | ("Graphics", "lineto") ->
        if args <> [TInt; TInt] then
          punt();
        TVoid
    | ("Graphics", "fill_circle") ->
        if args <> [TInt; TInt; TInt] then
          punt();
        TVoid
    | ("Graphics", "fill_rect") ->
        if args <> [TInt; TInt; TInt; TInt] then
          punt();
        TVoid
    | ("Graphics", "fill_poly") ->
        if args <> [TArray TInt; TArray TInt] then
          punt();
        TVoid
    | ("Graphics", "text_size_x") ->
        if args <> [TString] then
          punt();
        TInt
    | ("Graphics", "text_size_y") ->
        if args <> [TString] then
          punt();
        TInt
    | ("Graphics", "draw_string") -> 
        if args <> [TString] then
          punt();
        TVoid
    | ("Graphics", "get_image") -> 
        if args <> [TInt; TInt; TInt; TInt] then
          punt();
        TArray (TArray TInt)
    | ("Graphics", "draw_image") -> 
        if args <> [TArray (TArray TInt); TInt; TInt] then
          punt();
        TVoid
          (* input; uses state *)
    | ("Graphics", "wait_next_event") -> 
        if args <> [TInt] then
          punt();
        TVoid
    | ("CRC", "update") ->
        if args <> [TArray TByte] then
          punt();
        TVoid
    | ("Zip", "set_input") -> 
        if args <> [TArray TByte] then
          punt();
        TVoid
    | ("Zip", "deflate") -> 
        if args <> [TArray TByte; TInt; TInt] then
          punt();
        TInt
    | _ -> failwith "undefined intrinsic!"

