package ca.uwaterloo.ece251;

/** AST representation of an "order" expression (pre, post, levelorder). */
public class OrderExpr implements Expr {
    Expr.Order c;
    Expr v;

    public OrderExpr(Expr.Order c, Expr v) {
	this.c = c; this.v = v;
    }

    /** Convert "this" expression to a <code>ListValue</code>
     * representing the given order traversal, using
     * <code>Value.traverse()</code>. */
    public Value eval(Interp interp) {
	Value arg = v.eval(interp);
	return arg.traverse(c);
    }
}