package ca.uwaterloo.ece251.codegen;

import java.io.PrintWriter;
import java.util.List;
import java.util.LinkedList;
import java.util.Map;
import java.util.Stack;
import ca.uwaterloo.ece251.ast.*;
import ca.uwaterloo.ece251.symbol.*;
import ca.uwaterloo.ece251.type.TypeCheckingVisitor;

public class CodeGenVisitor extends DefaultVisitor
{
    PrintWriter w;
    String base;
    String url;
    TypeCheckingVisitor tv;
    Session currentSession;
    int labelCount = 0;

    public CodeGenVisitor(PrintWriter w, String base, String url, TypeCheckingVisitor tv) {
	this.w = w; this.base = base; this.url = url; this.tv = tv;
    }

    public void enter(Service s) {
	w.println("#include <stdio.h>");
	w.println("#include <stdbool.h>");
	w.println("#include <string.h>");
	w.println("#include <stdlib.h>");
	w.println("#include <time.h>");
	w.println("#include \"runwig.h\"");
	w.println();
	w.println("char *url;");
	w.println("char *sessionid;");
	w.println("int pc;");
	w.println("FILE *f;");
	w.println();
    }
    public void leave(Service s) {
	w.close();
    }

    /** Emit a function header for a function producing the given HTML.
     * Function takes the plug ids as arguments (each of type char *). 
     * e.g. 'void output_Total(char *total) {' */
    public void enter(HTML h) {
    }
    /** Emit a printf statement with the escaped contents of HTMLBody b. 
     * You may bail out if b.contents is whitespace-only. 
     * Util.escape() is useful here.
     * e.g. 'printf("Welcome!\n");' */
    public void enter(WhateverHTMLBody b) {
    }
    /** Same as Whatever, except that you should call toString() on b. */
    public void enter(InputHTMLBody b) {
    }
    /** Emit a print statement for the given plug. 
     * e.g. printf("%s", total); */
    public void enter(PlugHTMLBody b) {
    }

    /* Emit code to finish writing the HTML function. */
    public void leave(HTML h) {
    }

    /** Emit boilerplate code to begin a session. */
    public void enter(Session s) {
	currentSession = s;

	printVariableDeclarations(s);

	String sessionName = s.id.toString();
	w.println("int main() {");
	w.println("  srand48(time(0L));");
	w.println("  parseFields();");
	w.println("  url = \""+url+"\";");
	w.println("  sessionid = getenv(\"QUERY_STRING\");");
	w.println();
	w.println("  if (strcmp(sessionid, \""+sessionName+"\")==0)");
	w.println("    goto start_"+sessionName+";");
	w.println("  if (strncmp(sessionid, \""+sessionName+"$\","+
		  (sessionName.length()+1)+")==0)");
	w.println("    goto restart_"+sessionName+";");
	w.println("  printf(\"Content-type: text/html\\n\\n\");");
	w.println("  printf(\"<title>Illegal Request</title>\\n\");");
	w.println("  printf(\"<h1>Illegal Request: %s</h1>\\n\",sessionid);");
	w.println("  exit(1);");
	w.println();
	w.println("start_"+sessionName+":");
	w.println("  sessionid = randomString(\""+sessionName+"\",20);");
	// body of session follows
    }

    /** Generate a qualified name for s,
	e.g. local_Contribute_i. 
    * This helps with disambiguation in the presence of functions and
    * compound statements, which we're not implementing. */
    private String qualifiedVariableName(Id s) {
	return "local_"+currentSession.id+"_"+s.toString();
    }

    /** Emit variable declarations for the variables in Session s.
     * Hint: call getScope() with s's body. */
    private void printVariableDeclarations(Session s) {
    }

    /** Emit code to evaluate a given experssion.
     * Use the ExpVisitor to generate this code, to keep the
     * main CodeGenVisitor simpler. */
    public void leave(EvalStm s) {
	w.println("  /* "+s.toString()+" */");
        w.print("  ");
	ExpVisitor ev = new ExpVisitor();
	s.c.accept(ev);
	w.print(ev.rv.toString());
	w.println(";");
    }

    /** Emit code to show an HTML (first half). */
    public void enter(ShowStm s) {
        w.println("  /* show "+s.d.toString()+"... */");
	w.println("  printf(\"Content-type: text/html\\n\\n\");");
	w.println("  printf(\"<form method=\\\"POST\\\" action=\\\"%s?%s\\\">\\n\",url,sessionid);");
    }

    /** Call the function we declared earlier to output an HTML (no plugs). 
     * e.g. output_Welcome(); */
    public void enter(BaseDocument s) {
    }

    /** Call the function we declared earlier to output an HTML
     * (plugs).  Iterate over plugContents. Don't forget that you have:
     * 1) Util.commaSeparated and 2) a handy ExpVisitor to emit code
     * for the plug contents. 
     * You should also wrap ints with an itoa() call.
     * e.g. output_Total(itoa(getGlobalInt("global_tiny_amount"))); */
    public void enter(PlugDocument d) {
    }

    /* Emit code to show an HTML (second half: receives).
     * For each receive, fill in the local variable with the 
     * value you get from the CGI arguments, provided by getField.
     * Wrap in atoi() for integer variables.
     * i.e. local_Contribute_i = atoi(getField("contribution")); */
    public void leave(ShowStm s) {
	w.println("  printf(\"<p><input type=\\\"submit\\\" value=\\\"continue\\\">\\n\");");
	w.println("  printf(\"</form>\\n\");");
	saveVariables();

	w.println("  /* ... receive ["+Util.commaSeparated(s.receives)+"]; */ ");
	// write more code here.
    }

    /** Boilerplate code before an exit statement. */
    public void enter(ExitStm s) {
        w.println("  /* "+s.toString()+" */");
	w.println("  printf(\"Content-type: text/html\\n\\n\");");
    }

    /** Boilerplate code after an exit statement. */
    public void leave(ExitStm s) {
	w.println("  exit(0);");
    }

    public void enter(IfStm s) {
	// need not implement
    }

    public void enter(WhileStm s) {
	// need not implement
    }

    public void enter(CompoundStm s) {
	// need not implement
    }

    public void enter(ReturnStm s) {
	// need not implement
    }

    public void enter(ReturnVoidStm s) {
	// need not implement
    }

    /** Boilerplate code. Note that it also emits code to restore
     * variables, including the PC. */
    public void leave(Session s) {
	w.println("restart_"+s.id+":");
	w.println("  f = fopen(sessionid, \"r\");");
	w.println("  fscanf(f, \"%i\\n\",&pc);");
	restoreVariablesHelper();
	for (int i = 1; i <= labelCount; i++) {
	    w.println("  if (pc=="+i+") goto "+s.id+"_"+i+";");
	}
        w.println("}");
    }

    /** Emit boilerplate code around saving variables. */
    private void saveVariables() {
	w.println("  f = fopen(sessionid,\"w\");");
	w.println("  fprintf(f, \""+(labelCount+1)+"\\n\");");
	saveVariablesHelper();
	w.println("  fclose(f);");
	w.println("  exit(0);");
	labelCount++;
	w.println(currentSession.id+"_"+labelCount+":");
    }

    /** Emit code to actually save the variables.
     * Use fprintf with %i for ints and bools and %s for strings.
     * The symbol table tells you the names and types of the variables.
     * e.g. fprintf(f, "%i\n", local_Contribute_i); */
    private void saveVariablesHelper() {
    }
    /** Emit code to restore the variables.
     * Mostly the converse of saveVariablesHelper().
     * Note that this is like register spilling.
     * Don't forget that you should & scanf args if they're ints,
     *  but not strings.
     * e.g. fscanf(f, "%i\n", &local_Contribute_i);*/
    private void restoreVariablesHelper() {
    }

    /** Helper class to emit code for expressions. */
    class ExpVisitor extends DefaultVisitor {
	/** Buffer for the expression being emitted. */
	StringBuffer rv = new StringBuffer();
	/** When silence is nonempty, don't emit anything. */
	Stack silence = new Stack();

	/** Shh! */
	public void enter(AssignExp e) {
	    silence.push(new Object());
	}

	/** Create code for the assignment expression. 
	 * This is a bit tricky. I recommend that you
	 * create new ExpVisitors for both the lhs and rhs,
	 * and add the resulting strings together with an "=" sign 
	 * in between.
	 * However, there is one special case: if you are assigning to a
	 * _global_ variable (not in the curent scope), then you
	 * have to call putGlobalInt() instead of using the = sign.
	 * e.g. local_Contribute_i = local_Contribute_i + 1;
	 * e.g. putGlobalInt("global_tiny_amount", local_Contribute_i + 1); */
	public void leave(AssignExp e) {
	}

	/** Shh! */
	public void enter(BinopExp e) {
	    silence.push(new Object());
	}
	/** Emit code for the binary expression.
	 * Similar to leave(assignExp), except that you have to
	 * account for precedence.
	 * See the toString() method of BinopExp for hints. 
	 */
	public void leave(BinopExp e) {
	}
	public void enter(CallExp ce) {
	    // do not implement
	}
	public void enter(TupleopExp te) {
	    // do not implement
	}

	/** Shh! */
	public void enter(UnopExp ue) {
	    silence.push(new Object());
	}
	/** Write the unary expression, preceded by its operator. 
	 * Similar to BinopExp. */
	public void leave(UnopExp ue) {
	}

	/** Emit name of variable lv. If lv exists in the
	 * local scope, call qualifiedVariableName. Otherwise
	 * it is a global. 
	 * e.g. local_Contribute_i, getGlobalInt("global_tiny_amount") */
	public void leave(Lvalue lv) {
	}
	/** Emit boolean literal. */
	public void leave(BoolLiteralExp be) {
	    if (silence.isEmpty())
		rv.append(be.v ? "true" : "false");
	}
	/** Emit int literal. */
	public void leave(IntLiteralExp ie) {
	    if (silence.isEmpty())
		rv.append(ie);
	}
	/** Emit string literal. */
	public void leave(StringLiteralExp se) {
	    if (silence.isEmpty())
		rv.append(se);
	}

	public void leave(TupleLiteralExp te) {
	    // do not implement
	}
    }

    /** Helper function returning true if t is an int or bool. */
    private boolean isInt(Type t) {
	return t instanceof SimpleType && 
	    ((SimpleType)t).t == SimpleType.SimpleTypes.INT ||
	    ((SimpleType)t).t == SimpleType.SimpleTypes.BOOL;
    }
    /** Helper function returning true if t is a string. */
    private boolean isString(Type t) {
	return t instanceof SimpleType && 
	    ((SimpleType)t).t == SimpleType.SimpleTypes.STRING;
    }
}
