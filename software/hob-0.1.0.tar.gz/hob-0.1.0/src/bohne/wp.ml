(* Compute weakest preconditions *)

open Iabsyn
open Vcform
open Vctrans
open Id

type stmnt = 
  | EGuard of Iabsyn.expr 
  | FGuard of Vcform.form
  | Update of Iabsyn.expr
  | Havoc of Id.var_t list


type trace = stmnt list

let add_guard trace e = EGuard e::trace
let add_guard_from_form trace e = FGuard e::trace
let add_update trace e = Update e::trace
let add_havoc trace vs = Havoc vs::trace

let vcexpr_of_iabsyn mn e =
  let (precond : Vcform.form list ref) = ref [] in
  let add_precond f = (precond := f :: !precond) in
  let rec vcexpr_of_iabsyn0 e =
    match e with
    | LiteralExpr v -> (match v with
      | Int i -> Const (IntConst i)
      | Bool b -> Const (BoolConst b)
      | Obj n when v = Iabsyn.null_obj -> (Const NullConst)
      | Array a when a = [||] -> mk_newArray(mk_int 0,mk_null)
      | _ -> failwith "unsupported literal")
    | VarExpr lv -> (match lv with
      | LocalLvalue l -> Var (mk_local_var l)
      | RefLvalue v -> Var (mk_global_var mn v)
      | FieldLvalue (base, _) 
      | ArrayLvalue (base, _) ->
          failwith "don't yet support these varexprs")
    | FieldAccessExpr (base, f) ->
        let f' = mk_var (name_of_field f) in
        let base' = vcexpr_of_iabsyn0 base in
        let nullCheck = mk_neq(base', mk_null) in
        let _ = add_precond nullCheck in
        Vcform.App (f', [base'])
    | ArrayAccessExpr (base, i) ->
        let i' = vcexpr_of_iabsyn0 i in
        let base' = vcexpr_of_iabsyn0 base in
        let boundsCheck = mk_and[mk_lteq(mk_int 0, i');
                                 mk_lt(i',mk_arraySize base')] in
        let _ = add_precond boundsCheck in
        Vcform.mk_functionApply(ArrayRead,base',i')
    | ArrayLengthExpr (base) ->
        let base' = vcexpr_of_iabsyn0 base in
        mk_arraySize base'
    | NewExpr t -> 
        failwith "don't yet support newexpr"
    | NewArrayExpr (Types.TObj _, [e], d) (* when d=1 *) ->
        mk_newArray(vcexpr_of_iabsyn0 e, mk_null)
    | NewArrayExpr (_,_,_) ->
        failwith "vctrans, NewArrayExpr: only support 1-dimensional arrays of objects"
    | InvokeExpr (targ, args0) ->
        failwith "encountered a nested proc invocation, please unnest"
    | AssignExpr _ ->
        failwith "no assign in vc expr please!"
    | PostDecExpr e
    | PostIncExpr e
    | PreDecExpr e
    | PreIncExpr e -> 
        failwith "no side effects for vc stmts please!"
    | NegExpr e ->
        failwith "arith not yet in vc"
    | PlusExpr (lhs, rhs) ->
        mk_plus (vcexpr_of_iabsyn0 lhs, vcexpr_of_iabsyn0 rhs)
    | MinusExpr (lhs, rhs) ->
        mk_minus (vcexpr_of_iabsyn0 lhs, vcexpr_of_iabsyn0 rhs)
    | MultExpr (lhs, rhs) ->
        mk_mult (vcexpr_of_iabsyn0 lhs, vcexpr_of_iabsyn0 rhs)
    | DivExpr (lhs, rhs) ->
        mk_div (vcexpr_of_iabsyn0 lhs, vcexpr_of_iabsyn0 rhs)
    | ModExpr (lhs, rhs) ->
        mk_mod (vcexpr_of_iabsyn0 lhs, vcexpr_of_iabsyn0 rhs)
    | BitAndExpr (lhs, rhs)
    | BitOrExpr (lhs, rhs)
    | BitXorExpr (lhs, rhs)
    | ShiftLeftExpr (lhs, rhs)
    | SignedShiftRightExpr (lhs, rhs)
    | UnsignedShiftRightExpr (lhs, rhs) ->
        failwith "arith not yet in vc"
    | AndExpr (lhs, rhs) ->
        mk_and [vcexpr_of_iabsyn0 lhs;
                vcexpr_of_iabsyn0 rhs]
    | OrExpr (lhs, rhs) ->
        mk_or [vcexpr_of_iabsyn0 lhs;
               vcexpr_of_iabsyn0 rhs]
    | NotExpr e ->
        mk_not (vcexpr_of_iabsyn0 e)
    | EqExpr (lhs, rhs) ->
        mk_eq (vcexpr_of_iabsyn0 lhs,
               vcexpr_of_iabsyn0 rhs)
    | NeqExpr (lhs, rhs) ->
        mk_not (mk_eq (vcexpr_of_iabsyn0 lhs,
                       vcexpr_of_iabsyn0 rhs))
    | LtExpr (lhs, rhs) ->
        mk_lt (vcexpr_of_iabsyn0 lhs,
               vcexpr_of_iabsyn0 rhs)
    | GtExpr (lhs, rhs) ->
        mk_gt (vcexpr_of_iabsyn0 lhs,
               vcexpr_of_iabsyn0 rhs)
    | LteqExpr (lhs, rhs) ->
        mk_lteq (vcexpr_of_iabsyn0 lhs,
                 vcexpr_of_iabsyn0 rhs)
    | GteqExpr (lhs, rhs) ->
        mk_gteq (vcexpr_of_iabsyn0 lhs,
                 vcexpr_of_iabsyn0 rhs)
  in let res = vcexpr_of_iabsyn0 e in
  (res, mk_and !precond)

let assign modn (v:ident) (rhs:Iabsyn.expr) (f:Vcform.form) =  
  let vc_rhs, pre = vcexpr_of_iabsyn modn rhs in 
  (subst [(v, vc_rhs)] f, pre)
    
let functionUpdate (typeOfUpdate:constValue) (modn:string) (v:ident) (vc_ind:Vcform.form) (rhs:Iabsyn.expr) (f:Vcform.form) =
  let vc_rhs, pre = vcexpr_of_iabsyn modn rhs in
  let vc_functionUpdate = mk_functionUpdate(typeOfUpdate, mk_var v, vc_ind, vc_rhs) in
  (subst [(v, vc_functionUpdate)] f, pre)
    
let arrayAssign (modn:string) (v:ident) (ind:Iabsyn.expr) (rhs:Iabsyn.expr) (f:Vcform.form) =
  let vc_ind, pre1 = vcexpr_of_iabsyn modn ind in
  let boundsCheck = mk_and[mk_lteq(mk_int 0, vc_ind);
                           mk_lt(vc_ind, mk_arraySize (mk_var v))] in
  let fupd, pre2 =  functionUpdate ArrayWrite modn v vc_ind rhs f in
  (fupd, smk_and [pre1;boundsCheck;pre2])

let fieldAssign (modn:string) (field:ident) (lhs:Iabsyn.expr) (rhs:Iabsyn.expr) (f:Vcform.form) = 
  let vc_lhs, pre1 = vcexpr_of_iabsyn modn lhs in
  let nullCheck = mk_neq (vc_lhs, mk_null) in
  let fupd, pre2 = functionUpdate FieldWrite modn field vc_lhs rhs f in
  (fupd, smk_and [pre1;nullCheck;pre2])

let rec wp_stmnt modn (e:expr) (f:form) : form * form =
  match e with
    | AssignExpr(LocalLvalue v,rhs) -> 
        assign modn (mk_local_var v) rhs f
    | AssignExpr(RefLvalue v,rhs) -> 
        assign modn (mk_global_var modn v) rhs f
    | AssignExpr(ArrayLvalue(VarExpr (LocalLvalue v),e2),rhs) -> 
        arrayAssign modn (mk_local_var v) e2 rhs f
    | AssignExpr(ArrayLvalue(VarExpr (RefLvalue v),e2),rhs) -> 
        arrayAssign modn (mk_global_var modn v) e2 rhs f
    | AssignExpr(FieldLvalue(base,fld),rhs) ->
        fieldAssign modn (mk_global_var modn (Id.name_of_field fld)) base rhs f
    | AssignExpr(_,_) ->
        failwith "Vcwp.wp_expr: assignment expression not simple enough"
    | InvokeExpr(p,es) -> 
        Util.warn ("Vcwp.wp_expr: Ignored procedure call to " ^ Id.name_of_proc p); (f, Vcform.mk_true)
    | _ -> Util.warn
         ("Vcwp.wp_expr: don't know how to handle expression " ^ 
         Iabsynprinter.string_of_expr e); failwith "bohne/wp: FAIL FAST!!!" (* (f, Vcform.mk_true) *)

let wp_updates mn trace f = 
  let wp' f c =
    match c with
    | Update e -> fst (wp_stmnt mn e f)
    | _ -> f
    in
    List.fold_left wp' f trace

let null_checks mn trace =
  let null_check' checks c =
    match c with
    | Update e -> 
	let wp_checks, check = wp_stmnt mn e checks in
	smk_and [check;wp_checks]
    | EGuard e -> 
	let _, check = vcexpr_of_iabsyn mn e in
	smk_and [check;checks]
    | _ -> checks
  in
  List.fold_left null_check' Vcform.mk_true trace

let guard mn trace = 
    let guard' g c =
      match c with
      |	Update e -> fst (wp_stmnt mn e g)
      |	EGuard e ->
	  let g_e, _ = vcexpr_of_iabsyn mn e in
	  smk_and [g_e; g]
      |	FGuard g' -> smk_and [g'; g]
      |	_ -> g
    in
    List.fold_left guard' Vcform.mk_true trace

let wp mn trace f =
  let wp' f c =
    match c with
    | Update e -> 
	let wp_f, check = wp_stmnt mn e f in
	smk_and [check; wp_f]
    | Havoc vs -> 
	let vs_typ = List.map (fun v -> (v, TypeObjRef "")) vs in
	smk_foralls (vs_typ, f)
    | EGuard e ->
	let g_e, g_check = vcexpr_of_iabsyn mn e in
	smk_and [g_check; smk_impl (g_e, f)]
    | FGuard g ->
	smk_impl (g, f)
  in
  List.fold_left wp' f trace

(* Pretty printing for traces *)

let print_iabsyn_expr outchan e =
  let out = output_string outchan
  and pfout = Printf.fprintf outchan in
  let rec print_value v =
    match v with
    | Bool b -> pfout "%B" b
    | Obj o when v = null_obj -> out "null"
    |  _ -> failwith "unimplemented value"
  and print_lvalue lv =
    match lv with
    | LocalLvalue vt -> out vt
    | RefLvalue vt -> out vt
    | FieldLvalue (e, fd) -> print_expr e; out "."; out fd.Id.f_name
    | _ -> failwith "unimplemented lvalue"
  and pprint_expr pe e =
    let prec e =
      match e with
      |	AssignExpr _ -> 0
      |	OrExpr _ -> 1
      |	AndExpr _ -> 2
      | EqExpr _ | NeqExpr _ -> 3
      |	NotExpr _ | FieldAccessExpr _ -> 4 
      |	_ -> 4
    in 
    if prec pe > prec e then (out "("; print_expr e; out ")")
    else print_expr e
  and print_expr pe =
    match pe with 
    | LiteralExpr v -> print_value v
    | VarExpr lv -> print_lvalue lv
    | FieldAccessExpr (e, fd) -> pprint_expr pe e; out "."; out fd.Id.f_name
    | AssignExpr (lv, e) -> print_lvalue lv; out " = "; print_expr e
    | AndExpr (e1, e2) -> pprint_expr pe e1; out " && "; pprint_expr pe e2
    | OrExpr (e1, e2) -> pprint_expr pe e1; out " || "; pprint_expr pe e2
    | NotExpr e1 -> out "!"; pprint_expr pe e1
    | EqExpr (e1, e2) -> pprint_expr pe e1; out " == "; pprint_expr pe e2
    | NeqExpr (e1, e2) -> pprint_expr pe e1; out " != "; pprint_expr pe e2
    | _ -> failwith "unimplemented expr"
  in
  print_expr e

let print_trace outchan trace =
  let out = output_string outchan in
  let print_stmnt c =
    match c with
    | Update e -> print_iabsyn_expr outchan e; out ";\n"
    | Havoc vs -> 
	out "havoc "; 
	(match vs with
	| v::vs -> out v; List.iter (fun v -> out ", "; out v) vs
	| [] -> ());
	out ";\n"
    | EGuard e -> out "assume ("; print_iabsyn_expr outchan e; out ");\n"
    | FGuard f -> out "assume ("; out (Vcform.isabelle_formula f); out ");\n";
  in
  List.fold_right (fun c () -> print_stmnt c) trace ()
