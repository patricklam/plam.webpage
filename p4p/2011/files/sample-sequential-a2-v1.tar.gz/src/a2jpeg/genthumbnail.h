int create_thumbnail(char *filename, unsigned char *dest, int max);

//Scale image to (max x max)
struct ida_image* ece459_scale_thumbnail(struct ida_image *src, int max);

struct ida_image* scale_thumbnail(struct ida_image *src, int max);

int compress_thumbnail(struct ida_image *img, char *dest, int max);

struct ida_image* read_jpeg(char *filename);

