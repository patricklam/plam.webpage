// ElectricFieldControl.java
//
// Author: Raja Vallee-Rai
//
// This file is public domain.  You can do anything you want with 
// it, all at your own risk.  Enjoy!

import kor.base.*;
import java.awt.event.*;
import java.awt.*;

/**
 * This frame provides an interface to display and change the current external
 * electric field.
 */

class ElectricFieldControl extends Frame implements WindowListener, 
                                           ActionListener,
                                           AdjustmentListener,
                                           ItemListener
{
    static final int INITIAL_MAGNITUDE = 50,
                     MAX_MAGNITUDE = 100,
                     MIN_MAGNITUDE = 1;
                     
    Checkbox useBox;
    Button dismissButton;

    Playfield playfield;

    double dir;
    double magnitude;
    
    Scrollbar magnitudeBar;
    Label magnitudeLabel;

    Canvas diskCanvas;

    Label directionLabel, piAngleLabel, degreesAngleLabel;
            
    public ElectricFieldControl(Playfield playfield)
    {
        super("External Electric Field Control");
        
        this.playfield = playfield;
        
        addWindowListener(this);            
        setSize(new Dimension(400, 350));
        setLayout(new BorderLayout());

        WindowPlacer.placeWindowAt(this, "Northwest");

        // bottomPanel
        {
            Panel bottomPanel = new Panel();
            
            bottomPanel.setLayout(new GridLayout(0, 1));
            bottomPanel.add(new Label());

            // Use Button
            {
                Panel p = new Panel();
                
                p.setLayout(new FlowLayout());
                
                useBox = new Checkbox("External Electric Field On", false);
                useBox.addItemListener(this);
                p.add(useBox);
                
                bottomPanel.add(p);
            }

            // DismissButton
            {
                Panel p = new Panel();
                
                p.setLayout(new FlowLayout());
                
                dismissButton = new Button("Dismiss");
                p.add(dismissButton);
                dismissButton.addActionListener(this);
                
                bottomPanel.add(p);
            }
                        
            add(bottomPanel, "South");
        }
        
        // Center panel
        {
            Panel centerPanel = new Panel();
            
            centerPanel.setLayout(new BorderLayout());
            
            // Arrow Panel
            {
                Panel arrowPanel = new Panel();
                
                arrowPanel.setLayout(new BorderLayout());
                                
                arrowPanel.add(diskCanvas = new DiskCanvas(this), "Center");
                
                // direction panel
                {
                    Panel p = new Panel();
                    
                    p.setLayout(new GridLayout(0, 1));

                    // Sub-panel to center
                    {
                        Panel q = new Panel();
                                  
                        q.setLayout(new FlowLayout());
                        q.add(directionLabel = new Label("Direction: (+0.000, +0.000)"));
                        p.add(q);
                    }      
                    
                    // Sub-panel to center
                    {
                        Panel q = new Panel();
                                  
                        q.setLayout(new FlowLayout());
                        q.add(piAngleLabel = new Label(" 1.0pi"));
                        p.add(q);
                    }      
                    
                    // Sub-panel to center
                    {
                        Panel q = new Panel();
                                  
                        q.setLayout(new FlowLayout());
                        q.add(degreesAngleLabel = new Label(" 0 degrees"));
                        p.add(q);
                    }
                    
                    
                    updateDirectionAndLabels();
                    arrowPanel.add(p, "South");
                }
                
                centerPanel.add(arrowPanel, "Center");
            }
            
            // Scroll bar Panel
            {
                Panel barPanel = new Panel();
                
                barPanel.setLayout(new BorderLayout());
                
                magnitudeLabel = new Label("Magnitude");
                
                barPanel.add(magnitudeLabel, "South");

                // magnitude bar
                {
                    magnitudeBar = new Scrollbar(Scrollbar.VERTICAL, INITIAL_MAGNITUDE, 
                    5, MIN_MAGNITUDE, MAX_MAGNITUDE);
                
                    magnitudeBar.setBlockIncrement(10);
                    magnitudeBar.setUnitIncrement(1);
                    magnitudeBar.addAdjustmentListener(this);
                        
                    barPanel.add(magnitudeBar, "Center");
                }                
                
                updateMagnitudeAndLabel();
                
                centerPanel.add(barPanel, "East");
            }
            
            add(centerPanel, "Center");
        }
    }
    
    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource() == dismissButton)
        {
            handleClickToClose();
        }
    }
    
    public void itemStateChanged(ItemEvent e)
    {
        if(e.getSource() == useBox)
        {
            playfield.stopSimulatingIfNecessary();
            playfield.refreshViewers();
            playfield.updateForces();
            playfield.restartSimulatingIfNecessary();
        }
    }
    
    public void adjustmentValueChanged(AdjustmentEvent e)
    {
        if(e.getSource() == magnitudeBar);
        {
            playfield.stopSimulatingIfNecessary();
            
            updateMagnitudeAndLabel();
            playfield.refreshViewers();
            playfield.updateForces();
            
            playfield.restartSimulatingIfNecessary();
        }
    }

    public void setUseExternalField(boolean value)
    {
        useBox.setState(value);
        
        // no need to refresh (or pause simulation) because this is only called while 
        // restoring the state which does those things
    }

    public void setExternalField(double dir, double mag)
    {
        this.dir = dir; 
     
        updateDirectionAndLabels();
        
        magnitudeBar.setValue(barUnitsOfFactor(mag));
        updateMagnitudeAndLabel();
          
        // no need to refresh (or pause simulation) because this is only called while 
        // restoring the state which does those things
    }
    
    public boolean useExternalField()
    {
        return useBox.getState();
    }

    public DoublePair externalField()
    {
        return new DoublePair(Math.cos(dir) * magnitude, Math.sin(dir) * magnitude);
    }
        
    private 
    double factorOfBarUnits(int x)
    {
        return Math.pow(2, (x - 50) / 10.0);
    }
    
    private
    int barUnitsOfFactor(double x)
    {
        double minFactor = factorOfBarUnits(MIN_MAGNITUDE);
        double maxFactor = factorOfBarUnits(MAX_MAGNITUDE);
        
        x = Math.max(minFactor, x);
        x = Math.min(maxFactor, x);
        
        return (int) ((Math.log(x)/ Math.log(2.0)) * 10.0 + 50.0);
    }
    
    private
    void updateMagnitudeAndLabel()
    {
        magnitude = factorOfBarUnits(magnitudeBar.getValue());
        magnitudeLabel.setText("Magnitude: " + ExtDouble.truncatedOf(magnitude, 3));
    }

    void updateDirectionAndLabels()
    {
        directionLabel.setText("Direction: (" + ExtDouble.truncatedOf(Math.cos(dir), 3) + "," +
            ExtDouble.truncatedOf(Math.sin(dir), 3) + ")");
            
        double printDir = (dir >= 0) ? dir : dir + Math.PI * 2;
        
        degreesAngleLabel.setText(ExtDouble.truncatedOf(printDir / (2 * Math.PI) * 360.0, 1) + 
            " degrees");
            
        piAngleLabel.setText(ExtDouble.truncatedOf(printDir / Math.PI, 3) + "pi");   
    }
    
        
    void handleClickToClose()
    {
        setVisible(false);
    }

    public void windowClosing(WindowEvent e)
    {
        handleClickToClose();
    }
     
    public void windowOpened(WindowEvent e)
    {
    }
     
    public void windowIconified(WindowEvent e)
    {
    }
     
    public void windowDeiconified(WindowEvent e)
    {
    }
     
    public void windowClosed(WindowEvent e)
    {
    }
     
    public void windowActivated(WindowEvent e)
    {
    }
     
    public void windowDeactivated(WindowEvent e) 
    {
    }
}

class DiskCanvas extends Canvas implements MouseMotionListener
{
    int centerX;
    int centerY;

    int radius;
        
    ElectricFieldControl control;
    
    public DiskCanvas(ElectricFieldControl control)
    {
        this.control = control;
        this.addMouseMotionListener(this);
    }
    
    public void paint(Graphics g)
    {        
        Dimension size = getSize();
        radius = (Math.min(size.width, size.height) - 1) / 2;
                        
        centerX = (size.width - radius * 2) / 2 + radius; 
        centerY = (size.height - radius * 2) / 2 + radius;
        
        g.drawOval(centerX - radius, centerY - radius, radius * 2, radius * 2);
        
        control.playfield.viewer.drawArrow(g, centerX, centerY,
            centerX + (int) (Math.cos(control.dir) * radius), 
            centerY - (int) (Math.sin(control.dir) * radius), radius / 6);
    }
        
    public void mouseDragged(MouseEvent e)
    {
        double deltaX = e.getX() - centerX;
        double deltaY = e.getY() - centerY;
        
        if(Math.sqrt(deltaX * deltaX + deltaY * deltaY) >= 5.0)
        {
            // If she clicks on the center of the disk, ignore it.
            
            control.playfield.stopSimulatingIfNecessary();
            
            control.dir = Math.atan2(-deltaY, deltaX);
            control.updateDirectionAndLabels();
            
            control.playfield.refreshViewers();
            control.playfield.updateForces();
            
            control.playfield.restartSimulatingIfNecessary();
        }
        
        repaint();
    }
    
    public void mouseMoved(MouseEvent e)
    {
    }
}









