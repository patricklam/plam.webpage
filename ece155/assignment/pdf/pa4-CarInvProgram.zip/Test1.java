public class Test1 {
    public static void main(String[] argv) {
	CarList carList = new CarList();
	Car c1 = new Car(1,"Dodge","Dakota",1990,Car.CarColour.Green,30276);
	Car c2 = new Car(2,"Toyota","Highlander",1970,Car.CarColour.Green,60781);
	Car c3 = new Car(3,"Chevrolet","Silverado",2002,Car.CarColour.Orange,58485);

	carList.insertByYear(c1);
	carList.insertByYear(c2);
	carList.insertByYear(c3);
	System.out.println(carList);
	System.out.println(carList.getLength());
    }
}
