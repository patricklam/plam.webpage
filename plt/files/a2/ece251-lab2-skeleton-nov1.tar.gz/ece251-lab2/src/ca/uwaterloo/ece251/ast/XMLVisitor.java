package ca.uwaterloo.ece251.ast;

public class XMLVisitor extends AbstractVisitor {
    int tabLevel = 0;

    public void enter(SelectSingleSource t) {
	printTabs();
	System.out.printf("<select_source as='%s'>\n", t.as);
	tabLevel++;
    }

    public void enter(JoinSingleSource t) {
	printTabs();
	System.out.println("<join_source>");
	tabLevel++;
    }

    public void enter(IdExprPair t) {
	printTabs();
	System.out.printf("<id_expr id='%s'>\n", t.id);
	tabLevel++;
    }

    public void enter(UnaryOpExpr t) {
	printTabs();
	System.out.printf("<unary op='%s'>\n", t.op);
	tabLevel++;
    }

    public void enter(BinaryOpExpr t) {
	printTabs();
	System.out.printf("<binary op='%s'>\n", t.op);
	tabLevel++;
    }

    public void enter(ExprResultColumn t) {
	printTabs();
	System.out.println("<expr_result>");
	tabLevel++;
    }

    public void enter(CreateTableStmt t) {
	printTabs();
	System.out.printf("<create_table%s%s tn='%s'>\n",
			  t.temporary ? " temporary" : "",
			  t.ifNotExists ? " if_not_exists" : "",
			  t.tn.toString());
	tabLevel++;
    }

    public void enter(InsertStmt t) {
	printTabs();
	System.out.printf("<%s%s tn=%s%s>\n",
			  t.insert ? "insert" : "",
			  t.replace ? "replace" : "",
			  t.tn.toString(),
			  t.defaultValues ? " default_values" : "");
	tabLevel++;
    }

    public void enter(SelectStmt t) {
	printTabs();
	System.out.printf("<select%s%s>\n", 
			  t.distinct ? " distinct" : "",
			  t.all ? " all" : "");
	tabLevel++;
    }

    public void enter(UpdateStmt t) {
	printTabs();
	System.out.printf("<update value=\"%s\">\n", t.tn.toString());
	tabLevel++;
    }

    public void leave(SelectSingleSource t) {
	tabLevel--;
	printTabs();
	System.out.println("</select_source>");
    }

    public void leave(JoinSingleSource t) {
	tabLevel--;
	printTabs();
	System.out.println("</join_source>");
    }

    public void leave(QualifiedTableNameSingleSource t) {
	printTabs();
	System.out.printf("<tn_source tn='%s' as='%s' />\n", 
			  t.tn.toString(), t.as);
    }

    public void leave(ColumnDef t) {
	printTabs();
	System.out.printf("<column_def id=%s%s />\n", t.id, 
			  t.t == null ? "" : " type="+t.t.toString());
    }

    public void leave(IdExprPair t) {
	tabLevel--;
	printTabs();
	System.out.println("</id_expr>");
    }

    public void leave(UnaryOpExpr t) {
	tabLevel--;
	printTabs();
	System.out.println("</unary>");
    }

    public void leave(BinaryOpExpr t) {
	tabLevel--;
	printTabs();
	System.out.println("</binary>");
    }

    public void leave(LiteralExpr t) {
	printTabs();
	System.out.printf("<literal value=%s/>\n", t.value.toString());
    }

    public void leave(QualifiedTableNameExpr t) {
	printTabs();
	System.out.printf("<tn_expr value=%s />\n", t.tn.toString());
    }

    public void leave(ExprResultColumn t) {
	tabLevel--;
	printTabs();
	System.out.println("<expr_result/>");
    }

    public void leave(StarResultColumn t) {
	printTabs();
	if (t.table == null)
	    System.out.println("<star_result/>");
	else
	    System.out.printf("<star_result table=%s />\n", t.table);
    }

    public void leave(CreateTableStmt t) {
	tabLevel--;
	printTabs();
	System.out.println("</create_table>");
    }

    public void leave(DropTableStmt t) {
        System.out.printf("<drop_table%s %s/>\n", t.ifExists ? " if_exists" : "", t.tn);
    }

    public void leave(InsertStmt t) {
	System.out.printf("</%s%s>\n",
			  t.insert ? "insert" : "",
			  t.replace ? "replace" : "");
    }

    public void leave(SelectStmt t) {
	tabLevel--;
	printTabs();
	System.out.println("</select>");
    }

    public void leave(UpdateStmt t) {
	tabLevel--;
	printTabs();
	System.out.println("</update>");
    }

    public void leave(VacuumStmt t) {
	System.out.println("<vacuum />");
    }

    public void printTabs() {
	for (int i = 0; i < tabLevel; i++)
	    System.out.print(" ");
    }
}
