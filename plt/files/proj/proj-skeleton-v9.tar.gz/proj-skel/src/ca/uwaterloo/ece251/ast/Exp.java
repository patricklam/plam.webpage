package ca.uwaterloo.ece251.ast;

/** Generic superclass for expressions. */
abstract public class Exp implements ASTNode {
}
