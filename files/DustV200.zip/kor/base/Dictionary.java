// Dictionary.java
//
// Author: Raja Vallee-Rai
//
// This file is public domain.  You can do anything you want with 
// it, all at your own risk.  Enjoy!


package kor.base;

/**
 * An alternative Dictionary class provided in java.util.  The same concept, however:
 * you associate objects (definition objects) to other objects (entries).
 */

public
abstract class Dictionary
{
    /**
     * Associate a definitional object to an entry.
     */

    abstract
    public void associate(Object entry, Object associate);

    /**
     * Returns the definition of an entry.  
     *
     * @exception RuntimeException  if the entry has no associate.
     */
     
    abstract
    public Object associateOf(Object entry);

    /**
     * Does the entry have an associate?
     */
     
    abstract
    public boolean isObjAssociated(Object entry);

    /**
     * Returns the list of entries of the dictionary.
     */
     
    abstract
    public DynamicList listOfEntries();

    /**
     * Returns the list of definitional objects of the dictionary
     */
     
    abstract
    public DynamicList listOfAssociates();
}
