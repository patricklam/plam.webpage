open Iabsyn
open Types

let error_expr e s = 
  let (fn, p) = Ast.lookup_expr_pos e in
  Util.err (fn ^ " " ^ p) s

(* For each spec proc, check that there exists a same-named impl proc
   with the same parameters and return value. *)

let compare_mandatory_pair (s_n, s_t) (i_n, i_t) =
  i_n = s_n & i_t = s_t

let compare_pair s i =
  match (s, i) with
  | (None, None) -> true
  | (Some sp, Some ip) -> compare_mandatory_pair sp ip
  | _ -> false

(* need that we include modifies for any modifies in a callee *)
(* also check field accesses *)
let crosscheck_callees (m:Id.module_t) (ab:'a Aabsyn.abst_body)
    (ps:Sabsyn.proc_spec) (pi:'a Iabsyn.proc_def) (mi:'a Iabsyn.impl_module) =
  let crosscheck_field e et f =
    let fmt = 
      try
        List.find (fun x -> (TObj (x.format_name) = et)) 
          ab.Aabsyn.formats 
      with Not_found -> 
        List.find (fun x -> (TObj (x.format_name) = et)) 
          mi.Iabsyn.formats in
    if (not (List.exists (fun (fn,_) -> (fn = f))
               fmt.fields)) then
      error_expr e 
        ("Accessing abstraction-module-protected field "^
         (Id.name_of_field f)) in
  let rec crosscheck_callee_expr e =
    match e with
      Iabsyn.LiteralExpr _ -> ()
    | Iabsyn.VarExpr _ -> ()
    | Iabsyn.FieldAccessExpr (e', f) -> 
        crosscheck_callee_expr e';
        let et = Exprtbl.find Typechecker.typeof e' in
        crosscheck_field e et f
    | Iabsyn.ArrayAccessExpr (b, i) -> 
        crosscheck_callee_expr b; crosscheck_callee_expr i
    | Iabsyn.ArrayLengthExpr (b) -> 
        crosscheck_callee_expr b
    | Iabsyn.NewExpr _ -> ()
    | Iabsyn.NewArrayExpr _ -> ()
    | Iabsyn.InvokeExpr (p, args) -> 
        List.iter crosscheck_callee_expr args;
        (let cm = p.Id.p_module in
        let rv = 
          List.mem cm ps.Sabsyn.calls || Intrinsics.is_intrinsic p ||
          Scopes.is_call_internal m cm || cm = m in
        if not (rv) then
          error_expr e 
            ("Callee module "^cm^" not listed in spec");
        if not (Intrinsics.is_intrinsic p) then
          begin
            if (not ((Ast.has_spec_proc_by_t p) or 
                     (Ast.has_impl_proc_by_t p))) then
              error_expr e 
                ("Couldn't find any description of callee proc "^
                 (Id.name_of_proc p))
            else if (Ast.has_spec_proc_by_t p) then
              let cs = Ast.fetch_spec_proc_by_t p in
              if not ((Id.module_of_proc ps.Sabsyn.proc_name) = cm) &
                cs.Sabsyn.proc_modifiers.Id.is_private then
                error_expr e 
                  ("Calling private proc "^cm^"."^(Id.name_of_proc p));
              let hidden0 = 
                Scopes.compute_hidden_sets (Ast.fetch_spec m) cs in
              let hidden = List.map fst hidden0 in
              let callee_modified_sets = 
                Util.difference cs.Sabsyn.modifies hidden in
              if not (List.for_all 
                        (fun x -> 
                          List.mem x ps.Sabsyn.modifies ||
                          let xm = Util.unqualify_getting_module x in
                          Scopes.is_call_internal m xm) 
                        callee_modified_sets) then
                begin
                  let oops = Util.spacify ", " 
                      (List.filter 
                         (fun x -> not (List.mem x ps.Sabsyn.modifies)) 
                         cs.Sabsyn.modifies) in
                  error_expr e
                    ("Omitted modified sets "^oops^" belonging to callee "^
                     cm^"."^(Id.name_of_proc p))
                end
          end;
        if not (cm = m || Scopes.is_call_permissible ps cm) then
          error_expr e 
            ("Callee module "^cm^" violates scope calling condition"))
    | Iabsyn.AssignExpr (FieldLvalue (e', f), e) ->
        crosscheck_callee_expr e;
        crosscheck_callee_expr e';
        let et = Exprtbl.find Typechecker.typeof e' in
        crosscheck_field e' et f
    | Iabsyn.AssignExpr (_, e) -> crosscheck_callee_expr e
    | Iabsyn.PreIncExpr _ | Iabsyn.PostIncExpr _ 
    | Iabsyn.PreDecExpr _ | Iabsyn.PostDecExpr _ -> ()
    | Iabsyn.NotExpr e
    | Iabsyn.NegExpr e -> crosscheck_callee_expr e
    | Iabsyn.PlusExpr (e1, e2)
    | Iabsyn.MinusExpr (e1, e2)
    | Iabsyn.MultExpr (e1, e2)
    | Iabsyn.DivExpr (e1, e2)
    | Iabsyn.ModExpr (e1, e2)
    | Iabsyn.AndExpr (e1, e2)
    | Iabsyn.OrExpr (e1, e2)
    | Iabsyn.EqExpr (e1, e2)
    | Iabsyn.NeqExpr (e1, e2)
    | Iabsyn.LtExpr (e1, e2)
    | Iabsyn.GtExpr (e1, e2)
    | Iabsyn.LteqExpr (e1, e2)
    | Iabsyn.GteqExpr (e1, e2)
    | Iabsyn.BitAndExpr (e1, e2)
    | Iabsyn.BitOrExpr (e1, e2)
    | Iabsyn.BitXorExpr (e1, e2)
    | Iabsyn.ShiftLeftExpr (e1, e2)
    | Iabsyn.SignedShiftRightExpr (e1, e2)
    | Iabsyn.UnsignedShiftRightExpr (e1, e2) -> 
        crosscheck_callee_expr e1; crosscheck_callee_expr e1 in
  let rec crosscheck_callee_stmt s =
    match s with
      Iabsyn.EmptyStmt -> ()
    | Iabsyn.CompoundStmt cs -> List.iter crosscheck_callee_stmt cs
    | Iabsyn.ChoiceStmt (s, t) -> 
        crosscheck_callee_stmt s; crosscheck_callee_stmt t
    | Iabsyn.LocalDeclStmt (_, _, e) -> crosscheck_callee_expr e
    | Iabsyn.ExprStmt e -> crosscheck_callee_expr e
    | Iabsyn.ReturnStmt None -> ()
    | Iabsyn.ReturnStmt (Some rv) -> crosscheck_callee_expr rv
    | Iabsyn.WhileStmt (_, e, b) -> 
        crosscheck_callee_expr e; crosscheck_callee_stmt b
    | Iabsyn.AssertStmt _ | Iabsyn.AssumeStmt _ -> ()
    | Iabsyn.HavocStmt _ -> ()
    | Iabsyn.PragmaStmt _ -> ()
    | Iabsyn.IfStmt (e, t, f) -> 
        crosscheck_callee_expr e;
        crosscheck_callee_stmt t; crosscheck_callee_stmt f in
  crosscheck_callee_stmt pi.Iabsyn.proc_body

let fetch_abst_body mn ps a_ast = 
  try
    let pn = ps.Sabsyn.proc_name in
    let qpn = Id.module_of_proc pn ^ "." ^ Id.name_of_proc pn in
    if List.length a_ast.Aabsyn.body = 1 & 
      (let bb = List.nth a_ast.Aabsyn.body 0 in
      bb.Aabsyn.procs_to_analyze = []) then
      List.nth a_ast.Aabsyn.body 0
    else
      List.find (fun x -> List.mem qpn x.Aabsyn.procs_to_analyze)
        a_ast.Aabsyn.body with
  | Not_found -> 
      let pn = ps.Sabsyn.proc_name in
      let qpn = Id.module_of_proc pn ^ "." ^ Id.name_of_proc pn in
      Util.fatal 
        ("Could not find abstraction body for proc "^qpn^"()")

(* also should check that formats in spec are always declared,
 * and that they exist in impl *)
let verify s_ast a_ast i_ast =
  let mod_name = s_ast.Sabsyn.module_name in
  let spec_impl_check_proc m ps = 
    let n = Id.name_of_proc ps.Sabsyn.proc_name in
    let ab = fetch_abst_body mod_name ps a_ast in
    let pi = Ast.fetch_impl_proc n m in
    if not (compare_pair ps.Sabsyn.ret_val pi.Iabsyn.ret_val) then
      Util.err "[proc]" 
        ("Return values in impl and spec of proecdure "^n^" don't match");
    if not ((List.length ps.Sabsyn.formals) = (List.length pi.Iabsyn.formals)) then
      Util.err "[proc]" 
        ("Parameter count in impl and spec of procedure "^n^" don't match")
    else if not (ps.Sabsyn.proc_modifiers = pi.Iabsyn.proc_modifiers) then
      Util.err "[proc]" 
        ("Modifiers in impl and spec of procedure "^n^" don't match")
    else if not (ps.Sabsyn.proc_modifiers.Id.is_private) then
      match pi.Iabsyn.requires with 
      | Some _ -> Util.err "[proc]" 
            ("Declared a private requires clause for non-private proc "^n)
      | _ -> ()
    else if not (List.for_all2 compare_mandatory_pair ps.Sabsyn.formals pi.Iabsyn.formals) then
      Util.err "[proc]" 
        ("Parameters in impl and spec of procedure "^n^" don't match");
    ignore (crosscheck_callees mod_name ab ps pi i_ast) in
  Util.phase ("Spec/impl checking module "^mod_name) 
    List.iter (spec_impl_check_proc i_ast) s_ast.Sabsyn.procs

