package ca.uwaterloo.a10_userid;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity {
	
	// holds the wins and losses
	int dealerWins;
	int playerWins;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		// refactoring inner class listeners doesn't count
		Button b = (Button)findViewById(R.id.startButton);
		b.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				Intent i = new Intent(MainActivity.this, BlackJackActivity.class);
				startActivityForResult(i, 1);
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_main, menu);
		return true;
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data)
	{
		if (requestCode == 1 && resultCode > 0) {
			dealerWins = data.getIntExtra("dealerWins", 0);
			playerWins = data.getIntExtra("playerWins", 0);
			
			// 1 means you hit quit
			// 2 means you want another hand
			if (resultCode == 1) {
				// print the scores to the main screen
				TextView scores = (TextView)findViewById(R.id.scores);
				scores.setText("Player: " + String.valueOf(playerWins) + 
						"\n" + "Dealer: " + String.valueOf(dealerWins));
			}
			else if (resultCode == 2) {
				Intent i = new Intent(MainActivity.this, BlackJackActivity.class);
				i.putExtra("dealerWins", dealerWins);
				i.putExtra("playerWins", playerWins);
				startActivityForResult(i, 1);
			}
		}
	}

}
