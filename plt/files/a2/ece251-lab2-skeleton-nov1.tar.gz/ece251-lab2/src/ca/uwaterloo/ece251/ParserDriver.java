package ca.uwaterloo.ece251;

import java.io.*;

public class ParserDriver {
    public static void main(String[] args) throws Exception {
        PushbackReader r = new PushbackReader(new BufferedReader
					      (new InputStreamReader
					       (new FileInputStream(args[0]))));
	TokenStream ts = new TokenStream(r);
	Parser p = new Parser(ts);
	ca.uwaterloo.ece251.ast.Stmt s = p.stmt();
	ca.uwaterloo.ece251.ast.Visitor v = 
	    new ca.uwaterloo.ece251.ast.XMLVisitor();
	s.accept(v);
	r.close();
    }

}
