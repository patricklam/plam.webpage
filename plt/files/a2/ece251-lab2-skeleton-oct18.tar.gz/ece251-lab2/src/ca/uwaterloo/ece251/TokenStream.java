package ca.uwaterloo.ece251;

import java.util.Enumeration;
import java.io.*;
import java.util.regex.*;

public class TokenStream implements Enumeration<Token> {
    PushbackReader r;
    int lineno = 1, colstart = 0, colno = 0;
    private static final String WS = " \t\n";
    private static final String TOKEN_ENDS = ",();+-*/%";
    private static final int SINGLE_QUOTE = '\'';
    private static final int DOUBLE_QUOTE = '\"';
    private static final Pattern DIGITS_ONLY = Pattern.compile("[0-9]*");

    public TokenStream(PushbackReader r) {
	this.r = r;
    }

    public boolean hasMoreElements() {
	try {
	    int ch = r.read();
	    boolean ready = r.ready();
	    r.unread(ch);

	    return ready;
	} catch (IOException e) { return false; }
    }

    public Token nextElement() {
	/* read chars until EOF or whitespace,
	 * but not whitespace if in quotation marks.
	 * multi-line strings are out of scope. */
	StringBuffer sb = new StringBuffer();

	try {
	    boolean lastWasSingleQuote = false, inSingleQuote = false,
		lastWasDoubleQuote = false, inDoubleQuote = false;

	    // consume leading whitespace
	    { 
		int ch = r.read();
		if (WS.indexOf(ch) != -1) {
		    // consume all WS, then unread last non-WS ch.
		    while (WS.indexOf(ch) != -1) {
			ch = r.read();
			if (ch == '\n') { lineno++; colno = 0; }
			else colno++;
		    }
		} 
		r.unread(ch);
	    }

	    while (true) {
		if (!r.ready()) break;
		int ch = r.read();
		if (ch == '\r') continue;
		if (ch == '\n') { lineno++; colno = 0; }
		colno++;

		if (sb.toString().equals(".")) {
		    String ss = String.valueOf((char)ch);
		    if (!DIGITS_ONLY.matcher(ss).matches()) {
			r.unread(ch); colno--;
			break;
		    }
		}

		if (ch == SINGLE_QUOTE && !inDoubleQuote) {
		    if (lastWasSingleQuote)
			lastWasSingleQuote = false;
		    else {
			inSingleQuote = !inSingleQuote;
		    }
		}
		if (ch == DOUBLE_QUOTE && !inSingleQuote) {
		    if (lastWasDoubleQuote)
			lastWasDoubleQuote = false;
		    else {
			inDoubleQuote = !inDoubleQuote;
		    }
		}

		if (!inSingleQuote && !inDoubleQuote) {
		    if (WS.indexOf(ch) != -1) {
			// consume all WS, then unread last non-WS ch.
			while (WS.indexOf(ch) != -1) {
			    ch = r.read();
			    if (ch == '\n') { lineno++; colno = 0; }
			    else colno++;
			}
			r.unread(ch); colno--;
			break;
		    } else if (TOKEN_ENDS.indexOf(ch) != -1) {
			// in general, unread ch and ship off sb
			if (sb.length() > 0) {
			    // exception: +/- after a <DIGITS>e|E
			    // is not a token break.
			    if (!((sb.charAt(sb.length()-1) == 'E' ||
				   sb.charAt(sb.length()-1) == 'e') &&
				  (ch == '-' || ch == '+') && 
				  DIGITS_ONLY.matcher(sb.toString().substring(0, sb.length()-1)).matches())) {
				r.unread(ch); colno--;
			    }
			}
			else 
			    sb.append((char)ch);
			break;
		    } else if (ch == '.') {
			// break if we have any non-digits in sb.
			if (!DIGITS_ONLY.matcher(sb.toString()).matches()) {
			    r.unread(ch); colno--;
			    break;
			}
		    }
		}
		sb.append((char)ch);
	    }
	} catch (IOException e) {}
	LexerToken lt = new LexerToken(sb.toString(), lineno, colstart, colno-1);
	colstart = colno;
	return new Token(lt);
    }
}
