open Iabsyn
open Types
open Envutils

let compatible_for_assign l r =
  l = r || 
  match (l, r) with 
    (TObj _, TObj r') -> r' = Id.null_format 
  | (TString, TObj r') -> r' = Id.null_format
  | _ -> false

let format_defs = Hashtbl.create 0

let error_expr e s = 
  let (fn, p) = Ast.lookup_expr_pos e in
  Util.err (fn ^ " " ^ p) s
let error_stmt e s = Util.err "stmt" s
let error_general s = Util.err "gen" s

(* For each simple name used, verify that there exists a local, (current) 
       module variable or formal parameter declaring that name.
   For each invoke expression, check that the proc is defined, and do
       the normal check on each of its arguments.
*)
let declaration_checker (need_all_impls:bool)
    (ast:string impl_module list) : lvalue list =
  let module2tenv = create_module_tenvs ast in
  let list_of_reflvalues = ref [] in
  let rec declaration_check_expr 
      (tenv:type_environment list) e = match e with
  | LiteralExpr _ -> ()
  | VarExpr lvalue -> 
      (match lvalue with
      | LocalLvalue v -> 
          if not (Envutils.has_type_decl tenv v) then
            if (Envutils.has_type_decl 
                  (Envutils.get_tenv_for_current_module 
                     module2tenv tenv) v) then
              list_of_reflvalues := lvalue :: !list_of_reflvalues
            else
              error_expr e ("undeclared local variable "^v);
          ()
      | RefLvalue rv -> 
          failwith "shouldn't have any reflvalues yet"
      | FieldLvalue (e', f) -> declaration_check_expr tenv e'
      | ArrayLvalue (e', i) -> 
          declaration_check_expr tenv e'; 
          declaration_check_expr tenv i)
  | FieldAccessExpr (e', f) ->
      declaration_check_expr tenv e'
  | ArrayLengthExpr e' ->
      declaration_check_expr tenv e'
  | ArrayAccessExpr (e', i) ->
      declaration_check_expr tenv e';
      declaration_check_expr tenv i
  | NewExpr n -> 
      if (not (List.mem n (Ast.all_impl_formats ()))) then
        error_expr e ("undeclared format "^n^" for new");
      ()
  | NewArrayExpr (t, e', d) ->
      List.iter (declaration_check_expr tenv) e'
  | InvokeExpr (p, args) ->
      let m = Id.module_of_proc p in
      List.iter (declaration_check_expr tenv) args;
      if (not (Intrinsics.is_intrinsic p) & need_all_impls) then
        begin 
          if (not (List.mem m (Ast.all_impl_modules ()))) then 
            error_expr e ("invoking proc in undeclared module "^m)
          else if (not ((Ast.has_impl_proc (Id.name_of_proc p) 
                           (Ast.fetch_impl m)) ||
                           Ast.has_spec m &&
                           Ast.has_spec_proc (Id.name_of_proc p)
                             (Ast.fetch_spec m))) then
            error_expr e ("invoking undeclared proc "^(Id.name_of_proc p))
        end;
      ()
  | AssignExpr (lhs, e') -> 
      declaration_check_expr tenv (VarExpr lhs);
      declaration_check_expr tenv e'
  | PreIncExpr e' | PostIncExpr e' | PreDecExpr e' | PostDecExpr e' ->
      declaration_check_expr tenv (VarExpr e')
  | NegExpr e' | NotExpr e' -> declaration_check_expr tenv e'
  | PlusExpr (l, r) | MinusExpr (l, r) | MultExpr (l, r) | DivExpr (l, r) 
  | ModExpr (l, r) | AndExpr (l, r) | OrExpr (l, r) | EqExpr (l, r) 
  | NeqExpr (l, r) | LtExpr (l, r) | GtExpr (l, r) | LteqExpr (l, r) 
  | GteqExpr (l, r) | BitAndExpr (l, r) | BitOrExpr (l, r) 
  | BitXorExpr (l, r) | ShiftLeftExpr (l, r) | SignedShiftRightExpr (l, r) 
  | UnsignedShiftRightExpr (l, r) -> 
      declaration_check_expr tenv l; declaration_check_expr tenv r
 in
  let rec declaration_check_stmt 
      (pn:string) (rv:Id.var_t option) tenv (stmt_list:string stmt list)
      : type_environment list =
    match stmt_list with
      [] -> tenv
    | s::ss ->
      let tenv' =
        match s with
        | EmptyStmt -> tenv
        | HavocStmt vs ->
            (* actually allow the user to havoc arbitrary things,
             * like global vars and sets from arbitrary specs. *)
            (*List.iter (fun v ->
              if not (Envutils.has_type_decl tenv v) then
                error_stmt s ("undeclared local variable "^v)) vs;*) 
            tenv
        | CompoundStmt cs -> 
            declaration_check_stmt pn rv ([]::tenv) cs; tenv
        | ChoiceStmt (t, u) -> 
            (* after pulling-up, have no decls in t, u *)
            declaration_check_stmt pn rv tenv [t;u]; tenv
        | LocalDeclStmt (v, t, e) -> 
            (* break the abstraction barrier! *)
            if List.mem_assoc v (List.hd tenv) then
              error_stmt s ("local variable "^v^" multiply defined");
            let tenv' = ((v,t)::(List.hd tenv))::(List.tl tenv) in
            declaration_check_stmt pn rv tenv'
              [(ExprStmt (AssignExpr ((LocalLvalue v), e)))]; tenv'
        | ExprStmt e -> declaration_check_expr tenv e; tenv
        | ReturnStmt r -> 
            (match rv with
              None -> 
                (match r with None -> tenv
                | Some _ -> 
                    error_stmt r 
                      ("returning some from void-returning proc "^pn^".");
                    tenv)
            | Some rv' -> 
                (match r with 
                  None -> 
                    error_stmt r 
                      ("returning void from some-returning proc "^pn^".");
                    tenv
                | Some x -> declaration_check_expr tenv 
                      (AssignExpr ((LocalLvalue rv'), x)); tenv))
        | WhileStmt (i, e, w) -> 
            declaration_check_expr tenv e;
            declaration_check_stmt pn rv tenv [w]
        | AssertStmt (n, a) | AssumeStmt (n, a) -> tenv
        | PragmaStmt s -> tenv
        | IfStmt (e, t, f) -> 
            declaration_check_expr tenv e;
            ignore (declaration_check_stmt pn rv tenv [t]);
            ignore (declaration_check_stmt pn rv tenv [f]); tenv in
      declaration_check_stmt pn rv tenv' ss in      
  let declaration_check_proc tenv p =
    let rv1 = match p.ret_val with
      None -> None
    | Some r -> Some (fst r) in 
    let tenv' = 
      [(match p.ret_val with None -> []
      | Some x -> [x]) @ p.formals @ tenv] in
    ignore (declaration_check_stmt (Id.name_of_proc p.proc_id)
              rv1 tenv' [p.proc_body]) in
  let declaration_check_module m =
    List.iter (declaration_check_proc [("__current_module", TObj m.module_name)]) m.procs in
  List.iter declaration_check_module ast;
  if not (Util.no_errors ()) then
    Util.print_errors ();
  !list_of_reflvalues

(* prevent any writes to formal parameters *)
let formal_scribbling_checker (ast:string impl_module list) =
  let module2tenv = create_module_tenvs ast in
  let list_of_reflvalues = ref [] in
  let rec formal_scribbling_check_expr rv
      (tenv:type_environment list) e = 
    let fsce tenv' e' = formal_scribbling_check_expr rv tenv' e' in
    match e with
    | LiteralExpr _ -> ()
    | VarExpr lvalue -> 
        (match lvalue with
        | LocalLvalue v ->
            (match rv with
              Some r when v = r -> 
                error_expr e ("reading from return parameter "^v)
            | Some _ | None -> ())
        | RefLvalue _ -> ()
        | FieldLvalue (e', f) -> fsce tenv e'
        | ArrayLvalue (e', i) -> 
            fsce tenv e'; fsce tenv i)
    | FieldAccessExpr (e', f) ->
        fsce tenv e'
    | ArrayAccessExpr (e', i) ->
        fsce tenv e';
        fsce tenv i
    | ArrayLengthExpr (e') -> fsce tenv e'
    | NewExpr n -> 
        ()
    | NewArrayExpr (t, e', d) -> 
        List.iter (fsce tenv) e'
    | InvokeExpr (p, args) ->
        List.iter (fsce tenv) args
    | AssignExpr (lhs, e') -> 
        (match lhs with
        | LocalLvalue v ->
            if (Envutils.has_type_decl tenv v) then
              error_expr e ("writing to formal/return parameter "^v)
        | _ -> ());
        fsce tenv (VarExpr lhs);
        fsce tenv e'
    | PreIncExpr e' | PostIncExpr e' | PreDecExpr e' | PostDecExpr e' ->
        fsce tenv (VarExpr e')
    | NegExpr e' | NotExpr e' -> fsce tenv e'
    | PlusExpr (l, r) | MinusExpr (l, r) | MultExpr (l, r) | DivExpr (l, r) 
    | ModExpr (l, r) | AndExpr (l, r) | OrExpr (l, r) | EqExpr (l, r) 
    | NeqExpr (l, r) | LtExpr (l, r) | GtExpr (l, r) | LteqExpr (l, r) 
    | GteqExpr (l, r) | BitAndExpr (l, r) | BitOrExpr (l, r) 
    | BitXorExpr (l, r) | ShiftLeftExpr (l, r) | SignedShiftRightExpr (l, r) 
    | UnsignedShiftRightExpr (l, r) -> 
        fsce tenv l; 
        fsce tenv r in
  let rec formal_scribbling_check_stmt 
      (rv:Id.var_t option) tenv (s:string stmt) : unit =
    match s with
    | EmptyStmt -> ()
    | HavocStmt vs ->
        List.iter (fun v ->
          if (Envutils.has_type_decl tenv v) then
            error_stmt s ("havocing formal/return parameter "^v)) vs
    | ChoiceStmt (t, u) ->
        List.iter (formal_scribbling_check_stmt rv tenv) [t;u]
    | CompoundStmt cs -> 
        List.iter (formal_scribbling_check_stmt rv tenv) cs
    | LocalDeclStmt (v, t, e) -> 
        formal_scribbling_check_stmt rv tenv (ExprStmt e)
    | ExprStmt e -> formal_scribbling_check_expr rv tenv e
    | ReturnStmt r -> 
        (match rv with
        | Some rv' -> 
            (match r with
            | Some x -> formal_scribbling_check_expr rv tenv x
            | _ -> ())
        | _ -> ())
    | WhileStmt (i, e, w) -> 
        formal_scribbling_check_expr rv tenv e;
        formal_scribbling_check_stmt rv tenv w
    | AssertStmt (n, a) | AssumeStmt (n, a) -> ()
    | PragmaStmt s -> ()
    | IfStmt (e, t, f) -> 
        formal_scribbling_check_expr rv tenv e;
        formal_scribbling_check_stmt rv tenv t;
        formal_scribbling_check_stmt rv tenv f in
  let formal_scribbling_check_proc p =
    let rv1 = match p.ret_val with
      None -> None
    | Some r -> Some (fst r) in 
    let tenv' = 
      [(match p.ret_val with None -> []
      | Some x -> [x]) @ p.formals] in
    formal_scribbling_check_stmt rv1 tenv' p.proc_body in
  let formal_scribbling_check_module m =
    List.iter (formal_scribbling_check_proc) m.procs in
  List.iter formal_scribbling_check_module ast;
  if not (Util.no_errors ()) then
    Util.print_errors ()


(* structural equality is not good enough here,
 * because LocalLvalue "x" is not the same depending on context. *)
let typeof : value_type Exprtbl.t = Exprtbl.create 0

let type_checker ast =
  Exprtbl.clear typeof;
  let current_module = ref Id.main_module in
  let module2tenv = create_module_tenvs ast in
(* returns the type of the given expression. *)
  let rec compute_type_for_expr tenv exp : value_type =
    let t = real_compute_type_for_expr tenv exp in
    Exprtbl.replace typeof exp t; t
  and real_compute_type_for_expr tenv exp : value_type =
    let field_type e' f = 
      let bt = compute_type_for_expr tenv e' in
      (match bt with 
      | TObj btn -> 
          if not (Hashtbl.mem format_defs btn) then
            (error_expr exp ("format "^btn^" not declared"); TVoid)
          else
            let fl = Hashtbl.find format_defs btn in
            let fd = Hashtbl.find fl !current_module in
            (try Hashtbl.find fd f
            with Not_found -> error_expr exp 
                ("field "^(Id.name_of_field f)^" not declared"); TVoid)
      | _ -> error_expr exp ("field deref for "^(Id.name_of_field f)^" on non-object"); TVoid) in
    match exp with
    | LiteralExpr v -> 
        if v = null_obj then TObj Id.null_format
        else value_type_of_value v
    | VarExpr lvalue -> 
        (match lvalue with
        | LocalLvalue v -> 
            List.assoc v tenv
        | RefLvalue rv -> 
            Envutils.retrieve_type 
              [Hashtbl.find module2tenv !current_module] rv
        | FieldLvalue (e', f) -> 
            field_type e' f
        | ArrayLvalue (e', i) ->
            let t = compute_type_for_expr tenv e' in
            if ((compute_type_for_expr tenv i) <> TInt) then
              error_expr exp "tried array access on non-int";
            match t with 
            | TArray _ -> strip_one_array_level t
            | _ -> error_expr exp ("attempting to dereference a non-array");
                TVoid)
    | FieldAccessExpr (e', f) ->
        field_type e' f
    | ArrayAccessExpr (e', i) ->
        let t = compute_type_for_expr tenv e' in
        if ((compute_type_for_expr tenv i) <> TInt) then
          error_expr exp "tried array access on non-int";
        (match t with 
        | TArray _ -> strip_one_array_level t
        | _ -> error_expr exp ("attempting to dereference a non-array");
            TVoid)
    | ArrayLengthExpr e' ->
        let t = compute_type_for_expr tenv e' in
        (match t with 
        | TArray _ -> TInt
        | _ -> error_expr exp ("attempting to dereference a non-array");
            TVoid)
    | NewExpr n -> TObj n
    | NewArrayExpr (t, e', d) ->
        List.fold_left (fun y x -> 
          if (compute_type_for_expr tenv x) <> TInt then
            begin error_expr exp "giving non-int array dimension"; TVoid end
          else (TArray y)) t e'
        (* quack: use d also *)
    | InvokeExpr (p, args) ->
        let pm = Id.module_of_proc p in
        if (Intrinsics.is_intrinsic p) then
          Intrinsics.type_check_intrinsics p
            (List.map (compute_type_for_expr tenv) args)
        else if not (Ast.has_spec pm) & not (Ast.has_impl pm) then
          begin
            error_expr exp ("couldn't find impl or spec module "^pm); 
            TVoid
          end
        else
          let (targ_formals, targ_rv) = 
            if (Ast.has_impl pm) & (Ast.has_impl_proc (Id.name_of_proc p) 
                                      (Ast.fetch_impl pm)) then
              let ip = (Ast.fetch_impl_proc (Id.name_of_proc p) 
                          (Ast.fetch_impl pm)) in
              (ip.formals, ip.ret_val)
            else 
              let sp = Ast.fetch_spec_proc (Id.name_of_proc p)
                  (Ast.fetch_spec pm) in
              (sp.Sabsyn.formals, sp.Sabsyn.ret_val) in
          if (List.length args) != (List.length targ_formals) then
            begin
              let em = Printf.sprintf "arg count mismatch: expected %d, got %d"
                  (List.length targ_formals) (List.length args) in
              error_expr exp em
            end
          else
            begin
              let c = ref 0 in
              List.iter2 
                (fun x y -> c := !c + 1;
                  let ftype = snd y in
                  let atype = compute_type_for_expr tenv x in
                  if not (compatible_for_assign ftype atype) then
                    error_expr exp 
                      ("arg " ^ (string_of_int !c) ^
                       ": type mismatch: expected "
                       ^ (string_of_value_type ftype) ^ ", got "
                       ^ (string_of_value_type atype)))
                args targ_formals
            end;
          (match targ_rv with
          | None -> TVoid
          | Some (rv, t) -> t)
    | AssignExpr (LocalLvalue lv, e') ->
        let lhs_type = List.assoc lv tenv in
        let rhs_type = compute_type_for_expr tenv e' in
        if not (compatible_for_assign lhs_type rhs_type) then
          error_expr e' ("type mismatch: expected "
                 ^ (string_of_value_type lhs_type) ^ ", got "
                 ^ (string_of_value_type rhs_type)); TVoid
    | AssignExpr (RefLvalue rv, e') -> 
        let menv = (Ast.fetch_impl !current_module).references in
        let lhs_type = List.assoc rv menv in
        let rhs_type = compute_type_for_expr tenv e' in
        if not (compatible_for_assign lhs_type rhs_type) then
          error_expr exp ("type mismatch: expected "
                 ^ (string_of_value_type lhs_type) ^ ", got "
                 ^ (string_of_value_type rhs_type)); TVoid
    | AssignExpr (FieldLvalue (b, f), e') ->
        let lhs_type = compute_type_for_expr tenv (FieldAccessExpr (b, f)) in
        let rhs_type = compute_type_for_expr tenv e' in
        if not (compatible_for_assign lhs_type rhs_type) then
          error_expr exp ("bad field assign type"); TVoid
    | AssignExpr (ArrayLvalue (b, i), e') ->
        let lhs_type = compute_type_for_expr tenv (ArrayAccessExpr (b, i)) in
        let rhs_type = compute_type_for_expr tenv e' in
        if not (compatible_for_assign lhs_type rhs_type) then
          error_expr exp ("bad array assign type"); TVoid
    | PreIncExpr e' | PostIncExpr e' | PreDecExpr e' | PostDecExpr e' ->
        if (compute_type_for_expr tenv (VarExpr e') <> TInt) then
          error_expr exp "tried incrementing non-int"; TInt
    | NegExpr e' -> 
        if not (List.mem (compute_type_for_expr tenv e') 
                  [TInt; TFloat; TChar]) then
          error_expr exp "Neg of non-numeric"; 
        compute_type_for_expr tenv e'
    | NotExpr e' -> 
        if compute_type_for_expr tenv e' != TBool then
          error_expr exp "Not of non-boolean"; 
        TBool
    | AndExpr (l, r) | OrExpr (l, r) -> 
        if compute_type_for_expr tenv l != TBool or
          compute_type_for_expr tenv r != TBool then
          error_expr exp "and/or of non-boolean"; 
        TBool
    | EqExpr (l, r) | NeqExpr (l, r) ->
        let lt = compute_type_for_expr tenv l in
        let rt = compute_type_for_expr tenv r in
        if not (compatible_for_assign lt rt) then
          error_expr exp "type mismatch on equality operation";
        TBool
    | LtExpr (l, r) | GtExpr (l, r) 
    | LteqExpr (l, r) | GteqExpr (l, r) ->
        let lt = compute_type_for_expr tenv l in
        let rt = compute_type_for_expr tenv r in
        if not (List.mem lt [TInt; TFloat; TChar; TString]) or (lt <> rt) then
          error_expr exp "type mismatch on comparison operation";
        TBool
    | PlusExpr (l, r) | MinusExpr (l, r) | MultExpr (l, r) | DivExpr (l, r) 
    | ModExpr (l, r) |  BitAndExpr (l, r) | BitOrExpr (l, r) 
    | BitXorExpr (l, r) | ShiftLeftExpr (l, r) | SignedShiftRightExpr (l, r) 
    | UnsignedShiftRightExpr (l, r) -> 
        let lt = compute_type_for_expr tenv l in
        if (lt != compute_type_for_expr tenv r) then
          error_expr exp "type mismatch on binary operation";
        lt in
  let make_tenv_for_cs cs = 
    List.concat (List.map 
                   (fun s -> match s with
                   | LocalDeclStmt (v, t, e) -> [(v, t)]
                   | _ -> []) cs) in
  let rec type_check_stmt tenv s =
    match s with
    | EmptyStmt -> ()
    | HavocStmt s -> () (* havoc can't fail to typecheck, eh. *)
    | ChoiceStmt (t, u) ->
        type_check_stmt tenv t;
        type_check_stmt tenv u;
    | CompoundStmt cs ->
        let tenv' = (make_tenv_for_cs cs) @ tenv in
        List.iter (type_check_stmt tenv') cs
    | LocalDeclStmt (v, t, e) -> 
        (* short circuit test for empty initial arrays *)
        (match e with
        | LiteralExpr (Array _) -> ()
        | _ -> type_check_stmt tenv (ExprStmt (AssignExpr (LocalLvalue v, e))))
    | ExprStmt e -> 
        ignore (compute_type_for_expr tenv e)
    | ReturnStmt r ->
        let rt = (match r with 
        | None -> TVoid
        | Some re -> compute_type_for_expr tenv re) in
        let expected = List.assoc "__return_type" tenv in
        if not (compatible_for_assign expected rt) then 
          error_stmt s ("incompatible types for return: expecting "^string_of_value_type expected ^" and got "^string_of_value_type rt)
    | WhileStmt (_, e, body) ->
        if (compute_type_for_expr tenv e != TBool) then
          error_stmt s "loop cond must be boolean";
        type_check_stmt tenv body
    | AssertStmt _ | AssumeStmt _ -> ()
    | PragmaStmt _ -> ()
    | IfStmt (e, t, f) ->
        if (compute_type_for_expr tenv e != TBool) then
          error_stmt s "if cond must be boolean";
        type_check_stmt tenv t; type_check_stmt tenv f in
  let type_check_proc tenv p = 
    let rv1 = match p.ret_val with
      None -> None
    | Some r -> Some (fst r) in 
    let tenv' = 
      (match p.ret_val with None -> [("__return_type", TVoid)]
      | Some x -> [x; ("__return_type", snd x)]) @ p.formals @ tenv in
    ignore (type_check_stmt tenv' p.proc_body) in
  let type_check_module m = 
    current_module := m.module_name;
    Util.phase ("Type checking module "^m.module_name) 
      List.iter (type_check_proc m.references) m.procs in
  List.iter type_check_module ast
  
let verify ast = 
  let all_impl_modules = Ast.all_impl_modules () in
  let all_impl_modules_uniq = Util.remove_dups all_impl_modules in
  if (List.length all_impl_modules) != 
    (List.length all_impl_modules_uniq) then
    begin
      let rec find_dup n = 
        match n with
          [] -> []
        | q::qs -> 
            if (List.mem q qs) then 
              begin
                error_general ("Duplicate modules named "^q); []
              end
            else q::(find_dup qs) in
      ignore (find_dup all_impl_modules)
    end;
  Assembler.populate_format_definitions format_defs;
  formal_scribbling_checker ast;
  if not (Util.no_errors ()) then
    Util.print_errors ();
  type_checker ast;
  if not (Util.no_errors ()) then
    Util.print_errors ()
(* Type checking algorithm:
   - must check that every expression has expected type
    - must also check within expressions, that args have proper types.
   (goal is to avoid those types completely during execution) *)
