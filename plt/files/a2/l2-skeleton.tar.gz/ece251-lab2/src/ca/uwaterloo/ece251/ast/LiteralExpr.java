package ca.uwaterloo.ece251.ast;

public class LiteralExpr extends Expr {
    Literal value;
    public LiteralExpr(Literal value) {
	this.value = value;
    }

    public void accept(Visitor v) {
	v.enter(this);
	v.leave(this);
    }
}
