/*
 * wordole.c
 * Copyright (C) 1998-2004 A.J. van Os; Released under GPL
 *
 * Description:
 * Deal with the OLE internals of a MS Word file
 */

#define NDEBUG 1
#include <string.h>
#include "antiword.h"

#define PPS_NUMBER_INVALID      0xffffffffUL

/* Private type for Property Set Storage entries */
typedef struct pps_entry_tag {
        ULONG   ulNext;
        ULONG   ulPrevious;
        ULONG   ulDir;
        ULONG   ulSB;
        ULONG   ulSize;
        int     iLevel;
        char    szName[32];
        UCHAR   ucType;
} pps_entry_type;

/*
 * vComputePPSlevels - compute the levels of the Property Set Storage entries
 */
static void
vComputePPSlevels(pps_entry_type *atPPSlist, pps_entry_type *pNode,
			int iLevel, int iRecursionLevel)
{
	fail(atPPSlist == NULL || pNode == NULL);
	fail(iLevel < 0 || iRecursionLevel < 0);

	if (iRecursionLevel > 25) {
		/* This removes the possibility of an infinite recursion */
		DBG_DEC(iRecursionLevel);
		return;
	}
	if (pNode->iLevel <= iLevel) {
		/* Avoid entering a loop */
		DBG_DEC(iLevel);
		DBG_DEC(pNode->iLevel);
		return;
	}

	pNode->iLevel = iLevel;

	if (pNode->ulDir != PPS_NUMBER_INVALID) {
		vComputePPSlevels(atPPSlist,
				&atPPSlist[pNode->ulDir],
				iLevel + 1,
				iRecursionLevel + 1);
	}
	if (pNode->ulNext != PPS_NUMBER_INVALID) {
		vComputePPSlevels(atPPSlist,
				&atPPSlist[pNode->ulNext],
				iLevel,
				iRecursionLevel + 1);
	}
	if (pNode->ulPrevious != PPS_NUMBER_INVALID) {
		vComputePPSlevels(atPPSlist,
				&atPPSlist[pNode->ulPrevious],
				iLevel,
				iRecursionLevel + 1);
	}
} /* end of vComputePPSlevels */
