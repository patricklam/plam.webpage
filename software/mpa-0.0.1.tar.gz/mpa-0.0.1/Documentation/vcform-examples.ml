(*

S = { n | exists i. i < s & d[i] = n & !(n = null) }

proc add() ensures S' = S + e.

while (i < s) { // i: i < s; s: s > i
    if (d[i] == null) { // d: d[i] == null & (exists i. i < s & d[i] = e)
        d[i] = e;       // d: exists i. i < s & d[i] = e
        return;
    }
    i = i + 1;
              }

d[s] = e;               // d: exists i. i = s & d[i] = e & (something else)
s = s + 1;              // d: exists i. i < s & d[i] = e & (something else)

*)

open Vcform

(* util *)
let rec conj c = match c with
  [] -> Const (BoolConst true)
| [f] -> f
| f::fs -> App (Const And, [f; conj fs])
let not n = App (Const Not, [n])
let lt f g = App (Const Lt, [f; g])
let lteq f g = App (Const LtEq, [f; g])
let eq f g = App (Const Eq, [f; g])
let cup f g = App (Const Cup, [f; g])
let cap f g = App (Const Cap, [f; g])

(* d[i] = e *)
let d_of_i_eq_e = App (Const Eq, [App (Var "ArrayRead",
                                       [Var "d"; Var "i"]);
                                  Var "e"])
    
let i_lt_s = App (Const Lt, [Var "i"; Var "s"])

let defn_of_d = Binder (Exists, [("s", TypeInt)], conj [i_lt_s; d_of_i_eq_e])

(* arrayset examples *)

let add_precond_orig = 
  conj 
    [(Var "setInit");
     (not (eq (Var "e") (Const NullConst)))]

let add_precond =
  { 
    haveEnv = [(("setInit", TypeBool), Some (Const (BoolConst true)));
              (("e", TypeObjRef "Entry"), None)];
    haveBody = (not (eq (Var "e") (Const NullConst))); }

let add_ptA = 
  { haveEnv = [(("setInit", TypeBool), Some (Const (BoolConst true)));
              (("e", TypeObjRef "Entry"), None);
              (("i", TypeInt), Some 
                 (conj [(lt (Var "i") (Var "s"));
                        (lteq (Const (IntConst 0)) (Var "i"))]))];
    haveBody = conj [not (eq (Var "e") (Const NullConst))];
  }

let d_of_i = App (Var "ArrayRead",
                  [Var "d"; Var "i"])

let add_ptB =
  { haveEnv = [(("setInit", TypeBool), Some (Const (BoolConst true)));
              (("e", TypeObjRef "Entry"), None);
              (("i", TypeInt), None)];
    haveBody = conj [(not (eq (Var "e") (Const NullConst)));
                    (lt (Var "i") (Var "s"));
                    (eq d_of_i (Const NullConst))];
  }

let add_ptC =
  { haveEnv = [(("setInit", TypeBool), Some (Const (BoolConst true)));
              (("e", TypeObjRef "Entry"), None);
              (("i", TypeInt), None)];
    haveBody = conj [(not (eq (Var "e") (Const NullConst)));
                    (lt (Var "i") (Var "s"));
                    (eq d_of_i (Var "e"))];
  }

(* exists i1, ..., in. pre(x,y) & (x' = f(x, y, i1, ..., in)) & 
                                  (y' = g(x, y, i1, ..., in)) &
            constraint(x, y, x', y', i1, ..., in) *)

(* here are the originals *)

let fram v = eq (Var v) (Var (v ^ "'"))

let generic_precond f vs b = 
  { preamble = f;
    haveEnv = List.map (fun v -> eq (Var v) (Var v^"'")) vs ;
    haveBody = b }

let add_precond_orig = 
  generic_precond (Const (BoolConst true))
    ["e"]
    conj 
    [(Var "setInit");
     (not (eq (Var "e") (Const NullConst)));
     (eq (Var "i'") (Const (IntConst 0)))]

let add_ptA_orig =  (* at fixed point *)
  conj 
    [(Var "setInit");
     (lt (Var "i") (Var "s"));
     (not (eq (Var "e") (Const NullConst)))]

(* setInit & i < s & e != null & (d[i] = null) *)

let add_ptB_orig =
  conj
    [(Var "setInit");
     (lt (Var "i") (Var "s"));
     (not (eq (Var "e") (Const NullConst)));
     (eq d_of_i (Const NullConst))]

let add_ptC_orig =
  conj
    [(Var "setInit");
     (lt (Var "i") (Var "s"));
     (not (eq (Var "e") (Const NullConst)));
     (eq d_of_i (Var "e"))]

let add_postcond_orig =
  conj
    [(Var "setInit");
     (eq (Var "S'") (cup (Var "S") (Var "e")))]

