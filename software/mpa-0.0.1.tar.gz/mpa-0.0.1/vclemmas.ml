
let known_facts = ref [""]
let add_fact s = 
  known_facts := s :: !known_facts

let get_content fname =
  let chn = open_in fname in
  let len = in_channel_length chn in
  let str = String.make len ' ' in
  let _ = really_input chn str 0 len in
  (close_in chn; str)

let init mod_name = 
  let str = get_content (mod_name ^ "-lemmas" ^ ".thy") in
  let lemmaKW = Str.regexp_string "lemma" in
  let quote = Str.regexp_string "\"" in
  let len = String.length str in
  let pos = ref 0 in
  let skip_to descr r =
    let oldpos = !pos in
    try pos := Str.search_forward r str !pos + 1
    with Not_found -> 
      (Util.msg (Printf.sprintf "End of file while searching for %s at position %d.\n" descr oldpos); raise Not_found)
  in 
  let skip_one () = pos := !pos + 1 in
  begin
    (try
      while true do
        skip_to "lemma keyword" lemmaKW;
        skip_to "openning quote" quote;
        let pos1 = !pos in
        skip_to "closing quote" quote;
        add_fact (String.sub str pos1 (!pos-pos1-1))
      done
    with Not_found -> ());
    Util.msg (Printf.sprintf "Retrieved %d lemmas.\n" (List.length !known_facts));
    List.iter (fun s -> print_string (s ^ "\n\n")) !known_facts
  end

let known_fact lemma_text = List.mem lemma_text !known_facts
