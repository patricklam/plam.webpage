// Trace.java
//
// Author: Raja Vallee-Rai
//
// This file is public domain.  You can do anything you want with 
// it, all at your own risk.  Enjoy!

/**
 * The trace is a record of a particle's position in the world.  It's the constituent
 * of a Particle's trail.
 */
 
class Trace
{
    int screenX;
    int screenY;
    
    double posX;
    double posY;
    
    /**
     * Have the posX,posY been converted to valid screenX,screenY coordinates?
     */
    boolean isDrawable;
    
    public Trace(double posX, double posY)
    {
        this.posX = posX;
        this.posY = posY;
    }
}
