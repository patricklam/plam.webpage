INSERT INTO AntiqueOwners 
(OwnerID, OwnerLastName, OwnerFirstName)
SELECT EmployeeAddressTable.EmployeeIDNo, EmployeeAddressTable.LastName, EmployeeAddressTable.FirstName
FROM EmployeeAddressTable AS st WHERE EmployeeAddressTable.City = 'Waterloo';
