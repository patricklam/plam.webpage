package ca.uwaterloo.ece251.ast;

import java.util.List;

public class SelectStmt extends Stmt {
    boolean distinct;
    boolean all;
    List<ResultColumn> cols;
    List<SingleSource> js;
    Expr where, limit;

    public SelectStmt(boolean distinct, boolean all, 
		      List<ResultColumn> cols, List<SingleSource> js,
		      Expr where, Expr limit) {
	this.distinct = distinct; this.all = all;
	this.cols = cols; this.js = js;
	this.where = where; this.limit = limit;
    }

    public void accept(Visitor v) {
	v.enter(this);
	if (cols != null) {
	    for (ResultColumn rc : cols) {
		rc.accept(v);
	    }
	}
	if (js != null) {
	    for (SingleSource ss : js) {
		ss.accept(v);
	    }
	}
	if (where != null) where.accept(v);
	if (limit != null) limit.accept(v);
	v.leave(this);
    }
}
