package ca.uwaterloo.ece251.ast;

public class NumericLiteral extends Literal {
    String n;
    public NumericLiteral(String n) {
	this.n = n;
    }

    public String toString() {
	return n;
    }
}
