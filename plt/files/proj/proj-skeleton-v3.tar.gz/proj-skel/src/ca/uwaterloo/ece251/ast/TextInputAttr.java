package ca.uwaterloo.ece251.ast;

/** Represents a type=TEXT|RADIO attribute for an INPUT or SELECT tag. */
public class TextInputAttr extends InputAttr {
    public enum Type { TEXT, RADIO };
    Type t;

    public TextInputAttr(Type t) { this.t = t; }
    public String toString() {
	switch(t) {
	case TEXT: return "type = text";
	case RADIO: return "type = radio";
	}
	return null;
    }
}

