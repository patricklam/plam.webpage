public class Test3 {
    public static void main(String[] argv) {
	CarList carList = new CarList();
	Car c1 = new Car(1,"Dodge","Dakota",1990,Car.CarColour.Green,30276);
	Car c2 = new Car(2,"Toyota","Highlander",1970,Car.CarColour.Green,60781);
	Car c3 = new Car(3,"Chevrolet","Silverado",2002,Car.CarColour.Orange,58485);

	carList.append(c3);
	carList.append(c1);
	carList.append(c2);
	carList.storeCarDataByPrice("out.csv");
    }
}
