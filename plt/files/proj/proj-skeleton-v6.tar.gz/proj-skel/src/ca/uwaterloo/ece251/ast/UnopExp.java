package ca.uwaterloo.ece251.ast;

import java.util.List;

/** Unary operations. */
public class UnopExp extends Exp {
    public enum Unop {
        NOT("!"), NEG("-");

	private final String t;
	Unop(String t) { this.t = t; }
	public String toString() { return t; }
    };

    Unop op;
    Exp e;

    public UnopExp(Unop op, Exp e) {
	this.op = op; this.e = e;
    }

    public String toString() {
	String es = e.toString();
	if (Precedence.p(e).ordinal() > Precedence.p(this).ordinal())
	    es = "(" + es + ")";
	return op.toString() + es;
    }
}
