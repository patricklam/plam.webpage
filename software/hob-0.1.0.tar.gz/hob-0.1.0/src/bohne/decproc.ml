(** Interface to decision procedure/theorem prover *)

type dp_stats = {
    calls : int;
    cache_hits : int;
    total_time : float;
    max_time : float;
  }	


module type DP = 
  sig
    type form
    val valid : Vcform.env -> Vcform.form -> bool
  end

module type DP_INTERFACE =
  sig
    val entails : Vcform.form -> 
      Vcform.form -> Vcform.form -> bool
    val valid : Vcform.form -> bool
    val satisfiable : Vcform.form -> bool
    val stats : unit -> dp_stats
    val reset_stats : unit -> unit
  end
     
module Make (Dp : DP) : DP_INTERFACE =
  struct    
    open Preds

    let improved_caching = false

    let res_cache = Hashtbl.create 0

    let impl_cache = Hashtbl.create 0

    let calls = ref 0
    let cache_hits = ref 0
    let total_time = ref 0.0
    let max_time = ref 0.0

    let test_entails f1 f2 =
      let rec le f1 f2 =
	match (f1, f2) with
	(* boolean operators *)
	| (Vcform.Const (Vcform.BoolConst false), _) -> true
	| (_, Vcform.Const (Vcform.BoolConst true)) -> true
	| (Vcform.App (Vcform.Const Vcform.And, conj1), Vcform.App (Vcform.Const Vcform.And, conj2)) ->
	    List.for_all (fun c2 -> List.exists (fun c1 -> le c1 c2) conj1) conj2
	| (Vcform.App (Vcform.Const Vcform.Or, disj1), Vcform.App (Vcform.Const Vcform.Or, disj2)) ->
	    List.for_all (fun d1 -> List.exists (le d1) disj2) disj1
	(* |  (Vcform.App (Vcform.Const Vcform.Not, [f1']), Vcform.App (Vcform.Const Vcform.Not, [f2'])) ->
	    le f2' f1' *)
	| (Vcform.Binder (b1, [(v1, t1)], f1'), Vcform.Binder (b2, [(v2, t2)], f2'))
	  when b1 = b2 && t1 = t2 && v1 = v2 -> le f1' f2'
	| (Vcform.App (Vcform.Const Vcform.And, conj1), _) ->
	    List.exists (fun c1 -> le c1 f2) conj1
	| (_, Vcform.App (Vcform.Const Vcform.Or, disj2)) ->
	    List.exists (le f1) disj2 
	(* reachability - do not use for caching *)
	| (_, Vcform.App (Vcform.Var "rtrancl", [_;t11;t12])) ->
	    (match f1 with
	    | Vcform.App (Vcform.Const Vcform.Eq, [t21;t22]) ->
		(t11 = t21 (* || t21 = Vcform.Const Vcform.NullConst *)) && t12 = t22  
	      || (t11 = t22 (* || t22 = Vcform.Const Vcform.NullConst *)) && t12 = t21
 	      | _ -> false)
	(* equality *)
	| (Vcform.App (Vcform.Const Vcform.Eq, [t11;t12]), 
	   Vcform.App (Vcform.Const Vcform.Eq, [t21;t22])) ->
	     t11 = t21 && t12 = t22 || t11 = t22 && t12 = t21
	| _ -> f1 = f2
      in le f1 f2

    let find_cached_result env f =
      let unpack = function | Some b -> b | None -> false in
      match f with 
      |	Vcform.App (Vcform.Const Vcform.Impl, [f1;f2]) when improved_caching ->
	  let cached = Hashtbl.find_all impl_cache (env, f2) in
	  let _, res = 
	      List.find (fun (f3, res) -> ((test_entails f1 f3) && res) || (test_entails f3 f1 && not res)) cached
	  in res
      |	_ -> Hashtbl.find res_cache (env, f)

    let cache_result env f res =
      match f with
      |	Vcform.App (Vcform.Const Vcform.Impl, [f1;f2]) when improved_caching -> 
	  Hashtbl.add impl_cache (env, f2) (f1, res)
      |	_ -> Hashtbl.add res_cache (env, f) res

    let valid f =
      let env = Preds.get_local_env () in
      let _ = calls := !calls + 1 in 
      try
	let res = find_cached_result env f in
	cache_hits := !cache_hits + 1; res
      with Not_found ->
	let start_time = (Unix.times ()).Unix.tms_cutime in
	let res = Dp.valid env f in
	let time = (Unix.times ()).Unix.tms_cutime -. start_time in
	cache_result env f res; 
	total_time := !total_time +. time;
	max_time := max !max_time time;
	res 

    let satisfiable f =
      let not_f = Vcform.smk_not f in
      not (valid not_f)

    let entails gamma f g =
      let gamma_f = Vcform.smk_and [gamma;f] in
      if test_entails f g then true else
      valid (Vcform.App (Vcform.Const Vcform.Impl, [gamma_f; g]))
      

    let stats () =
      { calls = !calls;
	cache_hits = !cache_hits;
	total_time = !total_time;
	max_time = !max_time
      }	
      
    let reset_stats () =
      calls := 0; 
      cache_hits := 0;
      total_time := 0.0;
      max_time := 0.0
  end

module Mona : DP = 
  struct
    type form = Monaform.form
    
    open Monaform
    open Monaconvert
    open Preds

    let valid local_env f =
      let _ = Bohneutil.print_debug 4 (fun () -> "checking validity of formula:\n" ^
	Vcprint.isabelle_formula f ^ "\n") in
      let global_env = Preds.get_global_env () in
      let rec_defs = Preds.get_rec_defs () in
      let mode, preamble, f' = monaconvert (local_env @ global_env) rec_defs f in
      let res = match f' with
      |	Atom True -> true
      |	Atom False -> false
      |	_ -> Mona.valid mode preamble f'
      in
      let _ =  Bohneutil.print_debug_nl 4 
	  (fun () -> print_string 
	      ("Formula is " ^ if res then "valid" else "not valid")) in
      res
  end


module Dp = Make (Mona) 

