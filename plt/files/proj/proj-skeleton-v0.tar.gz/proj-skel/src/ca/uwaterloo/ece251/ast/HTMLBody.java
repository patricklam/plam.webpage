package ca.uwaterloo.ece251.ast;

/** Represents a part of the contents of an HTML template. */
abstract public class HTMLBody {
}




