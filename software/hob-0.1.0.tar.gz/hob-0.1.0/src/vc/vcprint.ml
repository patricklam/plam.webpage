
open Vcform

let nullConstName = "nullObj"

let isabelle_formula (f:form) = 
  let rec p s = "(" ^ s ^ ")" 
  and wr_int k = match k with
  | Const (IntConst i) -> Printf.sprintf "%d" i
  | _ -> failwith "vcprint.isa_form: non-constant cardinality constraint"
  and wr_form_list op fs = p (wr_form_list1 op fs)
  and infx f1 op f2 = p (wr_form f1 ^ op ^ wr_form f2)
  and wr_binder binder vts f = 
    p (binder ^ " " ^ String.concat " " (List.map fst vts) ^ ". " ^ wr_form f)
  and wr_type t = match t with
  | TypeVar id -> id
  | TypeObjRef str -> str ^ "-" ^ "OBJECT"
  | TypeArray t1 -> p (wr_type t1) ^ " array"
  | TypeSet t1 -> p (wr_type t1) ^ " set"
  | TypeList t1 -> p (wr_type t1) ^ " list"
  | TypeFun(ts,t1) -> p (wr_fun_type ts t1)
  | TypeInt -> "int"
  | TypeBool -> "bool"
  | TypeVoid -> "void"
  | TypeUniverse -> "universe"
  and wr_fun_type ts t1 = match ts with
  | [] -> wr_type t1
  | t2::ts2 -> wr_type t2 ^ " -> " ^ wr_fun_type ts2 t1
  and wr_form f =  match f with
  | Const (BoolConst true) -> "True"
  | Const (BoolConst false) -> "False"
  | App(Const Not, [f]) -> p ("~" ^ wr_form f)
  | App(Const Or,fs) -> wr_form_list " | " fs
  | App(Const And,fs) -> wr_form_list " & " fs
  | App(Const MetaAnd,fs) -> "[|" ^ wr_form_list1 ";\n" fs ^ "|]"
  | App(Const Impl,[f1;f2]) -> infx f1 " --> " f2
  | App(Const MetaImpl,[f1;f2]) -> infx f1 " ==>\n    " f2
  | App(Const Iff,[f1;f2]) -> infx f1 " = " f2

  | App(Const Eq,[f1;f2]) -> infx f1 " = " f2

  | Const EmptysetConst -> "{}"
  | App(Const FiniteSetConst, fs) -> "{" ^ wr_form_list1 ", " fs ^ "}"
  | App(Const Tuple, fs) -> "(" ^ wr_form_list1 ", " fs ^ ")"
  | App(Const Elem,[f1;f2]) -> infx f1 " : " f2
  | App(Const Sub,[f1;f2]) -> infx f1 " <= " f2
  | App(Const Cap,fs) -> wr_form_list " Int " fs
  | App(Const Cup,fs) -> wr_form_list " Un " fs
  | App(Const Diff,[f1;f2]) -> infx f1 " - " f2
  | App(Const Disjoint,fs) -> "handleDisjoint"
  | App(Const Cardeq,[f1;k]) -> "cardeq" ^ wr_int k ^ " " ^ wr_form f1
  | App(Const Cardleq,[f1;k]) -> "cardleq" ^ wr_int k ^ " " ^ wr_form f1
  | App(Const Cardgeq,[f1;k]) -> "cardgeq" ^ wr_int k ^ " " ^ wr_form f1

  | Const (IntConst k) -> Printf.sprintf "(%d::int)" k
  | App(Const Lt,[f1;f2]) -> infx f1 " < " f2
  | App(Const LtEq,[f1;f2]) -> infx f1 " <= " f2
  | App(Const Gt,[f1;f2]) -> infx f2 " < " f1
  | App(Const GtEq,[f1;f2]) -> infx f2 " <= " f1

  | App(Const Plus,[f1;f2]) -> infx f1 " + " f2
  | App(Const Minus,[f1;f2]) -> infx f1 " - " f2
  | App(Const Mult,[f1;f2]) -> infx f1 " * " f2
  | App(Const Div,[f1;f2]) -> infx f1 " div " f2
  | App(Const Mod,[f1;f2]) -> infx f1 " mod " f2

  | Const NullConst -> nullConstName
  | Const c -> Vcform.string_of_const c 

  | Var v -> v
  | Binder(Forall,vts,f1) -> wr_binder "ALL" vts f1
  | Binder(Exists,vts,f1) -> wr_binder "EX" vts f1
  | Binder(Lambda,vts,f1) -> wr_binder "%" vts f1
  | Binder(Comprehension,[(v,t)],f1) ->
      "{" ^ v ^ ". " ^ wr_form f1 ^ "}"
  | Binder(Comprehension,_,f1) -> failwith "vcprint.isa: multivar comprehensions?"
  | TypedForm(f1,t) -> p (wr_form f1 ^ " :: " ^ wr_type t)
  | App(f1,fs) -> wr_form_list " " (f1::fs)
(*
  | _ -> failwith "vcprint.isa_formula: Unexpected case"
*)  
  and wr_form_list1 op fs = match fs with
  | [] -> ""
  | [f] -> wr_form f
  | f::fs1 -> wr_form f ^ op ^ wr_form_list1 op fs1
  in wr_form f

let string_of_sequent (sq:sequent) = isabelle_formula (form_of_sequent sq)

let isabelle_input (mod_name:string) (proof:string) (sq:string) =
  "theory vc = " ^ mod_name ^ ":\n" ^
   "lemma \"" ^ sq ^ "\"\n" ^ proof ^ "\nend\n"
