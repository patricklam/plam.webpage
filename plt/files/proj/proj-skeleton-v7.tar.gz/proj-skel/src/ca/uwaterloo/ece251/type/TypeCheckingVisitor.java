package ca.uwaterloo.ece251.type;

import ca.uwaterloo.ece251.ast.*;
import ca.uwaterloo.ece251.symbol.SymbolTable;
import ca.uwaterloo.ece251.Error;
import java.util.HashMap;
import java.util.Set;
import java.util.HashSet;
import java.util.Map;
import java.util.Stack;
import java.util.List;
import java.util.LinkedList;

/** This visitor checks that all sub-Exps have the right type for
 * their containing Exp, and that Exps have the right type when
 * evaluated. This includes checking function calls, and that tuple
 * accesses are to tuples with the correct types, as well as checking
 * that the tuple plus and minus operators have the right fields in
 * their results. */
public class TypeCheckingVisitor extends DefaultVisitor {
    private SimpleType VOID = new SimpleType(SimpleType.SimpleTypes.VOID);
    private SimpleType BOOL = new SimpleType(SimpleType.SimpleTypes.BOOL);
    private SimpleType INT = new SimpleType(SimpleType.SimpleTypes.INT);
    private SimpleType STRING = new SimpleType(SimpleType.SimpleTypes.STRING);

    Map<Exp, Type> types = new HashMap<Exp, Type>();

    public TypeCheckingVisitor() {
    }

    /** Propagate the type of an Lvalue. */
    public void leave(Lvalue e) {
    }

    /** Propagate boolean type. */
    public void leave(BoolLiteralExp e) {
	types.put(e, BOOL);
    }

    /** Propagate int type. */
    public void leave(IntLiteralExp e) {
    }

    /** Propagate string type. */
    public void leave(StringLiteralExp e) {
    }

    /** Propagate any schema with the fields of the given <code>TupleLiteralExp</code>. */
    public void leave(TupleLiteralExp e) {
    }

    public void leave(UnopExp e) {
    }

    public void leave(TupleopExp e) {
	TupleType t = (TupleType)types.get(e.left);
	Set<Schema> schemas = SymbolTable.v().schemas();
	boolean found = false;
	List<WigField> fs = new LinkedList<WigField>();
	Schema ns = SymbolTable.v().findSchema(t.id);

	switch (e.op) {
	case TUPLE_PLUS: 
	    /* Construct a tuple type from LHStype, 
	     * keeping ids on the right. Find it in the symbol table. */
	    for (Id id : e.right) {
		for (WigField ff : ns.fields) {
		    if (ff.id.equals(id))
			fs.add(ff);
		}
	    }
	    for (Schema s : schemas) {
		if (s.fields.equals(fs)) {
		    t = new TupleType(s.id); 
		    found = true;
		}
	    }
	    if (!found) Error.error("[T18]: tuple operation "+e+" gives nonexistent schema.");
	    break;
	case TUPLE_MINUS:
	    /* Construct a tuple type from LHStype, 
	     * dropping ids on the right. Find it in the symbol table. */
	    // similar to TUPLE_PLUS.
	    break;
	}
	types.put(e, t);
    }

    public void leave(CallExp e) {
    }

    public void leave(BinopExp e) {
    }

    /** Check that LHS and RHS have the same type. */
    public void leave(AssignExp e) {
    }

    /** Check that <code>s</code> occurs inside a <code>Function</code>
     * and that the returned value has the proper type. */
    public void leave(ReturnStm s) {
    }

    /** Check that <code>s</code> occurs inside a <code>Function</code>. */
    public void leave(ReturnVoidStm s) {
    }

    /** Check that the if-condition is boolean. */
    public void leave(IfStm s) {
    }

    /** Check that the while-condition is boolean. */
    public void leave(WhileStm s) {
    }

    /** Check that expressions have non-void simple types. */
    public void leave(PlugDocument d) {
    }

    // Scope operations.

    Stack<CompoundStm> currentScope = new Stack<CompoundStm>();

    /** Record the current scope so that we can query it in the symbol
     * table. */
    public void enter(CompoundStm s) {
    }

    /** Leave a scope. */
    public void leave(CompoundStm s) {
    }
}
