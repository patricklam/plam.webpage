package ca.uwaterloo.ece251.ast;

public class SelectSingleSource extends SingleSource {
    SelectStmt select;
    String as;

    public SelectSingleSource(SelectStmt select, String as) {
	this.select = select;
	this.as = as;
    }

    public void accept(Visitor v) {
	v.enter(this);
	select.accept(v);
	v.leave(this);
    }
}
