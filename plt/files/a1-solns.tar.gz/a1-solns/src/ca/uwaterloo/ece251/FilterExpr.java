package ca.uwaterloo.ece251;

/** AST representation of a "filter" expression. */
public class FilterExpr implements Expr {
    Expr.Filter p;
    Expr v;

    public FilterExpr(Expr.Filter p, Expr v) {
	this.p = p; this.v = v;
    }

    /** Evaluate the argument, then filter it. */
    public Value eval(Interp interp) {
	Value arg = v.eval(interp);
	return arg.filter(p);
    }
}