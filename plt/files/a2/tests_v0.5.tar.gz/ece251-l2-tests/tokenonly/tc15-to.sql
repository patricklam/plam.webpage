SELECT * FROM Customers
WHERE FirstName = 'James' OR FirstName = 'Paula'