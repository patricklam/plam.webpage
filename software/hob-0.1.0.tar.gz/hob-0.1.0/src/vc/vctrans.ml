(* convert iabsyn exprs to vcform exprs *)
open Iabsyn
open Vcform
open Id

let set_var_prefix = "s_"
let prop_var_prefix = "p_"
let local_var_prefix = "l_"
let global_var_prefix = "g_"

(* let mk_local_var s = local_var_prefix ^ Util.replace_dot_with_uscore s *)
let mk_local_var s = Util.replace_dot_with_uscore s
(*
let mk_global_var mn s = 
  global_var_prefix ^ Util.replace_dot_with_uscore (Util.qualify_if_needed mn s)
*)
(*
let mk_set_var s = set_var_prefix ^ Util.replace_dot_with_uscore s
let mk_prop_var s = prop_var_prefix ^ Util.replace_dot_with_uscore s 
*)
let mk_global_var modn s = Util.replace_dot_with_uscore s
let mk_set_var s = Util.replace_dot_with_uscore s
let mk_prop_var s = Util.replace_dot_with_uscore s 

let vcexpr_of_iabsyn mn e =
  let (precond : Vcform.form list ref) = ref [] in
  let add_precond f = (precond := f :: !precond) in
  let rec vcexpr_of_iabsyn0 e =
    match e with
    | LiteralExpr v -> (match v with
      | Int i -> Const (IntConst i)
      | Bool b -> Const (BoolConst b)
      | Obj n when v = Iabsyn.null_obj -> (Const NullConst)
      | Array a when a = [||] -> mk_newArray(mk_int 0,mk_null)
      | _ -> failwith "unsupported literal")
    | VarExpr lv -> (match lv with
      | LocalLvalue l -> Var (mk_local_var l)
      | RefLvalue v -> Var (mk_global_var mn v)
      | FieldLvalue (base, _) 
      | ArrayLvalue (base, _) ->
          failwith "don't yet support these varexprs")
    | FieldAccessExpr (base, f) ->
        let f' = mk_var (name_of_field f) in
        let base' = vcexpr_of_iabsyn0 base in
        let nullCheck = mk_neq(base', mk_null) in
        let _ = add_precond nullCheck in
        Vcform.mk_functionApply(FieldRead,f',base')
    | ArrayAccessExpr (base, i) ->
        let i' = vcexpr_of_iabsyn0 i in
        let base' = vcexpr_of_iabsyn0 base in
        let boundsCheck = mk_and[mk_lteq(mk_int 0, i');
                                 mk_lt(i',mk_arraySize base')] in
        let _ = add_precond boundsCheck in
        Vcform.mk_functionApply(ArrayRead,base',i')
    | ArrayLengthExpr (base) ->
        let base' = vcexpr_of_iabsyn0 base in
        mk_arraySize base'
    | NewExpr t -> 
        failwith "don't yet support newexpr"
    | NewArrayExpr (Types.TObj _, [e], d) (* when d=1 *) ->
        mk_newArray(vcexpr_of_iabsyn0 e, mk_null)
    | NewArrayExpr (_,_,_) ->
        failwith "vctrans, NewArrayExpr: only support 1-dimensional arrays of objects"
    | InvokeExpr (targ, args0) ->
        failwith "encountered a nested proc invocation, please unnest"
    | AssignExpr _ ->
        failwith "no assign in vc expr please!"
    | PostDecExpr e
    | PostIncExpr e
    | PreDecExpr e
    | PreIncExpr e -> 
        failwith "no side effects for vc stmts please!"
    | NegExpr e ->
        failwith "arith not yet in vc"
    | PlusExpr (lhs, rhs) ->
        mk_plus (vcexpr_of_iabsyn0 lhs, vcexpr_of_iabsyn0 rhs)
    | MinusExpr (lhs, rhs) ->
        mk_minus (vcexpr_of_iabsyn0 lhs, vcexpr_of_iabsyn0 rhs)
    | MultExpr (lhs, rhs) ->
        mk_mult (vcexpr_of_iabsyn0 lhs, vcexpr_of_iabsyn0 rhs)
    | DivExpr (lhs, rhs) ->
        mk_div (vcexpr_of_iabsyn0 lhs, vcexpr_of_iabsyn0 rhs)
    | ModExpr (lhs, rhs) ->
        mk_mod (vcexpr_of_iabsyn0 lhs, vcexpr_of_iabsyn0 rhs)
    | BitAndExpr (lhs, rhs)
    | BitOrExpr (lhs, rhs)
    | BitXorExpr (lhs, rhs)
    | ShiftLeftExpr (lhs, rhs)
    | SignedShiftRightExpr (lhs, rhs)
    | UnsignedShiftRightExpr (lhs, rhs) ->
        failwith "arith not yet in vc"
    | AndExpr (lhs, rhs) ->
        mk_and [vcexpr_of_iabsyn0 lhs;
                vcexpr_of_iabsyn0 rhs]
    | OrExpr (lhs, rhs) ->
        mk_or [vcexpr_of_iabsyn0 lhs;
               vcexpr_of_iabsyn0 rhs]
    | NotExpr e ->
        mk_not (vcexpr_of_iabsyn0 e)
    | EqExpr (lhs, rhs) ->
        mk_eq (vcexpr_of_iabsyn0 lhs,
               vcexpr_of_iabsyn0 rhs)
    | NeqExpr (lhs, rhs) ->
        mk_not (mk_eq (vcexpr_of_iabsyn0 lhs,
                       vcexpr_of_iabsyn0 rhs))
    | LtExpr (lhs, rhs) ->
        mk_lt (vcexpr_of_iabsyn0 lhs,
               vcexpr_of_iabsyn0 rhs)
    | GtExpr (lhs, rhs) ->
        mk_gt (vcexpr_of_iabsyn0 lhs,
               vcexpr_of_iabsyn0 rhs)
    | LteqExpr (lhs, rhs) ->
        mk_lteq (vcexpr_of_iabsyn0 lhs,
                 vcexpr_of_iabsyn0 rhs)
    | GteqExpr (lhs, rhs) ->
        mk_gteq (vcexpr_of_iabsyn0 lhs,
                 vcexpr_of_iabsyn0 rhs)
  in let res = vcexpr_of_iabsyn0 e in
  (res, mk_and !precond)

let conj_vcexpr_of_iabsyn mn e =
  let (vcf,pre) = vcexpr_of_iabsyn mn e in
  mk_and [pre;vcf]

let rec vctype_of (t:Types.value_type) : Vcform.typeExpr = 
  match t with
    Types.TInt -> TypeInt
  | Types.TBool -> TypeBool
  | Types.TVoid -> TypeVoid
  | Types.TObj v -> TypeObjRef v
  | Types.TSet v -> TypeSet (vctype_of v)
  | Types.TArray v -> TypeArray (vctype_of v)
  | Types.TTuple _ -> TypeUniverse
  | Types.TFloat -> TypeUniverse
  | Types.TString -> TypeUniverse
  | Types.TChar -> TypeUniverse
  | Types.TByte -> TypeUniverse

let rec vcexpr_of_sabsyn_form f =
  let rec vcexpr_of_sabsyn_setexp se =
    match se with
    | Sabsyn.Prevar s -> Var (mk_set_var s)
    | Sabsyn.Postvar s -> Var (mk_set_var s ^ "'")
    | Sabsyn.Emptyset -> Const EmptysetConst
    | Sabsyn.Union us -> App (Const Cup, List.map vcexpr_of_sabsyn_setexp us)
    | Sabsyn.Inter is -> App (Const Cap, List.map vcexpr_of_sabsyn_setexp is)
    | Sabsyn.Diff (t, u) -> App (Const Diff, [vcexpr_of_sabsyn_setexp t;
                                       vcexpr_of_sabsyn_setexp u]) in
  let rec vcexpr_of_sabsyn_atom af =
    match af with
    | Sabsyn.Eq (s, t) -> mk_eq (vcexpr_of_sabsyn_setexp s,
                          vcexpr_of_sabsyn_setexp t)
    | Sabsyn.Neq (s, t) -> mk_not (mk_eq (vcexpr_of_sabsyn_setexp s,
                                   vcexpr_of_sabsyn_setexp t))
    | Sabsyn.Sub (s, t) -> mk_sub (vcexpr_of_sabsyn_setexp s,
                            vcexpr_of_sabsyn_setexp t)
    | Sabsyn.True -> Const (BoolConst true)
    | Sabsyn.False -> Const (BoolConst false)
    | Sabsyn.Cardeq (s, i) -> App (Const Cardeq, [vcexpr_of_sabsyn_setexp s;
                                                  Const (IntConst i)])
    | Sabsyn.Cardleq (s, i) -> App (Const Cardleq, [vcexpr_of_sabsyn_setexp s;
                                                    Const (IntConst i)])
    | Sabsyn.Cardgeq (s, i) -> App (Const Cardgeq, [vcexpr_of_sabsyn_setexp s;
                                                    Const (IntConst i)])
    | Sabsyn.Disjoint dl -> App (Const Disjoint, 
                          List.map vcexpr_of_sabsyn_setexp dl)
    | Sabsyn.Propvar pi -> Var (mk_prop_var pi)
    | Sabsyn.Propvarpost pi -> Var (mk_prop_var pi ^ "'") in
  match f with
  | Sabsyn.Atom af -> vcexpr_of_sabsyn_atom af
  | Sabsyn.Not f' -> mk_not (vcexpr_of_sabsyn_form f')
  | Sabsyn.And fl -> mk_and (List.map vcexpr_of_sabsyn_form fl)
  | Sabsyn.Or fl -> mk_or (List.map vcexpr_of_sabsyn_form fl)
  | Sabsyn.Impl (r, s) -> mk_impl (vcexpr_of_sabsyn_form r,
                            vcexpr_of_sabsyn_form s)
  | Sabsyn.Iff (r, s) -> mk_iff (vcexpr_of_sabsyn_form r,
                            vcexpr_of_sabsyn_form s)
  | Sabsyn.ExistsOne (v, f) -> failwith "vctrans deprec"
  | Sabsyn.ForallOne (v, f) -> failwith "vctrans deprec"
  | Sabsyn.ExistsSet (v, f) -> Binder (Exists, [fst v, vctype_of (snd v)], 
                                vcexpr_of_sabsyn_form f)
  | Sabsyn.ForallSet (v, f) -> Binder (Forall, [fst v, vctype_of (snd v)], 
                                vcexpr_of_sabsyn_form f)
  | Sabsyn.ExistsProp (v, f) -> Binder (Exists, [v, TypeBool],
                                        vcexpr_of_sabsyn_form f)
  | Sabsyn.ForallProp (v, f) -> Binder (Forall, [v, TypeBool],
                                        vcexpr_of_sabsyn_form f)
  | Sabsyn.UninterpretedString s -> Vcformparseutil.parse_formula s

let rec sabsyn_type_of_vc_type_expr t =
  match t with
  | TypeObjRef s -> Types.TObj s
  | TypeVar _ -> failwith "can't convert TypeVar to value_type"
  | TypeList _ -> failwith "can't convert TypeList to value_type"
  | TypeFun _ -> failwith "can't convert TypeFun to value_type"
  | TypeUniverse -> failwith "can't convert TypeUniverse to value_type"
  | TypeArray t -> Types.TArray (sabsyn_type_of_vc_type_expr t)
  | TypeSet t -> Types.TSet (sabsyn_type_of_vc_type_expr t)
  | TypeInt -> Types.TInt
  | TypeBool -> Types.TBool
  | TypeVoid -> Types.TVoid

let sabsyn_form_of_vcform mn local_names f =
  let rec sabsyn_form_of_vcform0 f = 
    let rec convert_setexp se =
      match se with
      | Const EmptysetConst -> Sabsyn.Emptyset
      | Const NullConst -> Sabsyn.Emptyset
      | Var v -> 
          let v_unprimed = Util.unprime v in
          let v' = if List.mem v_unprimed local_names then 
            v 
          else 
            Util.qualify_if_needed mn v in
          if (Util.is_primed v) then 
            Sabsyn.Postvar v'
          else 
            Sabsyn.Prevar v'
      | App (Const Cup, sel) ->
          Sabsyn.Union (List.map convert_setexp sel)
      | App (Const Cap, sel) ->
          Sabsyn.Inter (List.map convert_setexp sel)
      | App (Const Diff, sel) ->
          let (d1, d2) = convert_setexp_pair sel in
          Sabsyn.Diff (d1, d2)
      | App (Const Minus, sel) ->
          let (d1, d2) = convert_setexp_pair sel in
          Sabsyn.Diff (d1, d2)
      | App (Const FiniteSetConst, args) -> Sabsyn.Union (convert_setexps args)
      | TypedForm (f, t) -> convert_setexp f
      | Binder _ -> failwith "binder not a setexp"
      | Const _ -> failwith "this const not a setexp"
      | App _ -> failwith ("applying something that's not a setexp, in formula " ^ Vcprint.isabelle_formula se)
    and convert_setexp_pair args =
      match args with
      | [a1; a2] -> (convert_setexp a1, convert_setexp a2)
      | _ -> failwith "not a two-element list"
    and convert_setexps es =
      (match es with
      | [] -> []
      | e::es1 -> convert_setexp e :: convert_setexps es1)
    in
    match f with
    | Binder (k, vl, f0) ->
        (let vl' = List.map 
            (fun (v, t) -> (v, sabsyn_type_of_vc_type_expr t)) vl in
        let f' = sabsyn_form_of_vcform0 f0 in
        match k with
        | Forall -> 
            List.fold_right 
              (fun v f' -> Sabsyn.ForallSet (v, f')) vl' f'
        | Exists -> 
            List.fold_right 
              (fun v f' -> Sabsyn.ExistsSet (v, f')) vl' f'
        | _ -> failwith "can't transform lambda or comprehension to sabsyn")
    | TypedForm (f, t) -> sabsyn_form_of_vcform0 f
    | Var v -> failwith "improper top-level var in vcexpr"
    | Const c -> (match c with
      | BoolConst true -> Sabsyn.Atom Sabsyn.True | 
        BoolConst false -> Sabsyn.Atom Sabsyn.False
      | IntConst k -> failwith "no int consts in sabsyn"
      | _ -> failwith "improper top-level const in vcexpr")
    | App (Const op, args) ->
        (match op with
        | Eq -> 
            let (s1, s2) = convert_setexp_pair args in
            Sabsyn.Atom (Sabsyn.Eq (s1, s2))
        | Sub -> 
            let (s1, s2) = convert_setexp_pair args in
            Sabsyn.Atom (Sabsyn.Sub (s1, s2))
        | Elem -> 
            let (s1, s2) = convert_setexp_pair args in
            Sabsyn.Atom (Sabsyn.Sub (s1, s2))
        | Or -> Sabsyn.Or (List.map sabsyn_form_of_vcform0 args) 
        | And -> Sabsyn.Or (List.map sabsyn_form_of_vcform0 args) 
        | MetaAnd -> failwith "huh"
        | Not -> 
            (match args with 
            | [a] -> 
                Sabsyn.Not (sabsyn_form_of_vcform0 a)
            | _ -> failwith "notting multiple args")
        | Impl -> 
            (match args with 
            | [s; t] -> 
                Sabsyn.Impl (sabsyn_form_of_vcform0 s, 
                             sabsyn_form_of_vcform0 t)
            | _ -> failwith "Impl-ing args where |args| != 2")
        | MetaImpl -> failwith "huh"
        | Iff -> 
            (match args with 
            | [s; t] -> 
                Sabsyn.Iff (sabsyn_form_of_vcform0 s, 
                            sabsyn_form_of_vcform0 t)
            | _ -> failwith "iff-ing args where |args| != 2")
        | Disjoint -> 
            Sabsyn.Atom (Sabsyn.Disjoint (List.map convert_setexp args))
        | Cardeq -> 
            (match args with 
            | [s; Const (IntConst k)] -> 
                Sabsyn.Atom (Sabsyn.Cardeq (convert_setexp s, k))
            | _ -> failwith "bad form for cardeq")
        | Cardleq -> 
            (match args with 
            | [s; Const (IntConst k)] -> 
                Sabsyn.Atom (Sabsyn.Cardleq (convert_setexp s, k))
            | _ -> failwith "bad form for cardleq")
        | Cardgeq -> 
            (match args with 
            | [s; Const (IntConst k)] -> 
                Sabsyn.Atom (Sabsyn.Cardgeq (convert_setexp s, k))
            | _ -> failwith "bad form for cardgeq")
        | Cap | Cup | Diff -> failwith "setexp in non-setexp context!"
        | ArrayRead | ArrayWrite | NewArray | ArraySize -> 
            failwith "no arrays in sabsyn (yet)"
        | FieldWrite | FieldRead -> failwith "no fields in sabsyn (yet)"
        | Lt | Gt | LtEq | GtEq
        | Plus | Minus | Mult | Div | Mod ->
            failwith "arithmetic inappropriate for sabsyn"
        | FiniteSetConst -> 
            failwith "found finite set when expected a formula"
        | IntConst _ | BoolConst _ | NullConst | EmptysetConst -> 
            failwith "can't apply a literal"
        | Tuple -> failwith "can't deal with tuples")
    | App _ -> failwith "can't apply anything else" in
  sabsyn_form_of_vcform0 f


let interpret_uninterpreted_strings ast =
  let rec interpret_form local_names (f:Sabsyn.form) = 
    match f with
    | Sabsyn.And cs -> Sabsyn.And (List.map (interpret_form local_names) cs)
    | Sabsyn.UninterpretedString s -> 
        let vcs = Vcformparseutil.parse_formula (Util.trim_quotes s) in
        sabsyn_form_of_vcform ast.Sabsyn.module_name local_names vcs
    | _ -> f in
  let interpret_proc p = 
    let rv_name = match p.Sabsyn.ret_val with 
      None -> []
    | Some x -> [fst x] in
    let local_names = List.concat [(List.map fst p.Sabsyn.formals); rv_name] in
    {
     Sabsyn.proc_name = p.Sabsyn.proc_name;
     Sabsyn.proc_modifiers = p.Sabsyn.proc_modifiers;
     Sabsyn.formals = p.Sabsyn.formals;
     Sabsyn.ret_val = p.Sabsyn.ret_val;
     Sabsyn.suspends = p.Sabsyn.suspends;
     Sabsyn.requires = interpret_form local_names p.Sabsyn.requires;
     Sabsyn.modifies = p.Sabsyn.modifies;
     Sabsyn.calls    = p.Sabsyn.calls;
     Sabsyn.extra_ensures = List.map (fun (x, y) -> (interpret_form local_names x, y)) p.Sabsyn.extra_ensures;
     Sabsyn.ensures  = interpret_form local_names p.Sabsyn.ensures;
   } in
  { 
    Sabsyn.module_name = ast.Sabsyn.module_name;
    Sabsyn.instantiated_from = ast.Sabsyn.instantiated_from;
    Sabsyn.param_subst = ast.Sabsyn.param_subst;
    Sabsyn.properties = ast.Sabsyn.properties;
    Sabsyn.formats = ast.Sabsyn.formats;
    Sabsyn.specvars = ast.Sabsyn.specvars;
    Sabsyn.invariants = ast.Sabsyn.invariants;
    Sabsyn.procs = List.map interpret_proc ast.Sabsyn.procs;
    Sabsyn.defaults = ast.Sabsyn.defaults;
  }
