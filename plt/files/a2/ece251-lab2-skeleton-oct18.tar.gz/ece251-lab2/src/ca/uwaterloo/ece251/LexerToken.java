package ca.uwaterloo.ece251;

/** Raw tokens: your lexer must convert these into <code>Token</code>
 * instances. */
public class LexerToken {
    int ln; int colstart, colend;
    String s;

    public LexerToken(String s, int ln, int colstart, int colend) {
	this.s = s; this.ln = ln; 
	this.colstart = colstart; this.colend = colend;
    }

    public LexerToken(String s) {
	this.s = s; this.ln = -1; 
	this.colstart = -1; this.colend = colend;
    }
}
