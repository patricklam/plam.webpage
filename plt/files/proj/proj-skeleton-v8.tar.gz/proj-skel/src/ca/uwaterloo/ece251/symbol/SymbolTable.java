package ca.uwaterloo.ece251.symbol;
import ca.uwaterloo.ece251.ast.*;
import ca.uwaterloo.ece251.Error;

import java.util.Arrays;
import java.util.Map;
import java.util.HashMap;
import java.util.Stack;
import java.util.Set;
import java.util.HashSet;

/** Symbol table. */
public class SymbolTable {
    private ASTNode GLOBAL = new CompoundStm(null, null);
    private SymbolTable() {
	enterScope(GLOBAL);
	scopesForASTNode.put(GLOBAL, currentScopes);
    }

    private static SymbolTable instance = new SymbolTable();
    public static SymbolTable v() { return instance; }

    /* In WIG, htmls, functions, sessions, and schemas are top-level
     * definitions. */

    /* Functions and schemas live in separate namespaces, while
     * all variables live in the same namespace. 
     * This means that we allow a function and a variable to have the
     * same name. */

    Map<Id, HTML> htmls = new java.util.HashMap<Id, HTML>();
    Map<Id, Function> functions = new java.util.HashMap<Id, Function>();
    Map<Id, Schema> schemas = new java.util.HashMap<Id, Schema>();
    Map<Id, Session> sessions = new java.util.HashMap<Id, Session>();

    Stack<Map<Id, Type>> currentScopes = new Stack<Map<Id, Type>>();
    Map<ASTNode, Stack<Map<Id, Type>>> scopesForASTNode = 
	new HashMap<ASTNode, Stack<Map<Id, Type>>>();

    /** Add a new html into the global symbol table. */
    public void insert(HTML h) {
    }

    /** Returns the HTML with the given name. */
    public HTML findHTML(Id id) {
    }

    /** Add a new session into the global symbol table. */
    public void insert(Session s) {
    }

    /** Returns the session with the given name. */
    public Session findSession(Id id) {
    }

    /** Add a new function into the global symbol table. */
    public void insert(Function f) {
    }

    /** Returns the function with the given name. */
    public Function findFunction(Id id) {
    }

    /** Returns the set of functions. */
    public Set<Function> functions() {
    }

    /** Add a new schema into the global symbol table.
     * Checks the schema for multiply-defined field names. */
    public void insert(Schema s) {
    }

    /** Returns the set of schemas. */
    public Set<Schema> schemas() {
    }

    /** Returns the schema with the given name. */
    public Schema findSchema(Id id) {
    }

    /** Insert a variable into the current scope. */
    public void insert(Type t, Id v) {
    }

    /** Start a new scope and associate it with the given ASTNode. */
    public void enterScope(ASTNode s) {
    }

    /** Leave a scope. */
    public void leaveScope() {
    }

    /** Returns the type of <code>id</code> if defined in the current scope,
     * else returns null. */
    public Type findLocal(Id id) { 
    }

    /** Returns the type of <code>id</code> if defined,
     * else returns null. */
    public Type find(Id id) { 
    }

    /** Returns the type of <code>id</code> if defined in the scope of
     * <code>cs</code>, else returns null. */
    public Type findInScope(Id id, ASTNode cs) { 
    }

    void dumpScope(final ASTNode n, final StringBuffer sb) {
	Stack<Map<Id, Type>> s = scopesForASTNode.get(n);
	Map<Id, Type> m;

	// We always have the GLOBAL scope. If we're specifically supposed
	// to print it, then do so; otherwise we have one scope available.
	if (n == GLOBAL) {
	    sb.append("GLOBAL: "); 
	    m = s.get(0);
	}
	else {
	    if (n instanceof Function) {
		sb.append("Function "+((Function)n).id+": ");
	    } else if (n instanceof Session) {
		sb.append("Session "+((Session)n).id+": ");
		dumpScope(((Session)n).body, sb);
		return;
	    }

	    m = s.peek();
	}

	Id[] ids = m.keySet().toArray(new Id[0]);
	String[] outs = new String[ids.length];
	Arrays.sort(ids);
	
	for (int i = 0; i < ids.length; i++) {
	    outs[i] = ids[i] + ": " + m.get(ids[i]);
	}
	sb.append(Arrays.asList(outs));

	if (n != GLOBAL) {
	    n.accept(new DefaultVisitor() {
		    public void enter(CompoundStm s) {
			if (s != n)
			    dumpScope(s, sb); 
		    }
		});
	}
    }

    public String dump() {
	StringBuffer sb = new StringBuffer();
	Id[] ha = htmls.keySet().toArray(new Id[0]);
	Id[] fa = functions.keySet().toArray(new Id[0]);
	Id[] sca = schemas.keySet().toArray(new Id[0]);
	Id[] sa = sessions.keySet().toArray(new Id[0]);
	Arrays.sort(ha); Arrays.sort(fa); Arrays.sort(sca);
	sb.append("HTMLs: "+Arrays.asList(ha)+"\n");
	sb.append("Functions: "+Arrays.asList(fa)+"\n");
	sb.append("Schemas: "+Arrays.asList(sca)+"\n");
	sb.append("Sessions: "+Arrays.asList(sa)+"\n");
	sb.append("\n");
	sb.append("List of scopes:\n");
	dumpScope(GLOBAL, sb); 
	sb.append("\n");
	for (Id f : fa) {
	    dumpScope(findFunction(f), sb);
	    sb.append("\n");
	}
	for (Id f : sa) {
	    dumpScope(findSession(f), sb);
	    sb.append("\n");
	}

	return sb.toString();
    }
}
