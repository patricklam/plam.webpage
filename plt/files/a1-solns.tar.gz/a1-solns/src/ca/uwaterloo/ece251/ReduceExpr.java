package ca.uwaterloo.ece251;

/** AST representation of a "reduce" expression. */
public class ReduceExpr implements Expr {
    Expr.Accumulator c;
    Expr v;

    public ReduceExpr(Expr.Accumulator c, Expr v) {
	this.c = c; this.v = v;
    }

    public Value eval(Interp interp) {
	Value arg = v.eval(interp);
	return arg.reduce(c);
    }
}