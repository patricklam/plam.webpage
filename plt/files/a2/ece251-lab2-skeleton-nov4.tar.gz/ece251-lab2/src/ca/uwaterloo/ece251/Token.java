package ca.uwaterloo.ece251;

import java.util.regex.*;

/** Tokens after lexical analysis. Your first task is to convert
 * <code>LexerToken</code> instances into <code>Token</code> instances. */
public class Token {
    /** Store the raw data. */
    LexerToken rawToken;
    Type t;

    enum Type {
	EXPLAIN(""),
        QUERY(""),
        PLAN(""),
        CREATE(""),
        TEMP(""),
        TEMPORARY(""), 
	TABLE(""),
        IF(""),
        NOT(""),
        EXISTS(""),
	AS(""),
	NULL(""),
        INTEGER(""),
        REAL(""),
        TEXT(""),
	BLOB(""),
	DROP(""), 
	INSERT(""),
        REPLACE(""),
        INTO(""),
	VALUES(""),
        DEFAULT(""),
	LIMIT(""),
	SELECT(""),
        DISTINCT(""),
        ALL(""),
	INNER(""),
	FROM(""),
        WHERE(""),
	UPDATE(""),
        SET(""), 
	VACUUM(""),
	ISNULL(""),
        NOTNULL(""),
	SEMICOLON(""),
 	LPAREN(""),
        COMMA(""),
        RPAREN(""),
        DOT(""),
	STAR(""),
        EQUALS(""), 
	PLUS(""),
        MINUS(""),
        SLASH(""),
        PERCENT(""),
        LE(""),
        LT(""),
        GE(""),
        GT(""),
	ID(""),
	NUMERIC_LITERAL(""), 
	BOOLEAN_LITERAL(""), 
	STRING_LITERAL("");
 
	private final Pattern p;
	Type(String text) {
	    this.p = Pattern.compile(text, Pattern.CASE_INSENSITIVE);
	}
	public boolean matches(String s) { 
	    return p.matcher(s).matches(); 
	}
    };

    public Token(LexerToken rawToken) {
	this.rawToken = rawToken;
	String u = rawToken.s.toUpperCase();
	for (Token.Type tt : Token.Type.values())
	    if (tt.matches(u)) {
		this.t = tt;
		break;
	    }
    }

    /** Returns the token text associated with this token. */
    public String getText() {
	return this.rawToken.s;
    }

    /** Returns a textual representation of the token. */
    public String toString() {
	String ts = t == null ? "null" : t.toString();
	return "["+ts+": ('"+rawToken.s+"'), line "+rawToken.ln+", col "+rawToken.colstart+"-"+rawToken.colend+"]";
    }
}
