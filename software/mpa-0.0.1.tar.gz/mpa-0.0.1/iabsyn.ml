open Id
open Types

(* Abstract Syntax for Implementation Language *)

(* heap elements *)
type value = 
    Int of int
  | Bool of bool
  | Float of float
  | String of string
  | Char of char
  | Obj of int
  | Array of value array


let rec value_type_of_value x =
  match x with
  | Int _ -> TInt
  | Bool _ -> TBool
  | Float _ -> TFloat
  | String _ -> TString
  | Char _ -> TChar
  | Obj _ -> (TObj Id.unknown_format)
  | Array y -> TArray (value_type_of_value (y.(0)))
(* yes, we don't know the type of arrays of length 0 either. *)
(* in fact that would fail with array-out-of-bds *)

let null_obj = Obj 0

let initial_value x =
  match x with
  | TInt -> Int 0
  | TBool -> Bool false
  | TFloat -> Float 0.
  | TString -> String ""
  | TChar -> Char (char_of_int 0)
  | TObj _ -> null_obj
  | TVoid -> failwith "no initial value for void"
  | TArray y -> Array [| |]

(* program elements *)

type lvalue =
    LocalLvalue of var_t
  | RefLvalue of var_t
  | FieldLvalue of expr * field_t
  | ArrayLvalue of expr * expr
and expr =
    LiteralExpr of value
  | VarExpr of lvalue
  | FieldAccessExpr of expr * field_t
  | ArrayAccessExpr of expr * expr
  | NewExpr of Id.format_t
  | NewArrayExpr of value_type * expr list * int
  | InvokeExpr of proc_t * expr list
  | AssignExpr of lvalue * expr
  | PreIncExpr of lvalue | PostIncExpr of lvalue 
  | PreDecExpr of lvalue | PostDecExpr of lvalue
  | NegExpr of expr
  | PlusExpr of expr * expr
  | MinusExpr of expr * expr
  | MultExpr of expr * expr
  | DivExpr of expr * expr
  | ModExpr of expr * expr
  | AndExpr of expr * expr
  | OrExpr of expr * expr
  | NotExpr of expr
  | EqExpr of expr * expr
  | NeqExpr of expr * expr
  | LtExpr of expr * expr
  | GtExpr of expr * expr
  | LteqExpr of expr * expr
  | GteqExpr of expr * expr
  | BitAndExpr of expr * expr
  | BitOrExpr of expr * expr
  | BitXorExpr of expr * expr
  | ShiftLeftExpr of expr * expr
  | SignedShiftRightExpr of expr * expr
  | UnsignedShiftRightExpr of expr * expr

type 'asrt stmt =
    EmptyStmt
  | CompoundStmt of 'asrt stmt list
  | ChoiceStmt of 'asrt stmt * 'asrt stmt (* don't try to execute this! *)
  | LocalDeclStmt of var_t * value_type * expr
  | ExprStmt of expr 
    (* we should warn if not unit type *)
  | ReturnStmt of expr option
  | WhileStmt of 'asrt option * expr * 'asrt stmt
  | AssertStmt of string option * 'asrt
  | AssumeStmt of string option * 'asrt
  | HavocStmt of var_t list
  | PragmaStmt of string
  | IfStmt of expr * ('asrt stmt) * ('asrt stmt)

type format_decl = {
    format_name : format_t;
    fields      : (field_t * value_type) list
  }

type 'asrt proc_def = {
    proc_id    : proc_t;
    formals    : (var_t * value_type) list;
    ret_val    : (var_t * value_type) option;
    proc_body  : 'asrt stmt
  }

type 'asrt impl_module = {
    module_name : module_t;
    instantiated_from : module_t option;
    param_subst : (format_t * format_t) list;
    formats     : format_decl list;
    references  : (var_t * value_type) list;
    procs       : ('asrt proc_def) list
  }

module E = 
  struct
    type t = expr
    let equal = (==)
    let hash = Hashtbl.hash
  end

module Exprtbl = Hashtbl.Make (E)

module S = 
  struct
    type t = Sabsyn.form stmt
    let equal = (==)
    let hash = Hashtbl.hash
  end

module Stmttbl = Hashtbl.Make (S)
