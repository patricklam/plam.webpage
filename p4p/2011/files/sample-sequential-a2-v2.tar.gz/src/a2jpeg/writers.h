#include "list.h"

extern struct list_head writers;
