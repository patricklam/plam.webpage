let _ =
  while true do
    let input = read_line() in
    let f = Vcformparseutil.parse_formula input in
    let s = Vcprint.isabelle_formula f ^ "\n" in
    print_string ("Parsed a formula:\n" ^ s)
  done
