package ca.uwaterloo.ece251.ast;

import java.util.List;

/** Literal for tuples. */
public class TupleLiteralExp extends Exp {
    List<Id> fields;
    List<Exp> values;

    public TupleLiteralExp(List<Id> fields, List<Exp> values) {
	this.fields = fields; this.values = values; 
    }

    public String toString() {
	StringBuffer sb = new StringBuffer("tuple");
	if (fields != null && values != null) 
	    sb.append(" ("+Util.interleave(fields, values, " ", ", ")+")");
	else
	    sb.append(" {}");
	return sb.toString();
    }
}
