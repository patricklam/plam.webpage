package ca.uwaterloo.ece251.ast;

import java.util.List;

public class JoinSingleSource extends SingleSource {
    List<SingleSource> js;

    public JoinSingleSource(List<SingleSource> js) {
	this.js = js;
    }

    public void accept(Visitor v) {
	v.enter(this);
	for (SingleSource ss : js)
	    ss.accept(v);
	v.leave(this);
    }
}
