package ca.uwaterloo.ece251.ast;

/** Represents a conditional statement. */
public class IfStm extends Stm {
    Exp c;
    Stm thenBranch;
    Stm elseBranch;

    public IfStm(Exp c, Stm thenBranch, Stm elseBranch) {
	this.c = c;
	this.thenBranch = thenBranch;
	this.elseBranch = elseBranch;
    }

    public String toString() {
	return 
	    String.format("if (%s) %s;", c.toString(), thenBranch.toString()) + 
	    elseBranch == null ? "" : elseBranch.toString();
    }
}

