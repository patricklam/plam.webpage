package ca.uwaterloo.ece251.ast;

public class ColumnDef extends ASTNode {
    String id;
    Type t;

    public ColumnDef(String id, Type t) {
	this.id = id; this.t = t;
    }

    public void accept(Visitor v) {
	v.enter(this);
	v.leave(this);
    }
}
