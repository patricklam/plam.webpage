open Types
open Paleprinter

let pale_name = "palemona"

let write_types (file : out_channel)
    (ma : string Aabsyn.abst_module) : unit = 
  ()

let write_globals (file : out_channel)
    ((ma : string Aabsyn.abst_module),
     (mi : string Iabsyn.impl_module)) : unit = 
  ()

let get_str_from_clause (c : string Aabsyn.clause) : string = 
  match c with
  | Aabsyn.FormulaClause s -> s
  | _ -> failwith
        "Only FormulaClause allowed in PALE plugin."

let write_clause (file : out_channel)
    (c : string Aabsyn.clause) : unit = 
  output_string file (get_str_from_clause c)

let copy_invariants (file : out_channel) 
    (mi : string Iabsyn.impl_module)
    (ma : string Aabsyn.abst_module) : unit =
  let fmat = List.hd mi.Iabsyn.formats in
  let f = fmat.Iabsyn.format_name in
  let wr c =
    let str = get_str_from_clause c in begin
      if (String.sub str 0 4) = "type" then 
        let untilBracket = String.sub str 0 (String.length str - 2) in
        begin
          output_string file untilBracket;
          output_string file ("\ndata nextExternal : "^f^";\n"^
                              "pointer prevExternal : "^f^"\n"^
                              "[this^"^f^".nextExternal = {prevExternal}];\n"^
                              "bool isExternal;\n");
          output_string file "}\n"
        end
      else begin        
        write_clause file c
      end;
      output_string file "\n\n"
    end
  in List.iter wr ma.Aabsyn.invariants

let write_pred_defs (file : out_channel)
    (ma : string Aabsyn.abst_module) : unit = 
  let wr_def (d0: string Aabsyn.set_defn) =
    match (snd d0) with
    | Aabsyn.BaseForm d -> 
        let wr = output_string file in
        let set_name = Util.replace_dot_with_uscore (fst d0) in
        let pred_name = set_to_pred set_name in
        let bound_var = d.Aabsyn.x in
        let type_name = Util.replace_dot_with_uscore d.Aabsyn.xt in
        let defining_expr = d.Aabsyn.expr in
        begin
          wr "pred "; wr pred_name; 
          wr "(set "; wr set_name; wr ": "; wr type_name; wr ") =\n";
          wr "  allpos "; wr bound_var; wr " of "; wr type_name;
          wr ": "; wr bound_var; wr " in "; wr set_name; wr " <=> ";
          write_clause file defining_expr; wr ";\n"
        end
    | _ -> failwith "pale can't take cpd sets"
  in List.iter wr_def ma.Aabsyn.set_defns

let write_external_inv_def (file : out_channel)
    (ma : string Aabsyn.abst_module)
    (mi : string Iabsyn.impl_module) : unit =
  let wr s = output_string file s in
  let fmat = List.hd mi.Iabsyn.formats in
  let fmat_name = fmat.Iabsyn.format_name in
  let filter_obj_types = 
    function
      | (_, TObj _) -> true
      | _ -> false in
  let fmat_fields = List.map 
      (fun x -> (fst x).Id.f_name)
      (List.filter filter_obj_types
         fmat.Iabsyn.fields) in
  let (def_str, d) = match (List.hd ma.Aabsyn.set_defns) with
  | (_, Aabsyn.BaseForm d0) -> 
      (get_str_from_clause d0.Aabsyn.expr, d0)
  | _ -> failwith "can't write_external_inv_def of cpd" in
  let v = String.sub def_str (String.length def_str - 1) 1 in  
  let write_field_null s = wr (v^"."^s^"=null & ") in
  (* let write_field_plus s = wr (s^"+") in *)
      (* gross hack *)
  begin    
    wr ("data externals : "^fmat_name^";\n");
    wr "pred externalInv() = \n";
    wr ("  allpos "^v^" of " ^ fmat_name ^ ":\n");
    wr ("("^v^".isExternal =>\n");
    List.iter write_field_null fmat_fields;
    wr ("externals<nextExternal*>"^v^") &\n");
    wr ("((!"^v^".isExternal) =>\n");
    wr (v^".nextExternal=null & "^v^".prevExternal=null & ");
    (* List.iter write_field_plus fmat_fields; *)
    write_clause file d.Aabsyn.expr;
    wr ");\n"
  end

let write_header (file : out_channel)
    ((ma : string Aabsyn.abst_module),
     (ms : Sabsyn.spec_module),
     (mi : string Iabsyn.impl_module)) : unit = 
  begin
    (*
       write_types file ma;
       write_globals file (ma, mi);
    *)
    copy_invariants file mi ma;
    write_external_inv_def file ma mi;
    write_pred_defs file ma
  end


let pale_says_valid (file_name : string) : bool =
  let out_file = file_name ^ ".out" in
  let err_file = file_name ^ ".err" in
  begin
    (try Sys.remove out_file with Sys_error _ -> ());    
    (*
    ignore (Sys.command ("cat " ^ file_name));
     *)
    let result = Sys.command (pale_name ^ " " ^ file_name ^ " > " ^ out_file 
                              ^ ">&" ^ err_file) in
    (result==42)
  end

let analyze_proc 
    ((ma : string Aabsyn.abst_module),
     (ms : Sabsyn.spec_module),
     (mi : string Iabsyn.impl_module))
    (p : Sabsyn.proc_spec) : bool = 
  let file_name = p.Sabsyn.proc_name.Id.p_name ^ "-" ^
    p.Sabsyn.proc_name.Id.p_module ^ ".pale" in
  let file = open_out file_name in
  let wr = output_string file in
  let err s = Util.error s in
  let pname = p.Sabsyn.proc_name in

  let (global_refs : (string * string) list) =
    let pick_formats (v,t) = match t with
    | TObj format_name -> [(v,format_name)]
    | _ -> [] in        
    List.concat (List.map pick_formats mi.Iabsyn.references) in
  let _ = if global_refs = [] then err "no global references found" in
  let fmt = match (List.hd global_refs) with (v,t) -> t in
  let _ =
    if not (List.for_all (fun (v,t) -> t=fmt) global_refs) 
    then err ("All globals expected to be references of format " ^ fmt)
    else () in
  let global_refnames = 
    List.map Util.replace_dot_with_uscore
      (List.map fst global_refs) in

  let global_sets = Spec.collect_sets_types ms in
  let _ = 
    if not (List.for_all (fun (v,t) -> t=fmt) global_sets) 
    then err ("All specification sets expected to be of format " ^ fmt)
    else () in
  let setnames = List.map Util.replace_dot_with_uscore
      (List.map fst global_sets) in
  
  let is_pointer fmt ((v,t) : (Id.var_t * value_type)) : bool = match t with
  | TObj fmt1 when fmt1=fmt -> true
  | _ -> false in
  
  let pointer_paramnames = List.map fst (List.filter (is_pointer fmt) p.Sabsyn.formals) in
  
  let ret = match p.Sabsyn.ret_val with
  | Some (v,(TObj fmt1)) when fmt1=fmt -> Some v
  | _ -> None in

  let retparam = match ret with
  | Some v -> [v]
  | None -> [] in

  let singletons = global_refnames @ pointer_paramnames in

  let write_params() =
    let mk_param v = "pointer " ^ v ^ " : " ^ fmt in
    let printed = List.map mk_param pointer_paramnames in
    begin
      wr "proc ";
      wr pname.Id.p_name; wr "_"; wr pname.Id.p_module;
      wr "("; 
      wr (String.concat ";" printed); 
      wr "):";
      (match ret with
      | Some t -> wr fmt
      | None -> wr "void");
      wr "\n"
    end in
  
  let write_precondition() =
    let wr_setdef s = begin
      wr (set_to_pred s); wr "(";
      wr s; wr ") &\n";
    end in
    let wr_external_general_case v =
      wr ("(!"^v^ " in " ^ 
          List.hd setnames ^  (* assumes first is data !!! *)
          " => "^v^".nextExternal!=null & "^v^".prevExternal!=null) &") in
    let get_param_name (v,t) = v in   
    begin
      wr "[externalInv() & ";
      (if (p.Sabsyn.formals != []) then
        let v = get_param_name (List.hd p.Sabsyn.formals) in
        wr_external_general_case v);
      List.iter wr_setdef setnames;
      wr (Paleba.pale_string fmt singletons p.Sabsyn.requires);
      wr "]\n{"
    end in

  let write_postcondition() =
    let wr_quant s = 
      wr ("existset " ^ primed s ^ " of " ^ fmt ^ ":") in
    let wr_setdef s = begin
      wr (set_to_pred s); wr "(";
      wr (primed s); wr ") &\n";
    end in
    let return_stat = match ret with
    | Some v -> "return "^v^";\n"
    | None -> "" in
    begin    
      wr "split [externalInv() & (";
      List.iter wr_quant setnames;
      List.iter wr_setdef setnames;
      wr (Paleba.pale_string fmt (retparam @ singletons) p.Sabsyn.ensures);
      wr ")];\n";
      wr return_stat;
      wr "}\n[true]\n"
    end in

  let return_param rv = 
    match rv with
    | Some (v,(TObj fmt1)) when fmt1=fmt -> "pointer "^v^" : "^fmt^";\n"
    | Some (v,TBool) -> "bool "^v^";\n"
    | _ -> "" in
 
  let write_procedure() = 
    let wrset s = begin
      wr "set "; wr s;
      wr " : "; wr fmt; wr ";\n"
    end in
    begin
      wr "\n";
      write_params();
      List.iter wrset setnames;
      write_precondition();
      wr ("pointer prv77, nxt77 : " ^ fmt ^ ";\n");
      wr (return_param p.Sabsyn.ret_val);
      Paleprinter.print file (ma,ms,mi) (fmt,retparam,singletons) p;
      write_postcondition();
    end in
  
  begin
    Util.amsg ("Analyzing procedure " ^ p.Sabsyn.proc_name.Id.p_name ^"... ");
    write_header file (ma,ms,mi);
    Palestd.write_preds file (ma,ms,mi) p;
    write_procedure();
    close_out file;
    if pale_says_valid file_name then begin
      Util.msg (" procedure " ^ p.Sabsyn.proc_name.Id.p_name ^ " is ");
      Util.amsg ("valid.\n");
      true
    end else begin
      Util.msg (" procedure " ^ p.Sabsyn.proc_name.Id.p_name ^ " is ");
      Util.amsg ("invalid.\n");
      false
    end
  end

let analyze_module ((ma : string Aabsyn.abst_module),
                    (ms : Sabsyn.spec_module),
                    (mi : string Iabsyn.impl_module)) : bool = 
  begin
    let f = analyze_proc (ma,ms,mi) in
    let results = List.map f ms.Sabsyn.procs in
    List.fold_right (fun x y -> x && y) results true
  end
