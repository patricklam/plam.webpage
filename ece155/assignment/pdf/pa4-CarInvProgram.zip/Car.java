// ECE 150 Programming Assignment 4
//
// Car Class
// Version 3.0
//
// DO NOT MODIFY THIS CLASS

public class Car
{
    private int carID;
    private String make;
    private String model;
    private int year;
    private CarColour colour;
    private double price;

    public enum CarColour
    {
        White, Black, Red, Orange, Green, Yellow, Blue, Violet
    }

    public Car(int carID, String make, String model, int year,
        CarColour colour, double price)
    {
        this.carID = carID;
        this.make = make;
        this.model = model;
        this.year = year;
        this.colour = colour;
        this.price = price;
    }

    public int getCarID() { return carID; }
    public void setCarID(int carID) { this.carID = carID; }

    public String getMake() { return make; }
    public void setMake(String make) { this.make = make; }

    public String getModel() { return model; }
    public void setModel(String model) { this.model = model; }

    public int getYear() { return year; }
    public void setYear(int year) { this.year = year; }

    public CarColour getColour() { return colour; }
    public void setColour(CarColour colour) { this.colour = colour; }

    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }

    @Override
    public String toString()
    {
        return String.format("%d,%s,%s,%d,%s,%.2f", 
                             carID, make, model, year, colour.toString(), price);
    }
}
