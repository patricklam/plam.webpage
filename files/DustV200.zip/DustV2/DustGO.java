// DustGO.java
//
// Author: Raja Vallee-Rai
//
// This file is public domain.  You can do anything you want with 
// it, all at your own risk.  Enjoy!

import java.awt.*;
import java.awt.event.*;

/**
 * This class is the applet hook as well as container for the main() routine.
 */

public class DustGO extends java.applet.Applet implements ActionListener
{
	Button goButton;
	boolean isRunning = false;
	
	public static void main(String argv[])
	{
		new Dust();	
	}
	
	public void start()
	{
        setLayout(new FlowLayout());
		
		removeAll();
	
		add(new Label("Dust"));		
		goButton = new Button("GO!");
		
		if(isRunning)
		    goButton.setEnabled(false);
		
		add(goButton);		
        goButton.addActionListener(this);
	}
	
    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource() instanceof Button)
        {
            new Dust(this);
				
			((Button) e.getSource()).setEnabled(false);
			isRunning = true;
        }
    }
    	
	public void paint()
	{
	}
	
	public void stop()
	{		
		goButton.setEnabled(true);
		isRunning = false;
		System.gc();
	}
}
