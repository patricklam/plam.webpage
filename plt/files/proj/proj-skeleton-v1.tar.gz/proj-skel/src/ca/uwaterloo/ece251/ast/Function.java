package ca.uwaterloo.ece251.ast;

import java.util.List;

/** Represents a WiG function. */
public class Function {
    Type returnType;
    Id id;
    List<Type> argTypes;
    List<Id> argIds;
    Stm body;

    public Function(Type returnType, Id id, List<Type> argTypes,
		    List<Id> argIds, Stm body) {
	this.returnType = returnType;
	this.id = id;
	this.argTypes = argTypes;
	this.argIds = argIds;
	this.body = body;
    }

    public String toString() {
	return String.format("%s %s (%s) %s",
			     returnType.toString(), id.toString(), 
			     Util.interleave(argTypes, argIds, " ", ", "),
			     body.toString());
    }
}
