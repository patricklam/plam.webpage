open Iabsyn
open Vcform

type vcgen_abst_module = form Aabsyn.abst_module
type vcgen_impl_module = form Iabsyn.impl_module

let show_stmt s = Iabsynprinter.pstmt 2 Vcprint.isabelle_formula s

let parse_formula s =
  let buffer = Lexing.from_string s in begin
    Vcformparsing.input := Some s;
    Vcformparsing.buffer := Some buffer;
    try 
      (Vcformparse.main Vcformlex.token buffer)
    with _ -> failwith ("Syntax error parsing vc formula.")
  end


let vcform_convert_abst_module 
    (ast:string Aabsyn.abst_module) : vcgen_abst_module =
  let rec vcform_clause_convert f =
    let rec vcform_clause_convert0 f =
      match f with
      | Aabsyn.LetClause (sd, c') -> failwith "not supporting let in aabsyn"
      | Aabsyn.IffClause (s, t) -> 
            (mk_iff 
               (vcform_clause_convert0 s,
                vcform_clause_convert0 t))
      | Aabsyn.OrClause (s, t) -> 
            (mk_or [vcform_clause_convert0 s;
                           vcform_clause_convert0 t])
      | Aabsyn.AndClause (s, t) ->
            (mk_and [vcform_clause_convert0 s;
                            vcform_clause_convert0 t])
      | Aabsyn.NotClause n ->
            (mk_not (vcform_clause_convert0 n))
      | Aabsyn.FormulaClause f' -> (parse_formula f')
    in Aabsyn.FormulaClause (vcform_clause_convert0 f)
  and vcform_set_defn_rhs_convert sd = 
    match sd with
    | Aabsyn.IdForm id -> Aabsyn.IdForm id
    | Aabsyn.BaseForm bsd -> Aabsyn.BaseForm 
          { Aabsyn.x = bsd.Aabsyn.x;
            Aabsyn.xt = bsd.Aabsyn.xt;
            Aabsyn.expr = vcform_clause_convert bsd.Aabsyn.expr; } 
    | Aabsyn.UnionForm (l, r) -> Aabsyn.UnionForm 
          (vcform_set_defn_rhs_convert l,
           vcform_set_defn_rhs_convert r)
    | Aabsyn.IntersectionForm (l, r) -> Aabsyn.IntersectionForm 
          (vcform_set_defn_rhs_convert l,
           vcform_set_defn_rhs_convert r) 
  and vcform_set_defn_convert sd = (fst sd, 
                                    vcform_set_defn_rhs_convert (snd sd)) in
  {
   Aabsyn.module_name = ast.Aabsyn.module_name;
   Aabsyn.instantiated_from = ast.Aabsyn.instantiated_from;
   Aabsyn.param_subst = ast.Aabsyn.param_subst;
   Aabsyn.plugin = ast.Aabsyn.plugin;
   Aabsyn.invariants = List.map vcform_clause_convert ast.Aabsyn.invariants;
   Aabsyn.set_defns = List.map vcform_set_defn_convert ast.Aabsyn.set_defns;
   Aabsyn.pred_vars = ast.Aabsyn.pred_vars;
 }

let vcform_convert_impl_module 
    (ast:string Iabsyn.impl_module) : vcgen_impl_module =
  let rec vcform_convert_stmt s =
    match s with
    | EmptyStmt -> EmptyStmt
    | ChoiceStmt (t, u) -> ChoiceStmt (vcform_convert_stmt t, 
                                       vcform_convert_stmt u)
    | CompoundStmt cs -> CompoundStmt (List.map vcform_convert_stmt cs) 
    | LocalDeclStmt (v, t, e) -> LocalDeclStmt (v, t, e) 
    | ExprStmt e -> ExprStmt e
    | ReturnStmt r -> ReturnStmt r
    | WhileStmt (i, e, w) -> 
        let i' = match i with 
          Some x -> Some (parse_formula (Util.trim_quotes x))
        | None -> None in
        WhileStmt (i', e, vcform_convert_stmt w)
    | AssertStmt(n, a) -> AssertStmt (n, parse_formula (Util.trim_quotes a))
    | AssumeStmt(n, a) -> AssumeStmt (n, parse_formula (Util.trim_quotes a))
    | PragmaStmt s -> PragmaStmt s
    | HavocStmt ids -> HavocStmt ids
    | IfStmt (e, t, f) -> IfStmt (e, vcform_convert_stmt t,
                                  vcform_convert_stmt f) in
  let vcform_convert_proc p = 
    { proc_id = p.proc_id;
      formals = p.formals;
      ret_val = p.ret_val;
      proc_body = vcform_convert_stmt p.proc_body } in
  { module_name = ast.module_name;
    instantiated_from = ast.instantiated_from;
    param_subst = ast.param_subst;
    formats = ast.formats;
    references = ast.references;
    procs = List.map vcform_convert_proc ast.procs;
  }

let summarize_statement s = 
  let add id ids = if List.mem id ids then ids else id::ids in
  let rec collect s acc = match s with
  | ExprStmt e -> (match e with
    | AssignExpr(LocalLvalue v,rhs) -> add v acc        
    | AssignExpr(RefLvalue v,rhs) -> add v acc
    | AssignExpr(ArrayLvalue(VarExpr (LocalLvalue v),e2),rhs) -> add v acc
    | AssignExpr(ArrayLvalue(VarExpr (RefLvalue v),e2),rhs) -> add v acc
    | AssignExpr(_,_) -> 
        failwith "Vcwp.wp: assignment statement not simple enough"
    | _ -> failwith "Vcwp.wp: only assignment expressions are statements")        
  | CompoundStmt ss -> List.fold_right collect ss acc
  | ChoiceStmt(s1,s2) -> collect s1 (collect s2 acc)
  | IfStmt(_,_,_) -> failwith "vcgen.extract_proof: if should be desugared"
  | WhileStmt(_,_,_) -> failwith "vcgen.extract_proof: while should be desugared"
  | _ -> acc
  in HavocStmt (collect s [])

let assumify_and_ensurify modn ens pi s =
  let rec assumify0 s = 
    match s with
    | IfStmt (e, t, f) ->
        let t' = assumify0 t in
        let f' = assumify0 f in
        let ve = prime_all (Vctrans.vcexpr_of_iabsyn modn e) in
        let notve = mk_not ve in
        ChoiceStmt (CompoundStmt [AssumeStmt (None, ve); t'],
                    CompoundStmt [AssumeStmt (None, notve); f'])
    | WhileStmt (Some inv, e, b) ->
        let ve = prime_all (Vctrans.vcexpr_of_iabsyn modn e) in
        let notve = mk_not ve in
        let ab = assumify0 b in
        let b' = ChoiceStmt
            (CompoundStmt [AssumeStmt (Some "loop exp", ve);
                           ab;
                           AssertStmt (Some "loop inv", inv);
                           AssumeStmt (None, App 
                                         ((Const 
                                             (BoolConst false)), []))],
             AssumeStmt (Some "loop termination", notve)) in
        CompoundStmt [AssertStmt (Some "while precondition", inv);
                      summarize_statement ab;
                      AssumeStmt (Some "while precondition", inv);
                      b']
    | WhileStmt (None, e, _) ->
        let (fn, p) = Ast.lookup_expr_pos e in
        Util.err (fn ^ " " ^ p) "vcgen needs your loop invariants";
        Util.print_errors ();
        s
    | CompoundStmt cs ->
        CompoundStmt (List.map assumify0 cs)
    | ReturnStmt rs ->
        (match rs with
        | None -> CompoundStmt 
              [AssertStmt (Some "ensures clause", ens);
               AssumeStmt (Some "stop at return", Const (BoolConst false))]
        | Some e ->
            let ve = prime_all (Vctrans.vcexpr_of_iabsyn modn e) in
            let returnParam = fst (Util.unsome pi.ret_val) in
            let ens' = Vcform.subst [(Vctrans.mk_prop_var returnParam,ve)] ens in
            CompoundStmt 
              [AssertStmt (Some "ensures clause", ens');
               AssumeStmt (Some "stop at return", Const (BoolConst false))])
    | _ -> s in
  assumify0 s

let parse_set_defns ma = 
  let parse_set_defn sd = 
    let (lhs, rhs) = sd in
    match rhs with
    | Aabsyn.BaseForm r ->
        let e = match r.Aabsyn.expr with 
          Aabsyn.FormulaClause c -> c | _ -> failwith "conversion failed" in
        (lhs, Binder (Comprehension, [(r.Aabsyn.x, TypeObjRef r.Aabsyn.xt)],
                      e))
    | _ -> failwith "can't write derived set defns in vcgen" in
  List.map parse_set_defn ma.Aabsyn.set_defns

let collect_obj_locals (s:form Iabsyn.stmt) = 
  (* find local variables of object type *)
  let rec collect s acc = match s with
  | LocalDeclStmt(v,Types.TObj _,_) -> v::acc
  | CompoundStmt ss -> List.fold_right collect ss acc
  | ChoiceStmt(s1,s2) -> collect s1 (collect s2 acc)
  | WhileStmt(_,_,_) -> failwith "vcgen.collect_obj_locals: while should be desugared"
  | IfStmt(_,_,_) -> failwith "vcgen.collect_obj_locals: if should be desugared"
  | _ -> acc
  in collect s []

let extract_obj_vars typeEnv = 
  let add (v,t) acc = match t with Types.TObj _ -> v::acc | _ -> acc 
  in List.fold_right add typeEnv []

let map_inv_names mi ma f =
  (* give proper internal names to global variables used in user-specified
     global invariant, a simpler case of apply_defs *)
  let modn = ma.Aabsyn.module_name in
  (* find set substitutions -- defined sets in this module *)
  let sdefs = parse_set_defns ma in
  let mk_ssubst (id,f) = (Vctrans.mk_set_var id,f) in
  let sdefs_s = List.map mk_ssubst sdefs in
  let mk_ssubst' (id,f) = (primed (Vctrans.mk_set_var id),prime_all f) in
  let sdefs_s' = List.map mk_ssubst' sdefs in
  (* find substitution for global variables *)
  let globals = List.map fst mi.references in
  let mk_gsubst id = (id, Var (Vctrans.mk_global_var modn id)) in
  let gdefs = List.map mk_gsubst globals in
  let mk_gsubst' id = (id, Var (Vctrans.mk_global_var modn (primed id))) in
  let gdefs' = List.map mk_gsubst' globals in
  (* find predvar substitutions *)
  let pdefs = ma.Aabsyn.pred_vars in
  let mk_psubst id = (Vctrans.mk_prop_var (Util.qualify_if_needed modn id), 
                      Var (Vctrans.mk_global_var modn id)) in
  let pdefs_s = List.map mk_psubst pdefs in
  let mk_psubst' id = (primed (Vctrans.mk_prop_var (Util.qualify_if_needed modn id)),
                       Var (primed (Vctrans.mk_global_var modn id))) in
  let pdefs_s' = List.map mk_psubst' pdefs in
  (* apply substitution *)
  subst (sdefs_s @ sdefs_s' @ 
                gdefs @ gdefs' @
                pdefs_s @ pdefs_s') f

let apply_defs mi ma proc s f = (* map specification under abstraction function *)
  let modn = ma.Aabsyn.module_name in
  (* find set substitutions -- defined sets in this module *)
  let sdefs = parse_set_defns ma in
  let mk_ssubst (id,f) = (Vctrans.mk_set_var id,map_inv_names mi ma f) in
  let sdefs_s = List.map mk_ssubst sdefs in
  let mk_ssubst' (id,f) = (primed (Vctrans.mk_set_var id),
                           (prime_all (map_inv_names mi ma f))) in
  let sdefs_s' = List.map mk_ssubst' sdefs in
  (* find substitution for local variables as sets *)
  let locals = collect_obj_locals s @ extract_obj_vars proc.Iabsyn.formals in
  let mk_lsubst id = (Vctrans.mk_set_var id, Var (Vctrans.mk_local_var id)) in
  let ldefs_s = List.map mk_lsubst locals in
  let mk_lsubst' id = (primed (Vctrans.mk_set_var id), 
                       Var (primed (Vctrans.mk_local_var id))) in
  let ldefs_s' = List.map mk_lsubst' locals in
  (* find substitution for global variables as sets *)
  let globals = extract_obj_vars mi.references in
  let mk_gsubst id = (Vctrans.mk_set_var id, Var (Vctrans.mk_global_var modn id)) in
  let gdefs_s = List.map mk_gsubst globals in
  let mk_gsubst' id = (primed (Vctrans.mk_set_var id), 
                       Var (primed (Vctrans.mk_global_var modn id))) in
  let gdefs_s' = List.map mk_gsubst' globals in
  (* find predvar substitutions *)
  let pdefs = ma.Aabsyn.pred_vars in
  let mk_psubst id = (Vctrans.mk_prop_var (Util.qualify_if_needed modn id), Var (Vctrans.mk_global_var modn (Util.unqualify id))) in
  let pdefs_s = List.map mk_psubst pdefs in
  let mk_psubst' id = (primed (Vctrans.mk_prop_var (Util.qualify_if_needed modn id)),
                       Var (primed (Vctrans.mk_global_var modn (Util.unqualify id))))
  in
  let pdefs_s' = List.map mk_psubst' pdefs in
  (* apply substitution *)
  subst (sdefs_s @ sdefs_s' @ 
                ldefs_s @ ldefs_s' @ 
                gdefs_s @ gdefs_s' @ 
                pdefs_s @ pdefs_s') f

let rec concretize_specs mi ma proc (s:form Iabsyn.stmt) = 
  (* map all specs in the assert and assume statements within desugared 's' *)
  let rec conc s0 = match s0 with
  | AssertStmt(msg,f) -> AssertStmt(msg,apply_defs mi ma proc s f)
  | AssumeStmt(msg,f) -> AssumeStmt(msg,apply_defs mi ma proc s f)
  | CompoundStmt ss -> CompoundStmt (List.map conc ss)
  | ChoiceStmt(s1,s2) -> ChoiceStmt(conc s1, conc s2)
  | WhileStmt(_,_,_) -> failwith "vcgen.concretize_specs: while should be desugared"
  | IfStmt(_,_,_) -> failwith "vcgen.concretize_specs: if should be desugared"
  | _ -> s0
  in conc s

let rec extract_proof (s:form Iabsyn.stmt) =
  (* map all specs in the assert and assume statements within desugared 's' *)
  match s with
  | PragmaStmt pragma ->
      if (String.sub pragma 0 6)="proof " then
        String.sub pragma 6 (String.length pragma - 6)
      else ""
  | CompoundStmt ss -> String.concat "\n" 
        (List.filter (fun x -> x<>"") (List.map extract_proof ss))
  | ChoiceStmt(s1,s2) -> 
      let p1 = extract_proof s1 in
      let p2 = extract_proof s2 in
      if (p1<>"" & p2<>"") then failwith "ambiguous proof"
      else (if p1="" then p2 else p1)
  | WhileStmt(_,_,_) -> failwith "vcgen.extract_proof: while should be desugared"
  | _ -> ""

type isabelleOutput = Ok | Error of string

let parseIsabelleOutput (fn : string) : isabelleOutput = 
  let okString = "val it = () : unit" in
  let errorString = "***" in
  let isErrorLine s = Str.string_match (Str.regexp_string errorString) s 0 in
  let foundOk = ref false in
  let foundError = ref false in
  let errorOutput = ref "" in
  let line = ref "" in
  let chn = open_in fn in
  begin
    line := input_line chn;
    (try while true do
      if !line = okString then foundOk := true else ();
      if isErrorLine !line then begin
        errorOutput := !errorOutput ^ !line ^ "\n";
        foundError := true
      end else ();
      line := input_line chn
    done with End_of_file -> ());
    close_in chn;
    if !foundOk & not (!foundError) then Ok
    else Error !errorOutput
  end

let generate_sequents (f:form) : sequent list =
  let add hyp asms = match hyp with
  | App(Const And,fs) -> List.rev_append fs asms
  | _ -> hyp::asms in
  let rec gen asms f acc = match f with
  | App(Const Impl,[f1;f2]) -> gen (add f1 asms) f2 acc
  | App(Const And,fs) -> gens asms fs acc
  | Binder(Forall,vts,f1) -> gen asms f1 acc
  | _ -> (asms,f)::acc
  and gens asms fs acc = List.fold_right (gen asms) fs acc
  in gen [] f []

let decide_sq (mod_name:string) (proof0:string) (sq:sequent) =
  let default_proof = "by (auto simp add: array1_def array2_def cardeq1_def cardleq1_def)" in
  let proof = if proof0="" then default_proof else proof0 in
  let isabelleName = "isabelle" in
  let vc_file = "vc.thy" in
  let vc_in = "vc.in" in
  let vc_out = "vc.out" in
  let vc_string = Vcprint.string_of_sequent sq in
  begin
    Util.msg ("Verification condition:\n" ^ vc_string ^ "\n");
    if Vclemmas.known_fact vc_string then 
      (Util.msg ("The verification condition is cached as true.\n"); true)
    else  begin
      let lemma_string = Vcprint.isabelle_input mod_name proof vc_string in
      let chn = open_out vc_file in
      output_string chn lemma_string;
      close_out chn;
      let _ = Sys.command (isabelleName ^ " < " ^ vc_in ^ " > " ^ vc_out ^ " 2>&1") in
      flush_all();
      (match parseIsabelleOutput vc_out with
      | Ok -> 
          (Util.msg "VC proved valid.\n"; true)
      | Error msg ->
          (Util.msg "Failed to show VC valid.\n";
           Util.msg msg; Util.msg "\n"; false))
    end
  end

let decide (mod_name:string) (proof:string) (f:form) = 
  let sqs = generate_sequents f in
  let len = List.length sqs in
  let rec prove_all sqs k = 
    match sqs with
    | [] -> true
    | sq::sqs1 -> begin
        Util.msg (Printf.sprintf "Proving sequent %d of %d." k len);
        if decide_sq mod_name proof sq then prove_all sqs1 (k+1)
        else false
    end
  in
  prove_all sqs 0

let analyze_stmt (mod_name:string) (s:form Iabsyn.stmt) =
  Util.msg ("\nAnalyzing statement:\n" ^ 
            Iabsynprinter.pstmt 2 Vcprint.isabelle_formula s ^ "\n");
  let vc = unprime_all (Vcwp.wp mod_name s mk_true) in
  let svc = simplify vc in
  let proof = extract_proof s in
  decide mod_name proof svc

(* also uses all loaded spec modules in Ast.spec *)
let analyze_module ((ma0,ms,mi0):(string Aabsyn.abst_module *
                      Sabsyn.spec_module *
                      string Iabsyn.impl_module)) : bool =
  let mi = vcform_convert_impl_module mi0 in
  let ma = vcform_convert_abst_module ma0 in
  let _ = Vclemmas.init mi.module_name in
  let set_defns = parse_set_defns ma in  
  let extract_formula c = match c with 
  | Aabsyn.FormulaClause f -> f 
  | _ -> failwith "analyze_module.extract_formula: expected formula clause" in
  let analyze_proc (p:string) : bool = 
    let ps = Ast.fetch_spec_proc p ms in
    let pi = Ast.fetch_impl_proc p mi in   
    print_string ("Analyzing proc " ^ p ^ "... "); flush_all ();
    let invs0 = mk_and (List.map extract_formula ma.Aabsyn.invariants) in
    let invs = map_inv_names mi ma invs0 in
    let req = mk_and[invs;
                     Vctrans.vcexpr_of_sabsyn_form ps.Sabsyn.requires] in
    let ens = mk_and[prime_all invs; 
                     Vctrans.vcexpr_of_sabsyn_form ps.Sabsyn.ensures] in
    let body = Itrans.flatten_compound_stmt 
        (CompoundStmt 
           [AssumeStmt (Some "requires", req);
            assumify_and_ensurify mi.module_name ens pi pi.proc_body;
            AssertStmt (Some "ensures", ens)]) in
    let concretized_body = concretize_specs mi ma pi body in
    if (analyze_stmt mi.module_name concretized_body) then
      begin
        Printf.printf "Procedure %s passes.\n" p;
        true
      end
    else
      begin
        Printf.printf "Procedure %s fails.\n" p;
        false
      end
  in
  let results = List.map 
      (fun mm -> analyze_proc mm.Sabsyn.proc_name.Id.p_name) ms.Sabsyn.procs in
  List.fold_left (fun x y -> x & y) true results
