open Iabsyn
open Types
open Envutils

let unsome = function (Some x) -> x | None -> failwith "tried to deoptionify None"

type module_format_contribution = (Id.field_t, value_type) Hashtbl.t
type format_layout = (Id.module_t, module_format_contribution) Hashtbl.t

(* maps Id.format_t to format_layout *)
let format_definitions : (Id.format_t, format_layout) Hashtbl.t = 
  Hashtbl.create 2

(* block: local variable name -> type
 * module: reference name -> type *)
(* environment should probably also contain a binding for the current module name... *)

(* I think that using pairs is more efficient, but unless we have a typed
 * heap, we won't be able to produce heap dumps from it. *)
let heap : (value, (Id.field_t, value) Hashtbl.t) Hashtbl.t = Hashtbl.create 2
let get_field x f = Hashtbl.find (Hashtbl.find heap x) f
let get_fields x = Hashtbl.find heap x
let set_field x f y = Hashtbl.replace (Hashtbl.find heap x) f y

let in_channels : (value, in_channel) Hashtbl.t = Hashtbl.create 2
let out_channels : (value, out_channel) Hashtbl.t = Hashtbl.create 2

let file_descrs : (value, Unix.file_descr) Hashtbl.t = Hashtbl.create 2
let socket_addrs : (value, Unix.sockaddr) Hashtbl.t = Hashtbl.create 2

let put_input_channel_mapping nobj fd = 
  Hashtbl.replace in_channels nobj fd

let get_input_channel_mapping nobj =
  Hashtbl.find in_channels nobj

let clear_input_channel_mapping nobj =
  Hashtbl.remove in_channels nobj

let put_output_channel_mapping nobj fd = 
  Hashtbl.replace out_channels nobj fd

let get_output_channel_mapping nobj =
  Hashtbl.find out_channels nobj

let clear_output_channel_mapping nobj =
  Hashtbl.remove out_channels nobj

let put_file_descr_mapping nobj fd = 
  Hashtbl.replace file_descrs nobj fd

let get_file_descr_mapping nobj =
  Hashtbl.find file_descrs nobj

let clear_file_descr_mapping nobj =
  Hashtbl.remove file_descrs nobj

let put_socket_addr_mapping nobj a =
  Hashtbl.replace socket_addrs nobj a

let get_socket_addr_mapping nobj =
  Hashtbl.find socket_addrs nobj

let clear_socket_addr_mapping nobj =
  Hashtbl.remove socket_addrs nobj

let fresh_obj_counter = ref 0
let fresh_obj () = fresh_obj_counter := !fresh_obj_counter + 1; 
  let n = Obj !fresh_obj_counter in
  Hashtbl.add heap n (Hashtbl.create 2);
  n

let module2env : (Id.module_t, environment) Hashtbl.t = Hashtbl.create 2

let fetch_module_environment m =
  Hashtbl.find module2env m

let put_module_environment m v =
  Hashtbl.replace module2env m v

(* to interpret:
     "x = 5;"   retrieve_value env (Id.fetch_var "x") = ref (Int 5);
     "y = x.f;" mutate_value env (Id.fetch_var "y") (get_field (retrieve_value env (Id.fetch_var "x")) 
                  (Id.fetch_field "f" current_module)))
     "x.f = y;" set_field (Id.fetch_var "x") (Id.fetch_field "f" current_module) (retrieve_value env (Id.fetch_var "x"))
*)

let create_module_envs ast =
  let create_module_env (t:'a Iabsyn.impl_module) = 
    List.map (fun x -> (fst x, initial_value (snd x)))
      t.references in
  List.iter 
    (fun y -> Hashtbl.add module2env y.module_name (create_module_env y)) ast

let create_environment_for_proc proc_id proc =
  [("__current_module", (String (Id.module_of_proc proc_id)))]
