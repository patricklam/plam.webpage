INSERT INTO suppliers
(supplier_id, supplier_name)
SELECT customers.account_no, customers.name
FROM customers AS st WHERE customers.city = 'Newark';