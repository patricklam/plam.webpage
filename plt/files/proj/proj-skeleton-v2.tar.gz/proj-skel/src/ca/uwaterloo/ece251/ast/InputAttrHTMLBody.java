package ca.uwaterloo.ece251.ast;

import java.util.List;

/** Abstract class for a tag with input attributes. */
abstract public class InputAttrHTMLBody extends HTMLBody {
    List<InputAttr> attrs;
    public InputAttrHTMLBody(List<InputAttr> attrs) {
	this.attrs = attrs;
    }
}
