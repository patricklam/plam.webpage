open Sabsyn

type sets_and_bools = {
    s : Id.var_t list;
    b : Id.var_t list;
  }

(* needs to change when we add calls to methods. *)
let collect_called_modules ast =
  List.concat (List.map (fun x -> x.calls) ast.procs)

let collect_all_foo ast fn =
  let this_module_name = ast.module_name in
  let m_scope = List.concat (List.map Scopes.modules_in_scope 
                               (Scopes.scopes_of ast.module_name)) in
  let m_callees = List.filter (fun x -> not (List.mem x m_scope)) 
      (collect_called_modules ast) in
  List.concat (List.map 
                 (fun x -> (List.map (Util.qualify_if_needed x) 
                              (fn (Ast.fetch_spec x)))) 
                 (List.concat [m_scope; m_callees]))

let collect_all_sets ast = 
  collect_all_foo ast (fun x -> List.map fst x.sets)

let collect_all_bools ast = 
  collect_all_foo ast (fun x -> x.pred_vars)

let collect_sets_types ast : (string * string) list = 
  let this_module_name = ast.module_name in
  let m_scope = List.concat (List.map Scopes.modules_in_scope 
                               (Scopes.scopes_of ast.module_name)) in
  let m_callees = List.filter (fun x -> not (List.mem x m_scope)) 
      (collect_called_modules ast) in
  let qualify_name m (n, t) = (m ^ "." ^ n,t) in
  List.concat (List.map 
                 (fun x -> (List.map (qualify_name x) (Ast.fetch_spec x).sets)) 
                 (List.concat [m_scope; m_callees]))

let parse_formula s =
  let unsome = function (Some x) -> x 
    | None -> failwith "tried to unsome None" in
  let l = Speclanguage.Lexer.create_from_string "[formula]"
      ("formula "^ (Util.trim_quotes s)) in
  let p = Speclanguage.Parser.create l in
  let ast = Speclanguage.Parser.parse p in
  match ast with
    Speclanguage.Nodes.Start (Speclanguage.Nodes.PFile 
                            (Speclanguage.Nodes.AFormFile n), _) -> 
                              Deuglifyspec.convert_form 
                                (unsome n.Speclanguage.Nodes.form_file_form)
  | _ -> failwith "bad AST in Spec"

let rec fetch_set_type s m =
  if (String.contains s '.') then (* remote *)
   let dot = String.index s '.' in
   let modn = Str.string_before s dot in
   let nm = Str.string_after s (dot+1) in
   fetch_set_type nm (Ast.fetch_spec modn)
  else (* local *)
   snd (List.find (fun x -> fst x = s) m.sets)

