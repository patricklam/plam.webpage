// SystemFrameConsumer.java
//
// Author: Raja Vallee-Rai
//
// This file is public domain.  You can do anything you want with 
// it, all at your own risk.  Enjoy!

import java.util.*;

import kor.base.*;

/**
 * The SystemFrameConsumer is a thread which applies the Frames which are produced
 * by the Simulation object/thread onto the playfield to actual produce a change in the
 * particle's attributes (position + velocity).
 */

class SystemFrameConsumer implements Runnable
{
    Simulation simulation;
    Thread runningConsumer;
    PlayfieldViewer viewer;

    public SystemFrameConsumer(Simulation s, PlayfieldViewer viewer)
    {
        this.simulation = s;
        this.viewer = viewer;
        
        runningConsumer = new Thread(this);
        runningConsumer.start();
    }
    
    public void run()
    {
        for(;;)
        {
            try {
                Thread.sleep((int) (1.0 / simulation.playfield.controls.stepGranularity * 1000));
            } catch(InterruptedException e){}
            
            if(!simulation.readyFrames.isEmpty())
            {
                simulation.playfield.secsOfCacheReady = 
                    (double) simulation.readyFrames.size() / 
                    simulation.playfield.controls.stepGranularity;
                
                ParticleFrame[] nextFrame = (ParticleFrame[]) simulation.readyFrames.next();
                simulation.notifyOfDequeue();
                applyFrameOnPlayfield(nextFrame);
            }
        }
    }
    
    void applyFrameOnPlayfield(ParticleFrame[] nextFrame)
    {   
        Debug.assert(simulation.simulationID == simulation.simulationCount);

        synchronized(viewer.playfield)
        {
            Vector particles = simulation.playfield.particles;
            
            for(int i = 0; i < particles.size(); i++)
            {
                double tmp;
                
                Particle p = (Particle) particles.elementAt(i);
                ParticleFrame f = nextFrame[i];
                
                p.posX = f.posX;
                
                p.posY = f.posY;
                
                p.traces.insert(new Trace(f.posX, f.posY));

                p.velX = f.velX;
                p.velY = f.velY;
                
                p.accX = f.accX;
                p.accY = f.accY;
                
                p.forceX = f.forceX;
                p.forceY = f.forceY;
            }
                        
            viewer.playfield.refreshViewers();
        }
    }
}
