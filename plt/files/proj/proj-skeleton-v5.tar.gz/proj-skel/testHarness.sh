#!/bin/bash

echo
echo "ECE251"
echo "WIG Parser Tester v0.0"
echo "Sat Nov 13 00:46:56 EST 2010"
echo "---------------------------"
echo "Note: Pass your classpath as an argument (ex. testHarness.sh /home/mehdi/A2-ece251/bin/)."
echo "      Feel free to modify the paths."
echo

passed=0
failed=0

if [ ! -d output ]; then
   echo "Creating output folder"
   mkdir output
fi

echo
echo "Phase 1: Executing parser..."
echo

for wig in *.wig
do
   output=output/$wig

   echo "Testing ${wig}"
   java -classpath $1 ca.uwaterloo.ece251.WIG $wig > $output
done

echo
echo "Phase 2: Evaluating parser outputs..."
echo

for output in output/*
do
   expected=expected${output#output}
   if `diff -b -w ${expected} ${output} > /dev/null`
      then
         echo "[PASSED] $output Vs. $expected"
            passed=$((passed+1))
       else
         echo "[FAILED] $output Vs. $expected"
            failed=$((failed+1))
    fi
done

tests=$((passed+failed))
result=$(($passed * 100 / $tests))
# result=`echo "scale=2; 100 * $passed / ($passed+$failed)" | bc -l`
echo "Result: $passed/$tests ($result%) of test cases passed"
