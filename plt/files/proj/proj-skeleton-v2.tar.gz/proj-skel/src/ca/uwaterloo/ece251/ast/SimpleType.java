package ca.uwaterloo.ece251.ast;

public class SimpleType extends Type {
    public enum SimpleTypes { 
	INT("int"), BOOL("bool"), STRING("string"), VOID("void");
	private final String n;
	SimpleTypes(String n) { this.n = n; }
	public String toString() { return n; }
    };
    SimpleTypes t;

    public SimpleType(SimpleTypes t) {
	this.t = t;
    }

    public String toString() {
	return t.toString();
    }
}
