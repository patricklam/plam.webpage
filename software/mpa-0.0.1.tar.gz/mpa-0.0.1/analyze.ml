(* Main analyzer module *)

(* Analyze abst module
   using the corresponding impl module
   and spec modules. *)

(* uses scope information *)
let check_interscope_call_perms (mi:string Iabsyn.impl_module) = true

(* uses call graph and this impl to compute a list of reentrant sites *)
(* yeah, yeah, we need to compute the call graph. *)
let collect_reentrant_sites (mi:string Iabsyn.impl_module)
    : (Iabsyn.expr list * Iabsyn.expr list) = ([], [])
(* uses reentrant site list, scopes *)
let distribute_scope_invariants (rs:Iabsyn.expr list) (ms:Sabsyn.spec_module) 
    (mi:string Iabsyn.impl_module) = (ms, mi)
(* prepares a substitution list for spec modules,
   replacing a remote spec by its projected spec. *)
let project_remote_interfaces (ms:Sabsyn.spec_module) = Hashtbl.create 0

let preprocess_modules () =
  Ast.spec := List.map (fun ms -> 
    let all_sb = 
      { Spec.s = Spec.collect_all_sets ms;
        Spec.b = Spec.collect_all_bools ms
      } in
    Strans.expand_modifies_clauses all_sb ms) !Ast.spec

let analyze_typestate_module
    ((ma:string Aabsyn.abst_module),
     (ms:Sabsyn.spec_module),
     (mi0:string Iabsyn.impl_module)) 
    (rs:Iabsyn.expr list) : bool = 
      let mi1 = Util.phase "Jimplifying" Itrans.jimplify mi0 in
      let mi = Util.phase "Pulling up locals" Itrans.pull_up_locals mi1 in
      Util.phase "Recomputing jimplified types" Typechecker.verify [mi];
      Typestate.analyze_module (ma,ms,mi) rs

let analyze_pale_module
    ((ma:string Aabsyn.abst_module),
     (ms:Sabsyn.spec_module),
     (mi0:string Iabsyn.impl_module)) : bool =
  let mi = Util.phase "Pulling up locals" Itrans.pull_up_locals mi0 in
  Util.phase "Recomputing types" Typechecker.verify [mi];
  Pale.analyze_module (ma,ms,mi)

let analyze_vcgen_module
    ((ma:string Aabsyn.abst_module),
     (ms:Sabsyn.spec_module),
     (mi0:string Iabsyn.impl_module)) : bool =
  let mi = Util.phase "Pulling up locals" Itrans.pull_up_locals mi0 in
  Util.phase "Recomputing types" Typechecker.verify [mi];
  Vcgen.analyze_module (ma,ms,mi)

let analyze_module_by_name (mod_name : string) : bool = 
  let ma0 = Ast.fetch_abst mod_name in
  Printf.printf "Analyzing module %s [%s].\n" mod_name ma0.Aabsyn.plugin;
  let ms0 = Ast.fetch_spec mod_name in
  let mi0 = Ast.fetch_impl mod_name in
  if not (check_interscope_call_perms mi0) then (* ugh *)
    failwith ("Invalid inter-scope call in module "^mod_name);
  let (rsM, rsS) = collect_reentrant_sites mi0 in
  let (ms2, mi1) = distribute_scope_invariants rsS ms0 mi0 in
  let projected_spec_module_map = project_remote_interfaces ms2 in
  let ma = ma0 and ms = ms2 and mi = mi1 in begin
    let result = match ma.Aabsyn.plugin with
    | "flags" -> analyze_typestate_module (ma,ms,mi) rsM
    | "PALE" -> analyze_pale_module (ma,ms,mi)
    | "vcgen" -> analyze_vcgen_module (ma,ms,mi)
    | s -> Printf.printf "Couldn't understand plugin %s.\n" s; false in
    Printf.printf "Done analyzing module %s, " mod_name;
    if result then print_string "module is valid.\n" 
    else print_string "module is invalid.\n";
    result
  end

let parse (source_names : string list) = 
  let format_names = ref [] in
  let spec_names = ref [] in
  let abst_names = ref [] in
  List.iter (function n -> 
    (match Util.extension n with 
      ".fl" -> format_names := n :: !format_names
    | ".sl" -> spec_names := n :: !spec_names
    | ".al" -> abst_names := n :: !abst_names
    | _ -> failwith ("unrecognized file extension for file "^n))) source_names;
  Uglyast.spec_ast := snd (Uglyast.parse_spec_asts !spec_names);
  Uglyast.abst_ast := snd (Uglyast.parse_abst_asts !abst_names);
  Uglyast.impl_ast := Uglyast.parse_impl_asts !format_names;
  let spec_module_names = Uglyast.fetch_spec_module_names !Uglyast.spec_ast in
  let abst_module_names = Uglyast.fetch_abst_module_names !Uglyast.abst_ast in
  let impl_module_names = Uglyast.fetch_impl_module_names !Uglyast.impl_ast in
  Ast.impl := List.map 
      (fun x -> Deuglifyimpl.convert (Uglyast.fetch_impl_module x)) 
      impl_module_names;
  Ast.spec := List.map 
      (fun x -> Deuglifyspec.convert (Uglyast.fetch_spec_module x)) 
      spec_module_names;
  Ast.abst := List.map 
      (fun x -> Deuglifyabst.convert (Uglyast.fetch_abst_module x)) 
      abst_module_names;
  let r = Typechecker.declaration_checker false !Ast.impl in
  Ast.impl := Util.phase "Instantiating impl templates" 
      (List.map (Itrans.instantiate_templates false)) !Ast.impl;
  Ast.spec := Util.phase "Instantiating spec templates" 
      (List.map Strans.instantiate_templates) !Ast.spec;
  Ast.abst := Util.phase "Instantiating abst templates" 
      (List.map Atrans.instantiate_templates) !Ast.abst;
  Ast.impl := Util.phase "Local-ref conversion " 
      List.map (Itrans.transform_local_to_ref_lvalues r) !Ast.impl;
  Util.phase "Typechecking impl" (Typechecker.verify !Ast.impl);
  Util.phase "Crosschecking impl & spec" 
    List.iter (fun x -> 
      if (not (Ast.has_impl x)) then
        Util.err "[spec-impl checker]" ("Couldn't find impl module "^x^".")
      else
        Specimplchecker.verify (Ast.fetch_spec x) 
          (Ast.fetch_impl x)) (Ast.all_abst_modules ());
  Ast.abst := Util.phase "Factoring out on-the-fly sets in abst module"
    (List.map Atrans.factor_out_base_sets) !Ast.abst;
  if not (Util.no_errors ()) then
    Util.print_errors ()

let parse_cmdline () : string list =
  let speclist = 
    [("-v", Arg.Set Util.verbose, 
      "Verbose; display verbose debugging messages.");
     ("-u", Arg.Clear BA.optimize_formulas,
      "Unoptimize: do not optimize BA formulas.");
     ("-n", Arg.Set BA.no_mona,
      "No MONA: do not run MONA.");
     ("-a", Arg.Set Typestate.check_antecedents,
      "Antecedent checking: when checking f=>g, complain if !f")] in
  let source_names = ref [] in
  let usage_msg=("Usage:\n  "^Sys.argv.(0)^" [-v] [-u] <input filename>\n") in
  Arg.parse speclist (fun x -> source_names := x :: !source_names) usage_msg;
  if !BA.no_mona then print_string "WARNING!! Not running MONA to verify formulas!\n";
  if List.length !source_names = 0 then 
    begin 
      Arg.usage speclist usage_msg; 
      exit 1 
    end;
  !source_names

let go () =
  try
    let names = parse_cmdline () in
    parse names;
    preprocess_modules ();
    let analyzed_parents = ref [] in
    let analyze_abst_module m = 
      (* hey, you're in trouble if you instantiate abst, spec, impl with
       * different params.  But the proof shouldn't go through. *)
      let n = m.Aabsyn.module_name in
      match m.Aabsyn.instantiated_from with
      | None -> analyze_module_by_name n
      | Some n ->
          let chk = (n, m.Aabsyn.param_subst) in
          if List.mem chk !analyzed_parents then
            true
          else
            begin
              analyzed_parents := chk :: !analyzed_parents;
              analyze_module_by_name n
            end in
    let analysis_results = 
      (List.map analyze_abst_module !Ast.abst) in
    let result = (List.fold_left (fun a b -> a & b) true analysis_results) in
    if result then
      (print_string "The program is VALID.\n"; 0)
    else
      (print_string "The program is INVALID.\n"; 1)
  with Failure s -> (print_string (s^"\n"); 2)

let _ = exit (go ())
