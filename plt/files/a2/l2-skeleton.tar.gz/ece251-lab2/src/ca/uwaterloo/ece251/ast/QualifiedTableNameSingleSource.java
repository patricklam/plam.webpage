package ca.uwaterloo.ece251.ast;

public class QualifiedTableNameSingleSource extends SingleSource {
    QualifiedTableName tn;
    String as;

    public QualifiedTableNameSingleSource(QualifiedTableName tn, String as) {
	this.tn = tn;
	this.as = as;
    }

    public void accept(Visitor v) {
	v.enter(this);
	v.leave(this);
    }
}
