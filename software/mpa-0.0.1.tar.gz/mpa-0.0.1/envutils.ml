type environment = (Id.var_t * Iabsyn.value) list

type type_environment = (Id.var_t * Types.value_type) list

exception Nonexistant_name

let rec has_type_decl tenv_list x =
  match tenv_list with
  | [] -> false
  | t::ts  -> (List.mem_assoc x t) or (has_type_decl ts x)

let rec retrieve_type tenv_list x = 
  match tenv_list with
  | [] -> raise Nonexistant_name
  | t::ts  -> (try List.assoc x t
           with Not_found -> retrieve_type ts x)

let rec retrieve_value env_list x =
  match env_list with
  | [] -> raise Nonexistant_name
  | _  -> (try List.assoc x (List.hd env_list)
          with Not_found -> retrieve_value (List.tl env_list) x)

let rec mutate_value (env_list:environment list) x v : environment list =
  match env_list with
  | [] -> raise Nonexistant_name
  | _  -> (try ignore (List.assoc x (List.hd env_list)); 
               (((x,v)::(List.remove_assoc x (List.hd env_list)))::
                (List.tl env_list))
          with Not_found -> 
            (List.hd env_list)::mutate_value (List.tl env_list) x v)

let create_module_tenvs ast =
  let module2tenv = Hashtbl.create 0 in
  List.iter 
    (fun y -> Hashtbl.add module2tenv 
        y.Iabsyn.module_name y.Iabsyn.references) ast;
  module2tenv

let get_current_module env_list =
  match (retrieve_value env_list "__current_module") with
  | Iabsyn.String x -> Id.fetch_module x
  | _ -> failwith "bad type for current_module"

let get_current_module_from_tenv (tenv_list:type_environment list) =
  match (retrieve_value tenv_list "__current_module") with
  | Types.TObj x -> Id.fetch_module x
  | _ -> failwith "bad type for current_module"

let get_tenv_for_current_module module2tenv tenv_list : type_environment list =
  [Hashtbl.find module2tenv (get_current_module_from_tenv tenv_list)]

