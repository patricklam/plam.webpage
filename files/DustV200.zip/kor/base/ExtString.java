// ExtString.java
//
// Author: Raja Vallee-Rai
//
// This file is public domain.  You can do anything you want with 
// it, all at your own risk.  Enjoy!

       

package kor.base;

/**
 * Provides some useful methods which act on strings.
 */
public
class ExtString
{
    /**
     * Pads the string on the left with blanks to force it to be a certain size.
     *
     * @param length the desired final length of the string
     */
     
    static
    public String paddedLeftOf(String s, int length)
    {
        if(s.length() >= length)
            return s;
        else {
            int diff = length - s.length();
            char[] padding = new char[diff];
            
            for(int i = 0; i < diff; i++)
                padding[i] = ' ';
            
            return new String(padding) + s;
        }    
    }
     
    
    /**
     * Pads the string on the right with blanks to force it to be a certain size.
     *
     * @param length the desired final length of the string
     */
     
    static
    public String paddedRightOf(String s, int length)
    {
        if(s.length() >= length)
            return s;
        else {
            int diff = length - s.length();
            char[] padding = new char[diff];
            
            for(int i = 0; i < diff; i++)
                padding[i] = ' ';
            
            return s + new String(padding);
        }    
    }
}


