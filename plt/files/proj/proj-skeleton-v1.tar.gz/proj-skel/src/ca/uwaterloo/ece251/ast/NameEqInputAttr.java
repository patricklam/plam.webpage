package ca.uwaterloo.ece251.ast;

/** Represents a name=x attribute for an INPUT or SELECT tag. */
public class NameEqInputAttr extends InputAttr {
    Attr attr;

    public NameEqInputAttr(Attr attr) {
	this.attr = attr;
    }

    public String toString() {
	return "name ="+attr.toString();
    }
}

