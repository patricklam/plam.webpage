public class SubclassTest extends Super {
    void m() {
	super.m();
    }
}

class Super {
    Super next;

    void m() {
    }
}
