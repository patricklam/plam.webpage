SELECT 'aaaaa' FROM DUAL AS st;
