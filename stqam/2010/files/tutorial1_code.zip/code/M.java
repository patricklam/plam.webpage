class M {

    public static void main(String []argv) {
        M obj = new M();
        if (argv.length > 0) {
            obj.m(argv[0], argv.length);
        }
    }

    public int dummyMethod() {
        return 0;
    }

    public void m(String arg, int i) {
        int q = 1;
        A o = null;

        if (0 == i)
            q = 4;

        ++q;

        switch (arg.length()) {
            case 0: q /= 2; break;
            case 1: o = new A(); q = 10; break;
            case 2: o = new B(); q = 5; break;
            default: o = new B(); break;
        }

        if (arg.length() > 0) {
            o.m();
        }
        else {
            System.out.println("zero");
        }
    }
}

class A {
    public void m() {
        System.out.println("a");
    }
}

class B extends A {
    public void m() {
        System.out.println("b");
    }
}
