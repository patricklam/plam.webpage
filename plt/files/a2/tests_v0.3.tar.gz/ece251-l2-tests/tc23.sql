SELECT DISTINCT table_1.*,table_2.*,TRUE FROM db_2.table_1 AS table_3, (SELECT *) 
AS everything, (db_2.table_2 AS table_4, db_3.table_1 AS table_5) WHERE -+--3 
ISNULL NOTNULL LIMIT 1+2+3*4/6 >= (4-4)*(3+2);
