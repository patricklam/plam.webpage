(* Abstract Syntax for Abstraction Modules *)

open Id

type 'form clause = (* invariants *)
    LetClause of 'form set_defn * 'form clause
  | IffClause of 'form clause * 'form clause
  | OrClause  of 'form clause * 'form clause
  | AndClause of 'form clause * 'form clause
  | NotClause of 'form clause
  | FormulaClause of 'form
and 'form base_set_defn = {
    x           : var_t;
    xt          : format_t;
    expr        : 'form clause;
  }
and 'form set_defn_rhs = (* set formulas *)
  | IdForm of var_t
  | BaseForm of 'form base_set_defn
  | UnionForm of 'form set_defn_rhs * 'form set_defn_rhs
  | IntersectionForm of 'form set_defn_rhs * 'form set_defn_rhs
and 'form set_defn = var_t * 'form set_defn_rhs

type 'form abst_module = {
    module_name : module_t;
    instantiated_from : Id.module_t option;
    param_subst : (Id.format_t * Id.format_t) list;
    plugin      : string;
    invariants  : 'form clause list;
    set_defns   : 'form set_defn list;
    pred_vars   : Id.var_t list; (* not qualified *)
  }
