/**
 * Sample code for ECE 459, assignment 2 
 *
 * The code uses modified library functions from the
 * project fbida (http://linux.bytesex.org/fbida/)
 * that is released under GPL.
 *
 * @author: Xavier Noumbissi
 */

#include "jpegr.h"

#include "a2jpeg/genthumbnail.h"

#include "a2jpeg/write-jpeg.h"

#include "a2jpeg/readers.h"
#include "a2jpeg/dither.h"

#include <sys/stat.h>
#include <unistd.h>

#include <math.h>

#include <exif-data.h>

#define FALSE 0

#define TRUE 1

static JXFORM_CODE transmagic[] = {
  [1] = JXFORM_NONE,
  [2] = JXFORM_FLIP_H,
  [3] = JXFORM_ROT_180,
  [4] = JXFORM_FLIP_V,
  [5] = JXFORM_TRANSPOSE,
  [6] = JXFORM_ROT_90,
  [7] = JXFORM_TRANSVERSE,
  [8] = JXFORM_ROT_270,
};

/**
 * Max data size of a thumbnail
 */
#define THUMB_MAX 65536

/**
 * Path separator.
 */
static const char PATH_SEP = '/';

/**
 * The following charaters are append to the new created
 * and rotated jpeg file.
 */
#define SIZE_ENDING 4
const char ENDING[SIZE_ENDING] = ".a2";


/**
 * You specify the maximum number of row per column
 * that will appear in the montage file here.
 */
static const int MAX_ROW = 5;

static int createMontageFile (UserRequest * uRequest);

/*
 * The input of the user is stored in a UserRequest structure during parsing
 * of the command line. Then the request is fulfilled using functions
 * from the project fbida (http://linux.bytesex.org/fbida/).
 *
 * You may also want to provide more options to the user.
 */

int main (int argc, char *argv[])
{
  UserRequest *uRequest;
  if (FALSE == initUserRequest (&uRequest)) {
    no_memory ();
    return -1;
  }

  int choice = 0, option_index = 0;

  while (TRUE) {

    //A colon after an option character here means that an
    //argument is required for that option.
    //Two colons have to be used to indicate that the option
    //is optional

    choice =
      getopt_long (argc, argv, "qeh912t:o:", prog_options, &option_index);

    if (-1 == choice) {
      break;
    }

    switch (choice) {
    case '9':
      auto_rotate_flag = 0;
      uRequest->rotation = JXFORM_ROT_90;
      break;
    case '1':
      auto_rotate_flag = 0;
      uRequest->rotation = JXFORM_ROT_180;
      break;
    case '2':
      auto_rotate_flag = 0;
      uRequest->rotation = JXFORM_ROT_270;
      break;
    case 't':
      threads_flag = 1;
      getThreads (uRequest, optarg);
      break;
    case 'o':
      outdir_flag = 1;
      if (FALSE == getOutDir (uRequest, optarg)) {
	free (uRequest);
	abort_message ();
	return -1;
      }
      break;
    case 'h':
    default:
      help (argv);
      break;
    }
  }

  if (outdir_flag) {
    if (TRUE == processUserRequest (uRequest, argv, argc, optind))
      printUserRequest (uRequest);
  }
  else {
    printf ("You have to give an output directory. Try again.\n");
  }

  destroyUserRequest (&uRequest);

  return 0;
}

/**
 * This is where you may want to perform changes to parallelize
 * the rotations of input files and the creation of montage file.
 */
int processUserRequest (UserRequest * uRequest,
			char *argv[], int argc, int optind)
{

  int curFile = optind;
  int transform = FALSE;
  int max_files = argc - curFile;

  int i;
  for (i = 0; i < max_files; ++i) {

    if (FALSE == isValidFile (argv[curFile]))
      continue;

    uRequest->fileIn[i] = (char *) calloc (1, FILENAME_MAX);
    uRequest->fileRotIn[i] = (char *) calloc (1, FILENAME_MAX);

    if (0 == uRequest->fileIn[i]) {
      printf ("Could not allocate memory to process %s.\n", argv[curFile]);
      abort_message ();
      return FALSE;
    }

    strncat (uRequest->fileIn[i], uRequest->outDir,
	     strlen (uRequest->outDir));
    strncat (uRequest->fileIn[i], &PATH_SEP, 1);
    strncat (uRequest->fileIn[i], argv[curFile], strlen (argv[curFile]));

    strcpy (uRequest->fileRotIn[i], uRequest->fileIn[i]);
    strncat (uRequest->fileRotIn[i], ENDING, SIZE_ENDING);

    struct ida_image *curInputJpeg;

    curInputJpeg = read_jpeg (uRequest->fileIn[i]);
    if (!curInputJpeg) {
      printf ("Could not read jpeg file %s during montage creation\n",
	      uRequest->fileIn[i]);
      return FALSE;
    }

    uRequest->thumbnail[i] = calloc (1, THUMB_MAX);
    memcpy (uRequest->thumbnail[i], curInputJpeg, THUMB_MAX);
    uRequest->thumbnail[i] =
      ece459_scale_thumbnail (uRequest->thumbnail[i], 70);

    JXFORM_CODE exif_orientation = JXFORM_NONE;

    if (1 == auto_rotate_flag) {
      if (FALSE == getExifOrientation (uRequest->thumbnail[i],
				       &uRequest->auto_rotation[i])) {
	printf ("Could not read exif data from jpeg %s, so not"
		"rotation will be done\n", uRequest->fileIn[i]);

	continue;
      }
      exif_orientation = uRequest->auto_rotation[i];
    }
    else {
      exif_orientation = uRequest->rotation;
    }


    //Rotate the jpeg file
    jpeg_transform_files (uRequest->fileIn[i],
			  uRequest->fileRotIn[i],
			  exif_orientation,
			  uRequest->comment,
			  uRequest->thumbnail[i], THUMB_MAX, uRequest->flags);

    printf ("An input file %s\n", uRequest->fileIn[i]);
    printf ("An output file %s\n", uRequest->fileRotIn[i]);

    ++curFile;
    ++uRequest->nrFiles;
  }

  //Create a montage file
  transform = createMontageFile (uRequest);

  return transform;
}

/**
 * You may also want to make changes here to to parallelize
 * the creation of the montage file.
 */
int createMontageFile (UserRequest * uRequest)
{
  FILE *fp = fopen ("montage.jpg", "w");
  if (0 == fp) {
    printf ("Could not create a montage file.\n");
    return FALSE;
  }

  struct ida_image *montageJpeg =
    (struct ida_image *) calloc (1, sizeof (struct ida_image));

  montageJpeg->data = (unsigned char *) calloc (uRequest->nrFiles, THUMB_MAX);

  //Write input thumbnails data to the montage file.
     
  unsigned int y, x;

  int max_width = 0, tmp_width = 0, max_height = 0;

  int step = (uRequest->nrFiles % MAX_ROW);

  int x_max = 0;
  int y_max = ceil ((float) uRequest->nrFiles / MAX_ROW);

  for (y = 0; y < y_max; ++y) {

    x_max = (step * y) + MAX_ROW;
    montageJpeg->data += max_width * y;
    for (x = step * y; x < x_max && x < uRequest->nrFiles; ++x) {

      
      tmp_width += uRequest->thumbnail[x]->i.width;

      //Determining the max height of the montage file
      if (max_height < uRequest->thumbnail[x]->i.height)
	max_height = uRequest->thumbnail[x]->i.height;

      //Adding thumbnail data to the montage file
      montageJpeg->data = uRequest->thumbnail[x]->data;
      ++montageJpeg->data;
      ++uRequest->thumbnail[x]->data;
    }

    //Determining the max width of the montage file
    if (max_width < tmp_width)
      max_width = tmp_width;

  }

  max_height *= y_max;

  montageJpeg->i.width = max_width;
  montageJpeg->i.height = max_height;

  jpeg_write (fp, montageJpeg);

  free (montageJpeg);

  return TRUE;
}

int getExifOrientation (struct ida_image *aThumbnail,
			JXFORM_CODE * exifOrientation)
{
  ExifData *exifData = exif_data_new_from_data (aThumbnail, THUMB_MAX);

  if (0 == exifData)
    return FALSE;

  int orientation = get_orientation (exifData);
  if (orientation >= 1 && orientation <= 8)
    *exifOrientation = transmagic[orientation];
  else
    *exifOrientation = JXFORM_NONE;

  return TRUE;
}

void destroyUserRequest (UserRequest ** uRequest)
{
  int i;
  for (i = 0; i < (*uRequest)->nrFiles; ++i) {
    free ((*uRequest)->thumbnail[i]);
    free ((*uRequest)->fileIn[i]);
    free ((*uRequest)->fileRotIn[i]);
  }
  free ((*uRequest)->outDir);
  free (*uRequest);
}

int initUserRequest (UserRequest ** uRequest)
{
  (*uRequest) = (UserRequest *) calloc (1, sizeof (UserRequest));

  if (0 == *uRequest)
    return FALSE;

  char currentPath[FILENAME_MAX];

  if (!getcwd (currentPath, sizeof (currentPath)))
    return FALSE;

  unsigned int flags = JFLAG_TRANSFORM_IMAGE |
    JFLAG_TRANSFORM_THUMBNAIL | JFLAG_UPDATE_ORIENTATION;

  copyStr (&((*uRequest)->outDir), currentPath);

  memset (&(*uRequest)->auto_rotation, JXFORM_NONE, MAX_INPUT_FILE);

  (*uRequest)->rotation = JXFORM_NONE;
  (*uRequest)->threads = 2;
  (*uRequest)->nrFiles = 0;
  (*uRequest)->comment = 0;
  (*uRequest)->flags = flags;

  return TRUE;
}

void getThreads (UserRequest * uRequest, char *optarg)
{

  if (NULL == optarg)
    return;

  int t = atoi (optarg);
  if (0 != t)
    uRequest->threads = t;
}

int getOutDir (UserRequest * uRequest, char *optarg)
{
  if (NULL == optarg)
    return FALSE;

  if (0 == copyStr (&uRequest->outDir, optarg)) {
    no_memory ();
    return FALSE;
  }
  //Check if this is a valid directory
  struct stat st;
  if (0 != stat (uRequest->outDir, &st)) {
    printf ("Directory %s does not exist!\n", uRequest->outDir);
    return FALSE;
  }

  return TRUE;
}

/**
 * Prints data of a UserRequest struct.
 */
inline void printUserRequest (UserRequest * uRequest)
{
  int rot = 0;
  switch (uRequest->rotation) {
  case JXFORM_ROT_90:
    rot = 90;
    break;
  case JXFORM_ROT_180:
    rot = 180;
    break;
  case JXFORM_ROT_270:
    rot = 270;
    break;
  default:
    break;
  }

  char *files = (char *) calloc (1, FILENAME_MAX * uRequest->nrFiles);
  int iLast = uRequest->nrFiles - 1;
  int i;
  for (i = 0; i < iLast; ++i) {
    strncat (files, uRequest->fileIn[i], strlen (uRequest->fileIn[i]));
    strncat (files, ", ", 1);
  }
  strncat (files, uRequest->fileIn[iLast], strlen (uRequest->fileIn[iLast]));

  printf ("Rotation by %d degrees of file(s): %s "
	  "using %d threads.\n"
	  "Output in directory '%s'.\n", rot, files,
	  uRequest->threads, uRequest->outDir);

  free (files);
}

/**
 * Checks if 'fName' represents the name of a valid file.
 */
int isValidFile (const char *fName)
{
  struct stat st;
  if (0 != stat (fName, &st)) {
    printf ("File or directory %s does not exist!\n", fName);
    return FALSE;
  }
  return TRUE;
}

/**
 * Attempts to allocate memory for *dst, and if successful, copy
 * the content of *src to *dst.
 * Returns a NULL pointer if unsucessful.
 */
char *copyStr (char **dst, char *src)
{
  int srcSize = strlen (src) + 1;
  (*dst) = (char *) calloc (1, srcSize);
  if (NULL == (*dst)) {
    no_memory ();
    return 0;
  }
  strcpy (*dst, src);

  return *dst;
}

inline void help (char *argv[])
{
  printf ("Usage: %s [options] file(s)\n", argv[0]);
  printf ("\t-h,     --help        Print this message\n"
	  "\t-9,     --rotate_90   Rotate the jpeg by 90 degrees\n"
	  "\t-1,     --rotate_180  Rotate the jpeg by 180 degrees\n"
	  "\t-2,     --rotate_270  Rotate the jpeg by 270 degrees\n"
	  "\t-t n,   --threads n   Perform the rotation using 'n' threads\n"
	  "\t-o dir, --outdir  dir The directory where to store the modified files\n\n");
  printf ("Generated files are appended the suffix %s\n"
	  "2 threads are used by default to perform the rotation.\n", ENDING);
}

inline void abort_message ()
{
  printf ("An error occured. Execution was aborted! Try again.\n");
}

inline void no_memory ()
{
  printf ("Memory could not be allocated! Try again.\n");
}
