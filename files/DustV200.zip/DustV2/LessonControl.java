// LessonControl.java
//
// Author: Raja Vallee-Rai
//
// This file is public domain.  You can do anything you want with 
// it, all at your own risk.  Enjoy!

import kor.base.*;
import java.awt.event.*;
import java.awt.*;

import java.io.*;

/**
 * This frame controls the loading of lesson states, and the display of the lesson
 * texts.
 */

class LessonControl extends Frame implements ActionListener,
                                            WindowListener

{
    Playfield playfield;
    
    TextArea textArea;
    
    Button simButton, pageButton;
    Button restartButton, dismissButton;
    Button chooseButton;
    Button nextLessonButton, previousLessonButton;
    
    String preSimTextFileName;
    String postSimTextFileName;

    String preSimText, postSimText;
    
    String currentLesson;
    String currentDirOfLesson;
    
    String[] standardLessons;
    int currentStandardLessonID;
    
    boolean isCurrentLessonStandard;
     
    public LessonControl(Playfield playfield)
    {
        this.playfield = playfield;
        
        addWindowListener(this);
        setSize(new Dimension(430, 510));
        setLayout(new BorderLayout());
        
        WindowPlacer.placeWindowAt(this, "East");
        
        textArea = new TextArea("", 50, 30, TextArea.SCROLLBARS_VERTICAL_ONLY);
        
        textArea.setBackground(Color.lightGray);
        textArea.setEditable(false);
        textArea.setFont(new Font("Monospaced", Font.PLAIN, 14));
        add(textArea, "Center");
        
        // Bottom panel
        {
            Panel bottomPanel = new Panel();
            
            bottomPanel.setLayout(new GridLayout(0, 1));
        
            // First line
            {
                Panel p = new Panel();
                
                p.setLayout(new FlowLayout());
                p.add(simButton = new Button("Start Simulation"));
                simButton.addActionListener(this);
                
                p.add(pageButton = new Button("Next>>>>>>"));
                    // note that this this button actually will get renamed to Next>>
                    // in the call below to startLesson(), but this is necessary
                    // so that <<Previous fits in the button when it gets renamed.
                pageButton.addActionListener(this);
    
                p.add(restartButton = new Button("Restart Lesson"));
                restartButton.addActionListener(this);
                
                p.add(dismissButton = new Button("Dismiss"));
                dismissButton.addActionListener(this);
    
                bottomPanel.add(p);
            }

            // Second line
            {
                Panel p = new Panel();
                
                p.setLayout(new FlowLayout());
                p.add(chooseButton = new Button("Choose Lesson"));
                chooseButton.addActionListener(this);

                p.add(previousLessonButton = new Button("Previous Lesson"));
                previousLessonButton.addActionListener(this);                
                
                p.add(nextLessonButton = new Button("Next Lesson"));
                nextLessonButton.addActionListener(this);
                
                bottomPanel.add(p);
            }   
         
               
            add(bottomPanel, "South");
        }
        
        // Scan Lessons directory for lessons
        {
            File lessonDir = new File("Lessons");
            
            standardLessons = lessonDir.list();
        }
    }
    
    void chooseLesson()
    {
        FileDialog dialog = new FileDialog(this, "Open Which Lesson?", FileDialog.LOAD);
        
        dialog.setFilenameFilter(new LessonFilenameFilter());
        dialog.setDirectory("Lessons");
        dialog.show();
        
        String fileName = dialog.getFile();
        
        if(fileName != null)
           startLesson(dialog.getDirectory(), fileName);
           
    }
    
    String stringOfFileContents(String fileName)
    {
        FileReader fileReader = null;
        StringBuffer buffer = new StringBuffer();
        
        // Open file.
            try {
                fileReader = new FileReader(fileName);
            } catch(IOException e)
            {
                new OkayDialog(this, "Error", "Could not open file '" + fileName + 
                        "'.", "Okay");
            }
        
        // Read in all lines
            try {
                BufferedReader in = new BufferedReader(fileReader); 
                 
                for(;;)
                {
                    String nextLine = in.readLine();
                    
                    if(nextLine == null)
                        break;
                        
                    buffer.append(nextLine);
                    buffer.append("\n");
                    
                }
            } catch(IOException e)
            {
            }
            
        return buffer.toString();
    }
    
    void startLesson(String dir, String lesson)
    {   
        try {
            FileReader in = new FileReader(dir + lesson);
            
            setTitle(lesson);

            preSimTextFileName = null;
            postSimTextFileName = null;
            postSimText = null;
            preSimText = null;
            
            playfield.controls.unselectParticle();
            playfield.restoreStateFromStream(in);
            playfield.refreshViewers();
            
            if(preSimTextFileName != null && !preSimTextFileName.equals("none"))
                preSimText = stringOfFileContents("LessonTexts" + File.separator + 
                    preSimTextFileName);
                    
            if(postSimTextFileName != null && !postSimTextFileName.equals("none"))
                postSimText = stringOfFileContents("LessonTexts" + File.separator + 
                postSimTextFileName);
            
            simButton.setLabel("Start Simulation");

            pageButton.setLabel("Next>>");

            pageButton.setEnabled(postSimText != null);

            if(preSimText != null)
                textArea.setText(preSimText);
            else
                textArea.setText("");
                
            currentLesson = lesson;
            currentDirOfLesson = dir;
            
            // Determine if it's a "standard" lesson (one which has an order)
            {
                if(currentDirOfLesson.equals("Lessons" + File.separator))
                {
                    boolean found = false;
                    
                    for(int i = 0; i < standardLessons.length; i++)
                        if(standardLessons[i].equals(currentLesson))
                        {
                            currentStandardLessonID = i;
                            isCurrentLessonStandard = true;
                            found = true;
                            break;
                        }
                        
                    if(!found)
                        isCurrentLessonStandard = false;
                }
                else 
                    isCurrentLessonStandard = false;
            }
            
            // Set next/previous buttons appropriately
            {         
                nextLessonButton.setEnabled(false);
                previousLessonButton.setEnabled(false);
                  
                if(isCurrentLessonStandard)
                {
                    if(currentStandardLessonID != 0)
                        previousLessonButton.setEnabled(true);
                    
                    if(currentStandardLessonID != standardLessons.length - 1)
                        nextLessonButton.setEnabled(true);
                }
            }
            
        } catch(IOException e)
        {
            new OkayDialog(this, "Error", "Could not open lesson file '" + lesson + 
                        "'.", "Okay");
        }
    }
    
    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource() == dismissButton)
        {
            handleClickToClose();
        }
        else if(e.getSource() == chooseButton)
        {
            chooseLesson();
        }
        else if(e.getSource() == restartButton)
        {
            startLesson(currentDirOfLesson, currentLesson);
        }
        else if(e.getSource() == nextLessonButton)
        {
            startLesson("Lessons" + File.separator, standardLessons[currentStandardLessonID + 1]);
        }
        else if(e.getSource() == previousLessonButton)
        {
            startLesson("Lessons" + File.separator, standardLessons[currentStandardLessonID - 1]);
        }
        else if(e.getSource() == simButton)
        {
            if(simButton.getLabel().equals("Start Simulation"))
            {
                playfield.controls.parentDust.toFront();
                playfield.controls.handleStartSimulationClick();
            }
            else
                playfield.controls.handleStopSimulationClick();
        }
        else if(e.getSource() == pageButton)
        {
            if(pageButton.getLabel().equals("Next>>"))
            {
                textArea.setText(postSimText);
                pageButton.setLabel("<<Previous");
            }
            else {
                textArea.setText(preSimText);
                pageButton.setLabel("Next>>");
            }
        }
    }
        
    void handleClickToClose()
    {
        setVisible(false);
    }

    public void windowClosing(WindowEvent e)
    {
        handleClickToClose();
    }
     
    public void windowOpened(WindowEvent e)
    {
    }
     
    public void windowIconified(WindowEvent e)
    {
    }
     
    public void windowDeiconified(WindowEvent e)
    {
    }
     
    public void windowClosed(WindowEvent e)
    {
    }
     
    public void windowActivated(WindowEvent e)
    {
    }
     
    public void windowDeactivated(WindowEvent e) 
    {
    }
}

/** This class would be used, but it does not seem to work in jdk1.1.2 on win32
 */
 
class LessonFilenameFilter implements FilenameFilter
{
    public boolean accept(File dir, String name)
    {
        return name.endsWith(".lesson");
    }
}