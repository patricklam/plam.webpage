// $ANTLR 3.2 debian-4 Wig.g 2010-11-19 14:15:05

package ca.uwaterloo.ece251;

import ca.uwaterloo.ece251.ast.*;
import java.util.List;
import java.util.LinkedList;


import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
public class WigParser extends Parser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "ID", "BEGIN_HTML", "OPEN_SLASH", "END_HTML", "OPEN_TAG", "CLOSE_TAG", "WHATEVER", "META", "STRING_LITERAL", "INT_LITERAL", "WS", "'service'", "'{'", "'}'", "'const'", "'html'", "'='", "';'", "'['", "']'", "'input'", "'select'", "'schema'", "','", "'int'", "'bool'", "'string'", "'void'", "'tuple'", "'('", "')'", "'session'", "'show'", "'exit'", "'return'", "'if'", "'else'", "'while'", "'plug'", "'receive'", "'||'", "'&&'", "'=='", "'!='", "'<'", "'>'", "'<='", "'>='", "'+'", "'-'", "'*'", "'/'", "'%'", "'<<'", "'\\\\+'", "'\\\\-'", "'!'", "'true'", "'false'", "'.'"
    };
    public static final int OPEN_TAG=8;
    public static final int T__29=29;
    public static final int T__28=28;
    public static final int T__62=62;
    public static final int T__27=27;
    public static final int T__63=63;
    public static final int T__26=26;
    public static final int T__25=25;
    public static final int T__24=24;
    public static final int T__23=23;
    public static final int T__22=22;
    public static final int T__21=21;
    public static final int T__20=20;
    public static final int END_HTML=7;
    public static final int ID=4;
    public static final int T__61=61;
    public static final int T__60=60;
    public static final int EOF=-1;
    public static final int META=11;
    public static final int BEGIN_HTML=5;
    public static final int T__55=55;
    public static final int T__56=56;
    public static final int T__19=19;
    public static final int T__57=57;
    public static final int T__58=58;
    public static final int STRING_LITERAL=12;
    public static final int T__16=16;
    public static final int T__51=51;
    public static final int T__15=15;
    public static final int T__52=52;
    public static final int T__18=18;
    public static final int T__53=53;
    public static final int T__17=17;
    public static final int T__54=54;
    public static final int T__59=59;
    public static final int WHATEVER=10;
    public static final int T__50=50;
    public static final int T__42=42;
    public static final int T__43=43;
    public static final int T__40=40;
    public static final int INT_LITERAL=13;
    public static final int OPEN_SLASH=6;
    public static final int T__41=41;
    public static final int T__46=46;
    public static final int T__47=47;
    public static final int T__44=44;
    public static final int T__45=45;
    public static final int T__48=48;
    public static final int T__49=49;
    public static final int CLOSE_TAG=9;
    public static final int T__30=30;
    public static final int T__31=31;
    public static final int T__32=32;
    public static final int WS=14;
    public static final int T__33=33;
    public static final int T__34=34;
    public static final int T__35=35;
    public static final int T__36=36;
    public static final int T__37=37;
    public static final int T__38=38;
    public static final int T__39=39;

    // delegates
    // delegators


        public WigParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public WigParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return WigParser.tokenNames; }
    public String getGrammarFileName() { return "Wig.g"; }



    // $ANTLR start "service"
    // Wig.g:37:1: service returns [Service s] : 'service' '{' (h= html )* (sch= schema )* (v= variable )* (f= function )* (se= session )* '}' ;
    public final Service service() throws RecognitionException {
        Service s = null;

        HTML h = null;

        Schema sch = null;

        Variable v = null;

        Function f = null;

        Session se = null;



                    List<HTML> hl = new LinkedList<HTML>(); 
                    List<Schema> scl = new LinkedList<Schema>(); 
                    List<Variable> vl = new LinkedList<Variable>(); 
                    List<Function> fl = new LinkedList<Function>(); 
                    List<Session> sel = new LinkedList<Session>(); 
                
        try {
            // Wig.g:45:5: ( 'service' '{' (h= html )* (sch= schema )* (v= variable )* (f= function )* (se= session )* '}' )
            // Wig.g:45:7: 'service' '{' (h= html )* (sch= schema )* (v= variable )* (f= function )* (se= session )* '}'
            {
            match(input,15,FOLLOW_15_in_service54); if (state.failed) return s;
            match(input,16,FOLLOW_16_in_service56); if (state.failed) return s;
            // Wig.g:46:9: (h= html )*
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( (LA1_0==18) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // Wig.g:46:10: h= html
            	    {
            	    pushFollow(FOLLOW_html_in_service70);
            	    h=html();

            	    state._fsp--;
            	    if (state.failed) return s;
            	    if ( state.backtracking==0 ) {
            	       hl.add(h);
            	    }

            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);

            // Wig.g:47:9: (sch= schema )*
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( (LA2_0==26) ) {
                    alt2=1;
                }


                switch (alt2) {
            	case 1 :
            	    // Wig.g:47:10: sch= schema
            	    {
            	    pushFollow(FOLLOW_schema_in_service88);
            	    sch=schema();

            	    state._fsp--;
            	    if (state.failed) return s;
            	    if ( state.backtracking==0 ) {
            	       scl.add(sch);
            	    }

            	    }
            	    break;

            	default :
            	    break loop2;
                }
            } while (true);

            // Wig.g:48:9: (v= variable )*
            loop3:
            do {
                int alt3=2;
                alt3 = dfa3.predict(input);
                switch (alt3) {
            	case 1 :
            	    // Wig.g:48:10: v= variable
            	    {
            	    pushFollow(FOLLOW_variable_in_service106);
            	    v=variable();

            	    state._fsp--;
            	    if (state.failed) return s;
            	    if ( state.backtracking==0 ) {
            	       vl.add(v); 
            	    }

            	    }
            	    break;

            	default :
            	    break loop3;
                }
            } while (true);

            // Wig.g:49:9: (f= function )*
            loop4:
            do {
                int alt4=2;
                int LA4_0 = input.LA(1);

                if ( ((LA4_0>=28 && LA4_0<=32)) ) {
                    alt4=1;
                }


                switch (alt4) {
            	case 1 :
            	    // Wig.g:49:10: f= function
            	    {
            	    pushFollow(FOLLOW_function_in_service124);
            	    f=function();

            	    state._fsp--;
            	    if (state.failed) return s;
            	    if ( state.backtracking==0 ) {
            	       fl.add(f); 
            	    }

            	    }
            	    break;

            	default :
            	    break loop4;
                }
            } while (true);

            // Wig.g:50:9: (se= session )*
            loop5:
            do {
                int alt5=2;
                int LA5_0 = input.LA(1);

                if ( (LA5_0==35) ) {
                    alt5=1;
                }


                switch (alt5) {
            	case 1 :
            	    // Wig.g:50:10: se= session
            	    {
            	    pushFollow(FOLLOW_session_in_service142);
            	    se=session();

            	    state._fsp--;
            	    if (state.failed) return s;
            	    if ( state.backtracking==0 ) {
            	       sel.add(se); 
            	    }

            	    }
            	    break;

            	default :
            	    break loop5;
                }
            } while (true);

            match(input,17,FOLLOW_17_in_service148); if (state.failed) return s;
            if ( state.backtracking==0 ) {
               s = new Service(hl, scl, vl, fl, sel); 
            }

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return s;
    }
    // $ANTLR end "service"


    // $ANTLR start "html"
    // Wig.g:53:1: html returns [HTML h] : 'const' 'html' ID '=' BEGIN_HTML (hb= htmlbody )* OPEN_SLASH END_HTML ';' ;
    public final HTML html() throws RecognitionException {
        HTML h = null;

        Token ID1=null;
        HTMLBody hb = null;



                List<HTMLBody> htmlbody = new LinkedList<HTMLBody>();
            
        try {
            // Wig.g:56:7: ( 'const' 'html' ID '=' BEGIN_HTML (hb= htmlbody )* OPEN_SLASH END_HTML ';' )
            // Wig.g:56:9: 'const' 'html' ID '=' BEGIN_HTML (hb= htmlbody )* OPEN_SLASH END_HTML ';'
            {
            match(input,18,FOLLOW_18_in_html181); if (state.failed) return h;
            match(input,19,FOLLOW_19_in_html183); if (state.failed) return h;
            ID1=(Token)match(input,ID,FOLLOW_ID_in_html185); if (state.failed) return h;
            match(input,20,FOLLOW_20_in_html187); if (state.failed) return h;
            match(input,BEGIN_HTML,FOLLOW_BEGIN_HTML_in_html189); if (state.failed) return h;
            // Wig.g:57:9: (hb= htmlbody )*
            loop6:
            do {
                int alt6=2;
                int LA6_0 = input.LA(1);

                if ( (LA6_0==OPEN_SLASH) ) {
                    int LA6_1 = input.LA(2);

                    if ( (LA6_1==ID) ) {
                        alt6=1;
                    }


                }
                else if ( (LA6_0==OPEN_TAG||(LA6_0>=WHATEVER && LA6_0<=META)) ) {
                    alt6=1;
                }


                switch (alt6) {
            	case 1 :
            	    // Wig.g:57:10: hb= htmlbody
            	    {
            	    pushFollow(FOLLOW_htmlbody_in_html204);
            	    hb=htmlbody();

            	    state._fsp--;
            	    if (state.failed) return h;
            	    if ( state.backtracking==0 ) {
            	       htmlbody.add(hb); 
            	    }

            	    }
            	    break;

            	default :
            	    break loop6;
                }
            } while (true);

            match(input,OPEN_SLASH,FOLLOW_OPEN_SLASH_in_html219); if (state.failed) return h;
            match(input,END_HTML,FOLLOW_END_HTML_in_html221); if (state.failed) return h;
            match(input,21,FOLLOW_21_in_html223); if (state.failed) return h;
            if ( state.backtracking==0 ) {
               h = new HTML(new Id((ID1!=null?ID1.getText():null)), htmlbody); 
            }

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return h;
    }
    // $ANTLR end "html"


    // $ANTLR start "htmlbody"
    // Wig.g:61:1: htmlbody returns [HTMLBody b] : ( OPEN_TAG ID (a= attribute )* CLOSE_TAG | OPEN_SLASH ID CLOSE_TAG | OPEN_TAG '[' ID ']' CLOSE_TAG | WHATEVER | META | OPEN_TAG 'input' (a= attribute )* CLOSE_TAG | OPEN_TAG 'select' (a= attribute )* CLOSE_TAG (hb= htmlbody )* OPEN_SLASH 'select' CLOSE_TAG );
    public final HTMLBody htmlbody() throws RecognitionException {
        HTMLBody b = null;

        Token ID2=null;
        Token ID3=null;
        Token ID4=null;
        Token WHATEVER5=null;
        Token META6=null;
        Attribute a = null;

        HTMLBody hb = null;



                List<Attribute> attributes = new LinkedList<Attribute>();
                List<HTMLBody> htmlbodies = new LinkedList<HTMLBody>();
            
        try {
            // Wig.g:66:5: ( OPEN_TAG ID (a= attribute )* CLOSE_TAG | OPEN_SLASH ID CLOSE_TAG | OPEN_TAG '[' ID ']' CLOSE_TAG | WHATEVER | META | OPEN_TAG 'input' (a= attribute )* CLOSE_TAG | OPEN_TAG 'select' (a= attribute )* CLOSE_TAG (hb= htmlbody )* OPEN_SLASH 'select' CLOSE_TAG )
            int alt11=7;
            switch ( input.LA(1) ) {
            case OPEN_TAG:
                {
                switch ( input.LA(2) ) {
                case ID:
                    {
                    alt11=1;
                    }
                    break;
                case 22:
                    {
                    alt11=3;
                    }
                    break;
                case 24:
                    {
                    alt11=6;
                    }
                    break;
                case 25:
                    {
                    alt11=7;
                    }
                    break;
                default:
                    if (state.backtracking>0) {state.failed=true; return b;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 11, 1, input);

                    throw nvae;
                }

                }
                break;
            case OPEN_SLASH:
                {
                alt11=2;
                }
                break;
            case WHATEVER:
                {
                alt11=4;
                }
                break;
            case META:
                {
                alt11=5;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return b;}
                NoViableAltException nvae =
                    new NoViableAltException("", 11, 0, input);

                throw nvae;
            }

            switch (alt11) {
                case 1 :
                    // Wig.g:66:7: OPEN_TAG ID (a= attribute )* CLOSE_TAG
                    {
                    match(input,OPEN_TAG,FOLLOW_OPEN_TAG_in_htmlbody259); if (state.failed) return b;
                    ID2=(Token)match(input,ID,FOLLOW_ID_in_htmlbody261); if (state.failed) return b;
                    // Wig.g:66:19: (a= attribute )*
                    loop7:
                    do {
                        int alt7=2;
                        int LA7_0 = input.LA(1);

                        if ( (LA7_0==ID||LA7_0==STRING_LITERAL) ) {
                            alt7=1;
                        }


                        switch (alt7) {
                    	case 1 :
                    	    // Wig.g:66:20: a= attribute
                    	    {
                    	    pushFollow(FOLLOW_attribute_in_htmlbody266);
                    	    a=attribute();

                    	    state._fsp--;
                    	    if (state.failed) return b;
                    	    if ( state.backtracking==0 ) {
                    	       attributes.add(a); 
                    	    }

                    	    }
                    	    break;

                    	default :
                    	    break loop7;
                        }
                    } while (true);

                    match(input,CLOSE_TAG,FOLLOW_CLOSE_TAG_in_htmlbody272); if (state.failed) return b;
                    if ( state.backtracking==0 ) {
                      b = new OpenHTMLBody(new Id((ID2!=null?ID2.getText():null)), attributes); 
                    }

                    }
                    break;
                case 2 :
                    // Wig.g:68:7: OPEN_SLASH ID CLOSE_TAG
                    {
                    match(input,OPEN_SLASH,FOLLOW_OPEN_SLASH_in_htmlbody290); if (state.failed) return b;
                    ID3=(Token)match(input,ID,FOLLOW_ID_in_htmlbody292); if (state.failed) return b;
                    match(input,CLOSE_TAG,FOLLOW_CLOSE_TAG_in_htmlbody294); if (state.failed) return b;
                    if ( state.backtracking==0 ) {
                       b = new CloseHTMLBody(new Id((ID3!=null?ID3.getText():null))); 
                    }

                    }
                    break;
                case 3 :
                    // Wig.g:69:7: OPEN_TAG '[' ID ']' CLOSE_TAG
                    {
                    match(input,OPEN_TAG,FOLLOW_OPEN_TAG_in_htmlbody304); if (state.failed) return b;
                    match(input,22,FOLLOW_22_in_htmlbody306); if (state.failed) return b;
                    ID4=(Token)match(input,ID,FOLLOW_ID_in_htmlbody308); if (state.failed) return b;
                    match(input,23,FOLLOW_23_in_htmlbody310); if (state.failed) return b;
                    match(input,CLOSE_TAG,FOLLOW_CLOSE_TAG_in_htmlbody312); if (state.failed) return b;
                    if ( state.backtracking==0 ) {
                       b = new PlugHTMLBody(new Id((ID4!=null?ID4.getText():null))); 
                    }

                    }
                    break;
                case 4 :
                    // Wig.g:70:7: WHATEVER
                    {
                    WHATEVER5=(Token)match(input,WHATEVER,FOLLOW_WHATEVER_in_htmlbody322); if (state.failed) return b;
                    if ( state.backtracking==0 ) {
                       b = new WhateverHTMLBody((WHATEVER5!=null?WHATEVER5.getText():null)); 
                    }

                    }
                    break;
                case 5 :
                    // Wig.g:71:7: META
                    {
                    META6=(Token)match(input,META,FOLLOW_META_in_htmlbody332); if (state.failed) return b;
                    if ( state.backtracking==0 ) {
                       b = new MetaHTMLBody((META6!=null?META6.getText():null)); 
                    }

                    }
                    break;
                case 6 :
                    // Wig.g:72:7: OPEN_TAG 'input' (a= attribute )* CLOSE_TAG
                    {
                    match(input,OPEN_TAG,FOLLOW_OPEN_TAG_in_htmlbody342); if (state.failed) return b;
                    match(input,24,FOLLOW_24_in_htmlbody344); if (state.failed) return b;
                    // Wig.g:72:24: (a= attribute )*
                    loop8:
                    do {
                        int alt8=2;
                        int LA8_0 = input.LA(1);

                        if ( (LA8_0==ID||LA8_0==STRING_LITERAL) ) {
                            alt8=1;
                        }


                        switch (alt8) {
                    	case 1 :
                    	    // Wig.g:72:25: a= attribute
                    	    {
                    	    pushFollow(FOLLOW_attribute_in_htmlbody349);
                    	    a=attribute();

                    	    state._fsp--;
                    	    if (state.failed) return b;
                    	    if ( state.backtracking==0 ) {
                    	       attributes.add(a); 
                    	    }

                    	    }
                    	    break;

                    	default :
                    	    break loop8;
                        }
                    } while (true);

                    match(input,CLOSE_TAG,FOLLOW_CLOSE_TAG_in_htmlbody355); if (state.failed) return b;
                    if ( state.backtracking==0 ) {
                      b = new InputHTMLBody(attributes); 
                    }

                    }
                    break;
                case 7 :
                    // Wig.g:74:7: OPEN_TAG 'select' (a= attribute )* CLOSE_TAG (hb= htmlbody )* OPEN_SLASH 'select' CLOSE_TAG
                    {
                    match(input,OPEN_TAG,FOLLOW_OPEN_TAG_in_htmlbody373); if (state.failed) return b;
                    match(input,25,FOLLOW_25_in_htmlbody375); if (state.failed) return b;
                    // Wig.g:74:25: (a= attribute )*
                    loop9:
                    do {
                        int alt9=2;
                        int LA9_0 = input.LA(1);

                        if ( (LA9_0==ID||LA9_0==STRING_LITERAL) ) {
                            alt9=1;
                        }


                        switch (alt9) {
                    	case 1 :
                    	    // Wig.g:74:26: a= attribute
                    	    {
                    	    pushFollow(FOLLOW_attribute_in_htmlbody380);
                    	    a=attribute();

                    	    state._fsp--;
                    	    if (state.failed) return b;
                    	    if ( state.backtracking==0 ) {
                    	       attributes.add(a); 
                    	    }

                    	    }
                    	    break;

                    	default :
                    	    break loop9;
                        }
                    } while (true);

                    match(input,CLOSE_TAG,FOLLOW_CLOSE_TAG_in_htmlbody386); if (state.failed) return b;
                    // Wig.g:75:9: (hb= htmlbody )*
                    loop10:
                    do {
                        int alt10=2;
                        int LA10_0 = input.LA(1);

                        if ( (LA10_0==OPEN_SLASH) ) {
                            int LA10_1 = input.LA(2);

                            if ( (LA10_1==ID) ) {
                                alt10=1;
                            }


                        }
                        else if ( (LA10_0==OPEN_TAG||(LA10_0>=WHATEVER && LA10_0<=META)) ) {
                            alt10=1;
                        }


                        switch (alt10) {
                    	case 1 :
                    	    // Wig.g:75:10: hb= htmlbody
                    	    {
                    	    pushFollow(FOLLOW_htmlbody_in_htmlbody399);
                    	    hb=htmlbody();

                    	    state._fsp--;
                    	    if (state.failed) return b;
                    	    if ( state.backtracking==0 ) {
                    	       htmlbodies.add(hb); 
                    	    }

                    	    }
                    	    break;

                    	default :
                    	    break loop10;
                        }
                    } while (true);

                    match(input,OPEN_SLASH,FOLLOW_OPEN_SLASH_in_htmlbody405); if (state.failed) return b;
                    match(input,25,FOLLOW_25_in_htmlbody407); if (state.failed) return b;
                    match(input,CLOSE_TAG,FOLLOW_CLOSE_TAG_in_htmlbody409); if (state.failed) return b;
                    if ( state.backtracking==0 ) {
                      b = new SelectHTMLBody(attributes, htmlbodies); 
                    }

                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return b;
    }
    // $ANTLR end "htmlbody"


    // $ANTLR start "attribute"
    // Wig.g:85:1: attribute returns [Attribute a] : ( attr | l= attr '=' r= attr );
    public final Attribute attribute() throws RecognitionException {
        Attribute a = null;

        Attr l = null;

        Attr r = null;

        Attr attr7 = null;


        try {
            // Wig.g:85:33: ( attr | l= attr '=' r= attr )
            int alt12=2;
            int LA12_0 = input.LA(1);

            if ( (LA12_0==ID) ) {
                int LA12_1 = input.LA(2);

                if ( (LA12_1==20) ) {
                    alt12=2;
                }
                else if ( (LA12_1==ID||LA12_1==CLOSE_TAG||LA12_1==STRING_LITERAL) ) {
                    alt12=1;
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return a;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 12, 1, input);

                    throw nvae;
                }
            }
            else if ( (LA12_0==STRING_LITERAL) ) {
                int LA12_2 = input.LA(2);

                if ( (LA12_2==20) ) {
                    alt12=2;
                }
                else if ( (LA12_2==ID||LA12_2==CLOSE_TAG||LA12_2==STRING_LITERAL) ) {
                    alt12=1;
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return a;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 12, 2, input);

                    throw nvae;
                }
            }
            else {
                if (state.backtracking>0) {state.failed=true; return a;}
                NoViableAltException nvae =
                    new NoViableAltException("", 12, 0, input);

                throw nvae;
            }
            switch (alt12) {
                case 1 :
                    // Wig.g:86:7: attr
                    {
                    pushFollow(FOLLOW_attr_in_attribute442);
                    attr7=attr();

                    state._fsp--;
                    if (state.failed) return a;
                    if ( state.backtracking==0 ) {
                       a = new KeyOnlyAttribute(attr7); 
                    }

                    }
                    break;
                case 2 :
                    // Wig.g:87:7: l= attr '=' r= attr
                    {
                    pushFollow(FOLLOW_attr_in_attribute456);
                    l=attr();

                    state._fsp--;
                    if (state.failed) return a;
                    match(input,20,FOLLOW_20_in_attribute458); if (state.failed) return a;
                    pushFollow(FOLLOW_attr_in_attribute462);
                    r=attr();

                    state._fsp--;
                    if (state.failed) return a;
                    if ( state.backtracking==0 ) {
                       a = new KeyValueAttribute(l, r); 
                    }

                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return a;
    }
    // $ANTLR end "attribute"


    // $ANTLR start "attr"
    // Wig.g:89:1: attr returns [Attr a] : ( ID | STRING_LITERAL );
    public final Attr attr() throws RecognitionException {
        Attr a = null;

        Token ID8=null;
        Token STRING_LITERAL9=null;

        try {
            // Wig.g:89:23: ( ID | STRING_LITERAL )
            int alt13=2;
            int LA13_0 = input.LA(1);

            if ( (LA13_0==ID) ) {
                alt13=1;
            }
            else if ( (LA13_0==STRING_LITERAL) ) {
                alt13=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return a;}
                NoViableAltException nvae =
                    new NoViableAltException("", 13, 0, input);

                throw nvae;
            }
            switch (alt13) {
                case 1 :
                    // Wig.g:90:9: ID
                    {
                    ID8=(Token)match(input,ID,FOLLOW_ID_in_attr487); if (state.failed) return a;
                    if ( state.backtracking==0 ) {
                       a = new IdAttr(new Id((ID8!=null?ID8.getText():null))); 
                    }

                    }
                    break;
                case 2 :
                    // Wig.g:91:9: STRING_LITERAL
                    {
                    STRING_LITERAL9=(Token)match(input,STRING_LITERAL,FOLLOW_STRING_LITERAL_in_attr502); if (state.failed) return a;
                    if ( state.backtracking==0 ) {
                       a = new StringAttr((STRING_LITERAL9!=null?STRING_LITERAL9.getText():null)); 
                    }

                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return a;
    }
    // $ANTLR end "attr"


    // $ANTLR start "schema"
    // Wig.g:94:1: schema returns [Schema s] : 'schema' ID '{' (f= field )* '}' ;
    public final Schema schema() throws RecognitionException {
        Schema s = null;

        Token ID10=null;
        WigField f = null;


         List<WigField> fl = new LinkedList<WigField>(); 
        try {
            // Wig.g:95:59: ( 'schema' ID '{' (f= field )* '}' )
            // Wig.g:96:9: 'schema' ID '{' (f= field )* '}'
            {
            match(input,26,FOLLOW_26_in_schema531); if (state.failed) return s;
            ID10=(Token)match(input,ID,FOLLOW_ID_in_schema533); if (state.failed) return s;
            match(input,16,FOLLOW_16_in_schema535); if (state.failed) return s;
            // Wig.g:96:25: (f= field )*
            loop14:
            do {
                int alt14=2;
                int LA14_0 = input.LA(1);

                if ( ((LA14_0>=28 && LA14_0<=31)) ) {
                    alt14=1;
                }


                switch (alt14) {
            	case 1 :
            	    // Wig.g:96:26: f= field
            	    {
            	    pushFollow(FOLLOW_field_in_schema540);
            	    f=field();

            	    state._fsp--;
            	    if (state.failed) return s;
            	    if ( state.backtracking==0 ) {
            	       fl.add(f); 
            	    }

            	    }
            	    break;

            	default :
            	    break loop14;
                }
            } while (true);

            match(input,17,FOLLOW_17_in_schema546); if (state.failed) return s;
            if ( state.backtracking==0 ) {
               s = new Schema(new Id((ID10!=null?ID10.getText():null)), fl); 
            }

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return s;
    }
    // $ANTLR end "schema"


    // $ANTLR start "field"
    // Wig.g:99:1: field returns [ WigField f ] : simpletype ID ';' ;
    public final WigField field() throws RecognitionException {
        WigField f = null;

        Token ID12=null;
        Type simpletype11 = null;


        try {
            // Wig.g:99:30: ( simpletype ID ';' )
            // Wig.g:99:32: simpletype ID ';'
            {
            pushFollow(FOLLOW_simpletype_in_field568);
            simpletype11=simpletype();

            state._fsp--;
            if (state.failed) return f;
            ID12=(Token)match(input,ID,FOLLOW_ID_in_field570); if (state.failed) return f;
            match(input,21,FOLLOW_21_in_field572); if (state.failed) return f;
            if ( state.backtracking==0 ) {
               f = new WigField(simpletype11, new Id((ID12!=null?ID12.getText():null))); 
            }

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return f;
    }
    // $ANTLR end "field"


    // $ANTLR start "variable"
    // Wig.g:103:1: variable returns [Variable v] : type identifiers ';' ;
    public final Variable variable() throws RecognitionException {
        Variable v = null;

        Type type13 = null;

        List<Id> identifiers14 = null;


        try {
            // Wig.g:103:31: ( type identifiers ';' )
            // Wig.g:104:9: type identifiers ';'
            {
            pushFollow(FOLLOW_type_in_variable605);
            type13=type();

            state._fsp--;
            if (state.failed) return v;
            pushFollow(FOLLOW_identifiers_in_variable607);
            identifiers14=identifiers();

            state._fsp--;
            if (state.failed) return v;
            match(input,21,FOLLOW_21_in_variable609); if (state.failed) return v;
            if ( state.backtracking==0 ) {
               v = new Variable(type13, identifiers14); 
            }

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return v;
    }
    // $ANTLR end "variable"


    // $ANTLR start "identifiers"
    // Wig.g:106:1: identifiers returns [List<Id> ids] : i= ID ( ',' ii= ID )* ;
    public final List<Id> identifiers() throws RecognitionException {
        List<Id> ids = null;

        Token i=null;
        Token ii=null;

         ids = new LinkedList<Id>(); 
        try {
            // Wig.g:108:5: (i= ID ( ',' ii= ID )* )
            // Wig.g:108:7: i= ID ( ',' ii= ID )*
            {
            i=(Token)match(input,ID,FOLLOW_ID_in_identifiers635); if (state.failed) return ids;
            if ( state.backtracking==0 ) {
               ids.add(new Id((i!=null?i.getText():null))); 
            }
            // Wig.g:108:43: ( ',' ii= ID )*
            loop15:
            do {
                int alt15=2;
                int LA15_0 = input.LA(1);

                if ( (LA15_0==27) ) {
                    alt15=1;
                }


                switch (alt15) {
            	case 1 :
            	    // Wig.g:108:44: ',' ii= ID
            	    {
            	    match(input,27,FOLLOW_27_in_identifiers640); if (state.failed) return ids;
            	    ii=(Token)match(input,ID,FOLLOW_ID_in_identifiers644); if (state.failed) return ids;
            	    if ( state.backtracking==0 ) {
            	       ids.add(new Id((ii!=null?ii.getText():null))); 
            	    }

            	    }
            	    break;

            	default :
            	    break loop15;
                }
            } while (true);


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ids;
    }
    // $ANTLR end "identifiers"


    // $ANTLR start "simpletype"
    // Wig.g:111:1: simpletype returns [Type t] : ( 'int' | 'bool' | 'string' | 'void' );
    public final Type simpletype() throws RecognitionException {
        Type t = null;

        try {
            // Wig.g:111:29: ( 'int' | 'bool' | 'string' | 'void' )
            int alt16=4;
            switch ( input.LA(1) ) {
            case 28:
                {
                alt16=1;
                }
                break;
            case 29:
                {
                alt16=2;
                }
                break;
            case 30:
                {
                alt16=3;
                }
                break;
            case 31:
                {
                alt16=4;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return t;}
                NoViableAltException nvae =
                    new NoViableAltException("", 16, 0, input);

                throw nvae;
            }

            switch (alt16) {
                case 1 :
                    // Wig.g:112:7: 'int'
                    {
                    match(input,28,FOLLOW_28_in_simpletype672); if (state.failed) return t;
                    if ( state.backtracking==0 ) {
                       t = new SimpleType(SimpleType.SimpleTypes.INT); 
                    }

                    }
                    break;
                case 2 :
                    // Wig.g:113:7: 'bool'
                    {
                    match(input,29,FOLLOW_29_in_simpletype682); if (state.failed) return t;
                    if ( state.backtracking==0 ) {
                       t = new SimpleType(SimpleType.SimpleTypes.BOOL); 
                    }

                    }
                    break;
                case 3 :
                    // Wig.g:114:7: 'string'
                    {
                    match(input,30,FOLLOW_30_in_simpletype693); if (state.failed) return t;
                    if ( state.backtracking==0 ) {
                       t = new SimpleType(SimpleType.SimpleTypes.STRING); 
                    }

                    }
                    break;
                case 4 :
                    // Wig.g:115:7: 'void'
                    {
                    match(input,31,FOLLOW_31_in_simpletype704); if (state.failed) return t;
                    if ( state.backtracking==0 ) {
                       t = new SimpleType(SimpleType.SimpleTypes.VOID); 
                    }

                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return t;
    }
    // $ANTLR end "simpletype"


    // $ANTLR start "type"
    // Wig.g:117:1: type returns [Type t] : ( simpletype | 'tuple' ID );
    public final Type type() throws RecognitionException {
        Type t = null;

        Token ID16=null;
        Type simpletype15 = null;


        try {
            // Wig.g:117:23: ( simpletype | 'tuple' ID )
            int alt17=2;
            int LA17_0 = input.LA(1);

            if ( ((LA17_0>=28 && LA17_0<=31)) ) {
                alt17=1;
            }
            else if ( (LA17_0==32) ) {
                alt17=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return t;}
                NoViableAltException nvae =
                    new NoViableAltException("", 17, 0, input);

                throw nvae;
            }
            switch (alt17) {
                case 1 :
                    // Wig.g:118:7: simpletype
                    {
                    pushFollow(FOLLOW_simpletype_in_type725);
                    simpletype15=simpletype();

                    state._fsp--;
                    if (state.failed) return t;
                    if ( state.backtracking==0 ) {
                       t = simpletype15; 
                    }

                    }
                    break;
                case 2 :
                    // Wig.g:119:7: 'tuple' ID
                    {
                    match(input,32,FOLLOW_32_in_type736); if (state.failed) return t;
                    ID16=(Token)match(input,ID,FOLLOW_ID_in_type738); if (state.failed) return t;
                    if ( state.backtracking==0 ) {
                       t = new TupleType(new Id((ID16!=null?ID16.getText():null))); 
                    }

                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return t;
    }
    // $ANTLR end "type"


    // $ANTLR start "function"
    // Wig.g:122:1: function returns [Function f] : type ID '(' ( arguments )? ')' compoundstm ;
    public final Function function() throws RecognitionException {
        Function f = null;

        Token ID18=null;
        Type type17 = null;

        WigParser.arguments_return arguments19 = null;

        Stm compoundstm20 = null;


        try {
            // Wig.g:122:31: ( type ID '(' ( arguments )? ')' compoundstm )
            // Wig.g:123:9: type ID '(' ( arguments )? ')' compoundstm
            {
            pushFollow(FOLLOW_type_in_function762);
            type17=type();

            state._fsp--;
            if (state.failed) return f;
            ID18=(Token)match(input,ID,FOLLOW_ID_in_function764); if (state.failed) return f;
            match(input,33,FOLLOW_33_in_function766); if (state.failed) return f;
            // Wig.g:123:21: ( arguments )?
            int alt18=2;
            int LA18_0 = input.LA(1);

            if ( ((LA18_0>=28 && LA18_0<=32)) ) {
                alt18=1;
            }
            switch (alt18) {
                case 1 :
                    // Wig.g:123:21: arguments
                    {
                    pushFollow(FOLLOW_arguments_in_function768);
                    arguments19=arguments();

                    state._fsp--;
                    if (state.failed) return f;

                    }
                    break;

            }

            match(input,34,FOLLOW_34_in_function771); if (state.failed) return f;
            pushFollow(FOLLOW_compoundstm_in_function773);
            compoundstm20=compoundstm();

            state._fsp--;
            if (state.failed) return f;
            if ( state.backtracking==0 ) {
               f = new Function(type17, new Id((ID18!=null?ID18.getText():null)),
                              (arguments19!=null?arguments19.types:null), (arguments19!=null?arguments19.ids:null), compoundstm20); 
            }

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return f;
    }
    // $ANTLR end "function"

    public static class arguments_return extends ParserRuleReturnScope {
        public List<Type> types;
        public List<Id> ids;
    };

    // $ANTLR start "arguments"
    // Wig.g:127:1: arguments returns [List<Type> types, List<Id> ids] : a0= argument ( ',' an= argument )* ;
    public final WigParser.arguments_return arguments() throws RecognitionException {
        WigParser.arguments_return retval = new WigParser.arguments_return();
        retval.start = input.LT(1);

        WigParser.argument_return a0 = null;

        WigParser.argument_return an = null;


         
            List<Type> ts = new LinkedList<Type>();
            List<Id> is = new LinkedList<Id>();

        try {
            // Wig.g:132:5: (a0= argument ( ',' an= argument )* )
            // Wig.g:133:9: a0= argument ( ',' an= argument )*
            {
            pushFollow(FOLLOW_argument_in_arguments819);
            a0=argument();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) {
               ts.add((a0!=null?a0.t:null)); is.add((a0!=null?a0.id:null)); 
            }
            // Wig.g:134:9: ( ',' an= argument )*
            loop19:
            do {
                int alt19=2;
                int LA19_0 = input.LA(1);

                if ( (LA19_0==27) ) {
                    alt19=1;
                }


                switch (alt19) {
            	case 1 :
            	    // Wig.g:134:10: ',' an= argument
            	    {
            	    match(input,27,FOLLOW_27_in_arguments833); if (state.failed) return retval;
            	    pushFollow(FOLLOW_argument_in_arguments839);
            	    an=argument();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	       ts.add((an!=null?an.t:null)); is.add((an!=null?an.id:null)); 
            	    }

            	    }
            	    break;

            	default :
            	    break loop19;
                }
            } while (true);

            if ( state.backtracking==0 ) {
               retval.types = ts; retval.ids = is; 
            }

            }

            retval.stop = input.LT(-1);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "arguments"

    public static class argument_return extends ParserRuleReturnScope {
        public Type t;
        public Id id;
    };

    // $ANTLR start "argument"
    // Wig.g:137:1: argument returns [Type t, Id id] : type ID ;
    public final WigParser.argument_return argument() throws RecognitionException {
        WigParser.argument_return retval = new WigParser.argument_return();
        retval.start = input.LT(1);

        Token ID22=null;
        Type type21 = null;


        try {
            // Wig.g:137:34: ( type ID )
            // Wig.g:137:36: type ID
            {
            pushFollow(FOLLOW_type_in_argument869);
            type21=type();

            state._fsp--;
            if (state.failed) return retval;
            ID22=(Token)match(input,ID,FOLLOW_ID_in_argument871); if (state.failed) return retval;
            if ( state.backtracking==0 ) {
               retval.t = type21; retval.id = new Id((ID22!=null?ID22.getText():null)); 
            }

            }

            retval.stop = input.LT(-1);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "argument"


    // $ANTLR start "session"
    // Wig.g:141:1: session returns [Session s] : 'session' ID '(' ')' c= compoundstm ;
    public final Session session() throws RecognitionException {
        Session s = null;

        Token ID23=null;
        Stm c = null;


        try {
            // Wig.g:141:29: ( 'session' ID '(' ')' c= compoundstm )
            // Wig.g:142:9: 'session' ID '(' ')' c= compoundstm
            {
            match(input,35,FOLLOW_35_in_session904); if (state.failed) return s;
            ID23=(Token)match(input,ID,FOLLOW_ID_in_session906); if (state.failed) return s;
            match(input,33,FOLLOW_33_in_session908); if (state.failed) return s;
            match(input,34,FOLLOW_34_in_session910); if (state.failed) return s;
            pushFollow(FOLLOW_compoundstm_in_session914);
            c=compoundstm();

            state._fsp--;
            if (state.failed) return s;
            if ( state.backtracking==0 ) {
               s = new Session(new Id((ID23!=null?ID23.getText():null)), c); 
            }

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return s;
    }
    // $ANTLR end "session"


    // $ANTLR start "stm"
    // Wig.g:146:1: stm returns [Stm s] : ( ';' | 'show' d= document r= receive ';' | 'exit' d= document ';' | 'return' ';' | 'return' e= exp ';' | 'if' '(' e= exp ')' t= stm ( ( 'else' )=> 'else' els= stm )? | 'while' '(' e= exp ')' b= stm | c= compoundstm | exp ';' );
    public final Stm stm() throws RecognitionException {
        Stm s = null;

        Document d = null;

        List<Input> r = null;

        Exp e = null;

        Stm t = null;

        Stm els = null;

        Stm b = null;

        Stm c = null;

        Exp exp24 = null;


        try {
            // Wig.g:146:21: ( ';' | 'show' d= document r= receive ';' | 'exit' d= document ';' | 'return' ';' | 'return' e= exp ';' | 'if' '(' e= exp ')' t= stm ( ( 'else' )=> 'else' els= stm )? | 'while' '(' e= exp ')' b= stm | c= compoundstm | exp ';' )
            int alt21=9;
            alt21 = dfa21.predict(input);
            switch (alt21) {
                case 1 :
                    // Wig.g:146:23: ';'
                    {
                    match(input,21,FOLLOW_21_in_stm938); if (state.failed) return s;
                    if ( state.backtracking==0 ) {
                       s = new EmptyStm(); 
                    }

                    }
                    break;
                case 2 :
                    // Wig.g:147:7: 'show' d= document r= receive ';'
                    {
                    match(input,36,FOLLOW_36_in_stm948); if (state.failed) return s;
                    pushFollow(FOLLOW_document_in_stm952);
                    d=document();

                    state._fsp--;
                    if (state.failed) return s;
                    pushFollow(FOLLOW_receive_in_stm956);
                    r=receive();

                    state._fsp--;
                    if (state.failed) return s;
                    match(input,21,FOLLOW_21_in_stm958); if (state.failed) return s;
                    if ( state.backtracking==0 ) {
                      s = new ShowStm(d, r); 
                    }

                    }
                    break;
                case 3 :
                    // Wig.g:148:7: 'exit' d= document ';'
                    {
                    match(input,37,FOLLOW_37_in_stm968); if (state.failed) return s;
                    pushFollow(FOLLOW_document_in_stm972);
                    d=document();

                    state._fsp--;
                    if (state.failed) return s;
                    match(input,21,FOLLOW_21_in_stm974); if (state.failed) return s;
                    if ( state.backtracking==0 ) {
                       s = new ExitStm(d); 
                    }

                    }
                    break;
                case 4 :
                    // Wig.g:149:7: 'return' ';'
                    {
                    match(input,38,FOLLOW_38_in_stm984); if (state.failed) return s;
                    match(input,21,FOLLOW_21_in_stm986); if (state.failed) return s;
                    if ( state.backtracking==0 ) {
                       s = new ReturnVoidStm(); 
                    }

                    }
                    break;
                case 5 :
                    // Wig.g:150:7: 'return' e= exp ';'
                    {
                    match(input,38,FOLLOW_38_in_stm996); if (state.failed) return s;
                    pushFollow(FOLLOW_exp_in_stm1000);
                    e=exp();

                    state._fsp--;
                    if (state.failed) return s;
                    match(input,21,FOLLOW_21_in_stm1002); if (state.failed) return s;
                    if ( state.backtracking==0 ) {
                       s = new ReturnStm(e); 
                    }

                    }
                    break;
                case 6 :
                    // Wig.g:151:7: 'if' '(' e= exp ')' t= stm ( ( 'else' )=> 'else' els= stm )?
                    {
                    match(input,39,FOLLOW_39_in_stm1012); if (state.failed) return s;
                    match(input,33,FOLLOW_33_in_stm1014); if (state.failed) return s;
                    pushFollow(FOLLOW_exp_in_stm1018);
                    e=exp();

                    state._fsp--;
                    if (state.failed) return s;
                    match(input,34,FOLLOW_34_in_stm1020); if (state.failed) return s;
                    pushFollow(FOLLOW_stm_in_stm1024);
                    t=stm();

                    state._fsp--;
                    if (state.failed) return s;
                    // Wig.g:151:32: ( ( 'else' )=> 'else' els= stm )?
                    int alt20=2;
                    int LA20_0 = input.LA(1);

                    if ( (LA20_0==40) ) {
                        int LA20_1 = input.LA(2);

                        if ( (synpred1_Wig()) ) {
                            alt20=1;
                        }
                    }
                    switch (alt20) {
                        case 1 :
                            // Wig.g:151:33: ( 'else' )=> 'else' els= stm
                            {
                            match(input,40,FOLLOW_40_in_stm1033); if (state.failed) return s;
                            pushFollow(FOLLOW_stm_in_stm1037);
                            els=stm();

                            state._fsp--;
                            if (state.failed) return s;

                            }
                            break;

                    }

                    if ( state.backtracking==0 ) {
                       s = new IfStm(e, t, els); 
                    }

                    }
                    break;
                case 7 :
                    // Wig.g:153:7: 'while' '(' e= exp ')' b= stm
                    {
                    match(input,41,FOLLOW_41_in_stm1058); if (state.failed) return s;
                    match(input,33,FOLLOW_33_in_stm1060); if (state.failed) return s;
                    pushFollow(FOLLOW_exp_in_stm1064);
                    e=exp();

                    state._fsp--;
                    if (state.failed) return s;
                    match(input,34,FOLLOW_34_in_stm1066); if (state.failed) return s;
                    pushFollow(FOLLOW_stm_in_stm1070);
                    b=stm();

                    state._fsp--;
                    if (state.failed) return s;
                    if ( state.backtracking==0 ) {
                       s = new WhileStm(e, b); 
                    }

                    }
                    break;
                case 8 :
                    // Wig.g:154:7: c= compoundstm
                    {
                    pushFollow(FOLLOW_compoundstm_in_stm1082);
                    c=compoundstm();

                    state._fsp--;
                    if (state.failed) return s;
                    if ( state.backtracking==0 ) {
                       s = c; 
                    }

                    }
                    break;
                case 9 :
                    // Wig.g:155:7: exp ';'
                    {
                    pushFollow(FOLLOW_exp_in_stm1092);
                    exp24=exp();

                    state._fsp--;
                    if (state.failed) return s;
                    match(input,21,FOLLOW_21_in_stm1094); if (state.failed) return s;
                    if ( state.backtracking==0 ) {
                       s = new EvalStm(exp24); 
                    }

                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return s;
    }
    // $ANTLR end "stm"


    // $ANTLR start "document"
    // Wig.g:157:1: document returns [Document d] : ( ID | 'plug' ID '[' plugs ']' );
    public final Document document() throws RecognitionException {
        Document d = null;

        Token ID25=null;
        Token ID26=null;
        WigParser.plugs_return plugs27 = null;


        try {
            // Wig.g:157:31: ( ID | 'plug' ID '[' plugs ']' )
            int alt22=2;
            int LA22_0 = input.LA(1);

            if ( (LA22_0==ID) ) {
                alt22=1;
            }
            else if ( (LA22_0==42) ) {
                alt22=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return d;}
                NoViableAltException nvae =
                    new NoViableAltException("", 22, 0, input);

                throw nvae;
            }
            switch (alt22) {
                case 1 :
                    // Wig.g:158:9: ID
                    {
                    ID25=(Token)match(input,ID,FOLLOW_ID_in_document1117); if (state.failed) return d;
                    if ( state.backtracking==0 ) {
                       d = new BaseDocument(new Id((ID25!=null?ID25.getText():null))); 
                    }

                    }
                    break;
                case 2 :
                    // Wig.g:159:7: 'plug' ID '[' plugs ']'
                    {
                    match(input,42,FOLLOW_42_in_document1127); if (state.failed) return d;
                    ID26=(Token)match(input,ID,FOLLOW_ID_in_document1129); if (state.failed) return d;
                    match(input,22,FOLLOW_22_in_document1131); if (state.failed) return d;
                    pushFollow(FOLLOW_plugs_in_document1133);
                    plugs27=plugs();

                    state._fsp--;
                    if (state.failed) return d;
                    match(input,23,FOLLOW_23_in_document1135); if (state.failed) return d;
                    if ( state.backtracking==0 ) {
                       d = new PlugDocument(new Id((ID26!=null?ID26.getText():null)), (plugs27!=null?plugs27.ids:null), (plugs27!=null?plugs27.c:null)); 
                    }

                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return d;
    }
    // $ANTLR end "document"


    // $ANTLR start "receive"
    // Wig.g:162:1: receive returns [List<Input> r] : ( | 'receive' '[' ( inputs )? ']' );
    public final List<Input> receive() throws RecognitionException {
        List<Input> r = null;

        List<Input> inputs28 = null;


        try {
            // Wig.g:162:33: ( | 'receive' '[' ( inputs )? ']' )
            int alt24=2;
            int LA24_0 = input.LA(1);

            if ( (LA24_0==21) ) {
                alt24=1;
            }
            else if ( (LA24_0==43) ) {
                alt24=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return r;}
                NoViableAltException nvae =
                    new NoViableAltException("", 24, 0, input);

                throw nvae;
            }
            switch (alt24) {
                case 1 :
                    // Wig.g:163:9: 
                    {
                    }
                    break;
                case 2 :
                    // Wig.g:163:11: 'receive' '[' ( inputs )? ']'
                    {
                    match(input,43,FOLLOW_43_in_receive1170); if (state.failed) return r;
                    match(input,22,FOLLOW_22_in_receive1172); if (state.failed) return r;
                    // Wig.g:163:25: ( inputs )?
                    int alt23=2;
                    int LA23_0 = input.LA(1);

                    if ( (LA23_0==ID) ) {
                        alt23=1;
                    }
                    switch (alt23) {
                        case 1 :
                            // Wig.g:163:25: inputs
                            {
                            pushFollow(FOLLOW_inputs_in_receive1174);
                            inputs28=inputs();

                            state._fsp--;
                            if (state.failed) return r;

                            }
                            break;

                    }

                    match(input,23,FOLLOW_23_in_receive1177); if (state.failed) return r;
                    if ( state.backtracking==0 ) {
                       r = inputs28; 
                    }

                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return r;
    }
    // $ANTLR end "receive"


    // $ANTLR start "compoundstm"
    // Wig.g:165:1: compoundstm returns [Stm s] : '{' (v= variable )* (b= stm )* '}' ;
    public final Stm compoundstm() throws RecognitionException {
        Stm s = null;

        Variable v = null;

        Stm b = null;


         
              List<Variable> vl = new LinkedList<Variable>();
              List<Stm> sl = new LinkedList<Stm>();
            
        try {
            // Wig.g:170:5: ( '{' (v= variable )* (b= stm )* '}' )
            // Wig.g:170:7: '{' (v= variable )* (b= stm )* '}'
            {
            match(input,16,FOLLOW_16_in_compoundstm1205); if (state.failed) return s;
            // Wig.g:170:11: (v= variable )*
            loop25:
            do {
                int alt25=2;
                int LA25_0 = input.LA(1);

                if ( (LA25_0==32) ) {
                    int LA25_2 = input.LA(2);

                    if ( (LA25_2==ID) ) {
                        alt25=1;
                    }


                }
                else if ( ((LA25_0>=28 && LA25_0<=31)) ) {
                    alt25=1;
                }


                switch (alt25) {
            	case 1 :
            	    // Wig.g:170:12: v= variable
            	    {
            	    pushFollow(FOLLOW_variable_in_compoundstm1210);
            	    v=variable();

            	    state._fsp--;
            	    if (state.failed) return s;
            	    if ( state.backtracking==0 ) {
            	       vl.add(v); 
            	    }

            	    }
            	    break;

            	default :
            	    break loop25;
                }
            } while (true);

            // Wig.g:171:11: (b= stm )*
            loop26:
            do {
                int alt26=2;
                int LA26_0 = input.LA(1);

                if ( (LA26_0==ID||(LA26_0>=STRING_LITERAL && LA26_0<=INT_LITERAL)||LA26_0==16||LA26_0==21||(LA26_0>=32 && LA26_0<=33)||(LA26_0>=36 && LA26_0<=39)||LA26_0==41||LA26_0==53||(LA26_0>=60 && LA26_0<=62)) ) {
                    alt26=1;
                }


                switch (alt26) {
            	case 1 :
            	    // Wig.g:171:12: b= stm
            	    {
            	    pushFollow(FOLLOW_stm_in_compoundstm1230);
            	    b=stm();

            	    state._fsp--;
            	    if (state.failed) return s;
            	    if ( state.backtracking==0 ) {
            	      sl.add(b); 
            	    }

            	    }
            	    break;

            	default :
            	    break loop26;
                }
            } while (true);

            match(input,17,FOLLOW_17_in_compoundstm1236); if (state.failed) return s;
            if ( state.backtracking==0 ) {
               s = new CompoundStm(vl, sl); 
            }

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return s;
    }
    // $ANTLR end "compoundstm"

    public static class plugs_return extends ParserRuleReturnScope {
        public List<Id> ids;
        public List<Exp> c;
    };

    // $ANTLR start "plugs"
    // Wig.g:174:1: plugs returns [List<Id> ids, List<Exp> c] : p0= plug ( ',' pn= plug )* ;
    public final WigParser.plugs_return plugs() throws RecognitionException {
        WigParser.plugs_return retval = new WigParser.plugs_return();
        retval.start = input.LT(1);

        WigParser.plug_return p0 = null;

        WigParser.plug_return pn = null;


         
            List<Id> il = new LinkedList<Id>();
            List<Exp> cl = new LinkedList<Exp>();

        try {
            // Wig.g:179:5: (p0= plug ( ',' pn= plug )* )
            // Wig.g:179:7: p0= plug ( ',' pn= plug )*
            {
            pushFollow(FOLLOW_plug_in_plugs1271);
            p0=plug();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) {
               il.add((p0!=null?p0.id:null)); cl.add((p0!=null?p0.e:null)); 
            }
            // Wig.g:180:9: ( ',' pn= plug )*
            loop27:
            do {
                int alt27=2;
                int LA27_0 = input.LA(1);

                if ( (LA27_0==27) ) {
                    alt27=1;
                }


                switch (alt27) {
            	case 1 :
            	    // Wig.g:180:10: ',' pn= plug
            	    {
            	    match(input,27,FOLLOW_27_in_plugs1285); if (state.failed) return retval;
            	    pushFollow(FOLLOW_plug_in_plugs1289);
            	    pn=plug();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	       il.add((pn!=null?pn.id:null)); cl.add((pn!=null?pn.e:null)); 
            	    }

            	    }
            	    break;

            	default :
            	    break loop27;
                }
            } while (true);

            if ( state.backtracking==0 ) {
               retval.ids = il; retval.c = cl; 
            }

            }

            retval.stop = input.LT(-1);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "plugs"

    public static class plug_return extends ParserRuleReturnScope {
        public Id id;
        public Exp e;
    };

    // $ANTLR start "plug"
    // Wig.g:183:1: plug returns [Id id, Exp e] : ID '=' exp ;
    public final WigParser.plug_return plug() throws RecognitionException {
        WigParser.plug_return retval = new WigParser.plug_return();
        retval.start = input.LT(1);

        Token ID29=null;
        Exp exp30 = null;


        try {
            // Wig.g:183:29: ( ID '=' exp )
            // Wig.g:183:31: ID '=' exp
            {
            ID29=(Token)match(input,ID,FOLLOW_ID_in_plug1315); if (state.failed) return retval;
            match(input,20,FOLLOW_20_in_plug1317); if (state.failed) return retval;
            pushFollow(FOLLOW_exp_in_plug1319);
            exp30=exp();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) {
               retval.id = new Id((ID29!=null?ID29.getText():null)); retval.e = exp30; 
            }

            }

            retval.stop = input.LT(-1);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "plug"


    // $ANTLR start "inputs"
    // Wig.g:186:1: inputs returns [List<Input> li] : i0= input ( ',' in= input )* ;
    public final List<Input> inputs() throws RecognitionException {
        List<Input> li = null;

        Input i0 = null;

        Input in = null;


         li = new LinkedList<Input>(); 
        try {
            // Wig.g:188:5: (i0= input ( ',' in= input )* )
            // Wig.g:188:7: i0= input ( ',' in= input )*
            {
            pushFollow(FOLLOW_input_in_inputs1355);
            i0=input();

            state._fsp--;
            if (state.failed) return li;
            if ( state.backtracking==0 ) {
               li.add(i0); 
            }
            // Wig.g:188:37: ( ',' in= input )*
            loop28:
            do {
                int alt28=2;
                int LA28_0 = input.LA(1);

                if ( (LA28_0==27) ) {
                    alt28=1;
                }


                switch (alt28) {
            	case 1 :
            	    // Wig.g:188:38: ',' in= input
            	    {
            	    match(input,27,FOLLOW_27_in_inputs1361); if (state.failed) return li;
            	    pushFollow(FOLLOW_input_in_inputs1365);
            	    in=input();

            	    state._fsp--;
            	    if (state.failed) return li;
            	    if ( state.backtracking==0 ) {
            	       li.add(in); 
            	    }

            	    }
            	    break;

            	default :
            	    break loop28;
                }
            } while (true);


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return li;
    }
    // $ANTLR end "inputs"


    // $ANTLR start "input"
    // Wig.g:190:1: input returns [Input i] : lvalue '=' ID ;
    public final Input input() throws RecognitionException {
        Input i = null;

        Token ID32=null;
        Lvalue lvalue31 = null;


        try {
            // Wig.g:190:25: ( lvalue '=' ID )
            // Wig.g:190:27: lvalue '=' ID
            {
            pushFollow(FOLLOW_lvalue_in_input1382);
            lvalue31=lvalue();

            state._fsp--;
            if (state.failed) return i;
            match(input,20,FOLLOW_20_in_input1384); if (state.failed) return i;
            ID32=(Token)match(input,ID,FOLLOW_ID_in_input1386); if (state.failed) return i;
            if ( state.backtracking==0 ) {
               i = new Input(lvalue31, new Id((ID32!=null?ID32.getText():null))); 
            }

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return i;
    }
    // $ANTLR end "input"


    // $ANTLR start "exp"
    // Wig.g:192:1: exp returns [Exp e] : ( or_exp | lvalue '=' r= exp );
    public final Exp exp() throws RecognitionException {
        Exp e = null;

        Exp r = null;

        Exp or_exp33 = null;

        Lvalue lvalue34 = null;


        try {
            // Wig.g:193:5: ( or_exp | lvalue '=' r= exp )
            int alt29=2;
            int LA29_0 = input.LA(1);

            if ( ((LA29_0>=STRING_LITERAL && LA29_0<=INT_LITERAL)||(LA29_0>=32 && LA29_0<=33)||LA29_0==53||(LA29_0>=60 && LA29_0<=62)) ) {
                alt29=1;
            }
            else if ( (LA29_0==ID) ) {
                switch ( input.LA(2) ) {
                case 17:
                case 21:
                case 23:
                case 27:
                case 33:
                case 34:
                case 44:
                case 45:
                case 46:
                case 47:
                case 48:
                case 49:
                case 50:
                case 51:
                case 52:
                case 53:
                case 54:
                case 55:
                case 56:
                case 57:
                case 58:
                case 59:
                    {
                    alt29=1;
                    }
                    break;
                case 63:
                    {
                    int LA29_3 = input.LA(3);

                    if ( (LA29_3==ID) ) {
                        int LA29_5 = input.LA(4);

                        if ( (LA29_5==20) ) {
                            alt29=2;
                        }
                        else if ( (LA29_5==17||LA29_5==21||LA29_5==23||LA29_5==27||LA29_5==34||(LA29_5>=44 && LA29_5<=59)) ) {
                            alt29=1;
                        }
                        else {
                            if (state.backtracking>0) {state.failed=true; return e;}
                            NoViableAltException nvae =
                                new NoViableAltException("", 29, 5, input);

                            throw nvae;
                        }
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return e;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 29, 3, input);

                        throw nvae;
                    }
                    }
                    break;
                case 20:
                    {
                    alt29=2;
                    }
                    break;
                default:
                    if (state.backtracking>0) {state.failed=true; return e;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 29, 2, input);

                    throw nvae;
                }

            }
            else {
                if (state.backtracking>0) {state.failed=true; return e;}
                NoViableAltException nvae =
                    new NoViableAltException("", 29, 0, input);

                throw nvae;
            }
            switch (alt29) {
                case 1 :
                    // Wig.g:193:7: or_exp
                    {
                    pushFollow(FOLLOW_or_exp_in_exp1404);
                    or_exp33=or_exp();

                    state._fsp--;
                    if (state.failed) return e;
                    if ( state.backtracking==0 ) {
                       e = or_exp33; 
                    }

                    }
                    break;
                case 2 :
                    // Wig.g:194:7: lvalue '=' r= exp
                    {
                    pushFollow(FOLLOW_lvalue_in_exp1414);
                    lvalue34=lvalue();

                    state._fsp--;
                    if (state.failed) return e;
                    match(input,20,FOLLOW_20_in_exp1416); if (state.failed) return e;
                    pushFollow(FOLLOW_exp_in_exp1420);
                    r=exp();

                    state._fsp--;
                    if (state.failed) return e;
                    if ( state.backtracking==0 ) {
                      e = new AssignExp(lvalue34, r); 
                    }

                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return e;
    }
    // $ANTLR end "exp"


    // $ANTLR start "or_exp"
    // Wig.g:196:1: or_exp returns [Exp e] : a0= and_exp ( '||' an= and_exp )* ;
    public final Exp or_exp() throws RecognitionException {
        Exp e = null;

        Exp a0 = null;

        Exp an = null;


        try {
            // Wig.g:196:24: (a0= and_exp ( '||' an= and_exp )* )
            // Wig.g:196:26: a0= and_exp ( '||' an= and_exp )*
            {
            pushFollow(FOLLOW_and_exp_in_or_exp1436);
            a0=and_exp();

            state._fsp--;
            if (state.failed) return e;
            if ( state.backtracking==0 ) {
               e = a0; 
            }
            // Wig.g:197:9: ( '||' an= and_exp )*
            loop30:
            do {
                int alt30=2;
                int LA30_0 = input.LA(1);

                if ( (LA30_0==44) ) {
                    alt30=1;
                }


                switch (alt30) {
            	case 1 :
            	    // Wig.g:197:10: '||' an= and_exp
            	    {
            	    match(input,44,FOLLOW_44_in_or_exp1450); if (state.failed) return e;
            	    pushFollow(FOLLOW_and_exp_in_or_exp1454);
            	    an=and_exp();

            	    state._fsp--;
            	    if (state.failed) return e;
            	    if ( state.backtracking==0 ) {
            	      e = new BinopExp(BinopExp.Binop.OR, e, an); 
            	    }

            	    }
            	    break;

            	default :
            	    break loop30;
                }
            } while (true);


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return e;
    }
    // $ANTLR end "or_exp"


    // $ANTLR start "and_exp"
    // Wig.g:199:1: and_exp returns [Exp e] : c0= comp_exp ( '&&' cn= comp_exp )* ;
    public final Exp and_exp() throws RecognitionException {
        Exp e = null;

        Exp c0 = null;

        Exp cn = null;


        try {
            // Wig.g:199:25: (c0= comp_exp ( '&&' cn= comp_exp )* )
            // Wig.g:199:27: c0= comp_exp ( '&&' cn= comp_exp )*
            {
            pushFollow(FOLLOW_comp_exp_in_and_exp1473);
            c0=comp_exp();

            state._fsp--;
            if (state.failed) return e;
            if ( state.backtracking==0 ) {
               e = c0; 
            }
            // Wig.g:200:9: ( '&&' cn= comp_exp )*
            loop31:
            do {
                int alt31=2;
                int LA31_0 = input.LA(1);

                if ( (LA31_0==45) ) {
                    alt31=1;
                }


                switch (alt31) {
            	case 1 :
            	    // Wig.g:200:10: '&&' cn= comp_exp
            	    {
            	    match(input,45,FOLLOW_45_in_and_exp1487); if (state.failed) return e;
            	    pushFollow(FOLLOW_comp_exp_in_and_exp1491);
            	    cn=comp_exp();

            	    state._fsp--;
            	    if (state.failed) return e;
            	    if ( state.backtracking==0 ) {
            	      e = new BinopExp(BinopExp.Binop.AND, e, cn); 
            	    }

            	    }
            	    break;

            	default :
            	    break loop31;
                }
            } while (true);


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return e;
    }
    // $ANTLR end "and_exp"


    // $ANTLR start "comp_exp"
    // Wig.g:202:1: comp_exp returns [Exp e] : e0= plus_exp ( ( '==' | '!=' | '<' | '>' | '<=' | '>=' ) en= plus_exp )* ;
    public final Exp comp_exp() throws RecognitionException {
        Exp e = null;

        Exp e0 = null;

        Exp en = null;


        BinopExp.Binop b = null; 
        try {
            // Wig.g:204:5: (e0= plus_exp ( ( '==' | '!=' | '<' | '>' | '<=' | '>=' ) en= plus_exp )* )
            // Wig.g:205:9: e0= plus_exp ( ( '==' | '!=' | '<' | '>' | '<=' | '>=' ) en= plus_exp )*
            {
            pushFollow(FOLLOW_plus_exp_in_comp_exp1528);
            e0=plus_exp();

            state._fsp--;
            if (state.failed) return e;
            if ( state.backtracking==0 ) {
              e = e0; 
            }
            // Wig.g:206:9: ( ( '==' | '!=' | '<' | '>' | '<=' | '>=' ) en= plus_exp )*
            loop33:
            do {
                int alt33=2;
                int LA33_0 = input.LA(1);

                if ( ((LA33_0>=46 && LA33_0<=51)) ) {
                    alt33=1;
                }


                switch (alt33) {
            	case 1 :
            	    // Wig.g:206:10: ( '==' | '!=' | '<' | '>' | '<=' | '>=' ) en= plus_exp
            	    {
            	    // Wig.g:206:10: ( '==' | '!=' | '<' | '>' | '<=' | '>=' )
            	    int alt32=6;
            	    switch ( input.LA(1) ) {
            	    case 46:
            	        {
            	        alt32=1;
            	        }
            	        break;
            	    case 47:
            	        {
            	        alt32=2;
            	        }
            	        break;
            	    case 48:
            	        {
            	        alt32=3;
            	        }
            	        break;
            	    case 49:
            	        {
            	        alt32=4;
            	        }
            	        break;
            	    case 50:
            	        {
            	        alt32=5;
            	        }
            	        break;
            	    case 51:
            	        {
            	        alt32=6;
            	        }
            	        break;
            	    default:
            	        if (state.backtracking>0) {state.failed=true; return e;}
            	        NoViableAltException nvae =
            	            new NoViableAltException("", 32, 0, input);

            	        throw nvae;
            	    }

            	    switch (alt32) {
            	        case 1 :
            	            // Wig.g:206:11: '=='
            	            {
            	            match(input,46,FOLLOW_46_in_comp_exp1543); if (state.failed) return e;
            	            if ( state.backtracking==0 ) {
            	               b = BinopExp.Binop.EQ; 
            	            }

            	            }
            	            break;
            	        case 2 :
            	            // Wig.g:207:15: '!='
            	            {
            	            match(input,47,FOLLOW_47_in_comp_exp1562); if (state.failed) return e;
            	            if ( state.backtracking==0 ) {
            	               b = BinopExp.Binop.NEQ; 
            	            }

            	            }
            	            break;
            	        case 3 :
            	            // Wig.g:208:15: '<'
            	            {
            	            match(input,48,FOLLOW_48_in_comp_exp1581); if (state.failed) return e;
            	            if ( state.backtracking==0 ) {
            	               b = BinopExp.Binop.LT; 
            	            }

            	            }
            	            break;
            	        case 4 :
            	            // Wig.g:209:15: '>'
            	            {
            	            match(input,49,FOLLOW_49_in_comp_exp1600); if (state.failed) return e;
            	            if ( state.backtracking==0 ) {
            	               b = BinopExp.Binop.GT; 
            	            }

            	            }
            	            break;
            	        case 5 :
            	            // Wig.g:210:15: '<='
            	            {
            	            match(input,50,FOLLOW_50_in_comp_exp1619); if (state.failed) return e;
            	            if ( state.backtracking==0 ) {
            	               b = BinopExp.Binop.LE; 
            	            }

            	            }
            	            break;
            	        case 6 :
            	            // Wig.g:211:15: '>='
            	            {
            	            match(input,51,FOLLOW_51_in_comp_exp1638); if (state.failed) return e;
            	            if ( state.backtracking==0 ) {
            	               b = BinopExp.Binop.GE; 
            	            }

            	            }
            	            break;

            	    }

            	    pushFollow(FOLLOW_plus_exp_in_comp_exp1659);
            	    en=plus_exp();

            	    state._fsp--;
            	    if (state.failed) return e;
            	    if ( state.backtracking==0 ) {
            	      e = new BinopExp(b, e, en); 
            	    }

            	    }
            	    break;

            	default :
            	    break loop33;
                }
            } while (true);


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return e;
    }
    // $ANTLR end "comp_exp"


    // $ANTLR start "plus_exp"
    // Wig.g:214:1: plus_exp returns [Exp e] : t0= times_exp ( ( '+' | '-' ) tn= times_exp )* ;
    public final Exp plus_exp() throws RecognitionException {
        Exp e = null;

        Exp t0 = null;

        Exp tn = null;


        BinopExp.Binop b = null; 
        try {
            // Wig.g:216:5: (t0= times_exp ( ( '+' | '-' ) tn= times_exp )* )
            // Wig.g:216:7: t0= times_exp ( ( '+' | '-' ) tn= times_exp )*
            {
            pushFollow(FOLLOW_times_exp_in_plus_exp1692);
            t0=times_exp();

            state._fsp--;
            if (state.failed) return e;
            if ( state.backtracking==0 ) {
               e = t0; 
            }
            // Wig.g:216:36: ( ( '+' | '-' ) tn= times_exp )*
            loop35:
            do {
                int alt35=2;
                int LA35_0 = input.LA(1);

                if ( ((LA35_0>=52 && LA35_0<=53)) ) {
                    alt35=1;
                }


                switch (alt35) {
            	case 1 :
            	    // Wig.g:216:37: ( '+' | '-' ) tn= times_exp
            	    {
            	    // Wig.g:216:37: ( '+' | '-' )
            	    int alt34=2;
            	    int LA34_0 = input.LA(1);

            	    if ( (LA34_0==52) ) {
            	        alt34=1;
            	    }
            	    else if ( (LA34_0==53) ) {
            	        alt34=2;
            	    }
            	    else {
            	        if (state.backtracking>0) {state.failed=true; return e;}
            	        NoViableAltException nvae =
            	            new NoViableAltException("", 34, 0, input);

            	        throw nvae;
            	    }
            	    switch (alt34) {
            	        case 1 :
            	            // Wig.g:216:38: '+'
            	            {
            	            match(input,52,FOLLOW_52_in_plus_exp1698); if (state.failed) return e;
            	            if ( state.backtracking==0 ) {
            	               b = BinopExp.Binop.PLUS; 
            	            }

            	            }
            	            break;
            	        case 2 :
            	            // Wig.g:216:73: '-'
            	            {
            	            match(input,53,FOLLOW_53_in_plus_exp1704); if (state.failed) return e;
            	            if ( state.backtracking==0 ) {
            	               b = BinopExp.Binop.MINUS; 
            	            }

            	            }
            	            break;

            	    }

            	    pushFollow(FOLLOW_times_exp_in_plus_exp1711);
            	    tn=times_exp();

            	    state._fsp--;
            	    if (state.failed) return e;
            	    if ( state.backtracking==0 ) {
            	       e = new BinopExp(b, e, tn); 
            	    }

            	    }
            	    break;

            	default :
            	    break loop35;
                }
            } while (true);


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return e;
    }
    // $ANTLR end "plus_exp"


    // $ANTLR start "times_exp"
    // Wig.g:218:1: times_exp returns [Exp e] : l0= lshf_exp ( ( '*' | '/' | '%' ) ln= lshf_exp )* ;
    public final Exp times_exp() throws RecognitionException {
        Exp e = null;

        Exp l0 = null;

        Exp ln = null;


         BinopExp.Binop b = null; 
        try {
            // Wig.g:220:5: (l0= lshf_exp ( ( '*' | '/' | '%' ) ln= lshf_exp )* )
            // Wig.g:220:7: l0= lshf_exp ( ( '*' | '/' | '%' ) ln= lshf_exp )*
            {
            pushFollow(FOLLOW_lshf_exp_in_times_exp1739);
            l0=lshf_exp();

            state._fsp--;
            if (state.failed) return e;
            if ( state.backtracking==0 ) {
               e = l0; 
            }
            // Wig.g:221:9: ( ( '*' | '/' | '%' ) ln= lshf_exp )*
            loop37:
            do {
                int alt37=2;
                int LA37_0 = input.LA(1);

                if ( ((LA37_0>=54 && LA37_0<=56)) ) {
                    alt37=1;
                }


                switch (alt37) {
            	case 1 :
            	    // Wig.g:221:10: ( '*' | '/' | '%' ) ln= lshf_exp
            	    {
            	    // Wig.g:221:10: ( '*' | '/' | '%' )
            	    int alt36=3;
            	    switch ( input.LA(1) ) {
            	    case 54:
            	        {
            	        alt36=1;
            	        }
            	        break;
            	    case 55:
            	        {
            	        alt36=2;
            	        }
            	        break;
            	    case 56:
            	        {
            	        alt36=3;
            	        }
            	        break;
            	    default:
            	        if (state.backtracking>0) {state.failed=true; return e;}
            	        NoViableAltException nvae =
            	            new NoViableAltException("", 36, 0, input);

            	        throw nvae;
            	    }

            	    switch (alt36) {
            	        case 1 :
            	            // Wig.g:221:11: '*'
            	            {
            	            match(input,54,FOLLOW_54_in_times_exp1754); if (state.failed) return e;
            	            if ( state.backtracking==0 ) {
            	               b = BinopExp.Binop.TIMES; 
            	            }

            	            }
            	            break;
            	        case 2 :
            	            // Wig.g:221:47: '/'
            	            {
            	            match(input,55,FOLLOW_55_in_times_exp1760); if (state.failed) return e;
            	            if ( state.backtracking==0 ) {
            	               b = BinopExp.Binop.DIV; 
            	            }

            	            }
            	            break;
            	        case 3 :
            	            // Wig.g:221:80: '%'
            	            {
            	            match(input,56,FOLLOW_56_in_times_exp1765); if (state.failed) return e;
            	            if ( state.backtracking==0 ) {
            	               b = BinopExp.Binop.MOD; 
            	            }

            	            }
            	            break;

            	    }

            	    pushFollow(FOLLOW_lshf_exp_in_times_exp1772);
            	    ln=lshf_exp();

            	    state._fsp--;
            	    if (state.failed) return e;
            	    if ( state.backtracking==0 ) {
            	       e = new BinopExp(b, e, ln); 
            	    }

            	    }
            	    break;

            	default :
            	    break loop37;
                }
            } while (true);


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return e;
    }
    // $ANTLR end "times_exp"


    // $ANTLR start "lshf_exp"
    // Wig.g:223:1: lshf_exp returns [Exp e] : t0= tplus_exp ( '<<' tn= tplus_exp )* ;
    public final Exp lshf_exp() throws RecognitionException {
        Exp e = null;

        Exp t0 = null;

        Exp tn = null;


        try {
            // Wig.g:223:26: (t0= tplus_exp ( '<<' tn= tplus_exp )* )
            // Wig.g:223:28: t0= tplus_exp ( '<<' tn= tplus_exp )*
            {
            pushFollow(FOLLOW_tplus_exp_in_lshf_exp1791);
            t0=tplus_exp();

            state._fsp--;
            if (state.failed) return e;
            if ( state.backtracking==0 ) {
               e = t0; 
            }
            // Wig.g:223:57: ( '<<' tn= tplus_exp )*
            loop38:
            do {
                int alt38=2;
                int LA38_0 = input.LA(1);

                if ( (LA38_0==57) ) {
                    alt38=1;
                }


                switch (alt38) {
            	case 1 :
            	    // Wig.g:223:58: '<<' tn= tplus_exp
            	    {
            	    match(input,57,FOLLOW_57_in_lshf_exp1796); if (state.failed) return e;
            	    pushFollow(FOLLOW_tplus_exp_in_lshf_exp1802);
            	    tn=tplus_exp();

            	    state._fsp--;
            	    if (state.failed) return e;
            	    if ( state.backtracking==0 ) {
            	       e = new BinopExp(BinopExp.Binop.TUPLE_FROM, e, tn); 
            	    }

            	    }
            	    break;

            	default :
            	    break loop38;
                }
            } while (true);


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return e;
    }
    // $ANTLR end "lshf_exp"


    // $ANTLR start "tplus_exp"
    // Wig.g:225:1: tplus_exp returns [Exp e] : u0= unary_exp ( ( '\\\\+' | '\\\\-' ) '(' identifiers ')' )* ;
    public final Exp tplus_exp() throws RecognitionException {
        Exp e = null;

        Exp u0 = null;

        List<Id> identifiers35 = null;


        TupleopExp.Tupleop b = null; 
        try {
            // Wig.g:227:5: (u0= unary_exp ( ( '\\\\+' | '\\\\-' ) '(' identifiers ')' )* )
            // Wig.g:227:7: u0= unary_exp ( ( '\\\\+' | '\\\\-' ) '(' identifiers ')' )*
            {
            pushFollow(FOLLOW_unary_exp_in_tplus_exp1832);
            u0=unary_exp();

            state._fsp--;
            if (state.failed) return e;
            if ( state.backtracking==0 ) {
               e = u0; 
            }
            // Wig.g:227:38: ( ( '\\\\+' | '\\\\-' ) '(' identifiers ')' )*
            loop40:
            do {
                int alt40=2;
                int LA40_0 = input.LA(1);

                if ( ((LA40_0>=58 && LA40_0<=59)) ) {
                    alt40=1;
                }


                switch (alt40) {
            	case 1 :
            	    // Wig.g:227:39: ( '\\\\+' | '\\\\-' ) '(' identifiers ')'
            	    {
            	    // Wig.g:227:39: ( '\\\\+' | '\\\\-' )
            	    int alt39=2;
            	    int LA39_0 = input.LA(1);

            	    if ( (LA39_0==58) ) {
            	        alt39=1;
            	    }
            	    else if ( (LA39_0==59) ) {
            	        alt39=2;
            	    }
            	    else {
            	        if (state.backtracking>0) {state.failed=true; return e;}
            	        NoViableAltException nvae =
            	            new NoViableAltException("", 39, 0, input);

            	        throw nvae;
            	    }
            	    switch (alt39) {
            	        case 1 :
            	            // Wig.g:227:40: '\\\\+'
            	            {
            	            match(input,58,FOLLOW_58_in_tplus_exp1838); if (state.failed) return e;
            	            if ( state.backtracking==0 ) {
            	               b = TupleopExp.Tupleop.TUPLE_PLUS; 
            	            }

            	            }
            	            break;
            	        case 2 :
            	            // Wig.g:227:87: '\\\\-'
            	            {
            	            match(input,59,FOLLOW_59_in_tplus_exp1844); if (state.failed) return e;
            	            if ( state.backtracking==0 ) {
            	               b = TupleopExp.Tupleop.TUPLE_MINUS; 
            	            }

            	            }
            	            break;

            	    }

            	    match(input,33,FOLLOW_33_in_tplus_exp1850); if (state.failed) return e;
            	    pushFollow(FOLLOW_identifiers_in_tplus_exp1852);
            	    identifiers35=identifiers();

            	    state._fsp--;
            	    if (state.failed) return e;
            	    match(input,34,FOLLOW_34_in_tplus_exp1854); if (state.failed) return e;
            	    if ( state.backtracking==0 ) {
            	       e = new TupleopExp(b, e, identifiers35); 
            	    }

            	    }
            	    break;

            	default :
            	    break loop40;
                }
            } while (true);


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return e;
    }
    // $ANTLR end "tplus_exp"


    // $ANTLR start "unary_exp"
    // Wig.g:229:1: unary_exp returns [Exp e] : ( ( '!' | '-' ) u0= unary_exp | b= base_exp );
    public final Exp unary_exp() throws RecognitionException {
        Exp e = null;

        Exp u0 = null;

        Exp b = null;


        UnopExp.Unop u = null; 
        try {
            // Wig.g:230:33: ( ( '!' | '-' ) u0= unary_exp | b= base_exp )
            int alt42=2;
            int LA42_0 = input.LA(1);

            if ( (LA42_0==53||LA42_0==60) ) {
                alt42=1;
            }
            else if ( (LA42_0==ID||(LA42_0>=STRING_LITERAL && LA42_0<=INT_LITERAL)||(LA42_0>=32 && LA42_0<=33)||(LA42_0>=61 && LA42_0<=62)) ) {
                alt42=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return e;}
                NoViableAltException nvae =
                    new NoViableAltException("", 42, 0, input);

                throw nvae;
            }
            switch (alt42) {
                case 1 :
                    // Wig.g:230:35: ( '!' | '-' ) u0= unary_exp
                    {
                    // Wig.g:230:35: ( '!' | '-' )
                    int alt41=2;
                    int LA41_0 = input.LA(1);

                    if ( (LA41_0==60) ) {
                        alt41=1;
                    }
                    else if ( (LA41_0==53) ) {
                        alt41=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return e;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 41, 0, input);

                        throw nvae;
                    }
                    switch (alt41) {
                        case 1 :
                            // Wig.g:230:36: '!'
                            {
                            match(input,60,FOLLOW_60_in_unary_exp1876); if (state.failed) return e;
                            if ( state.backtracking==0 ) {
                               u = UnopExp.Unop.NOT; 
                            }

                            }
                            break;
                        case 2 :
                            // Wig.g:230:68: '-'
                            {
                            match(input,53,FOLLOW_53_in_unary_exp1882); if (state.failed) return e;
                            if ( state.backtracking==0 ) {
                              u = UnopExp.Unop.NEG; 
                            }

                            }
                            break;

                    }

                    pushFollow(FOLLOW_unary_exp_in_unary_exp1890);
                    u0=unary_exp();

                    state._fsp--;
                    if (state.failed) return e;
                    if ( state.backtracking==0 ) {
                      e = new UnopExp(u, u0); 
                    }

                    }
                    break;
                case 2 :
                    // Wig.g:230:145: b= base_exp
                    {
                    pushFollow(FOLLOW_base_exp_in_unary_exp1898);
                    b=base_exp();

                    state._fsp--;
                    if (state.failed) return e;
                    if ( state.backtracking==0 ) {
                      e = b; 
                    }

                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return e;
    }
    // $ANTLR end "unary_exp"


    // $ANTLR start "base_exp"
    // Wig.g:232:1: base_exp returns [Exp e] : ( ID '(' ( exps )? ')' | INT_LITERAL | 'true' | 'false' | 'tuple' '{' ( fieldvalues )? '}' | STRING_LITERAL | '(' e0= exp ')' | lvalue );
    public final Exp base_exp() throws RecognitionException {
        Exp e = null;

        Token ID36=null;
        Token INT_LITERAL38=null;
        Token STRING_LITERAL40=null;
        Exp e0 = null;

        List<Exp> exps37 = null;

        WigParser.fieldvalues_return fieldvalues39 = null;

        Lvalue lvalue41 = null;


        try {
            // Wig.g:232:25: ( ID '(' ( exps )? ')' | INT_LITERAL | 'true' | 'false' | 'tuple' '{' ( fieldvalues )? '}' | STRING_LITERAL | '(' e0= exp ')' | lvalue )
            int alt45=8;
            alt45 = dfa45.predict(input);
            switch (alt45) {
                case 1 :
                    // Wig.g:233:7: ID '(' ( exps )? ')'
                    {
                    ID36=(Token)match(input,ID,FOLLOW_ID_in_base_exp1917); if (state.failed) return e;
                    match(input,33,FOLLOW_33_in_base_exp1919); if (state.failed) return e;
                    // Wig.g:233:14: ( exps )?
                    int alt43=2;
                    int LA43_0 = input.LA(1);

                    if ( (LA43_0==ID||(LA43_0>=STRING_LITERAL && LA43_0<=INT_LITERAL)||(LA43_0>=32 && LA43_0<=33)||LA43_0==53||(LA43_0>=60 && LA43_0<=62)) ) {
                        alt43=1;
                    }
                    switch (alt43) {
                        case 1 :
                            // Wig.g:233:14: exps
                            {
                            pushFollow(FOLLOW_exps_in_base_exp1921);
                            exps37=exps();

                            state._fsp--;
                            if (state.failed) return e;

                            }
                            break;

                    }

                    match(input,34,FOLLOW_34_in_base_exp1924); if (state.failed) return e;
                    if ( state.backtracking==0 ) {
                       e = new CallExp(new Id((ID36!=null?ID36.getText():null)), exps37); 
                    }

                    }
                    break;
                case 2 :
                    // Wig.g:234:7: INT_LITERAL
                    {
                    INT_LITERAL38=(Token)match(input,INT_LITERAL,FOLLOW_INT_LITERAL_in_base_exp1934); if (state.failed) return e;
                    if ( state.backtracking==0 ) {
                      e = new IntLiteralExp(Integer.parseInt((INT_LITERAL38!=null?INT_LITERAL38.getText():null)));
                    }

                    }
                    break;
                case 3 :
                    // Wig.g:235:7: 'true'
                    {
                    match(input,61,FOLLOW_61_in_base_exp1944); if (state.failed) return e;
                    if ( state.backtracking==0 ) {
                      e = new BoolLiteralExp(true);
                    }

                    }
                    break;
                case 4 :
                    // Wig.g:236:7: 'false'
                    {
                    match(input,62,FOLLOW_62_in_base_exp1954); if (state.failed) return e;
                    if ( state.backtracking==0 ) {
                      e = new BoolLiteralExp(false);
                    }

                    }
                    break;
                case 5 :
                    // Wig.g:237:7: 'tuple' '{' ( fieldvalues )? '}'
                    {
                    match(input,32,FOLLOW_32_in_base_exp1964); if (state.failed) return e;
                    match(input,16,FOLLOW_16_in_base_exp1966); if (state.failed) return e;
                    // Wig.g:237:19: ( fieldvalues )?
                    int alt44=2;
                    int LA44_0 = input.LA(1);

                    if ( (LA44_0==ID) ) {
                        alt44=1;
                    }
                    switch (alt44) {
                        case 1 :
                            // Wig.g:237:19: fieldvalues
                            {
                            pushFollow(FOLLOW_fieldvalues_in_base_exp1968);
                            fieldvalues39=fieldvalues();

                            state._fsp--;
                            if (state.failed) return e;

                            }
                            break;

                    }

                    match(input,17,FOLLOW_17_in_base_exp1971); if (state.failed) return e;
                    if ( state.backtracking==0 ) {
                      e = new TupleLiteralExp((fieldvalues39!=null?fieldvalues39.f:null), (fieldvalues39!=null?fieldvalues39.v:null)); 
                    }

                    }
                    break;
                case 6 :
                    // Wig.g:238:7: STRING_LITERAL
                    {
                    STRING_LITERAL40=(Token)match(input,STRING_LITERAL,FOLLOW_STRING_LITERAL_in_base_exp1981); if (state.failed) return e;
                    if ( state.backtracking==0 ) {
                       e = new StringLiteralExp((STRING_LITERAL40!=null?STRING_LITERAL40.getText():null)); 
                    }

                    }
                    break;
                case 7 :
                    // Wig.g:239:7: '(' e0= exp ')'
                    {
                    match(input,33,FOLLOW_33_in_base_exp1991); if (state.failed) return e;
                    pushFollow(FOLLOW_exp_in_base_exp1995);
                    e0=exp();

                    state._fsp--;
                    if (state.failed) return e;
                    match(input,34,FOLLOW_34_in_base_exp1997); if (state.failed) return e;
                    if ( state.backtracking==0 ) {
                       e = e0; 
                    }

                    }
                    break;
                case 8 :
                    // Wig.g:240:7: lvalue
                    {
                    pushFollow(FOLLOW_lvalue_in_base_exp2007);
                    lvalue41=lvalue();

                    state._fsp--;
                    if (state.failed) return e;
                    if ( state.backtracking==0 ) {
                       e = lvalue41; 
                    }

                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return e;
    }
    // $ANTLR end "base_exp"


    // $ANTLR start "exps"
    // Wig.g:243:1: exps returns [List<Exp> es] : e0= exp ( ',' en= exp )* ;
    public final List<Exp> exps() throws RecognitionException {
        List<Exp> es = null;

        Exp e0 = null;

        Exp en = null;


         List<Exp> l = new LinkedList<Exp>(); 
        try {
            // Wig.g:244:48: (e0= exp ( ',' en= exp )* )
            // Wig.g:245:9: e0= exp ( ',' en= exp )*
            {
            pushFollow(FOLLOW_exp_in_exps2038);
            e0=exp();

            state._fsp--;
            if (state.failed) return es;
            if ( state.backtracking==0 ) {
               l.add(e0); 
            }
            // Wig.g:245:34: ( ',' en= exp )*
            loop46:
            do {
                int alt46=2;
                int LA46_0 = input.LA(1);

                if ( (LA46_0==27) ) {
                    alt46=1;
                }


                switch (alt46) {
            	case 1 :
            	    // Wig.g:245:35: ',' en= exp
            	    {
            	    match(input,27,FOLLOW_27_in_exps2043); if (state.failed) return es;
            	    pushFollow(FOLLOW_exp_in_exps2047);
            	    en=exp();

            	    state._fsp--;
            	    if (state.failed) return es;
            	    if ( state.backtracking==0 ) {
            	       l.add(en); 
            	    }

            	    }
            	    break;

            	default :
            	    break loop46;
                }
            } while (true);

            if ( state.backtracking==0 ) {
               es = l; 
            }

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return es;
    }
    // $ANTLR end "exps"


    // $ANTLR start "lvalue"
    // Wig.g:248:1: lvalue returns [Lvalue lv] : ( ID | q= ID '.' i= ID );
    public final Lvalue lvalue() throws RecognitionException {
        Lvalue lv = null;

        Token q=null;
        Token i=null;
        Token ID42=null;

        try {
            // Wig.g:248:28: ( ID | q= ID '.' i= ID )
            int alt47=2;
            int LA47_0 = input.LA(1);

            if ( (LA47_0==ID) ) {
                int LA47_1 = input.LA(2);

                if ( (LA47_1==63) ) {
                    alt47=2;
                }
                else if ( (LA47_1==17||(LA47_1>=20 && LA47_1<=21)||LA47_1==23||LA47_1==27||LA47_1==34||(LA47_1>=44 && LA47_1<=59)) ) {
                    alt47=1;
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return lv;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 47, 1, input);

                    throw nvae;
                }
            }
            else {
                if (state.backtracking>0) {state.failed=true; return lv;}
                NoViableAltException nvae =
                    new NoViableAltException("", 47, 0, input);

                throw nvae;
            }
            switch (alt47) {
                case 1 :
                    // Wig.g:249:7: ID
                    {
                    ID42=(Token)match(input,ID,FOLLOW_ID_in_lvalue2080); if (state.failed) return lv;
                    if ( state.backtracking==0 ) {
                       lv = new Lvalue(null, new Id((ID42!=null?ID42.getText():null))); 
                    }

                    }
                    break;
                case 2 :
                    // Wig.g:250:7: q= ID '.' i= ID
                    {
                    q=(Token)match(input,ID,FOLLOW_ID_in_lvalue2092); if (state.failed) return lv;
                    match(input,63,FOLLOW_63_in_lvalue2094); if (state.failed) return lv;
                    i=(Token)match(input,ID,FOLLOW_ID_in_lvalue2098); if (state.failed) return lv;
                    if ( state.backtracking==0 ) {
                       lv = new Lvalue(new Id((q!=null?q.getText():null)), new Id((i!=null?i.getText():null))); 
                    }

                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return lv;
    }
    // $ANTLR end "lvalue"

    public static class fieldvalues_return extends ParserRuleReturnScope {
        public List<Id> f;
        public List<Exp> v;
    };

    // $ANTLR start "fieldvalues"
    // Wig.g:252:1: fieldvalues returns [List<Id> f, List<Exp> v] : f0= fieldvalue ( ',' fn= fieldvalue )* ;
    public final WigParser.fieldvalues_return fieldvalues() throws RecognitionException {
        WigParser.fieldvalues_return retval = new WigParser.fieldvalues_return();
        retval.start = input.LT(1);

        WigParser.fieldvalue_return f0 = null;

        WigParser.fieldvalue_return fn = null;


         
            List<Id> fl = new LinkedList<Id>(); 
            List<Exp> vl = new LinkedList<Exp>();

        try {
            // Wig.g:257:5: (f0= fieldvalue ( ',' fn= fieldvalue )* )
            // Wig.g:257:7: f0= fieldvalue ( ',' fn= fieldvalue )*
            {
            pushFollow(FOLLOW_fieldvalue_in_fieldvalues2124);
            f0=fieldvalue();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) {
               fl.add((f0!=null?f0.id:null)); vl.add((f0!=null?f0.e:null)); 
            }
            // Wig.g:258:9: ( ',' fn= fieldvalue )*
            loop48:
            do {
                int alt48=2;
                int LA48_0 = input.LA(1);

                if ( (LA48_0==27) ) {
                    alt48=1;
                }


                switch (alt48) {
            	case 1 :
            	    // Wig.g:258:10: ',' fn= fieldvalue
            	    {
            	    match(input,27,FOLLOW_27_in_fieldvalues2138); if (state.failed) return retval;
            	    pushFollow(FOLLOW_fieldvalue_in_fieldvalues2142);
            	    fn=fieldvalue();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	       fl.add((fn!=null?fn.id:null)); vl.add((fn!=null?fn.e:null));
            	    }

            	    }
            	    break;

            	default :
            	    break loop48;
                }
            } while (true);

            if ( state.backtracking==0 ) {
               retval.f = fl; retval.v = vl; 
            }

            }

            retval.stop = input.LT(-1);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "fieldvalues"

    public static class fieldvalue_return extends ParserRuleReturnScope {
        public Id id;
        public Exp e;
    };

    // $ANTLR start "fieldvalue"
    // Wig.g:261:1: fieldvalue returns [Id id, Exp e] : ID '=' exp ;
    public final WigParser.fieldvalue_return fieldvalue() throws RecognitionException {
        WigParser.fieldvalue_return retval = new WigParser.fieldvalue_return();
        retval.start = input.LT(1);

        Token ID43=null;
        Exp exp44 = null;


        try {
            // Wig.g:261:35: ( ID '=' exp )
            // Wig.g:262:9: ID '=' exp
            {
            ID43=(Token)match(input,ID,FOLLOW_ID_in_fieldvalue2183); if (state.failed) return retval;
            match(input,20,FOLLOW_20_in_fieldvalue2185); if (state.failed) return retval;
            pushFollow(FOLLOW_exp_in_fieldvalue2187);
            exp44=exp();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) {
               retval.id = new Id((ID43!=null?ID43.getText():null)); retval.e = exp44; 
            }

            }

            retval.stop = input.LT(-1);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "fieldvalue"

    // $ANTLR start synpred1_Wig
    public final void synpred1_Wig_fragment() throws RecognitionException {   
        // Wig.g:151:33: ( 'else' )
        // Wig.g:151:34: 'else'
        {
        match(input,40,FOLLOW_40_in_synpred1_Wig1028); if (state.failed) return ;

        }
    }
    // $ANTLR end synpred1_Wig

    // Delegated rules

    public final boolean synpred1_Wig() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred1_Wig_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }


    protected DFA3 dfa3 = new DFA3(this);
    protected DFA21 dfa21 = new DFA21(this);
    protected DFA45 dfa45 = new DFA45(this);
    static final String DFA3_eotS =
        "\12\uffff";
    static final String DFA3_eofS =
        "\12\uffff";
    static final String DFA3_minS =
        "\1\21\5\4\1\uffff\1\25\1\4\1\uffff";
    static final String DFA3_maxS =
        "\1\43\5\4\1\uffff\1\41\1\4\1\uffff";
    static final String DFA3_acceptS =
        "\6\uffff\1\2\2\uffff\1\1";
    static final String DFA3_specialS =
        "\12\uffff}>";
    static final String[] DFA3_transitionS = {
            "\1\6\12\uffff\1\1\1\2\1\3\1\4\1\5\2\uffff\1\6",
            "\1\7",
            "\1\7",
            "\1\7",
            "\1\7",
            "\1\10",
            "",
            "\1\11\5\uffff\1\11\5\uffff\1\6",
            "\1\7",
            ""
    };

    static final short[] DFA3_eot = DFA.unpackEncodedString(DFA3_eotS);
    static final short[] DFA3_eof = DFA.unpackEncodedString(DFA3_eofS);
    static final char[] DFA3_min = DFA.unpackEncodedStringToUnsignedChars(DFA3_minS);
    static final char[] DFA3_max = DFA.unpackEncodedStringToUnsignedChars(DFA3_maxS);
    static final short[] DFA3_accept = DFA.unpackEncodedString(DFA3_acceptS);
    static final short[] DFA3_special = DFA.unpackEncodedString(DFA3_specialS);
    static final short[][] DFA3_transition;

    static {
        int numStates = DFA3_transitionS.length;
        DFA3_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA3_transition[i] = DFA.unpackEncodedString(DFA3_transitionS[i]);
        }
    }

    class DFA3 extends DFA {

        public DFA3(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 3;
            this.eot = DFA3_eot;
            this.eof = DFA3_eof;
            this.min = DFA3_min;
            this.max = DFA3_max;
            this.accept = DFA3_accept;
            this.special = DFA3_special;
            this.transition = DFA3_transition;
        }
        public String getDescription() {
            return "()* loopback of 48:9: (v= variable )*";
        }
    }
    static final String DFA21_eotS =
        "\13\uffff";
    static final String DFA21_eofS =
        "\13\uffff";
    static final String DFA21_minS =
        "\1\4\3\uffff\1\4\6\uffff";
    static final String DFA21_maxS =
        "\1\76\3\uffff\1\76\6\uffff";
    static final String DFA21_acceptS =
        "\1\uffff\1\1\1\2\1\3\1\uffff\1\6\1\7\1\10\1\11\1\4\1\5";
    static final String DFA21_specialS =
        "\13\uffff}>";
    static final String[] DFA21_transitionS = {
            "\1\10\7\uffff\2\10\2\uffff\1\7\4\uffff\1\1\12\uffff\2\10\2\uffff"+
            "\1\2\1\3\1\4\1\5\1\uffff\1\6\13\uffff\1\10\6\uffff\3\10",
            "",
            "",
            "",
            "\1\12\7\uffff\2\12\7\uffff\1\11\12\uffff\2\12\23\uffff\1\12"+
            "\6\uffff\3\12",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA21_eot = DFA.unpackEncodedString(DFA21_eotS);
    static final short[] DFA21_eof = DFA.unpackEncodedString(DFA21_eofS);
    static final char[] DFA21_min = DFA.unpackEncodedStringToUnsignedChars(DFA21_minS);
    static final char[] DFA21_max = DFA.unpackEncodedStringToUnsignedChars(DFA21_maxS);
    static final short[] DFA21_accept = DFA.unpackEncodedString(DFA21_acceptS);
    static final short[] DFA21_special = DFA.unpackEncodedString(DFA21_specialS);
    static final short[][] DFA21_transition;

    static {
        int numStates = DFA21_transitionS.length;
        DFA21_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA21_transition[i] = DFA.unpackEncodedString(DFA21_transitionS[i]);
        }
    }

    class DFA21 extends DFA {

        public DFA21(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 21;
            this.eot = DFA21_eot;
            this.eof = DFA21_eof;
            this.min = DFA21_min;
            this.max = DFA21_max;
            this.accept = DFA21_accept;
            this.special = DFA21_special;
            this.transition = DFA21_transition;
        }
        public String getDescription() {
            return "146:1: stm returns [Stm s] : ( ';' | 'show' d= document r= receive ';' | 'exit' d= document ';' | 'return' ';' | 'return' e= exp ';' | 'if' '(' e= exp ')' t= stm ( ( 'else' )=> 'else' els= stm )? | 'while' '(' e= exp ')' b= stm | c= compoundstm | exp ';' );";
        }
    }
    static final String DFA45_eotS =
        "\12\uffff";
    static final String DFA45_eofS =
        "\12\uffff";
    static final String DFA45_minS =
        "\1\4\1\21\10\uffff";
    static final String DFA45_maxS =
        "\1\76\1\77\10\uffff";
    static final String DFA45_acceptS =
        "\2\uffff\1\2\1\3\1\4\1\5\1\6\1\7\1\1\1\10";
    static final String DFA45_specialS =
        "\12\uffff}>";
    static final String[] DFA45_transitionS = {
            "\1\1\7\uffff\1\6\1\2\22\uffff\1\5\1\7\33\uffff\1\3\1\4",
            "\1\11\3\uffff\1\11\1\uffff\1\11\3\uffff\1\11\5\uffff\1\10\1"+
            "\11\11\uffff\20\11\3\uffff\1\11",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA45_eot = DFA.unpackEncodedString(DFA45_eotS);
    static final short[] DFA45_eof = DFA.unpackEncodedString(DFA45_eofS);
    static final char[] DFA45_min = DFA.unpackEncodedStringToUnsignedChars(DFA45_minS);
    static final char[] DFA45_max = DFA.unpackEncodedStringToUnsignedChars(DFA45_maxS);
    static final short[] DFA45_accept = DFA.unpackEncodedString(DFA45_acceptS);
    static final short[] DFA45_special = DFA.unpackEncodedString(DFA45_specialS);
    static final short[][] DFA45_transition;

    static {
        int numStates = DFA45_transitionS.length;
        DFA45_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA45_transition[i] = DFA.unpackEncodedString(DFA45_transitionS[i]);
        }
    }

    class DFA45 extends DFA {

        public DFA45(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 45;
            this.eot = DFA45_eot;
            this.eof = DFA45_eof;
            this.min = DFA45_min;
            this.max = DFA45_max;
            this.accept = DFA45_accept;
            this.special = DFA45_special;
            this.transition = DFA45_transition;
        }
        public String getDescription() {
            return "232:1: base_exp returns [Exp e] : ( ID '(' ( exps )? ')' | INT_LITERAL | 'true' | 'false' | 'tuple' '{' ( fieldvalues )? '}' | STRING_LITERAL | '(' e0= exp ')' | lvalue );";
        }
    }
 

    public static final BitSet FOLLOW_15_in_service54 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_16_in_service56 = new BitSet(new long[]{0x00000009F4060000L});
    public static final BitSet FOLLOW_html_in_service70 = new BitSet(new long[]{0x00000009F4060000L});
    public static final BitSet FOLLOW_schema_in_service88 = new BitSet(new long[]{0x00000009F4020000L});
    public static final BitSet FOLLOW_variable_in_service106 = new BitSet(new long[]{0x00000009F0020000L});
    public static final BitSet FOLLOW_function_in_service124 = new BitSet(new long[]{0x00000009F0020000L});
    public static final BitSet FOLLOW_session_in_service142 = new BitSet(new long[]{0x0000000800020000L});
    public static final BitSet FOLLOW_17_in_service148 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_18_in_html181 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_19_in_html183 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_ID_in_html185 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_20_in_html187 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_BEGIN_HTML_in_html189 = new BitSet(new long[]{0x0000000000000D40L});
    public static final BitSet FOLLOW_htmlbody_in_html204 = new BitSet(new long[]{0x0000000000000D40L});
    public static final BitSet FOLLOW_OPEN_SLASH_in_html219 = new BitSet(new long[]{0x0000000000000080L});
    public static final BitSet FOLLOW_END_HTML_in_html221 = new BitSet(new long[]{0x0000000000200000L});
    public static final BitSet FOLLOW_21_in_html223 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_OPEN_TAG_in_htmlbody259 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_ID_in_htmlbody261 = new BitSet(new long[]{0x0000000000001210L});
    public static final BitSet FOLLOW_attribute_in_htmlbody266 = new BitSet(new long[]{0x0000000000001210L});
    public static final BitSet FOLLOW_CLOSE_TAG_in_htmlbody272 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_OPEN_SLASH_in_htmlbody290 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_ID_in_htmlbody292 = new BitSet(new long[]{0x0000000000000200L});
    public static final BitSet FOLLOW_CLOSE_TAG_in_htmlbody294 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_OPEN_TAG_in_htmlbody304 = new BitSet(new long[]{0x0000000000400000L});
    public static final BitSet FOLLOW_22_in_htmlbody306 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_ID_in_htmlbody308 = new BitSet(new long[]{0x0000000000800000L});
    public static final BitSet FOLLOW_23_in_htmlbody310 = new BitSet(new long[]{0x0000000000000200L});
    public static final BitSet FOLLOW_CLOSE_TAG_in_htmlbody312 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_WHATEVER_in_htmlbody322 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_META_in_htmlbody332 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_OPEN_TAG_in_htmlbody342 = new BitSet(new long[]{0x0000000001000000L});
    public static final BitSet FOLLOW_24_in_htmlbody344 = new BitSet(new long[]{0x0000000000001210L});
    public static final BitSet FOLLOW_attribute_in_htmlbody349 = new BitSet(new long[]{0x0000000000001210L});
    public static final BitSet FOLLOW_CLOSE_TAG_in_htmlbody355 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_OPEN_TAG_in_htmlbody373 = new BitSet(new long[]{0x0000000002000000L});
    public static final BitSet FOLLOW_25_in_htmlbody375 = new BitSet(new long[]{0x0000000000001210L});
    public static final BitSet FOLLOW_attribute_in_htmlbody380 = new BitSet(new long[]{0x0000000000001210L});
    public static final BitSet FOLLOW_CLOSE_TAG_in_htmlbody386 = new BitSet(new long[]{0x0000000000000D40L});
    public static final BitSet FOLLOW_htmlbody_in_htmlbody399 = new BitSet(new long[]{0x0000000000000D40L});
    public static final BitSet FOLLOW_OPEN_SLASH_in_htmlbody405 = new BitSet(new long[]{0x0000000002000000L});
    public static final BitSet FOLLOW_25_in_htmlbody407 = new BitSet(new long[]{0x0000000000000200L});
    public static final BitSet FOLLOW_CLOSE_TAG_in_htmlbody409 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_attr_in_attribute442 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_attr_in_attribute456 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_20_in_attribute458 = new BitSet(new long[]{0x0000000000001010L});
    public static final BitSet FOLLOW_attr_in_attribute462 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ID_in_attr487 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_STRING_LITERAL_in_attr502 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_26_in_schema531 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_ID_in_schema533 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_16_in_schema535 = new BitSet(new long[]{0x00000000F0020000L});
    public static final BitSet FOLLOW_field_in_schema540 = new BitSet(new long[]{0x00000000F0020000L});
    public static final BitSet FOLLOW_17_in_schema546 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_simpletype_in_field568 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_ID_in_field570 = new BitSet(new long[]{0x0000000000200000L});
    public static final BitSet FOLLOW_21_in_field572 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_type_in_variable605 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_identifiers_in_variable607 = new BitSet(new long[]{0x0000000000200000L});
    public static final BitSet FOLLOW_21_in_variable609 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ID_in_identifiers635 = new BitSet(new long[]{0x0000000008000002L});
    public static final BitSet FOLLOW_27_in_identifiers640 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_ID_in_identifiers644 = new BitSet(new long[]{0x0000000008000002L});
    public static final BitSet FOLLOW_28_in_simpletype672 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_29_in_simpletype682 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_30_in_simpletype693 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_31_in_simpletype704 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_simpletype_in_type725 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_32_in_type736 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_ID_in_type738 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_type_in_function762 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_ID_in_function764 = new BitSet(new long[]{0x0000000200000000L});
    public static final BitSet FOLLOW_33_in_function766 = new BitSet(new long[]{0x00000005F0000000L});
    public static final BitSet FOLLOW_arguments_in_function768 = new BitSet(new long[]{0x0000000400000000L});
    public static final BitSet FOLLOW_34_in_function771 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_compoundstm_in_function773 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_argument_in_arguments819 = new BitSet(new long[]{0x0000000008000002L});
    public static final BitSet FOLLOW_27_in_arguments833 = new BitSet(new long[]{0x00000001F0000000L});
    public static final BitSet FOLLOW_argument_in_arguments839 = new BitSet(new long[]{0x0000000008000002L});
    public static final BitSet FOLLOW_type_in_argument869 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_ID_in_argument871 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_35_in_session904 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_ID_in_session906 = new BitSet(new long[]{0x0000000200000000L});
    public static final BitSet FOLLOW_33_in_session908 = new BitSet(new long[]{0x0000000400000000L});
    public static final BitSet FOLLOW_34_in_session910 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_compoundstm_in_session914 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_21_in_stm938 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_36_in_stm948 = new BitSet(new long[]{0x0000040000000010L});
    public static final BitSet FOLLOW_document_in_stm952 = new BitSet(new long[]{0x0000080000200000L});
    public static final BitSet FOLLOW_receive_in_stm956 = new BitSet(new long[]{0x0000000000200000L});
    public static final BitSet FOLLOW_21_in_stm958 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_37_in_stm968 = new BitSet(new long[]{0x0000040000000010L});
    public static final BitSet FOLLOW_document_in_stm972 = new BitSet(new long[]{0x0000000000200000L});
    public static final BitSet FOLLOW_21_in_stm974 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_38_in_stm984 = new BitSet(new long[]{0x0000000000200000L});
    public static final BitSet FOLLOW_21_in_stm986 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_38_in_stm996 = new BitSet(new long[]{0x7020000300003010L});
    public static final BitSet FOLLOW_exp_in_stm1000 = new BitSet(new long[]{0x0000000000200000L});
    public static final BitSet FOLLOW_21_in_stm1002 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_39_in_stm1012 = new BitSet(new long[]{0x0000000200000000L});
    public static final BitSet FOLLOW_33_in_stm1014 = new BitSet(new long[]{0x7020000300003010L});
    public static final BitSet FOLLOW_exp_in_stm1018 = new BitSet(new long[]{0x0000000400000000L});
    public static final BitSet FOLLOW_34_in_stm1020 = new BitSet(new long[]{0x702002F300213010L});
    public static final BitSet FOLLOW_stm_in_stm1024 = new BitSet(new long[]{0x0000010000000002L});
    public static final BitSet FOLLOW_40_in_stm1033 = new BitSet(new long[]{0x702002F300213010L});
    public static final BitSet FOLLOW_stm_in_stm1037 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_41_in_stm1058 = new BitSet(new long[]{0x0000000200000000L});
    public static final BitSet FOLLOW_33_in_stm1060 = new BitSet(new long[]{0x7020000300003010L});
    public static final BitSet FOLLOW_exp_in_stm1064 = new BitSet(new long[]{0x0000000400000000L});
    public static final BitSet FOLLOW_34_in_stm1066 = new BitSet(new long[]{0x702002F300213010L});
    public static final BitSet FOLLOW_stm_in_stm1070 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_compoundstm_in_stm1082 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_exp_in_stm1092 = new BitSet(new long[]{0x0000000000200000L});
    public static final BitSet FOLLOW_21_in_stm1094 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ID_in_document1117 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_42_in_document1127 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_ID_in_document1129 = new BitSet(new long[]{0x0000000000400000L});
    public static final BitSet FOLLOW_22_in_document1131 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_plugs_in_document1133 = new BitSet(new long[]{0x0000000000800000L});
    public static final BitSet FOLLOW_23_in_document1135 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_43_in_receive1170 = new BitSet(new long[]{0x0000000000400000L});
    public static final BitSet FOLLOW_22_in_receive1172 = new BitSet(new long[]{0x7020000300803010L});
    public static final BitSet FOLLOW_inputs_in_receive1174 = new BitSet(new long[]{0x0000000000800000L});
    public static final BitSet FOLLOW_23_in_receive1177 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_16_in_compoundstm1205 = new BitSet(new long[]{0x702002F3F0233010L});
    public static final BitSet FOLLOW_variable_in_compoundstm1210 = new BitSet(new long[]{0x702002F3F0233010L});
    public static final BitSet FOLLOW_stm_in_compoundstm1230 = new BitSet(new long[]{0x702002F300233010L});
    public static final BitSet FOLLOW_17_in_compoundstm1236 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_plug_in_plugs1271 = new BitSet(new long[]{0x0000000008000002L});
    public static final BitSet FOLLOW_27_in_plugs1285 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_plug_in_plugs1289 = new BitSet(new long[]{0x0000000008000002L});
    public static final BitSet FOLLOW_ID_in_plug1315 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_20_in_plug1317 = new BitSet(new long[]{0x7020000300003010L});
    public static final BitSet FOLLOW_exp_in_plug1319 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_input_in_inputs1355 = new BitSet(new long[]{0x0000000008000002L});
    public static final BitSet FOLLOW_27_in_inputs1361 = new BitSet(new long[]{0x7020000300003010L});
    public static final BitSet FOLLOW_input_in_inputs1365 = new BitSet(new long[]{0x0000000008000002L});
    public static final BitSet FOLLOW_lvalue_in_input1382 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_20_in_input1384 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_ID_in_input1386 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_or_exp_in_exp1404 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_lvalue_in_exp1414 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_20_in_exp1416 = new BitSet(new long[]{0x7020000300003010L});
    public static final BitSet FOLLOW_exp_in_exp1420 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_and_exp_in_or_exp1436 = new BitSet(new long[]{0x0000100000000002L});
    public static final BitSet FOLLOW_44_in_or_exp1450 = new BitSet(new long[]{0x7020000300003010L});
    public static final BitSet FOLLOW_and_exp_in_or_exp1454 = new BitSet(new long[]{0x0000100000000002L});
    public static final BitSet FOLLOW_comp_exp_in_and_exp1473 = new BitSet(new long[]{0x0000200000000002L});
    public static final BitSet FOLLOW_45_in_and_exp1487 = new BitSet(new long[]{0x7020000300003010L});
    public static final BitSet FOLLOW_comp_exp_in_and_exp1491 = new BitSet(new long[]{0x0000200000000002L});
    public static final BitSet FOLLOW_plus_exp_in_comp_exp1528 = new BitSet(new long[]{0x000FC00000000002L});
    public static final BitSet FOLLOW_46_in_comp_exp1543 = new BitSet(new long[]{0x7020000300003010L});
    public static final BitSet FOLLOW_47_in_comp_exp1562 = new BitSet(new long[]{0x7020000300003010L});
    public static final BitSet FOLLOW_48_in_comp_exp1581 = new BitSet(new long[]{0x7020000300003010L});
    public static final BitSet FOLLOW_49_in_comp_exp1600 = new BitSet(new long[]{0x7020000300003010L});
    public static final BitSet FOLLOW_50_in_comp_exp1619 = new BitSet(new long[]{0x7020000300003010L});
    public static final BitSet FOLLOW_51_in_comp_exp1638 = new BitSet(new long[]{0x7020000300003010L});
    public static final BitSet FOLLOW_plus_exp_in_comp_exp1659 = new BitSet(new long[]{0x000FC00000000002L});
    public static final BitSet FOLLOW_times_exp_in_plus_exp1692 = new BitSet(new long[]{0x0030000000000002L});
    public static final BitSet FOLLOW_52_in_plus_exp1698 = new BitSet(new long[]{0x7020000300003010L});
    public static final BitSet FOLLOW_53_in_plus_exp1704 = new BitSet(new long[]{0x7020000300003010L});
    public static final BitSet FOLLOW_times_exp_in_plus_exp1711 = new BitSet(new long[]{0x0030000000000002L});
    public static final BitSet FOLLOW_lshf_exp_in_times_exp1739 = new BitSet(new long[]{0x01C0000000000002L});
    public static final BitSet FOLLOW_54_in_times_exp1754 = new BitSet(new long[]{0x7020000300003010L});
    public static final BitSet FOLLOW_55_in_times_exp1760 = new BitSet(new long[]{0x7020000300003010L});
    public static final BitSet FOLLOW_56_in_times_exp1765 = new BitSet(new long[]{0x7020000300003010L});
    public static final BitSet FOLLOW_lshf_exp_in_times_exp1772 = new BitSet(new long[]{0x01C0000000000002L});
    public static final BitSet FOLLOW_tplus_exp_in_lshf_exp1791 = new BitSet(new long[]{0x0200000000000002L});
    public static final BitSet FOLLOW_57_in_lshf_exp1796 = new BitSet(new long[]{0x7020000300003010L});
    public static final BitSet FOLLOW_tplus_exp_in_lshf_exp1802 = new BitSet(new long[]{0x0200000000000002L});
    public static final BitSet FOLLOW_unary_exp_in_tplus_exp1832 = new BitSet(new long[]{0x0C00000000000002L});
    public static final BitSet FOLLOW_58_in_tplus_exp1838 = new BitSet(new long[]{0x0000000200000000L});
    public static final BitSet FOLLOW_59_in_tplus_exp1844 = new BitSet(new long[]{0x0000000200000000L});
    public static final BitSet FOLLOW_33_in_tplus_exp1850 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_identifiers_in_tplus_exp1852 = new BitSet(new long[]{0x0000000400000000L});
    public static final BitSet FOLLOW_34_in_tplus_exp1854 = new BitSet(new long[]{0x0C00000000000002L});
    public static final BitSet FOLLOW_60_in_unary_exp1876 = new BitSet(new long[]{0x7020000300003010L});
    public static final BitSet FOLLOW_53_in_unary_exp1882 = new BitSet(new long[]{0x7020000300003010L});
    public static final BitSet FOLLOW_unary_exp_in_unary_exp1890 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_base_exp_in_unary_exp1898 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ID_in_base_exp1917 = new BitSet(new long[]{0x0000000200000000L});
    public static final BitSet FOLLOW_33_in_base_exp1919 = new BitSet(new long[]{0x7020000700003010L});
    public static final BitSet FOLLOW_exps_in_base_exp1921 = new BitSet(new long[]{0x0000000400000000L});
    public static final BitSet FOLLOW_34_in_base_exp1924 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_INT_LITERAL_in_base_exp1934 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_61_in_base_exp1944 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_62_in_base_exp1954 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_32_in_base_exp1964 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_16_in_base_exp1966 = new BitSet(new long[]{0x0000000000020010L});
    public static final BitSet FOLLOW_fieldvalues_in_base_exp1968 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_17_in_base_exp1971 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_STRING_LITERAL_in_base_exp1981 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_33_in_base_exp1991 = new BitSet(new long[]{0x7020000300003010L});
    public static final BitSet FOLLOW_exp_in_base_exp1995 = new BitSet(new long[]{0x0000000400000000L});
    public static final BitSet FOLLOW_34_in_base_exp1997 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_lvalue_in_base_exp2007 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_exp_in_exps2038 = new BitSet(new long[]{0x0000000008000002L});
    public static final BitSet FOLLOW_27_in_exps2043 = new BitSet(new long[]{0x7020000300003010L});
    public static final BitSet FOLLOW_exp_in_exps2047 = new BitSet(new long[]{0x0000000008000002L});
    public static final BitSet FOLLOW_ID_in_lvalue2080 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ID_in_lvalue2092 = new BitSet(new long[]{0x8000000000000000L});
    public static final BitSet FOLLOW_63_in_lvalue2094 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_ID_in_lvalue2098 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_fieldvalue_in_fieldvalues2124 = new BitSet(new long[]{0x0000000008000002L});
    public static final BitSet FOLLOW_27_in_fieldvalues2138 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_fieldvalue_in_fieldvalues2142 = new BitSet(new long[]{0x0000000008000002L});
    public static final BitSet FOLLOW_ID_in_fieldvalue2183 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_20_in_fieldvalue2185 = new BitSet(new long[]{0x7020000300003010L});
    public static final BitSet FOLLOW_exp_in_fieldvalue2187 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_40_in_synpred1_Wig1028 = new BitSet(new long[]{0x0000000000000002L});

}