UPDATE Customers
SET DOB = '5/10/1974'
WHERE LastName = 'Goldfish';
