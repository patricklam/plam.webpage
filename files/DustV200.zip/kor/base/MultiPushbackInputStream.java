// MultiPushbackInputStream.java
//
// Author: Raja Vallee-Rai
//
// This file is public domain.  You can do anything you want with 
// it, all at your own risk.  Enjoy!


package kor.base;

import java.io.*;
import java.util.*;

/**
 * This class provides you with an input stream where multiple characters
 * can be pushed back instead of just one as is the case with PushbackInputStream.
 */

public
class MultiPushbackInputStream extends FilterInputStream
{
	java.util.Stack pushbackStack;

	public MultiPushbackInputStream(InputStream in)
	{
		super(in);
		
		pushbackStack = new java.util.Stack();
	}

	public int read() throws IOException
	{
		if(!pushbackStack.isEmpty())
			return ((Integer) pushbackStack.pop()).intValue();
		else
			return super.read();
	}
	
	public int read(byte bytes[], int offset, int length) throws IOException
	{
		int numRead = 0;
		
		// Read as much as you can off the pushbackStack.
		{
			while(numRead < length && !pushbackStack.isEmpty())
			{
				bytes[offset + numRead] = (byte) 
					((Integer) pushbackStack.pop()).intValue();
				numRead++;
			}
		}
		
		// Read off the rest from the input stream.
		{	
			if(numRead == length)
				return numRead;
			else
				return super.read(bytes, offset + numRead, length - numRead);
		}
	}
	
	public void pushback(byte b)
	{
		pushbackStack.push(new Integer(b));
	}
}
