package ca.uwaterloo.ece251.symbol;

import ca.uwaterloo.ece251.ast.*;
import ca.uwaterloo.ece251.Error;
import java.util.Stack;

/** This just checks that every variable we use has a definition. */
public class SymbolUseVisitor extends DefaultVisitor {
    SymbolTable st;

    public SymbolUseVisitor(SymbolTable st) {
	this.st = st;
    }

    public void enter(CompoundStm stm) {
    }

    public void leave(CompoundStm stm) {
    }

    // More enter, leave functions go here.
}
