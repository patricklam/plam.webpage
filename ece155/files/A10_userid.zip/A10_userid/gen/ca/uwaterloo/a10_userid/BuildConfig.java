/** Automatically generated file. DO NOT MODIFY */
package ca.uwaterloo.a10_userid;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}