package ca.uwaterloo.ece251.ast;

import java.util.List;
import java.util.Iterator;

/** Utility functions. */
public class Util {
    public static String lines(List<?> l, int indent) {
	StringBuffer sb = new StringBuffer();
	for (Object o : l) {
	    sb.append(o.toString()+"\n");
	}
	if (l.size() > 0) sb.append("\n");
	return sb.toString();
    }

    public static String join(List<?> l, String sep) {
	StringBuffer sb = new StringBuffer();
	for (Object o : l) {
	    sb.append(sep+o.toString());
	}
	return sb.toString();
    }

    public static String commaSeparated(List<?> l) {
	StringBuffer sb = new StringBuffer();
	Iterator<?> it = l.iterator();
	while (it.hasNext()) {
	    sb.append(it.next().toString());
	    if (it.hasNext()) sb.append(", ");
	}
	return sb.toString();
    }

    public static String interleave(List<?> a, List<?> b, String sep) {
	Iterator it1 = a.iterator(), it2 = b.iterator();
	StringBuffer sb = new StringBuffer();
	while (it1.hasNext()) {
	    sb.append(it1.next().toString() + " " + it2.next().toString());
	    if (it1.hasNext()) sb.append(sep);
	}
	return sb.toString();
    }
}
