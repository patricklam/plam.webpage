/* 
 * File:   write-jpeg.h
 * Author: noundou
 *
 * Created on January 30, 2011, 1:40 PM
 */

#ifndef WRITE_JPEG_H
#define	WRITE_JPEG_H

#ifdef	__cplusplus
extern "C" {
#endif


int jpeg_write(FILE *fp, struct ida_image *img);


#ifdef	__cplusplus
}
#endif

#endif	/* WRITE_JPEG_H */

