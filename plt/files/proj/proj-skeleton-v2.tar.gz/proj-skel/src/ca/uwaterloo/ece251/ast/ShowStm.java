package ca.uwaterloo.ece251.ast;

import java.util.List;

/** Represents a show statement. */
public class ShowStm extends Stm {
    Document d;
    List<Input> receives;

    public ShowStm(Document d, List<Input> receives) {
	this.d = d; this.receives = receives;
    }

    public String toString() {
	return String.format("show %s%s;",
			     d.toString(), 
			     receives == null ? "" : 
			     " receive ["+Util.commaSeparated(receives)+"]");
    }
}

