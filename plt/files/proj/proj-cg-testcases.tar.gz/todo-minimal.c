#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include "runwig.h"

char *url;
char *sessionid;
int pc;
FILE *f;
#define SLEN 80

void output_Update(char * msg0, char * msg1, char * msg2, char * msg3, char * msg4, char * msg5)
{
  printf("<body>");
  printf("<h1>");
  printf("Personal TODO List");
  printf("</h1>");
  printf("<hr>");
  printf("<b>");
  printf("Stored TODO messages:");
  printf("</b>");
  printf("<p>");
  printf("\n    TODO 1:");
  printf("%s", msg0);
  printf("<p>");
  printf("TODO 2: ");
  printf("%s", msg1);
  printf("<p>");
  printf("TODO 3: ");
  printf("%s", msg2);
  printf("<p>");
  printf("TODO 4: ");
  printf("%s", msg3);
  printf("<p>");
  printf("TODO 5: ");
  printf("%s", msg4);
  printf("<p>");
  printf("TODO 6: ");
  printf("%s", msg5);
  printf("<p>");
  printf("<hr>");
  printf("<b>");
  printf("New TODO (TODO #, Message):");
  printf("</b>");
  printf("<p>");
  printf("<input name=\"insertValue\" type=\"text\" size=\"2\">\n");
  printf("<input name=\"todo\" type=\"text\" size=\"40\">\n");
  printf("<p>");
  printf("<hr>");
  printf("<b>");
  printf("Delete TODO #:");
  printf("</b>");
  printf("<p>");
  printf("<input name=\"deleteValue\" type=\"text\" size=\"2\">\n");
  printf("<p>");
  printf("<hr>");
  printf("<p>");
  printf("<input name=\"quit\" type=\"radio\" value=\"yes\">\n");
  printf(" Quit now\n  ");
  printf("</body>");
}

void output_delete(char * deleteValue)
{
  printf("<body>");
  printf("<h1>");
  printf("Deleting todo entry: ");
  printf("%s", deleteValue);
  printf("</h1>");
  printf("</body>");
}

void output_ByeBye(char * conns, char * msgs)
{
  printf("<body>");
  printf("<h1>");
  printf("Thanks for using The Personal TODO List");
  printf("</h1>");
  printf("\n    You made ");
  printf("%s", conns);
  printf(" connections\n    and wrote ");
  printf("%s", msgs);
  printf(" messages (divided by 2).\n  ");
  printf("</body>");
}

char * local_todo_msg;
int local_todo_connections;
int local_todo_deleteValue;
char * local_todo_username;
int local_todo_written;
int local_todo_insertValue;
bool local_todo_correct;
char * local_todo_password;
char * local_todo_quit;
int main() {
  local_todo_msg = malloc(SLEN);
  local_todo_username = malloc(SLEN);
  local_todo_password = malloc(SLEN);
  local_todo_quit = malloc(SLEN);
  srand48(time(0L));
  parseFields();
  url = "http://ece251.patricklam.ca/~plam/cgi-bin/todo-minimal";
  sessionid = getenv("QUERY_STRING");

  if (!sessionid || !*sessionid || strcmp(sessionid, "todo")==0)
    goto start_todo;
  if (strncmp(sessionid, "todo$",5)==0)
    goto restart_todo;
  printf("Content-type: text/html\n\n");
  printf("<title>Illegal Request</title>\n");
  printf("<h1>Illegal Request: %s</h1>\n",sessionid);
  exit(1);

start_todo:
  sessionid = randomString("todo",20);
  /* connections = 0; */
  local_todo_connections = 0;
  /* correct = false; */
  local_todo_correct = false;
  /* written = 0; */
  local_todo_written = 0;
  /* quit = "no"; */
  strcpy(local_todo_quit,"no");
  /* while (quit != "yes") */
  while (strcmp(local_todo_quit,"yes")!=0) {
  /* show plug Update[msg0=msg0, msg1=msg1, msg2=msg2, msg3=msg3, msg4=msg4, msg5=msg5]... */
  printf("Content-type: text/html\n\n");
  printf("<form method=\"POST\" action=\"%s?%s\">\n",url,sessionid);
  output_Update(getGlobalString("global_todo-minimal_msg0"), getGlobalString("global_todo-minimal_msg1"), getGlobalString("global_todo-minimal_msg2"), getGlobalString("global_todo-minimal_msg3"), getGlobalString("global_todo-minimal_msg4"), getGlobalString("global_todo-minimal_msg5"));
  printf("<p><input type=\"submit\" value=\"continue\">\n");
  printf("</form>\n");
  f = fopen(sessionid,"w");
  fprintf(f, "1\n");
  fprintf(f, "%s\n",local_todo_msg);
  fprintf(f, "%i\n",local_todo_connections);
  fprintf(f, "%i\n",local_todo_deleteValue);
  fprintf(f, "%s\n",local_todo_username);
  fprintf(f, "%i\n",local_todo_written);
  fprintf(f, "%i\n",local_todo_insertValue);
  fprintf(f, "%i\n",local_todo_correct);
  fprintf(f, "%s\n",local_todo_password);
  fprintf(f, "%s\n",local_todo_quit);
  fclose(f);
  exit(0);
todo_1:
  /* ... receive [msg = todo, insertValue = insertValue, deleteValue = deleteValue, quit = quit]; */ 
  local_todo_msg = getField("todo");
  local_todo_insertValue = atoi(getField("insertValue"));
  local_todo_deleteValue = atoi(getField("deleteValue"));
  local_todo_quit = getField("quit");
  /* connections = connections + 1; */
  local_todo_connections = local_todo_connections + 1;
  /* if (msg != "") */
  if (strcmp(local_todo_msg,"")!=0) {
  /* written = written + 1; */
  local_todo_written = local_todo_written + 1;
  /* if (insertValue < 1 || insertValue > 6) */
  if (local_todo_insertValue < 1 || local_todo_insertValue > 6) {
  /* msg0 = msg1; */
  putGlobalString("global_todo-minimal_msg0", getGlobalString("global_todo-minimal_msg1"));
  /* msg1 = msg2; */
  putGlobalString("global_todo-minimal_msg1", getGlobalString("global_todo-minimal_msg2"));
  /* msg2 = msg3; */
  putGlobalString("global_todo-minimal_msg2", getGlobalString("global_todo-minimal_msg3"));
  /* msg3 = msg4; */
  putGlobalString("global_todo-minimal_msg3", getGlobalString("global_todo-minimal_msg4"));
  /* msg4 = msg5; */
  putGlobalString("global_todo-minimal_msg4", getGlobalString("global_todo-minimal_msg5"));
  /* msg5 = msg; */
  putGlobalString("global_todo-minimal_msg5", local_todo_msg);
  }
  /* if (insertValue == 1) */
  if (local_todo_insertValue == 1) {
  /* msg0 = msg; */
  putGlobalString("global_todo-minimal_msg0", local_todo_msg);
  }
  /* if (insertValue == 2) */
  if (local_todo_insertValue == 2) {
  /* msg1 = msg; */
  putGlobalString("global_todo-minimal_msg1", local_todo_msg);
  }
  /* if (insertValue == 3) */
  if (local_todo_insertValue == 3) {
  /* msg2 = msg; */
  putGlobalString("global_todo-minimal_msg2", local_todo_msg);
  }
  /* if (insertValue == 4) */
  if (local_todo_insertValue == 4) {
  /* msg3 = msg; */
  putGlobalString("global_todo-minimal_msg3", local_todo_msg);
  }
  /* if (insertValue == 5) */
  if (local_todo_insertValue == 5) {
  /* msg4 = msg; */
  putGlobalString("global_todo-minimal_msg4", local_todo_msg);
  }
  /* if (insertValue == 6) */
  if (local_todo_insertValue == 6) {
  /* msg5 = msg; */
  putGlobalString("global_todo-minimal_msg5", local_todo_msg);
  }
  }
  /* if (deleteValue >= 1 && deleteValue <= 6) */
  if (local_todo_deleteValue >= 1 && local_todo_deleteValue <= 6) {
  /* show plug delete[deleteValue=deleteValue]... */
  printf("Content-type: text/html\n\n");
  printf("<form method=\"POST\" action=\"%s?%s\">\n",url,sessionid);
  output_delete(itoa(local_todo_deleteValue));
  printf("<p><input type=\"submit\" value=\"continue\">\n");
  printf("</form>\n");
  f = fopen(sessionid,"w");
  fprintf(f, "2\n");
  fprintf(f, "%s\n",local_todo_msg);
  fprintf(f, "%i\n",local_todo_connections);
  fprintf(f, "%i\n",local_todo_deleteValue);
  fprintf(f, "%s\n",local_todo_username);
  fprintf(f, "%i\n",local_todo_written);
  fprintf(f, "%i\n",local_todo_insertValue);
  fprintf(f, "%i\n",local_todo_correct);
  fprintf(f, "%s\n",local_todo_password);
  fprintf(f, "%s\n",local_todo_quit);
  fclose(f);
  exit(0);
todo_2:
  /* ... receive []; */ 
  /* if (deleteValue == 1) */
  if (local_todo_deleteValue == 1) {
  /* msg0 = ""; */
  putGlobalString("global_todo-minimal_msg0", "");
  }
  /* if (deleteValue == 2) */
  if (local_todo_deleteValue == 2) {
  /* msg1 = ""; */
  putGlobalString("global_todo-minimal_msg1", "");
  }
  /* if (deleteValue == 3) */
  if (local_todo_deleteValue == 3) {
  /* msg2 = ""; */
  putGlobalString("global_todo-minimal_msg2", "");
  }
  /* if (deleteValue == 4) */
  if (local_todo_deleteValue == 4) {
  /* msg3 = ""; */
  putGlobalString("global_todo-minimal_msg3", "");
  }
  /* if (deleteValue == 5) */
  if (local_todo_deleteValue == 5) {
  /* msg4 = ""; */
  putGlobalString("global_todo-minimal_msg4", "");
  }
  /* if (deleteValue == 6) */
  if (local_todo_deleteValue == 6) {
  /* msg5 = ""; */
  putGlobalString("global_todo-minimal_msg5", "");
  }
  }
  }
  /* exit plug ByeBye[conns=connections, msgs=written * 2]; */
  printf("Content-type: text/html\n\n");
  output_ByeBye(itoa(local_todo_connections), itoa(local_todo_written * 2));
  exit(0);
restart_todo:
  f = fopen(sessionid, "r");
  fscanf(f, "%i\n",&pc);
  fscanf(f, "%s\n",local_todo_msg);
  fscanf(f, "%i\n",&local_todo_connections);
  fscanf(f, "%i\n",&local_todo_deleteValue);
  fscanf(f, "%s\n",local_todo_username);
  fscanf(f, "%i\n",&local_todo_written);
  fscanf(f, "%i\n",&local_todo_insertValue);
  fscanf(f, "%i\n",&local_todo_correct);
  fscanf(f, "%s\n",local_todo_password);
  fscanf(f, "%s\n",local_todo_quit);
  if (pc==1) goto todo_1;
  if (pc==2) goto todo_2;
}
