// ZoomControl.java
//
// Author: Raja Vallee-Rai
//
// This file is public domain.  You can do anything you want with 
// it, all at your own risk.  Enjoy!

import kor.base.*;
import java.awt.event.*;
import java.awt.*;

/**
 * The ZoomControl frame controls the current zoom magnification of the playfield.
 */

class ZoomControl extends Frame implements WindowListener, 
                                           ActionListener,
                                           AdjustmentListener
{
    static final int INITIAL_ZOOM = 50,
                     MAX_ZOOM = 100,
                     MIN_ZOOM = 1;

    Label zoomLabel;
    Scrollbar zoomBar;

    Button dismissButton;

    Playfield playfield;
    double zoomFactor;
    
    public ZoomControl(Playfield playfield)
    {
        super("Zoom Control");
        
        this.playfield = playfield;
        
        addWindowListener(this);            
        setSize(new Dimension(300, 150));
        setLayout(new BorderLayout());

        WindowPlacer.placeWindowAt(this, "Southwest");

        // topPanel
        {
            Panel topPanel = new Panel();
            
            topPanel.setLayout(new GridLayout(0, 1));

            // Zoom bar
            {
                zoomLabel = new Label("Magnification");
                zoomBar = new Scrollbar(Scrollbar.HORIZONTAL, INITIAL_ZOOM, 1, MIN_ZOOM, 
                    MAX_ZOOM);
                
                zoomBar.setBlockIncrement(10);
                zoomBar.setUnitIncrement(1);
                zoomBar.addAdjustmentListener(this);
                
                topPanel.add(zoomLabel);
                topPanel.add(zoomBar);
                
                updateZoomFactorAndLabel();
            }
            
            topPanel.add(new Label());

            // DismissButton
            {
                Panel p = new Panel();
                
                p.setLayout(new FlowLayout());
                
                dismissButton = new Button("Dismiss");
                p.add(dismissButton);
                dismissButton.addActionListener(this);
                
                topPanel.add(p);
            }
                        
            add(topPanel, "Center");
        }
    }
    
    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource() == dismissButton)
        {
            handleClickToClose();
        }
    }
    
    public double zoomFactor()
    {
        return zoomFactor;
    }
    
    public void adjustmentValueChanged(AdjustmentEvent e)
    {
        if(e.getSource() == zoomBar)
        {
            updateZoomFactorAndLabel();
            playfield.refreshViewers();
        }
    }

    public void setZoomFactor(double factor)
    {
        // I need to figure out how to produce the Scrollbar value from the actual value
     
        int units = barUnitsOfFactor(factor);
        
        zoomBar.setValue(units);
        updateZoomFactorAndLabel();
    }
     
    private int barUnitsOfFactor(double x)
    {
        double minFactor = factorOfBarUnits(MIN_ZOOM);
        double maxFactor = factorOfBarUnits(MAX_ZOOM);
        
        x = Math.max(minFactor, x);
        x = Math.min(maxFactor, x);
        
        return (int) ((Math.log(x)/ Math.log(2.0)) * 15.0 + 50.0);
    }
       
    private
    double factorOfBarUnits(int x)
    {
        return Math.pow(2, (x - 50) / 15.0);
    }

    private
    void updateZoomFactorAndLabel()
    {
        zoomFactor = Math.pow(2, (zoomBar.getValue() - 50) / 15.0);
        zoomLabel.setText("Zoom Magnification (x" + ExtDouble.truncatedOf(zoomFactor, 2) + ")");
    }
        
    void handleClickToClose()
    {
        setVisible(false);
    }

    public void windowClosing(WindowEvent e)
    {
        handleClickToClose();
    }
     
    public void windowOpened(WindowEvent e)
    {
    }
     
    public void windowIconified(WindowEvent e)
    {
    }
     
    public void windowDeiconified(WindowEvent e)
    {
    }
     
    public void windowClosed(WindowEvent e)
    {
    }
     
    public void windowActivated(WindowEvent e)
    {
    }
     
    public void windowDeactivated(WindowEvent e) 
    {
    }
}

