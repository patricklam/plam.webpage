open Bf
open Bf_set
open Decproc
open Preds
open Bohneutil

module type ABSTRACTION =
  sig
    type abs_objs = Bf.bf
    type abs_state = Bf.bf
    type abs_states = Bf_set.bf_set

    val set_max_cube_length : int -> unit

    val alpha : Vcform.form -> Vcform.form -> abs_state
    (** [alpha psi f] computes over-approximation of [f] for context [psi] *)

    val beta : Vcform.form -> Vcform.form -> abs_state
    (** [beta psi f] computes under-approximation of [f] for context [psi] *)

    val coerce : string list -> Vcform.form -> abs_states -> abs_states
    (** [remove_empty ign f abs] removes cubes from [abs] that are
       unsatisfiable with respect to [f] *)

	
    val	abstract_post : Vcform.form ->
	(Vcform.form -> Vcform.form) -> abs_states -> abs_states
    (** [abstract_post g wp psi] computes abstract post for guard [g], 
      * weakest precondition operator [wp], and abstract value [psi] *)

    val print_abs_state : abs_state -> unit
    (** print an abstract state *)

    val print_abs_states : abs_states -> unit
    (** print set of abstract states *)

    val gamma_objs : abs_objs -> Vcform.form
    (** convert abstract objects to formula *)

    val gamma_state : abs_state -> Vcform.form
    (** convert abstract value to formula *)

    val gamma : abs_states -> Vcform.form
    (** convert set of abstract values to formula *)

    val project_irrelevant : Vcform.form -> abs_state -> abs_state

    val compute_empty_cubes : unit -> unit
    (** precompute empty cubes *)

    val split_singletons : Vcform.form -> Preds.pred list -> string list -> abs_states -> abs_states
  end
      
module Abstr : ABSTRACTION = 
  struct
    type abs_objs = Bf.bf
    type abs_state = Bf.bf
    type abs_states = Bf_set.bf_set

    (* maximal length of cubes *)
    let max_cube_length = ref 2
    
    let empty_cubes = ref Bf.bottom
	
    (* cache for abstract weakest preconditions *)
    let pred_upd_map = Hashtbl.create 0

    let set_max_cube_length n = 
      max_cube_length := n

    let print_cubes cs =
      Bf.print stdout Preds.get_pred_name cs

    let print_abs_state = print_cubes
	
    let print_abs_states abs_states =
      Bf_set.print stdout Preds.get_pred_name abs_states

    let project_pre_preds bf =
      let pre_preds =
	Preds.fold_preds (fun acc i ->
	  if Preds.is_pre_pred i then i::acc
	  else acc) [] 
      in Bf.exists pre_preds bf

    let gamma_objs bf =
      let res = ref [] in
      let process_cube c =
	let cube = 
	  Preds.fold_preds
	    (fun cube p -> 
	      if not (Preds.is_pre_pred p) then
		if c (Bf.var_index p) = 0 then 
		  Vcform.smk_not (Preds.get_pred_def p)::cube 
		else if c (Bf.var_index p) = 1 then 
		  Preds.get_pred_def p::cube
		else cube
	      else cube) [] in
	res := Vcform.smk_and cube::!res
      in
      Bf.foreach_cube bf process_cube;
      Vcform.mk_or !res
	
    let gamma_state bf =
      Vcform.mk_foralls ([Preds.typed_free_var], gamma_objs bf)

    let gamma bfs =
      let process_bf acc bf = gamma_state bf::acc in
      Vcform.mk_or (Bf_set.fold process_bf [] bfs)
	
    (* free variables of a formula (modified version of Vcform.fv) *) 
    let fv f = 
      let add v bv acc = 
	if (List.mem v bv) || (List.mem v acc) then acc
	else v::acc in
      let rec fv1 f bv acc = match f with
      | Vcform.App (f1, fs) -> fv1 f1 bv (fv_list fs bv acc)
      | Vcform.Binder (_, tvs, f1) -> fv1 f1 (List.rev_append (List.rev_map fst tvs) bv) acc
      | Vcform.Var v -> add v bv acc
      | Vcform.Const Vcform.NullConst -> add Preds.null_name bv acc (* here is the difference *)
      | Vcform.Const _ -> acc
      | Vcform.TypedForm (f1, t) -> fv1 f1 bv acc
      and fv_list fs bv acc = match fs with
      | [] -> acc
      | f::fs1 -> fv_list fs1 bv (fv1 f bv acc)
      in fv1 f [] []

    (* heuristic that checks whether a predicate [p] is relevant 
     * for the abstraction of a formula [f] *)
    let is_relevant ign f =
      let filter v = 
	try Preds.is_var (Preds.get_pred v)
	with _ -> false
      in
      let fv_f = List.filter filter (fv f) in
      fun p ->
	let fv_p = List.filter filter (fv (Preds.get_pred_def p)) in
	fv_p = [] || p = Preds.null_pred ||
	List.exists (fun v -> List.mem v fv_p) fv_f &&
	not (List.exists (fun v -> List.mem v fv_p) ign)

    let project_irrelevant f bf =
      let irrel_preds = Preds.fold_preds 
	  (fun acc p -> if is_relevant [] f p then acc else p::acc) []
      in Bf.exists irrel_preds bf


    let build_cubes exclude max_length =
      let pmax = Preds.get_max_index () in
      let process_cube c =
	let rec extend_cubes p complete acc acc_len =
	  if p + 1 + acc_len < max_length then complete 
	  else
	    let skip_me = extend_cubes (p - 1) complete acc acc_len in
	    if exclude Bf.top true p && exclude Bf.top false p then skip_me
	    else
	      let acc' = 
		List.fold_left 
		  (fun cs c -> 
		    if exclude c false p then 
		      if exclude c true p then cs 
		      else Bf.conj (Bf.mk_var p) c::cs
		    else
		      if exclude c true p then
			Bf.conj (Bf.neg (Bf.mk_var p)) c::cs
		      else Bf.conj (Bf.mk_var p) c::
			Bf.conj (Bf.neg (Bf.mk_var p)) c::cs)
		  [] acc
	      in
	      if not (acc' = []) then
		if acc_len + 1 = max_length then
		  extend_cubes (p - 1) (List.rev_append acc' skip_me) [Bf.top] 0
		else 
		  extend_cubes (p - 1) skip_me acc' (acc_len + 1)
	      else skip_me
	in
	extend_cubes pmax [] [Bf.top] 0 
      in
      if max_length > 0 then 
	List.fold_left (fun ecs c -> List.rev_append (process_cube c) ecs) [] [Bf.top] 
      else [Bf.top]
 
    let compute_empty_cubes () =
      (* restrict to cubes of length 2 *
       * cubes that are only build from predicates for program variables are never empty *)
      let is_empty c = Dp.valid (Vcform.smk_not (gamma_objs c)) in
      let vars = List.fold_left (fun acc p -> Bf.disj (Bf.mk_var p) acc) Bf.bottom (Preds.get_all_vars ()) in
      let exclude c s i = 
	Preds.is_pre_pred i || 
	not (Bf.eq c Bf.top) && (not (is_relevant [] (gamma_objs c) i) || 
	Preds.is_var i && (Bf.le c vars || Bf.le (Bf.neg c) vars)) in 
      let cubes = build_cubes exclude 2 in
      empty_cubes := List.fold_left 
	  (fun acc c -> 
	    if is_empty c then Bf.disj acc c
	    else acc) Bf.bottom cubes;
      print_debug 2 (fun () -> print_newline (); print_cubes !empty_cubes)

	  
    let build_exclude_map max_length psi f =
      let conj s i c = 
	Bf.conj c (if s then Bf.mk_var i
	else Bf.neg (Bf.mk_var i))
      and disj s i c = 
	Bf.disj c (if s then Bf.mk_var i
	else Bf.neg (Bf.mk_var i))
      and disj_not i c = Bf.disj (Bf.neg (Bf.mk_var i)) c 
      and exclude_map = Hashtbl.create 0 in
      let check_pred ((f_cs, ge_f, notf_cs, ge_notf) as res) i =
	if not (Preds.is_pre_pred i) && is_relevant [] f i then
	  let p = Preds.get_pred_def i in
	  if Dp.entails psi p f then begin
	    Hashtbl.add exclude_map i true;
	    (disj true i f_cs, ge_f, notf_cs, conj false i ge_notf)
	  end
	  else if Dp.entails psi (Vcform.smk_not p) f then begin
	    Hashtbl.add exclude_map i true;
	    (disj false i f_cs, ge_f, notf_cs, conj true i ge_notf)
	  end
	  else if Dp.entails psi f (Vcform.smk_not p) then begin
	    Hashtbl.add exclude_map i true;
	    (f_cs, conj false i ge_f, disj true i notf_cs, ge_notf)
	  end
	  else if Dp.entails psi f p then begin 
	    Hashtbl.add exclude_map i true;
	    (f_cs, conj true i ge_f, disj false i notf_cs, ge_notf)
	  end
	  else res
        else begin
	  Hashtbl.add exclude_map i true; 
	  res
	end 
      in 
      let f_cubes, ge_f, notf_cubes, ge_notf = 
	Preds.fold_preds check_pred (Bf.bottom, Bf.top, Bf.bottom, Bf.top) in
      let max_length = 
	min max_length (Preds.get_max_index () - Hashtbl.length exclude_map + 1) 
      in
      let f_cubes, ge_f =
	if Dp.entails psi (gamma_objs ge_f) f then 
	  (Bf.disj f_cubes ge_f, Bf.top) else (f_cubes, ge_f)
      and notf_cubes, ge_notf =
	if Dp.entails psi (gamma_objs ge_notf) (Vcform.smk_not f) then 
	  (Bf.disj notf_cubes ge_notf, Bf.top) else (notf_cubes, ge_notf)
      in
      (exclude_map, ge_f, f_cubes, ge_notf, notf_cubes, max_length)
	
    let uabstract_vcform psi f skip_notf =
      let conj s p c = 
	Bf.conj c (if s then Bf.mk_var p
	else Bf.neg (Bf.mk_var p))
      in 
      let exclude_map, ge_f, f_cubes, ge_notf, notf_cubes, max_length = 
	build_exclude_map !max_cube_length psi f 
      in
      let _ = print_debug 4 (fun () -> 
	print_string "ge_f = ";  print_cubes ge_f;
	print_string "f_cubes = "; print_cubes f_cubes;
	print_string "ge_notf = "; print_cubes ge_notf;
	print_string "notf_cubes = "; print_cubes notf_cubes;
	Printf.printf "max_cube_length = %d\n" max_length;
	Printf.printf "exclude_map ="; print_cubes 
	  (Hashtbl.fold (fun p _ acc -> Bf.conj (Bf.mk_var p) acc) exclude_map Bf.top))
      in
      let notf = Vcform.smk_not f in
      let rec uabstract k abs_f abs_notf =
	if k > max_length then 
	  (Bf.conj abs_f (Bf.neg !empty_cubes), Bf.conj abs_notf (Bf.neg !empty_cubes))
	else
	  let exclude_cubes = Bf.disj (Bf.disj !empty_cubes abs_f) abs_notf in 
	  let exclude c s p = 
	    Hashtbl.mem exclude_map p || 
	    Bf.le (conj s p c) exclude_cubes
	  in
	  let cubes = build_cubes exclude k in 
	  let process_cube (abs_f, abs_notf) c = 
	    let c_f = Bf.conj ge_f c in
	    let def_c_f = gamma_objs c_f in
	    let _ = print_debug 4 (fun () -> print_cubes c_f) in
	    if Dp.entails psi def_c_f f then 
	      let _ = print_debug_nl 4 (fun () -> print_string "=> f") in
	      (Bf.disj c_f abs_f, abs_notf)
	    else if not skip_notf then
	      let c_notf = Bf.conj ge_notf c in
	      let def_c_notf = gamma_objs c_notf in
	      let _ = print_debug 4 (fun () -> print_cubes c_notf) in
	      if Dp.entails psi def_c_notf notf then 
		let _ = print_debug_nl 4 (fun () -> print_string "=> ~f") in
		(abs_f, Bf.disj c_notf abs_notf)
	      else (abs_f, abs_notf)
	    else (abs_f, abs_notf)
	  in
	  let abs_f', abs_notf' = List.fold_left process_cube (abs_f, abs_notf) cubes in
	  uabstract (k + 1) abs_f' abs_notf'
      in
      let abs_f, abs_notf = uabstract 2 f_cubes notf_cubes in
      (abs_f, abs_notf)
	
    let coerce ign f bfs =
      let vars = List.fold_left (fun acc p -> Bf.disj (Bf.mk_var p) acc) Bf.bottom (Preds.get_all_vars ()) in
      let res = ref Bf.bottom in
      let check_cube bf c = 
	let monoms_c =  
	  Preds.fold_preds
	    (fun cubes q ->
	      if c (Bf.var_index q) = 1 then
		List.map (Bf.conj (Bf.mk_var q)) cubes
	      else if c (Bf.var_index q) = 0 then 
		List.map (Bf.conj (Bf.neg (Bf.mk_var q))) cubes
	      else if c (Bf.var_index q) = 2
		  && is_relevant ign f q
		  && not (Preds.is_pre_pred q) then
		List.fold_left 
		  (fun acc c -> 
		    let c_and_q = Bf.conj (Bf.mk_var q) c 
		    and c_and_notq = Bf.conj (Bf.neg (Bf.mk_var q)) c in
		    let c1 = 
		      if not (Bf.le c_and_notq !empty_cubes)
		      then [c_and_notq] else []
		    and c2 = 
		      if not (Bf.le c_and_q !empty_cubes)
		      then [c_and_q] else []
		    in c1 @ c2 @ acc) [] cubes
	      else cubes
	    ) [Bf.top]
	in
	List.iter (fun c -> 
	  if not (Dp.entails (gamma_state bf) 
		    f (Vcform.mk_not (gamma_objs c))) 
	  then res := Bf.disj !res c) monoms_c    
      in
      Bf_set.map (fun bf ->
	res := Bf.bottom; Bf.foreach_cube bf (check_cube bf); !res) bfs
	
    let alpha psi f =
      let abs_notf, _ = uabstract_vcform psi (Vcform.smk_not f) true in
      let _ = print_debug_nl 4 (fun () -> print_cubes abs_notf; print_newline ()) in
      let abs_f = project_pre_preds (Bf.conj (Bf.neg abs_notf) (Bf.neg !empty_cubes)) in
      abs_f 
	
    let beta psi f = fst (uabstract_vcform psi f true)
 
    let split_singletons sidecond ps ign bfs =
      let process_bf p acc bf =
	let res = ref acc in
	let dom_bf = Bf.dom bf in 
	let bf_p_cubes = Bf.conj bf (Bf.mk_var p) in
	let bf_notp_cubes = Bf.conj bf (Bf.neg (Bf.mk_var p)) in
	let process_cube c =
	  let p_cubes = Preds.fold_preds
	      (fun p_cubes q ->
		if c (Bf.var_index q) = 1 then
		  List.map (Bf.conj (Bf.mk_var q)) p_cubes
		else if c (Bf.var_index q) = 0 then 
		  List.map (Bf.conj (Bf.neg (Bf.mk_var q))) p_cubes
		else if c (Bf.var_index q) = 2
		    && is_relevant ign (Preds.get_pred_def p) q  
		    && not (Preds.is_pre_pred q) then
		  List.fold_left 
		    (fun acc c -> 
		      let c_and_q = Bf.conj (Bf.mk_var q) c 
		      and c_and_notq = Bf.conj (Bf.neg (Bf.mk_var q)) c in
		      if Bf.le c_and_q !empty_cubes then 
			c_and_notq::acc
		      else if Bf.le c_and_notq !empty_cubes then
			c_and_q::acc
		      else c_and_q::c_and_notq::acc) [] p_cubes
		else p_cubes
	      ) [Bf.top] in
	  List.iter (fun c -> 
	    let bf' = Bf.disj bf_notp_cubes c in
	    res := Bf_set.add !res bf') p_cubes
	in
	let _ = Bf.foreach_cube bf_p_cubes process_cube in
	!res
      in
      let process_p acc p =
	Bf_set.fold (process_bf p) Bf_set.bottom acc
      in
      let prune_empty bf =
	if not (Dp.valid (Vcform.mk_impl (sidecond, Vcform.smk_not (gamma_state (project_pre_preds bf))))) 
	then Bf.conj (Bf.neg !empty_cubes) bf
	else Bf.bottom
      in
      let res = List.fold_left process_p bfs ps in
      Bf_set.map prune_empty res
	

    let abstract_post g wp abs_states =
      let add_split_variable vars p wp_p =
	if Preds.is_var p then
	  match wp_p with
	  | Vcform.App (Vcform.Const Vcform.Eq, [_; Vcform.Var _]) -> p::vars
	  | _ -> vars
	else vars
      in
      (* computes abstract transition relation for [context] and stmnt *)
      let abs_trans_rel context =
	let process_pred (split_vars, trans_rel) p =
	  let def_p = Preds.get_pred_def p in
          let wp_p = wp def_p
	  and wp_notp = wp (Vcform.smk_not def_p)
	  and p' = Bf.mk_primed_var p in
	  if Preds.is_const p || wp_p = def_p then
	    (split_vars, Bf.conj trans_rel (Bf.equi (Bf.mk_var p) p'))
	  else
	    let _ = print_debug_nl 2 (fun () -> 
	      print_endline ("\nprocess predicate " ^ Preds.get_pred_name p);
	      Printf.printf "wp(%s) = %s" (Preds.get_pred_name p)
		(Vcform.isabelle_formula wp_p)) in
	    let pred_update : Bf.bf =
	      try Hashtbl.find pred_upd_map (p, wp_p, context) 
	      with Not_found ->
		let pred_upd = 
		  let abs_wp_p, abs_wp_notp = uabstract_vcform context wp_p false in
		  (* and abs_wp_notp, _ = uabstract_vcform context wp_notp true in *)
		  let _ = print_debug_nl 2 (fun () -> 
		    Printf.printf "wp^#(%s) = \n" (Preds.get_pred_name p); print_cubes abs_wp_p;
		    Printf.printf "wp^#(~%s) = \n" (Preds.get_pred_name p); print_cubes abs_wp_notp)
		  in
		  Bf.conj (Bf.impl (abs_wp_p) p')
                    (Bf.impl (abs_wp_notp) (Bf.neg p'))
		in Hashtbl.add pred_upd_map (p, wp_p, context) pred_upd; pred_upd
	    in 
	    (add_split_variable split_vars p wp_p, Bf.conj trans_rel pred_update)
	in
	Preds.fold_preds process_pred ([], Bf.top) 
      in
      let abs_post' abs_states =
	let context = 
	  let join = Bf_set.join abs_states in
	  let var_state =
	    Preds.fold_preds (fun acc p -> 
	      if Preds.is_var p then Vcform.subst [(Preds.free_var_name, Vcform.mk_var (Preds.get_pred_name p))]
		  (gamma_objs (Bf.conj join (Bf.mk_var p)))::acc
	      else acc) []
	  in Vcform.smk_and (g::var_state)
	in    
	let split_vars, tr = abs_trans_rel context in
	let post_states = Bf_set.map (fun abs_state ->
	  let post = Bf.rel_prod abs_state tr in
	  let _ = print_debug_nl 2 (fun () -> 
	    print_string "Psi:\n"; 
	    print_cubes abs_state;
	    print_debug 3 (fun () ->
	      print_string "Psi & tr^#:\n"; 
	      print_cubes (Bf.conj tr abs_state));
	    print_string "post^#(Psi):\n"; 
	    print_abs_states (split_singletons Vcform.mk_true 
				(Preds.null_pred::split_vars) [] (Bf_set.singleton post)))
	  in 
	  post) abs_states
	in
	split_singletons Vcform.mk_true (Preds.null_pred::split_vars) [] post_states 
      in
      if Bf_set.le abs_states Bf_set.bottom then Bf_set.bottom 
      else abs_post' abs_states

  end

