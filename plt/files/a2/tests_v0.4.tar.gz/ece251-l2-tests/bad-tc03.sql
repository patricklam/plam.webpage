SELECT v.date, p.price, v.volume
FROM INSERT volume v LEFT JOIN Price p ON p.itemID=v.itemID  GROUP BY p2.[date] );