
let _ =
  try
    let lexbuf = Lexing.from_channel stdin in
    while true do
      let result = Predformparse.main Predformlex.token lexbuf in
      print_string (Predformpretty.pform result); print_newline(); flush stdout
    done
  with Predformlex.Eof ->
    print_string "Parsing exception caught...\n";
    exit 0
