// ECE 150 Programming Assignment 4
//
// CarListEntry Class
// Version 3.0
//
// DO NOT MODIFY THIS CLASS

public class CarListEntry
{
    private Car data;
    CarListEntry next;
    
    public CarListEntry(Car pCar)
    {
	this(pCar, null);
    }

    public CarListEntry(Car pCar, CarListEntry pNext)
    {
        data = new Car(pCar.getCarID(), pCar.getMake(), pCar.getModel(), pCar.getYear(),
		       pCar.getColour(), pCar.getPrice());
	next = pNext;
    }

    public Car getData() { return data; }
    public void setData(Car data) { this.data = data; }

    @Override
    public String toString()
    {
        String result = null;

        if (data != null)
        {
            result = data.toString();
        }
        return result;
    }
}
