open Abstlanguage
open Nodes
open Aabsyn

let unsome = function (Some x) -> x | None -> failwith "tried to deoptionify None"
let d x = Tokens.getText (unsome x)

let rec convert (mdl0:p_abst_module) : string abst_module = 
  match mdl0 with
  | AAbstModule mdl ->
      let mdl_name = Id.fetch_module (d mdl.abst_module_abst_module_name) in
      let rec convert_expr : p_expr -> string clause = fun exp ->
        match exp with
        | ALetExpr e -> LetClause (convert_set_defn (unsome e.let_expr_v),
                                   convert_expr (unsome e.let_expr_e))
        | AIffExpr e -> IffClause 
              (convert_expr (unsome e.iff_expr_l),
               convert_expr (unsome e.iff_expr_r))
        | AOrExpr e -> OrClause
              (convert_expr (unsome e.or_expr_l),
               convert_expr (unsome e.or_expr_r))
        | AAndExpr e -> AndClause
              (convert_expr (unsome e.and_expr_l),
               convert_expr (unsome e.and_expr_r))
        | ANotExpr e -> NotClause (convert_expr (unsome e.not_expr_expr))
        | AFormulaExpr e -> FormulaClause 
              (Util.trim_quotes (d e.formula_expr_string_literal))
      and convert_set_defn (ASetDefn (sd:a_set_defn)) : string set_defn =
        ((mdl_name ^ "." ^Id.fetch_var (d sd.set_defn_l)), 
         convert_set_defn_rhs (unsome sd.set_defn_r))
      and convert_set_defn_rhs (sdr:p_set_defn_rhs) : string set_defn_rhs =
        match sdr with
        | ACupSetDefnRhs crhs -> UnionForm 
              (convert_set_defn_rhs (unsome crhs.cup_set_defn_rhs_l), 
               convert_set_defn_rhs (unsome crhs.cup_set_defn_rhs_r))
        | ACapSetDefnRhs crhs -> IntersectionForm 
              (convert_set_defn_rhs (unsome crhs.cap_set_defn_rhs_l), 
               convert_set_defn_rhs (unsome crhs.cap_set_defn_rhs_r))
        | ABracedSetDefnRhs brhs -> BaseForm
            {  x = Id.fetch_var (d brhs.braced_set_defn_rhs_r);
               xt = Id.fetch_format (d brhs.braced_set_defn_rhs_rt);
               expr = (convert_expr (unsome brhs.braced_set_defn_rhs_cond)) }
        | AIdSetDefnRhs id -> 
            IdForm (Util.qualify_if_needed mdl_name
                      (d id.id_set_defn_rhs_identifier)) in
      let select_invs m = match m with
        AInvAbstMember _ -> true | _ -> false in
      let select_sets m = match m with
        ASetDefnAbstMember _ -> true 
      | _ -> false in
      let select_predvars m = match m with
        APredVarAbstMember _ -> true 
      | _ -> false in
      { 
        module_name = mdl_name;
        instantiated_from = None; 
        param_subst = [];
        plugin = Util.trim_quotes (d mdl.abst_module_abst_module_plugin);
        invariants = List.map 
          (fun x -> match x with AInvAbstMember x' -> 
            convert_expr (unsome x'.inv_abst_member_expr) 
          | _ -> failwith "filter failed")
          (List.filter select_invs mdl.abst_module_abst_module_abst_member);
        set_defns = List.map
          (fun x -> match x with
            ASetDefnAbstMember x' -> 
              convert_set_defn (unsome x'.set_defn_abst_member_set_defn)
          | _ -> failwith "filter failed")
          (List.filter select_sets mdl.abst_module_abst_module_abst_member);
        pred_vars = List.map
          (fun x -> match x with
            APredVarAbstMember x' -> 
              Util.qualify_if_needed mdl_name (d x'.pred_var_abst_member_identifier)
          | _ -> failwith "filter failed")
          (List.filter select_predvars
             mdl.abst_module_abst_module_abst_member);
      }
   | AInstAbstModule m1 ->  
       { 
         module_name = Id.fetch_module 
           (d m1.inst_abst_module_n);
         instantiated_from = Some 
           (Id.fetch_module (d m1.inst_abst_module_parent));
         param_subst = List.map (fun (ASubst x) -> 
          (Id.fetch_format (d x.subst_f),
           Id.fetch_format (d x.subst_a)))
          m1.inst_abst_module_params;
         plugin = "<none>";
         invariants = [];
         set_defns = [];
         pred_vars = [];
       }



