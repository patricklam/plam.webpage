open Types

(* For each spec proc, check that there exists a same-named impl proc
   with the same parameters and return value. *)

let compare_mandatory_pair (s_n, s_t) (i_n, i_t) =
  i_n = s_n & i_t = s_t

let compare_pair s i =
  match (s, i) with
  | (None, None) -> true
  | (Some sp, Some ip) -> compare_mandatory_pair sp ip
  | _ -> false

(* also should check that formats in spec are always declared,
 * and that they exist in impl *)
let verify s_ast i_ast =
  let spec_impl_check_proc m ps = 
    let n = Id.name_of_proc ps.Sabsyn.proc_name in
    let pi = Ast.fetch_impl_proc n m in
    if not (compare_pair ps.Sabsyn.ret_val pi.Iabsyn.ret_val) then
      Util.err "[proc]" 
        ("Return values in impl and spec of proecdure "^n^" don't match");
    if not ((List.length ps.Sabsyn.formals) = (List.length pi.Iabsyn.formals)) then
      Util.err "[proc]" 
        ("Parameter count in impl and spec of procedure "^n^" don't match")
    else if not (List.for_all2 compare_mandatory_pair ps.Sabsyn.formals pi.Iabsyn.formals) then
      Util.err "[proc]" 
        ("Parameters in impl and spec of procedure "^n^" don't match")
in
  Util.phase ("Spec/impl checking module "^s_ast.Sabsyn.module_name) 
    List.iter (spec_impl_check_proc i_ast) s_ast.Sabsyn.procs
