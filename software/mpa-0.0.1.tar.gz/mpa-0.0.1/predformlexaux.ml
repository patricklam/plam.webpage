open Predformparse
open Predformid

let kwlist = [
  ("true", TRUE);
  ("false", FALSE);
  ("and", AND);
  ("or", OR);
  ("not", NOT);
  ("set", SET);
  ("bool", BOOL);
  ("forall", FORALL);
  ("exists", EXISTS);
  ("exists1", EXISTSONE);
  ("exactly", EXACTLY);
  ("atleast", ATLEAST);
  ("atmost", ATMOST);
  ("let", LET);
  ("in", IN)
(*   ("union", UnionTok); *)
(*   ("inter", InterTok); *)
(*   ("subset", SubsetTok); *)
(*   ("elem", ElemTok); *)
(*   ("letbool", LetboolTok); *)
(*   ("let", LetTok); *)
(*   ("letset", LetsetTok); *)
(*   ("letsetc", LetsetcTok); *)
(*   ("letsetr", LetsetrTok); *)
(*   ("in", InTok); *)
(*   ("not", NotTok); *)
(*   ("and", AndTok); *)
(*   ("or", OrTok); *)
(*   ("card", CardTok); *)
(*   ("disjoint", DisjointTok); *)
(*   ("isempty", IsemptyTok) *)
]

let keywords = begin
  let tbl = Hashtbl.create 100 in
  let addpair (str,tok) = Hashtbl.add tbl str tok in
  begin
    List.iter addpair kwlist;
    tbl
  end
end

let identOrKeyword s =
  try Hashtbl.find keywords s with 
    Not_found -> try match List.assoc s !identKinds with
    | ObjId -> OBJIDENT s
    | SetId -> SETIDENT s
    | PropId -> BOOLIDENT s
    | _ -> IDENT s
    with Not_found -> IDENT s

let getNat (s:string) = NATLIT (int_of_string s)

