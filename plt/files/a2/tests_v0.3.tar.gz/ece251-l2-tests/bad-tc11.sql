SELECT supplier_id FROM suppliers AS test WHERE supplier_name = 'IBM';
