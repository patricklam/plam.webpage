package ca.uwaterloo.ece251.ast;

public class StarResultColumn extends ResultColumn {
    String table;
    public StarResultColumn(String table) {
	this.table = table;
    }
    public void accept(Visitor v) {
	v.enter(this);
	v.leave(this);
    }
}

