package ca.uwaterloo.ece251.ast;

import java.util.List;

/** Represents one HTML template. */
public class HTML {
    Id id;
    List<HTMLBody> htmlbody;

    public HTML(Id id, List<HTMLBody> htmlbody) {
	this.id = id;
	this.htmlbody = htmlbody;
    }

    public String toString() {
	return String.format("const html %s = <html>%s</html>;\n",
			     id.toString(),
			     Util.lines(htmlbody, 2));
    }
}

