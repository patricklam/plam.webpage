(* Abstract Syntax for Specification Language *)

open Types

type ident = string  
type setIdent  = ident
type propIdent = ident
type typeIdent = ident
type predIdent = ident
type bVarDecl = ident * typeIdent 

type form = 
  | Atom of atomForm
  | Not of form
  | And of form list
  | Or of form list
  | Impl of form * form
  | Iff of form * form
  | ExistsOne of bVarDecl * form (* deprecated! *)
  | ForallOne of bVarDecl * form (* deprecated! *)
  | ExistsSet of bVarDecl * form
  | ForallSet of bVarDecl * form

and atomForm = 
  | Eq of setExp * setExp
  | Neq of setExp * setExp
  | Sub of setExp * setExp
  | True
  | False
  | Cardeq of setExp * int
  | Cardleq of setExp * int
  | Cardgeq of setExp * int
  | Disjoint of setExp list
  | Propvar of propIdent
  | Propvarpost of propIdent

and setExp =
  | Prevar of setIdent
  | Postvar of setIdent
  | Emptyset
  | Union of setExp list
  | Inter of setExp list
  | Diff of setExp * setExp

and predUse = {
    predName : predIdent;
    predPrimed : bool;
    predArgs : setExp list
  }

type predDef = {
    predDefName : predIdent;
    predDefFormals : ident list;
    predDefBody : form
  }

type proc_spec = { (* procedure specification *)
    proc_name : Id.proc_t;
    formals    : (Id.var_t * value_type) list;
    ret_val    : (Id.var_t * value_type) option;
    requires : form;
    modifies : Id.var_t list; (* N.B. always qualified *)
    frame_cond : form;
    calls    : Id.module_t list;
    ensures  : form
}

type spec_module = { 
    module_name : Id.module_t;
    instantiated_from : Id.module_t option;
    param_subst : (Id.format_t * Id.format_t) list;
    properties  : predDef list;
    formats     : Id.format_t list;
    sets        : (Id.var_t * Id.format_t) list; 
    pred_vars   : Id.var_t list;
    procs       : proc_spec list
}

let collect_free_vars form = 
  let rec collect_setexp s =
    match s with
    | Prevar i -> [i]
    | Postvar i -> [i]
    | Emptyset -> []
    | Union sel -> List.concat (List.map collect_setexp sel)
    | Inter sel -> List.concat (List.map collect_setexp sel)
    | Diff (l, r) -> collect_setexp l @ collect_setexp r in
  let rec collect_atom a =
    match a with
    | Eq (l, r) -> collect_setexp l @ collect_setexp r
    | Neq (l, r) -> collect_setexp l @ collect_setexp r
    | Sub (l, r) -> collect_setexp l @ collect_setexp r
    | True -> []
    | False -> []
    | Cardeq (se, i) -> collect_setexp se
    | Cardleq (se, i) -> collect_setexp se
    | Cardgeq (se, i) -> collect_setexp se
    | Disjoint sel -> List.concat (List.map collect_setexp sel)
    | Propvar i -> [i]
    | Propvarpost i -> [i]
  and collect_form f =
    match f with
    | Atom af -> collect_atom af
    | Not nf -> collect_form nf
    | And fl -> List.concat (List.map collect_form fl)
    | Or fl -> List.concat (List.map collect_form fl)
    | Impl (p, c) -> collect_form p @ collect_form c
    | Iff (p, c) -> collect_form p @ collect_form c
    | ExistsOne ((v, t), f) -> 
        List.filter (fun x -> x <> v) (collect_form f)
    | ForallOne ((v, t), f) -> 
        List.filter (fun x -> x <> v) (collect_form f)
    | ExistsSet ((v, t), f) -> 
        List.filter (fun x -> x <> v) (collect_form f)
    | ForallSet ((v, t), f) -> 
        List.filter (fun x -> x <> v) (collect_form f) in
  collect_form form

let subst (x, y) form =
  let rec subst_setexp s =
    match s with
    | Prevar i -> (if (i = x) then y else s)
    | Postvar i -> (if (i = x) then y else s)
    | Emptyset -> Emptyset
    | Union sel -> Union (List.map subst_setexp sel)
    | Inter sel -> Inter (List.map subst_setexp sel)
    | Diff (l, r) -> Diff (subst_setexp l, subst_setexp r) in
  let rec subst_atom a =
    match a with
    | Eq (l, r) -> Eq (subst_setexp l, subst_setexp r)
    | Neq (l, r) -> Neq (subst_setexp l, subst_setexp r)
    | Sub (l, r) -> Sub (subst_setexp l, subst_setexp r)
    | True -> True
    | False -> False
    | Cardeq (se, i) -> Cardeq (subst_setexp se, i)
    | Cardleq (se, i) -> Cardleq (subst_setexp se, i)
    | Cardgeq (se, i) -> Cardgeq (subst_setexp se, i)
    | Disjoint sel -> Disjoint (List.map subst_setexp sel)
    | Propvar i -> a
    | Propvarpost i -> a
  and subst_form f =
    match f with
    | Atom af -> Atom (subst_atom af)
    | Not nf -> Not (subst_form nf)
    | And fl -> And (List.map subst_form fl)
    | Or fl -> Or (List.map subst_form fl)
    | Impl (p, c) -> Impl (subst_form p, subst_form c)
    | Iff (p, c) -> Iff (subst_form p, subst_form c)
    | ExistsOne ((v, t), f) -> 
        if v = x then f 
        else ExistsOne ((v, t), subst_form f)
    | ForallOne ((v, t), f) -> 
        if v = x then f 
        else ForallOne ((v, t), subst_form f)
    | ExistsSet ((v, t), f) -> 
        if v = x then f 
        else ExistsSet ((v, t), subst_form f)
    | ForallSet ((v, t), f) -> 
        if v = x then f
        else ForallSet ((v, t), subst_form f) in
  subst_form form

(* Priming expressions, for primed predicate expansion *)

let primed s = s ^ "'"
let fsts vts = List.map fst vts

let rec prime_form (f : form) (but : ident list) : form = 
  let pr f = prime_form f but in
  match f with  
| Atom a -> Atom (prime_atom a but)
| Not f -> Not (pr f)
| And fs -> And (List.map pr fs)
| Or fs -> Or (List.map pr fs)
| Impl (f1,f2) -> Impl (pr f1, pr f2)
| Iff (f1,f2) -> Iff (pr f1, pr f2)
| ExistsOne (bv,f1) -> ExistsOne(bv,prime_form f1 (fst bv :: but))
| ForallOne (bv,f1) -> ForallOne(bv,prime_form f1 (fst bv :: but))
| ExistsSet (bv,f1) -> ExistsSet(bv,prime_form f1 (fst bv :: but))
| ForallSet (bv,f1) -> ForallSet(bv,prime_form f1 (fst bv :: but))
and prime_atom (a : atomForm) but = 
  let pr s = prime_exp s but in
  match a with
| Eq(s1,s2) -> Eq(pr s1, pr s2)
| Neq(s1,s2) -> Neq(pr s1, pr s2)
| Sub(s1,s2) -> Sub(pr s1, pr s2)
| True -> True
| False -> False
| Cardeq(s,i) -> Cardeq(pr s,i)
| Cardleq(s,i) -> Cardleq(pr s,i)
| Cardgeq(s,i) -> Cardgeq(pr s,i)
| Disjoint ss -> Disjoint (List.map pr ss)
| Propvar p -> Propvar (primed p)
| Propvarpost p -> Propvarpost p
and prime_exp s but = 
  let pr s1 = prime_exp s1 but in
  match s with
| Prevar id -> if List.mem id but then Prevar id else Postvar id
| Postvar id -> Postvar id
| Emptyset -> Emptyset
| Union ss -> Union (List.map pr ss)
| Inter ss -> Union (List.map pr ss)
| Diff(s1,s2) -> Diff(pr s1,pr s2)

let prime_all (f : form) = prime_form f []

(* Partial pretty-printer

let toString (m:spec_module) : string =
  let buf = Buffer.create 1024 in
  let wr s = Buffer.add_string buf s in
  let wrln = wr "\n" in
  let wr_sep str f bs =
    match bs with
      [] -> ()
    | b::bs ->
        begin
          f b;
          let strf b1 = (wr str; f b1) in
          List.iter strf bs
        end in
  let wr_idents is = wr_sep ", " wr is in
  let wr_format f = (wr "format "; wr f; wr ";\n") in
  let wr_set (s,typ) = (wr s; wr "."; wr typ) in
  let wr_proc (spec : proc_spec) : unit =
    let wr_formal (id,typ) = (wr id; wr ":"; wr typ) in
    let wr_return r = match r with
      Some (id,typ) ->
        begin
          wr "returns "; wr id; wr ":"; wr typ
        end
    | None -> () in 
    let wr_call m = match m with
      (mod_name,proc) -> 
        (wr mod_name; wr "."; wr proc) in
    begin
      wr "proc "; wr spec.proc_name;
      wr "(";
      wr_sep "; " wr_formal spec.formals; 
      wr ")";
      wr_return spec.retVal; 
      wrln;
      wr "requires ";
      wr (BA.toString spec.requires); 
      wr "\n";
      wr "modifies "; wr_idents spec.modifies; wrln;
      wr "calls "; wr_idents spec.calls; wrln;
      wr "ensures ";
      wr (BA.toString spec.ensures); 
      wr ";\n"
    end in
  begin    
    wr "spec module "; wr m.module_name; wr "{\n";
    List.iter wr_format m.formats;
    wr "sets "; 
    (wr_sep : string -> (string * string -> unit) -> (string * string) list -> unit) 
      ", " wr_set m.sets; 
    List.iter wr_proc m.procs;
    wr "}\n";
    Buffer.contents buf
  end

*)
