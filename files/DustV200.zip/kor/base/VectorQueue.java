// VectorQueue.java
//
// Author: Raja Vallee-Rai
//
// This file is public domain.  You can do anything you want with 
// it, all at your own risk.  Enjoy!

package kor.base;

import java.util.*;

/**
 * Provides an implementation of the abstract Queue class using java.util.Vector.
 * Note multiplethreads can share a VectorQueue because this implementation uses the Vector 
 * object which is itself synchronized.  
 */
 
public
class VectorQueue extends Queue
{
    private 
    Vector queue;

    private
    int size;
        
    public VectorQueue()
    {
        queue = new Vector();
    }
    
    public void insert(Object o)
    {
        queue.addElement(o);
        size++;
    } 
    
    public Object next()
    {
        Debug.assert(!isEmpty());
        
        Object toReturn = queue.firstElement();
        queue.removeElementAt(0);
        
        size--;
        
        return toReturn;
    }
    
    public Object head()
    {
        return queue.lastElement();
    }
    
    public Object tail()
    {
        return queue.firstElement();
    }
    
    public boolean isEmpty()
    {
        return queue.isEmpty();
    }
    
    public boolean contains(Object o)
    {
        return queue.contains(o);
    }
    
    public int size()
    {
        return size;
    }
}
