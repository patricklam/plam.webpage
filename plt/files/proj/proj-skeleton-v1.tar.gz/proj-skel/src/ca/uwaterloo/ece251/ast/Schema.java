package ca.uwaterloo.ece251.ast;

import java.util.List;

/** Represents a schema. */
public class Schema {
    Id id;
    List<WigField> fields;

    public Schema(Id id, List<WigField> fields) {
	this.id = id; this.fields = fields;
    }

    public String toString() {
	return String.format("schema %s { %s }",
			     id.toString(),
			     Util.join(fields, " "));
    }
}

