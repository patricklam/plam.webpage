
type value_type =
    TInt
  | TBool
  | TFloat
  | TString
  | TChar
  | TByte
  | TObj of Id.format_t
  | TSet of value_type
  | TArray of value_type
  | TVoid
  | TTuple of (value_type list)

let is_primitive_value_type t =
  match t with 
  | TArray _ | TObj _ | TSet _ | TTuple _ -> false
  | _ -> true

let rec value_type_of_string x =
  let chop_off_n s n =
    let l = String.length s in
    if l > n then
      String.sub s 0 (l-n)
    else
      s in
  let lastn s n =
    let l = String.length s in
    if l > n then
      String.sub s (l-n) n
    else
      "" in
  if lastn x 2 = "[]" then 
    TArray (value_type_of_string (chop_off_n x 2))
  else if lastn x 4 = " set" then 
    TSet (value_type_of_string (chop_off_n x 4))
  else
    match x with
    | "int" -> TInt
    | "bool" -> TBool
    | "float" -> TFloat
    | "string" -> TString
    | "char" -> TChar
    | _ -> TObj (Id.fetch_format x)

let rec string_of_value_type x =
  match x with
  | TInt -> "int"
  | TBool -> "bool"
  | TFloat -> "float"
  | TString -> "string"
  | TChar -> "char"
  | TByte -> "byte"
  | TObj y -> y
  | TVoid -> "void"
  | TArray y -> ((string_of_value_type y)^"[]")
  | TTuple y -> (List.fold_left 
      (fun x1 x2 -> x1 ^ "*" ^ (string_of_value_type x2)) "" y)
  | TSet y -> (string_of_value_type y)^" set"

let strip_one_array_level (x:value_type) =
  match x with
  | TArray y -> y
  | _ -> failwith "not an array"
