package ca.uwaterloo.ece251.ast;

/** Represents anything else in an HTML body. */
public class WhateverHTMLBody extends HTMLBody {
    String contents;

    public WhateverHTMLBody(String contents) {
	this.contents = contents;
    }

    public String toString() {
	return contents;
    }
}
