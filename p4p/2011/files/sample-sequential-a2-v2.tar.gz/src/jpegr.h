/**
 * Sample code for ECE 459, assignment 2 
 *
 * The code uses modified library functions from the
 * project fbida (http://linux.bytesex.org/fbida/)
 * that is released under GPL.
 *
 * @author: Xavier Noumbissi
 */

#ifndef ECE459__JPEGR__H
#define ECE459__JPEGR__H

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>

#include "a2jpeg/jpeglib.h"

#include "a2jpeg/jpegtools.h"


#define MAX_INPUT_FILE 50

/*******************************************************
 * Structure to control a user operation request
 ******************************************************/
typedef struct {
  JXFORM_CODE rotation; //when processing from the command line
  JXFORM_CODE auto_rotation[MAX_INPUT_FILE];
  unsigned int nrFiles;		//Number of valid files of the user request
  unsigned int threads;		//Number of threads to be used
  unsigned int flags;
  unsigned char *comment;
  struct ida_image *thumbnail[MAX_INPUT_FILE];
  char *outDir;			//output directory
  char *fileIn[MAX_INPUT_FILE];
  char *fileRotIn[MAX_INPUT_FILE];
} UserRequest;

/*******************************************************
 * Program options
 ******************************************************/
static int threads_flag = 0;
static int outdir_flag = 0;
static int auto_rotate_flag = 1;

static struct option prog_options[] = {
  {"help", no_argument, 0, 'h'},
  {"rotate_90", no_argument, 0, '9'},
  {"rotate_180", no_argument, 0, '1'},
  {"rotate_270", no_argument, 0, '2'},
  {"threads", required_argument, &threads_flag, 't'},
  {"outdir", required_argument, &outdir_flag, 'o'}
};

/*******************************************************
 * Program functions
 ******************************************************/
void destroyUserRequest(UserRequest ** uRequest);

int initUserRequest (UserRequest ** uRequest);

int processUserRequest (UserRequest * uRequest,
			 char *argv[], int argc, int optind);

int getExifOrientation (struct ida_image *aThumbnail,
			JXFORM_CODE * exifOrientation);

void getThreads (UserRequest * uRequest, char *optarg);

int isValidFile (const char *fName);

int getOutDir (UserRequest * uRequest, char *optarg);

void printUserRequest (UserRequest *);

int isValidFile (const char *fName);

char *copyStr (char **dst, char *src);

void help (char *argv[]);

void abort_message ();

void no_memory ();

#endif //ECE459__JPEGR__H
