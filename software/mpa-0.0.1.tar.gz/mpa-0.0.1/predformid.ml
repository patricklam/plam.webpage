type identKind = 
  | PropId
  | FunId of int
  | RelId of int
  | ConstId
  | ObjId
  | SetId
  | Unknown

type kinds = (string * identKind) list

let identKinds : kinds ref = ref 
    [("S",SetId);("T",SetId);("Q",SetId);
     ("x",ObjId);("y",ObjId);("z",ObjId);
     ("p",PropId);("q",PropId);("r",PropId)]

let addObj s = 
  identKinds := (s,ObjId) :: !identKinds

let removeObj s =
  match !identKinds with
  | (s1,ObjId)::ks when s1=s -> identKinds := ks
  | _ -> 
      failwith ("predformauxlex: obj ident " 
                ^ s ^ " pop error")

let addSet s = 
  identKinds := (s,SetId) :: !identKinds

let removeSet s =
  match !identKinds with
  | (s1,SetId)::ks when s1=s -> identKinds := ks
  | _ -> 
      failwith ("predformauxlex: set ident " 
                ^ s ^ " pop error")

let addBool s = 
  identKinds := (s,PropId) :: !identKinds

let removeBool s =
  match !identKinds with
  | (s1,PropId)::ks when s1=s -> identKinds := ks
  | _ -> 
      failwith ("predformauxlex: bool ident " 
                ^ s ^ " pop error")
