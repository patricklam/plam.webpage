open String

exception Bad_string
exception Bail

let rec remove_dups n = 
  match n with
    [] -> []
  | q::qs -> if (List.mem q qs) then remove_dups qs else q::(remove_dups qs)

let rec find_dups n = 
  match n with
    [] -> []
  | q::qs -> if (List.mem q qs) then q::(find_dups qs) else find_dups qs

let trim_quotes s = 
  let trim_last s' = if String.get s' ((String.length s')-1) = '"' then
    String.sub s' 0 ((String.length s')-1) else s' in
  if String.get s 0 = '"' then 
    (trim_last (String.sub s 1 ((String.length s) - 1)))
  else
    trim_last s

let unescaped s =
  let n = ref 0 in
    for i = 0 to length s - 1 do
      n := !n +
        (match unsafe_get s i with
           '\\' when String.unsafe_get s (i+1) != '\\' ->
             (match String.unsafe_get s (i+1) with
               'n' -> 0
             | 't' -> 0
             | _ -> 1)
        | _ -> 1)
    done;
    if !n = length s then s else begin
      let s' = create !n in
      n := 0;
      let skip = ref 0 in
      (try (for i = 0 to length s - 1 do
        begin
          if (i + !skip) = length s then raise Bail;
          match unsafe_get s (i + !skip) with
          | '\\' when String.unsafe_get s (i+ !skip+1) != '\\' ->
              (match String.unsafe_get s (i+ !skip+1) with
                'n' -> String.unsafe_set s' !n '\n'; incr skip
              | 't' -> String.unsafe_set s' !n '\t'; incr skip
              | '\\' -> String.unsafe_set s' !n '\\'; incr skip;
              | _ -> raise Bad_string)
          | c -> unsafe_set s' !n c
        end;
        incr n
      done) with Bail -> ());
      Str.first_chars s' (length s - !skip)
    end

let replace_dot_with_uscore s =
  let dot = Str.regexp "\\." in
  let caret = Str.regexp "\\^" in
  Str.global_replace dot "_" 
    (Str.global_replace caret "$" s)

let error_list = ref []

let err loc msg = 
  error_list := !error_list @
    [loc ^ ": error: "^msg]

let error msg = (print_string (msg ^"\n"); flush_all(); err "" msg)

let no_errors () = (List.length !error_list = 0)

let print_errors () = 
  List.iter (function x -> print_string (x ^ "\n")) !error_list;
  failwith (string_of_int (List.length !error_list)^" errors.")

let verbose = ref false

let amsg s = print_string s; flush_all ()

let msg s = if !verbose then amsg s
  
let phase : string -> 'a -> 'a =
  function s -> function v -> 
    msg s; msg "..."; 
    let r = v in msg "done.\n"; r

let extension n =
  let d = String.rindex n '.' in
  String.sub n d (String.length n - d)

let unsome : 'a option -> 'a = 
function
  | Some x -> x
  | None   -> failwith "tried to deoptionify None"

let fileToLine (fn:string) : string =
  begin
    let chn = open_in fn in
      let str = input_line chn in
      close_in chn;
      str
  end

let chop_off_2 s =
  let l = String.length s in
  if l > 2 then
    String.sub s 0 (l-2)
  else
    s

let last2 s =
  let l = String.length s in
  if l > 2 then
    String.sub s (l-2) 2
  else
    ""

let getTime () = Unix.gettimeofday ()

let empty l = match l with [] -> true | _ -> false

let qualify_if_needed mname n =
  if String.contains n '.' then n else (mname ^ "." ^ n)

let unqualify s =
  if String.contains s '.' then
    let i = String.rindex s '.' in
    String.sub s (i+1) (String.length s - i - 1)
  else s

let disjoint l1 l2 = 
  List.for_all (fun x -> not (List.mem x l2)) l1

let intersect l1 l2 =
  List.filter (fun x -> List.mem x l2) l1

let difference l1 l2 =
  List.filter (fun x -> not (List.mem x l2)) l1

let spacify i = 
  let s' z = List.fold_left (fun x y -> x ^ i ^ y) "" z in
  function [] -> ""
  | [x] -> x
  | x::xs -> x ^ i ^ (s' xs)

let split_by sep s =
  let sep_regexp = Str.regexp (Str.quote sep) in
  Str.split sep_regexp s
