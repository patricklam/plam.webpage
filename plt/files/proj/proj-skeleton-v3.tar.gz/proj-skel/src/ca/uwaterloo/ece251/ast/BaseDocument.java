package ca.uwaterloo.ece251.ast;

/** Represents a document to send as-is. */
public class BaseDocument extends Document {
    public BaseDocument(Id id) {
	super(id);
    }
    public String toString() {
	return id.toString();
    }
}
