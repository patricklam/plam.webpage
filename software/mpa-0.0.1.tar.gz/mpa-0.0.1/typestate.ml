(* Typestate Plugin *)

open Iabsyn
open Types

type typestate_impl_module = Sabsyn.form Iabsyn.impl_module

let loop_widening_count = 3
let check_antecedents = ref false

let typestate_convert_impl_module 
    (ast:string Iabsyn.impl_module) : typestate_impl_module =
  let rec typestate_convert_stmt s =
    match s with
    | EmptyStmt -> EmptyStmt
    | HavocStmt n -> HavocStmt n
    | ChoiceStmt (t, u) -> ChoiceStmt (typestate_convert_stmt t, 
                                       typestate_convert_stmt u)
    | CompoundStmt cs -> CompoundStmt (List.map typestate_convert_stmt cs) 
    | LocalDeclStmt (v, t, e) -> LocalDeclStmt (v, t, e) 
    | ExprStmt e -> ExprStmt e
    | ReturnStmt r -> ReturnStmt r
    | WhileStmt (i, e, w) -> 
        let i' = match i with 
          Some x -> Some (Spec.parse_formula x) | None -> None in
        WhileStmt (i', e, typestate_convert_stmt w)
    | AssertStmt (n, a) -> AssertStmt (n, Spec.parse_formula a)
    | AssumeStmt (n, a) -> AssumeStmt (n, Spec.parse_formula a)
    | PragmaStmt s -> PragmaStmt s
    | IfStmt (e, t, f) -> IfStmt (e, typestate_convert_stmt t,
                                  typestate_convert_stmt f) in
  let typestate_convert_proc p = 
    { proc_id = p.proc_id;
      formals = p.formals;
      ret_val = p.ret_val;
      proc_body = typestate_convert_stmt p.proc_body } in
  { module_name = ast.module_name;
    instantiated_from = ast.instantiated_from;
    param_subst = ast.param_subst;
    formats = ast.formats;
    references = ast.references;
    procs = List.map typestate_convert_proc ast.procs;
  }

let id_regexp = "[a-zA-Z$_][a-zA-Z0-9$_]*"
let set_exp = Str.regexp 
    ("\\("^id_regexp ^ "\\)\\.\\(" ^ id_regexp ^ "\\)[ \t]*=" ^
     "[ \t]*\\([0-9\\|true\\|false]+\\)")

type typestate_pred = {
    o : string;
    f : string;
    v : int
  }

let parse_typestate_pred s =
  if not (Str.string_match set_exp s 0) or
    (Str.matched_string s <> s) then 
    failwith ("Typestate predicate "^s^" does not parse.");
  let v0 = Str.matched_group 3 s in
  { o = Str.matched_group 1 s; 
    f = Str.matched_group 2 s;
    v = if v0 = "true" then 1
        else if v0 = "false" then 0
        (*else if v0 = "false" or v0 = "0" then 
          failwith ("Bad initial value (0, false) for typestate predicate.")*)
        else int_of_string (Str.matched_group 3 s) }

(* helpers *)
let strip s = 
  let s' = if String.contains s '^' then 
    Str.string_before s (String.index s '^') else s in
  if String.contains s' '\'' then
    Str.string_before s' (String.index s '\'') else s'
let primed x = x ^ "'"
let hatted i x = x ^ "^" ^ string_of_int i
let make_v_empty v = BA.Atom (BA.Eq (v, BA.Emptyset))
let exclude_v_from_s v s = BA.Atom (BA.Eq ((BA.Var (primed s)), 
                                           BA.Diff ((BA.Var s), v)))
let add_v_to_s v s = BA.Atom (BA.Eq ((BA.Var (primed s)), 
                                     BA.Union [(BA.Var s); (BA.Var v)]))
let frame_one x = BA.Atom (BA.Eq ((BA.Var (primed x)), (BA.Var x)))
let frame_one_bool x = BA.mk_iff (BA.Atom (BA.Propvar (primed x)), 
                                  BA.Atom (BA.Propvar x))
let all_sets_but all_sets x = 
  List.filter (fun y -> not (y = x)) all_sets
let frame_except all_sb not_stable = 
  let unstable y = not (List.mem y not_stable) in
  BA.mk_and (List.map frame_one
            (List.filter unstable all_sb.Spec.s) @
          List.map frame_one_bool
            (List.filter unstable all_sb.Spec.b))

let to_relation all_sb (f:BA.form) : BA.form = 
  (* conjoin with S'=S for all sets S *)
  BA.mk_and [f; frame_except all_sb []]

let collect_cheesy_obj_type_map pi : 
    (Id.var_t list * Id.var_t list * (Id.var_t, value_type) Hashtbl.t) =
  let lnames = ref [] in
  let bnames = ref [] in
  let tenv = Hashtbl.create 1 in 
  let updateLNames (x,y) = Hashtbl.add tenv x y; 
    match y with
    | TObj _ -> lnames := x :: !lnames
    | TBool -> bnames := x :: !bnames
    | _ -> () in
  let rec collect_types s = match s with
  | LocalDeclStmt (v, t, _) -> updateLNames (v,t)
  | CompoundStmt cs -> List.iter collect_types cs
  | WhileStmt (_, _, b) -> collect_types b
  | IfStmt (_, t, f) -> collect_types f; collect_types t
  | _ -> () in 
  begin
    let fr = match pi.ret_val with
      None -> pi.formals
    | Some rv -> rv :: pi.formals in
    List.iter updateLNames fr;
    collect_types pi.proc_body;
    (!lnames, !bnames, tenv)
  end

let universal_close_bool_vars (bool_vars:BA.ident list) f =
  let bool_vars' = List.map (fun x -> primed x) bool_vars in
  BA.mk_forallProp (bool_vars @ bool_vars',f)

let existential_close_bool_vars (bool_vars:BA.ident list) f =
  let bool_vars' = List.map (fun x -> primed x) bool_vars in
  BA.mk_existsProp (bool_vars @ bool_vars',f)

(* gives both primed and unprimed versions *)
let compute_BA_set_names fetch_type (all_sets:BA.ident list) =
  let mkbv s = (s, string_of_value_type (fetch_type s)) in
  let vts = List.map mkbv all_sets in
  let mkbv' s = (primed s, string_of_value_type (fetch_type s)) in
  let vts' = List.map mkbv' all_sets in
  vts @ vts'

let decide_implication msg fetch_type all_sb
    extra_conjs f g = 
  let free_vars = compute_BA_set_names fetch_type all_sb.Spec.s in
   let antecedent = BA.mk_and [f; extra_conjs] in 
  let f' = BA.mk_forallSet (free_vars, 
                            universal_close_bool_vars all_sb.Spec.b
                              (BA.mk_impl (antecedent, g))) in
  (* if the antecedent is false, then something's bad! *)
  if !check_antecedents then
    begin
      let antecedent' = BA.mk_existsSet (free_vars,
                                         existential_close_bool_vars
                                           all_sb.Spec.b antecedent) in
      if (not (BA.MONA.valid ("antecedent of "^msg) antecedent'))
      then
        begin
          BA.MONA.log "*** warning: antecedent always false! ***\n";
          Util.amsg "*** warning: antecedent always false! ***\n"
        end
    end;
  if (BA.MONA.valid msg f')
  then true
  else 
    begin
      Util.err "[impl]" 
        (BA.MONA.getCounterexample (List.map fst free_vars) f');
      false
    end
        
(* incorporation is the result of quantifier elimination on:
    \exists \hat{S_1}, ..., \hat{S_n}. B[S_i' -> \hat{S_i}] /\ 
                                       B_s[S_i -> \hat{S_i}]
 *)

let rec extract_vars f = match f with
| BA.ExistsSet (vts,f') -> vts @ extract_vars f'
| _ -> []

let rec extract_body f = match f with
| BA.ExistsSet (_,BA.And cs) -> BA.flatten cs []
| BA.ExistsSet (_,f') -> extract_body f'
| BA.And cs -> BA.flatten cs []
| _ -> [f]

let incorp msg (ic:int ref) fetch_type all_sb (b2:BA.form) (b1:BA.form) = 
  ic := !ic + 1;
  let b1_subst = List.map (fun s -> (primed s, BA.Var (hatted !ic s))) all_sb.Spec.s in
  let b1_bool_subst = List.map (fun s -> (primed s, BA.Propvar (hatted !ic s))) all_sb.Spec.b in
  let b1' = BA.subst_propvar b1_bool_subst (BA.subst b1_subst b1) in
  let b2_subst = List.map (fun s -> (s, BA.Var (hatted !ic s))) all_sb.Spec.s in
  let b2_bool_subst = List.map (fun s -> (s, BA.Propvar (hatted !ic s))) all_sb.Spec.b in
  let b2' = BA.subst_propvar b2_bool_subst (BA.subst b2_subst b2) in
  let boundVars = List.map (fun x -> (hatted !ic x, Types.string_of_value_type (fetch_type x))) all_sb.Spec.s in
  let vars1 = extract_vars b1' in
  let body1 = extract_body b1' in
  let vars2 = extract_vars b2' in
  let body2 = extract_body b2' in
  let res1 = BA.mk_existsProp (List.map (fun s -> hatted !ic s) all_sb.Spec.b,
                            BA.mk_existsSet (boundVars @ vars1 @ vars2, 
                                          BA.mk_and (body1 @ body2))) in
  let res = BA.simplify res1 in
  begin
(*
    BA.MONA.log ("INCORPORATION:" ^ msg ^ "\n");
    BA.MONA.log "  INCORP FIRST: "; BA.MONA.log (BA.MONA.form_to_mona b1); BA.MONA.log "\n\n";
    BA.MONA.log "  INCORP SECOND: "; BA.MONA.log (BA.MONA.form_to_mona b2); BA.MONA.log "\n\n";
    BA.MONA.log "  INCORP RES: "; BA.MONA.log (BA.MONA.form_to_mona res); BA.MONA.log "\n\n"; 
*)
    res
  end

exception Impl_failed

let rec convert_set_defn_form f munge =
  match f with
  | Aabsyn.BaseForm b -> failwith "shoulda transformed the formula"
  | Aabsyn.IdForm id -> BA.Var (munge id)
  | Aabsyn.UnionForm (a, b) -> BA.Union [convert_set_defn_form a munge;
                                  convert_set_defn_form b munge]
  | Aabsyn.IntersectionForm (a, b) -> 
      BA.Inter [convert_set_defn_form a munge;
                convert_set_defn_form b munge]

(* also uses all loaded spec modules in Ast.spec *)
let analyze_module : (string Aabsyn.abst_module *
                      Sabsyn.spec_module *
                      string Iabsyn.impl_module) -> 
                        Iabsyn.expr list -> bool = fun (ma, ms, mi0) rs ->
  let mi = typestate_convert_impl_module mi0 in
  let prefix_and a b = a & b in
  let alts_raw = Hashtbl.create 1 in
  let triggers = Hashtbl.create 1 in
  let derived_set_idents = ref [] in
  let derived_set_defns = ref [] in
  List.iter 
    (function d -> match (snd d) with (* assume post-transform: base or cpd *)
      (Aabsyn.BaseForm sd) -> 
        (match sd.Aabsyn.expr with
          (Aabsyn.FormulaClause se) -> 
            let sdp = (parse_typestate_pred se) in
            let a = (try Hashtbl.find alts_raw (sdp.f, sd.Aabsyn.xt) with
              Not_found -> 
                let l = ref [] in Hashtbl.add alts_raw 
                  (sdp.f, sd.Aabsyn.xt) l; l) in
            a := (fst d) :: !a;
            Hashtbl.add triggers (sdp.f, sd.Aabsyn.xt, sdp.v) (fst d)
        | _ -> failwith "typestate plugin only handles direct forms")
    | _ -> 
        let cd = snd d in
        let lhs = BA.Var (fst d) in
        let lhs' = BA.Var (primed (fst d)) in
        let rhs = convert_set_defn_form cd (fun x -> x) in
        let rhs' = convert_set_defn_form cd primed in
        derived_set_idents := (fst d) :: !derived_set_idents;
        derived_set_defns := BA.Atom (BA.Eq (lhs, rhs))::
          BA.Atom (BA.Eq (lhs', rhs')) :: 
          !derived_set_defns)
    ma.Aabsyn.set_defns;
  (* frame with derived set defns *)
  let frame_except_d all_sb non_stable = 
    frame_except all_sb (non_stable @ !derived_set_idents) in
  let alts = Hashtbl.create 1 in
  List.iter
    (function (_, Aabsyn.BaseForm sd) ->
      (match sd.Aabsyn.expr with
        Aabsyn.FormulaClause se -> 
          let sdp = (parse_typestate_pred se) in
          let a = Hashtbl.find alts_raw (sdp.f, sd.Aabsyn.xt) in
          List.iter (fun x -> Hashtbl.add alts x 
              (List.filter (fun y -> y <> x) !a)) !a
      | _ -> failwith "typestate plugin only handles direct forms")
      | _ -> ())
    ma.Aabsyn.set_defns;
  let disjtness_conds = 
    let varify x = (BA.Var x) in
    let varify' x = (BA.Var (primed x)) in
    let a = ref [] in
    Hashtbl.iter (fun (f, _) vs -> 
      if (List.length !vs) > 1 then
        a := BA.Atom (BA.Disjoint (List.map varify !vs)) ::
          BA.Atom (BA.Disjoint (List.map varify' !vs)) :: !a)
      alts_raw;
    !a in
  (* used to record what we've ensured at return statements *)
  let extra_results = ref [] in
  let analyze_proc (p:string) : bool = 
    let ps = Ast.fetch_spec_proc p ms in
    let pi = Ast.fetch_impl_proc p mi in
    (* global means in-scope *)
    let global_sets = 
      let global_sets_abst = Abst.collect_all_sets ma in
      let global_sets_spec = Spec.collect_all_sets ms in
      Util.remove_dups 
        (List.merge compare
           (List.sort compare global_sets_abst)
           (List.sort compare global_sets_spec)) in
    let global_bools = 
      let global_bools_abst = Abst.collect_all_bools ma in
      let global_bools_spec = Spec.collect_all_bools ms in
      Util.remove_dups
        (List.merge compare
           (List.sort compare global_bools_abst)
           (List.sort compare global_bools_spec)) in
    (* local means in proc *)
    let (local_sets, local_bools, tenv) = collect_cheesy_obj_type_map pi in
    let all_sb =
      { Spec.s = global_sets @ local_sets;
        Spec.b = global_bools @ local_bools; } in
    let fetch_type (s:Id.var_t) = 
      let s' = strip s in
      try 
        Hashtbl.find tenv s'
      with Not_found -> 
        try TObj (Abst.fetch_local_set_type s' ma)
        with Not_found -> TObj (Spec.fetch_set_type s' ms) in
    let enforce_impl msg f g : unit = 
      let res = decide_implication msg fetch_type all_sb 
          (BA.mk_and (disjtness_conds @ !derived_set_defns))
          f g in      
      if not res then begin        
        print_string ("Error found analyzing procedure " ^ p ^ ": ");
        print_string msg; print_string ".\n"; 
        raise Impl_failed
      end in
    let ic = ref 0 in
    let oc = ref 0 in
    (* transfer function helpers *)
    let inc msg = incorp msg ic fetch_type all_sb in
    let set_v_to_null (v:Id.var_t) = 
      let fram = frame_except_d all_sb [v] in
      BA.mk_and [make_v_empty (BA.Var (primed v)); fram] in
    let y_gets_x (y:Id.var_t) (x:Id.var_t) = 
      let fram = frame_except_d all_sb [y] in
      BA.mk_and [BA.Atom (BA.Eq (BA.Var (primed y), BA.Var x)); fram] in
    let y_iff_x (y:Id.var_t) (x:Id.var_t) = 
      let fram = frame_except_d all_sb [y] in
      BA.mk_and [BA.Iff (BA.Atom (BA.Propvar (primed y)), (BA.Atom (BA.Propvar x))); fram] in
    let b'_gets_not_b b' b =
      let fram = frame_except_d all_sb [] in
      BA.mk_and [BA.Iff (b', BA.Not b); fram] in
    let assign_new_to_v (v:Id.var_t) = 
      let fram = frame_except_d all_sb [v] in
      let v_disj_all = BA.mk_and (List.map 
          (fun x -> BA.Atom (BA.Disjoint [(BA.Var (primed v)); 
                                          (BA.Var (primed x))])) 
                              (all_sets_but (all_sb.Spec.s) v)) in
      BA.mk_and [BA.Atom (BA.Cardeq (BA.Var (primed v), 1)); v_disj_all; fram] in
    let put_v_in_r (v:Id.var_t) (r:Id.var_t) =
      let r_alts = Hashtbl.find alts r in
      let fram = frame_except_d all_sb (r::r_alts) in
      BA.mk_and [(add_v_to_s v r); fram] in
    (* end helpers *)
    let rec analyze_stmt (f:BA.form) (s:Sabsyn.form Iabsyn.stmt) =
      let rec compute_if_cond (e:Iabsyn.expr)
          : (BA.form * BA.form) = 
        let handle_true_branch v r =
          BA.Atom (BA.Sub (v, r)) in
        let handle_false_branch v r =
          BA.Atom (BA.Disjoint [v; r]) in
        let blow_up_result_tf v r = (handle_true_branch v r,
                                     handle_false_branch v r) in
        let blow_up_result_tt v r r' = (handle_true_branch v r,
                                        handle_true_branch v r') in
        let rec handle_if_cond0 e : (BA.form * BA.form) = 
          (match e with
          | EqExpr (FieldAccessExpr (VarExpr (LocalLvalue x), fd), 
                    LiteralExpr (Int c)) -> 
                      (try 
                        let xt = match fetch_type x with TObj t -> t 
                        | _ -> raise Not_found in
                        let r = Hashtbl.find triggers 
                            (Id.name_of_field fd, xt, c) in
                        blow_up_result_tf (BA.Var x) (BA.Var r)
                      with Not_found -> (BA.Atom BA.True, BA.Atom BA.True))
          | EqExpr (FieldAccessExpr (VarExpr (LocalLvalue x), fd), 
                    LiteralExpr (Bool false)) ->
                      (* never triggered, due to jimplification? *)
                      (* should be now: less-aggressive jimplification *)
                      (try 
                        let xt = match fetch_type x with TObj t -> t 
                        | _ -> raise Not_found in
                        let r = Hashtbl.find triggers 
                            (Id.name_of_field fd, xt, 0) in
                        blow_up_result_tf (BA.Var x) (BA.Var r)
                      with Not_found -> (BA.Atom BA.True, BA.Atom BA.True))
          | EqExpr (VarExpr (LocalLvalue x), LiteralExpr n) 
              when n = Iabsyn.null_obj -> 
                (BA.Atom (BA.Eq (BA.Var x, BA.Emptyset)),
                 BA.Atom (BA.Neq (BA.Var x, BA.Emptyset)))
          | NeqExpr (VarExpr (LocalLvalue x), rhs) -> 
              let (f1, f2) = handle_if_cond0 (EqExpr (VarExpr (LocalLvalue x), rhs)) in
              (f2, f1)
          | FieldAccessExpr (VarExpr (LocalLvalue x), fd) -> 
              (* guaranteed to be bool field, due to typechecking *)
              (try 
                let xt = match fetch_type x with TObj t -> t 
                | _ -> raise Not_found in
                let r = Hashtbl.find triggers (Id.name_of_field fd, xt, 1) in
                (try let r' = Hashtbl.find triggers 
                    (Id.name_of_field fd, xt, 0) in
                blow_up_result_tt (BA.Var x) (BA.Var r) (BA.Var r')
                with Not_found -> blow_up_result_tf (BA.Var x) (BA.Var r))
              with Not_found -> (BA.Atom BA.True, BA.Atom BA.True))
          | AndExpr (e1, e2) -> 
              let (f1p, f1m) = handle_if_cond0 e1 in
              let (f2p, f2m) = handle_if_cond0 e2 in
              (BA.mk_and [f1p; f2p], BA.mk_or [f1m; f2m])
          | VarExpr (LocalLvalue b) -> 
              (BA.Atom (BA.Propvar b), 
               BA.Not (BA.Atom (BA.Propvar b)))
          | LiteralExpr (Bool true) ->
              (BA.Atom BA.True, BA.Atom BA.False)
          | LiteralExpr (Bool false) ->
              (BA.Atom BA.False, BA.Atom BA.True)
          | NotExpr (e) -> 
              let (f1, f2) = handle_if_cond0 e in
              (f2, f1)
          | _ -> (BA.Atom BA.True, BA.Atom BA.True)) in
        let (fp, fm) = handle_if_cond0 e in
        let set_subst = List.map (fun s -> (s, BA.Var (primed s))) (all_sb.Spec.s) in
        let bool_subst = List.map (fun s -> (s, BA.Propvar (primed s))) (all_sb.Spec.b) in
        let fp' = BA.subst_propvar bool_subst (BA.subst set_subst fp) in
        let fm' = BA.subst_propvar bool_subst (BA.subst set_subst fm) in
        (fp', fm') in
      let handle_if_cond (e:Iabsyn.expr) (f:BA.form) 
          : (BA.form * BA.form) = 
        let (fp', fm') = compute_if_cond e in
        (BA.mk_and [f;fp'], BA.mk_and [f;fm']) in
      let analyze_while cond body f =
        let count = ref 0 in
        let coarsen formula = 
          count := !count + 1;
          if !count > loop_widening_count then BA.Atom BA.True else formula in
        let (fplus, fminus) = handle_if_cond cond f in
        let f0 = ref fplus in
        let f1 = ref (analyze_stmt !f0 body) in
        let impl f g = decide_implication "loop invariant preservation" fetch_type all_sb 
            (BA.mk_and (disjtness_conds @ !derived_set_defns))
            f g in
        while not (impl !f1 !f0) do 
          f0 := !f1;
          let f0' = analyze_stmt !f0 body in
          f1 := coarsen (BA.mk_or [!f0; f0']);
        done;
        Util.msg "Synthesized loop invariant: ";
        BA.show_form !f0;
        Util.msg ". ";
        (* check loop invariant *)
        let free_vars = (List.map fst
                           (compute_BA_set_names fetch_type (all_sb.Spec.s))) in
        let f' = BA.Not (BA.mk_forallSetId (free_vars, universal_close_bool_vars (all_sb.Spec.b)
                                              (BA.mk_impl (!f0, BA.Atom BA.False)))) in
        if (not (BA.MONA.valid "checking loop invariant dumbness" f')) then
            Util.err "[syn-loop-inv]" "loop invariant implies false!";
        BA.mk_and [fminus; !f0] in
      (match s with
      | EmptyStmt -> f
      | HavocStmt _ -> failwith "havoc inappropriate for typestate"
      | CompoundStmt sl -> List.fold_left analyze_stmt f sl
      | ChoiceStmt _ -> failwith "choice inappropriate for typestate"
      | LocalDeclStmt (v, t, expr) -> 
          analyze_stmt f (ExprStmt (AssignExpr (LocalLvalue v, expr)))
      | ExprStmt expr -> 
          let analyze_invoke apply_bool_subst rv_subst rv_names p' actuals f =
            let callee_mod_name = Id.module_of_proc p' in
            let callee_spec_mod = Ast.fetch_spec callee_mod_name in
            let callee = Ast.fetch_spec_proc p'.Id.p_name callee_spec_mod in
            (* create formals -> actuals map *)
            let formals_sub0 = List.map2 
                (fun (x, xt) y -> ((x, xt), y))
                callee.Sabsyn.formals actuals in
            let formals_sub1 = List.filter (fun (x, _) -> 
              not (is_primitive_value_type (snd x))) formals_sub0 in
            let formals_sub = List.map 
                (fun (x, y) -> 
                  match y with
                    VarExpr (LocalLvalue y') -> (fst x, BA.Var y')
                  | _ -> failwith "not simple actual") formals_sub1 in
            let formals_sub1_b = List.filter (fun (x, _) ->
              snd x = TBool) formals_sub0 in
            let formals_sub_b = List.map
                (fun (x, y) ->
                  match y with
                  | LiteralExpr (Bool true) -> (fst x, BA.True)
                  | LiteralExpr (Bool false) -> (fst x, BA.False)
                  | VarExpr (LocalLvalue y') -> (fst x, BA.Propvar y')
                  | VarExpr (RefLvalue y') -> 
                      let y'' = Util.qualify_if_needed 
                          ms.Sabsyn.module_name y' in 
                      (fst x, BA.Propvar y'')
                  | _ -> failwith "not simple actual") formals_sub1_b in
            (* apply formals -> actuals map *)
            let req1 = BA.subst_propvar formals_sub_b 
                (BA.subst formals_sub 
                   (BA.ba_of_sabsyn callee.Sabsyn.requires))
            and ens1 = BA.subst_propvar formals_sub_b 
                (BA.subst formals_sub 
                   (BA.subst rv_subst 
                      (BA.ba_of_sabsyn callee.Sabsyn.ensures))) in
            (* don't forget the return value, if it's a boolean *)
            let ens2 = apply_bool_subst ens1 in
            (* prime all sets for requires *)
            (* must prime all bools too!*)
            let req' = BA.subst_propvar 
                (List.map
                   (fun x -> (x, BA.Propvar (primed x)))
                   all_sb.Spec.b)
                (BA.subst 
                   (List.map 
                      (fun x -> (x, BA.Var (primed x))) 
                      all_sb.Spec.s) req1) in
            (* preserve all local sets for ensures set *)
            let ens' = BA.mk_and [ens2; frame_except 
                                    { Spec.s = local_sets;
                                      Spec.b = local_bools; } rv_names] in
            let ens'' = BA.mk_and (ens' :: disjtness_conds @ !derived_set_defns) in
            let msg = Printf.sprintf "requires clause in a call to procedure %s.%s"
                callee_mod_name (Id.name_of_proc p') in
            enforce_impl msg f req';
let f' = 
            inc "proc call" ens'' f in
f' in
          let get_assign_fn_unknown x fd =
            (try 
              let xt = match Hashtbl.find tenv x with TObj t -> t 
              | _ -> raise Not_found in
              let removals = Hashtbl.find alts_raw 
                  (Id.name_of_field fd, xt) in
              let r = (List.map
                         (exclude_v_from_s (BA.Var x)) 
                         !removals) in
              let fram = frame_except_d all_sb (!removals) in
              BA.mk_and (fram :: r)
            with Not_found -> frame_except_d all_sb []) in
          let get_assign_fn x fd c = 
            let xt = match Hashtbl.find tenv x with TObj t -> t 
            | _ -> failwith "field read on non-Obj" in
            if (not (Hashtbl.mem alts_raw (Id.name_of_field fd, xt))) 
            then frame_except_d all_sb [] (* don't care about this write *)
            else
              let removals = Hashtbl.find alts_raw (Id.name_of_field fd, xt) in
              if (Hashtbl.mem 
                    triggers (Id.name_of_field fd, xt, c)) then
                let new_set = 
                  Hashtbl.find triggers 
                    (Id.name_of_field fd, xt, c) in
                let removals' = 
                  List.filter (fun x -> x != new_set) !removals in
                let r = List.map (exclude_v_from_s (BA.Var x)) removals' in
                BA.mk_and ((put_v_in_r x new_set) :: r)
              else 
                get_assign_fn_unknown x fd in
          let explicit_bool lhs e =
            match e with
            | LiteralExpr (Bool true) ->
                Some (BA.Atom (BA.Propvar (primed lhs)))
            | LiteralExpr (Bool false) -> 
                Some (BA.Not (BA.Atom (BA.Propvar (primed lhs))))
            | _ -> None in
          (match expr with 
            (* booleans *)
            (* objects *)
          | AssignExpr (LocalLvalue lv, NewExpr _) -> 
              inc "new statement" (assign_new_to_v lv) f
          | AssignExpr (LocalLvalue y, VarExpr (LocalLvalue x)) -> 
              let xt = fetch_type x in
              (match xt with
              | TBool -> inc "assignment to local" (y_iff_x y x) f
              | TInt -> f
              | TObj _ -> inc "assignment to local" (y_gets_x y x) f
              | _ -> failwith "unexpected assignment")
            (* x = y.f *)
          | AssignExpr (LocalLvalue x,
                        FieldAccessExpr (VarExpr (LocalLvalue y), fd)) ->
                          let xt = fetch_type x in
                          if (xt = TBool) then 
                            begin
                              let yt = string_of_value_type (fetch_type y) in
                              let fram = frame_except_d all_sb [x] in
                              let trigger_t = (Id.name_of_field fd, yt, 1) in
                              let trigger_f = (Id.name_of_field fd, yt, 0) in
                              let a1 = if Hashtbl.mem triggers trigger_t then
                                let new_set = 
                                  Hashtbl.find triggers trigger_t in
                                BA.Iff (BA.Atom (BA.Propvar (primed x)),
                                        BA.Atom (BA.Sub 
                                                   (BA.Var y, 
                                                    BA.Var new_set)))
                              else BA.Atom BA.True in
                              let a2 = if Hashtbl.mem triggers trigger_f then 
                                let new_set' = 
                                  Hashtbl.find triggers trigger_f in
                                BA.Iff (BA.Not (BA.Atom (BA.Propvar (primed x))),
                                        BA.Atom (BA.Sub 
                                                   (BA.Var y,
                                                    BA.Var new_set')))
                              else BA.Atom BA.True in
                              inc "field assignment" (BA.mk_and [a1; a2; fram]) f
                            end
                          else f
            (* x.f = y *)
          | AssignExpr (FieldLvalue (VarExpr (LocalLvalue x), fd), 
                        LiteralExpr (Int c)) 
          | AssignExpr (FieldLvalue (VarExpr (RefLvalue x), fd), 
                        LiteralExpr (Int c)) ->
                          inc "assignment of const to field" (get_assign_fn x fd c) f
          | AssignExpr (FieldLvalue (VarExpr (LocalLvalue x), fd), 
                        LiteralExpr (Bool b))
          | AssignExpr (FieldLvalue (VarExpr (RefLvalue x), fd), 
                        LiteralExpr (Bool b)) ->
                          inc "assignment of bool to field" (get_assign_fn x fd 
                            (if b then 1 else 0)) f
          | AssignExpr (FieldLvalue (VarExpr (LocalLvalue x), fd), 
                        VarExpr (LocalLvalue y)) 
          | AssignExpr (FieldLvalue (VarExpr (RefLvalue x), fd), 
                        VarExpr (LocalLvalue y)) ->
                          let yt = fetch_type y in
                          if (yt = TBool) then 
                            let a1 = BA.mk_and [BA.Atom (BA.Propvar y);
                                             (get_assign_fn x fd 1)] in
                            let a2 = BA.mk_and [BA.Not (BA.Atom (BA.Propvar y));
                                             (get_assign_fn x fd 0)] in
                            inc "assignment to field" (BA.Or [a1; a2]) f
                          else f
          | AssignExpr (FieldLvalue (VarExpr (LocalLvalue x), fd), _)
          | AssignExpr (FieldLvalue (VarExpr (RefLvalue x), fd), _) ->
              inc "unknown assignment to field" (get_assign_fn_unknown x fd) f
            (* x = foo() *)
          | AssignExpr (LocalLvalue lhs, InvokeExpr (p, actuals)) -> 
              if Intrinsics.is_intrinsic p then f else (* not quite right *)
              (* it's not wrong because intrinsics aren't set-active,
               * but should probably be fixed sometime. *)
              (* also should support local calls by inlining, 
               * without need for spec. *)
              let callee = Ast.fetch_spec_proc 
                  p.Id.p_name (Ast.fetch_spec p.Id.p_module) in
              let rv = match callee.Sabsyn.ret_val with 
                None -> failwith "assigning from retval of a void fn"
              | Some x -> x in
              let rv_type = snd rv in
              let apply_bool_subst f = 
                if (rv_type = TBool) then 
                  BA.subst_propvar [(primed (fst rv), BA.Propvar (primed lhs));
                                    (fst rv, BA.Propvar (primed lhs))] f
                else f in
              let rv_subst = 
                if (is_primitive_value_type rv_type) then []
                else [(primed (fst rv), BA.Var (primed lhs)); 
                      (fst rv, BA.Var (primed lhs))] in
              let rv_names = [lhs] in
              analyze_invoke apply_bool_subst rv_subst rv_names p actuals f
            (* uncaught assignments *)
          | AssignExpr (LocalLvalue lhs, rhs) -> 
              if (rhs = LiteralExpr null_obj) then
                inc "local gets null" (set_v_to_null lhs) f
              else
                (let f0 = explicit_bool lhs rhs in
                match f0 with
                | Some ef ->
                    let fram = frame_except_d all_sb [lhs] in
                    let f1 = BA.mk_and [ef; fram] in
                    inc "assignment of bool to local" f1 f
                | None -> 
                    (match rhs with 
                    | NotExpr (VarExpr (LocalLvalue b)) ->
                        inc "assignment to bool" (b'_gets_not_b (BA.Atom (BA.Propvar (primed lhs)))
                               (BA.Atom (BA.Propvar b))) f
                    | _ -> (let t = fetch_type lhs in
                      match t with
                      | TBool ->
                          let (fp, fm) = compute_if_cond rhs in
                          let lp = BA.Atom (BA.Propvar (primed lhs)) in
                          inc "assignment to bool" (BA.mk_and 
                                 [BA.mk_iff (lp, fp); 
                                  BA.mk_iff (BA.Not lp, fm);
                                  frame_except_d all_sb [lhs]]) f
                      | TObj _ ->
                          if (BA.occurs (primed lhs) f) then
                            (* if we don't do that check, we explode *)
                            let fram = frame_except_d all_sb [lhs] in
                            inc "assignment" fram f
                          else f
                      | _ -> f)))
          | AssignExpr (RefLvalue lhs0, rhs) ->
              (let t = snd (List.find (fun x -> fst x = lhs0) mi.references) in
              match t with
              | TBool ->
                  let lhs = 
                    Util.qualify_if_needed ms.Sabsyn.module_name lhs0 in
                  if (BA.occurs (primed lhs) f) then
                    (* if we don't do that check, we explode *)
                    let fram = frame_except_d all_sb [lhs] in
                    (* could also use compute_if_cond, which is stronger *)
                    (let f0 = explicit_bool lhs rhs in
                    match f0 with
                    | Some ef ->
                        let f1 = BA.mk_and [ef; fram] in
                        inc "assignment" f1 f
                    | None -> inc "assignment" fram f)
                  else f
              | _ -> f)
          | AssignExpr (ArrayLvalue _, _) -> f
          | InvokeExpr (p, actuals) -> 
              if Intrinsics.is_intrinsic p then f else
              (* hide return value if appropriate *)
              let callee = Ast.fetch_spec_proc 
                  p.Id.p_name (Ast.fetch_spec p.Id.p_module) in
              let apply_bool_subst f =
                match callee.Sabsyn.ret_val with
                | Some (rvn, TBool) -> 
                    BA.mk_existsProp ([primed rvn; rvn], f)
                | _ -> f in
              analyze_invoke apply_bool_subst [] [] p actuals f
            (* inc, dec *)
          | PreIncExpr lv | PostIncExpr lv
          | PreDecExpr lv | PostDecExpr lv -> 
              (match lv with 
              | FieldLvalue (VarExpr (LocalLvalue x), fd) -> 
                  inc "post/pre inc/dec" (get_assign_fn_unknown x fd) f
              | FieldLvalue _ -> failwith "unjimplified"
              | _ -> f)
          | _ -> print_string "punting an expr!\n"; BA.Atom BA.True)
      | ReturnStmt None -> 
          extra_results := f :: !extra_results; 
          BA.Atom BA.False
      | ReturnStmt Some expr -> 
          (match ps.Sabsyn.ret_val with None -> failwith "no retval" 
          | Some (rv, _) ->
              let f' = analyze_stmt f 
                  (ExprStmt (AssignExpr (LocalLvalue rv, expr))) in
              extra_results := f' :: !extra_results; BA.Atom BA.False)
      | WhileStmt (inv0, expr, body) -> 
          (match inv0 with
            Some inv1 -> 
              Util.msg "Verified loop invariant.";
              let inv = BA.mk_and ((BA.ba_of_sabsyn 
                                   (Sabsyn.And 
                                      [inv1; ps.Sabsyn.frame_cond])) :: 
                                (!derived_set_defns)) in
              let (fplus, fminus) = handle_if_cond expr inv in
              let inv' = analyze_stmt fplus body in begin
                enforce_impl ("prestate must imply loop invariant:\n" ^ 
                              BA.MONA.form_to_mona inv) f inv;
                enforce_impl ("preservation of loop invariant:\n" ^
                              BA.wrap (BA.MONA.form_to_mona inv') ^ "\n ==>\n" ^
                              BA.wrap (BA.MONA.form_to_mona inv)) inv' inv;
                BA.mk_and ((BA.ba_of_sabsyn 
                              (Sabsyn.And 
                                 [inv1; ps.Sabsyn.frame_cond])) :: fminus ::
                           (!derived_set_defns)) 
              end
          | None -> analyze_while expr body f)
      | AssertStmt (n, a) -> 
          begin
            let nm = match n with Some s -> s | None -> "" in
            enforce_impl ("assertion " ^ nm) f (BA.ba_of_sabsyn a);
            f
          end
      | AssumeStmt (n, a) -> 
          let ba = BA.ba_of_sabsyn a in
          Util.amsg ("[typestate] making the assumption: " ^ 
                     (BA.MONA.form_to_mona ba)^".\n");
          BA.mk_and [f; ba]
      | PragmaStmt s -> (* ignore pragmas *)
          Format.printf "Warning: ignoring pragma %s\n" s; f
      | IfStmt (expr, then_cond, else_cond) -> 
          let (fplus, fminus) = handle_if_cond expr f in
          BA.mk_optimized_or
            [(analyze_stmt fplus then_cond);
             (analyze_stmt fminus else_cond)]) in
    let req = (BA.ba_of_sabsyn ps.Sabsyn.requires) in
    let initial_fact = to_relation all_sb req in
    let ens = (BA.ba_of_sabsyn ps.Sabsyn.ensures) in try begin
      print_string ("Analyzing proc " ^ p ^ "... "); flush_all ();
      extra_results := [];
      let primary_result = analyze_stmt initial_fact pi.proc_body in
      (match pi.ret_val with
      | None ->
          BA.MONA.log "Checking ensures clause...";
          enforce_impl "procedure end ensures clause" 
            primary_result ens
      | Some _ -> 
          if (primary_result != BA.Atom BA.True) then
            Util.err "[proc]" "apparently falling off the end of a non-void proc");
      if (!extra_results <> []) then
        BA.MONA.log "Checking additional ensures clauses...";
      List.iter (fun e -> enforce_impl "return statement additional ensures clause" e ens) !extra_results;
      Printf.printf "Procedure %s passes.\n" p;
      true
    end with Impl_failed -> begin
      Printf.printf "Procedure %s fails.\n" p;
      false
    end
        (* end of analyze_proc *)
  in 
  let results = List.map (fun mm -> analyze_proc mm.Sabsyn.proc_name.Id.p_name) ms.Sabsyn.procs in
  let truth = List.fold_left (fun x y -> x & y) true results in
  if (!Util.verbose) then BA.print_stats ();
  truth
