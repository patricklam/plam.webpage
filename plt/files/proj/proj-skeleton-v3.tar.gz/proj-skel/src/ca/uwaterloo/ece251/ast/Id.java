package ca.uwaterloo.ece251.ast;

/** Represents an identifier. These go into symbol tables. */
public class Id {
    String s;

    public Id(String s) { this.s = s; }
    public String toString() { return s; }
}
