package ca.uwaterloo.ece251.ast;

import java.util.*;

public class UpdateStmt extends Stmt {
    QualifiedTableName tn;
    List<IdExprPair> sets;
    Expr where;

    public UpdateStmt(QualifiedTableName tn, List<IdExprPair> sets, 
		      Expr where) {
	this.tn = tn; this.sets = sets; this.where = where;
    }

    public void accept(Visitor v) {
	v.enter(this);
	for (IdExprPair p : sets)
	    p.accept(v);
	where.accept(v);
	v.leave(this);
    }
}

