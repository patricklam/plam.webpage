package ca.uwaterloo.ece251.symbol;

import ca.uwaterloo.ece251.ast.*;
import ca.uwaterloo.ece251.Error;
import java.util.Iterator;

/** Creates a Symbol for each defined name.
 * Throws an error in the event of a multiply-defined name. */
public class SymbolDefVisitor extends DefaultVisitor {
    public SymbolDefVisitor() {
    }

    /** Introduce HTML h into symbol table. */
    public void enter(HTML h) {
	st.insert(h);
    }

    // More enter, leave functions go here.
}
