SELECT * FROM Persons WHERE FirstName='Tove';
