// Dust.java
//
// Author: Raja Vallee-Rai
//
// This file is public domain.  You can do anything you want with 
// it, all at your own risk.  Enjoy!

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

import kor.base.*;

/**
 * Frame which contains the playfield canvas and the main menu bar.  
 * Instantiating the Dust object starts the applicatoin.
 */

class Dust extends Frame
{
    DustGO parent;
    Playfield playfield;
    PlayfieldControls controls;

    public Dust()
    {
        this(null);
    }
    
    public Dust(DustGO parent)
    {
        super("Dust");
        setSize(new Dimension(500, 480));
        
        this.parent = parent;
        
        playfield = new Playfield();

        MenuBar bar = new MenuBar();
                
        controls = new PlayfieldControls(playfield, bar, this);
        PlayfieldViewer v = new PlayfieldViewer(playfield);

        setMenuBar(bar);
        
        setLayout(new BorderLayout());
        
        add(v, "Center");
        add(controls, "East");
        
        WindowPlacer.placeWindowAt(this, "Center");
        addWindowListener(controls);
        setVisible(true);

        playfield.controls.lessonControl.setVisible(true);
        playfield.controls.lessonControl.toFront();

        playfield.controls.lessonControl.startLesson("Lessons" + File.separator, 
            "Lesson00-WelcomeToDust");        
    }

    public void stop()
    {
        dispose();
        controls.disposeAssociatedFrames();
        playfield.disposeViewers();

        if(parent == null)
            System.exit(0);
        else
            parent.stop();
    }
}






