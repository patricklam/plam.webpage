// BoundaryControl.java
//
// Author: Raja Vallee-Rai
//
// This file is public domain.  You can do anything you want with 
// it, all at your own risk.  Enjoy!

import kor.base.*;
import java.awt.event.*;
import java.awt.*;

/**
 * This is a frame which controls the use of the boundary and its size.
 */

class BoundaryControl extends Frame implements WindowListener, 
                                           ActionListener,
                                           AdjustmentListener,
                                           ItemListener
{
    static final int INITIAL_RADIUS = 8,
                     MAX_RADIUS = 100,
                     MIN_RADIUS = 3;

    Label radiusLabel;
    Scrollbar radiusBar;

    Button dismissButton;

    Playfield playfield;
    private double boundaryRadius;

    private Checkbox boundaryBox;
    private Checkbox displayBox;
            
    public BoundaryControl(Playfield playfield)
    {
        super("Boundary Control");
        
        this.playfield = playfield;
        
        addWindowListener(this);            
        setSize(new Dimension(300, 200));
        setLayout(new BorderLayout());

        WindowPlacer.placeWindowAt(this, "South");

        // topPanel
        {
            Panel topPanel = new Panel();
            
            topPanel.setLayout(new GridLayout(0, 1));

            // Radius bar
            {
                radiusLabel = new Label("Magnification");
                radiusBar = new Scrollbar(Scrollbar.HORIZONTAL, INITIAL_RADIUS, 1, MIN_RADIUS, 
                    MAX_RADIUS);
                
                radiusBar.setBlockIncrement(10);
                radiusBar.setUnitIncrement(1);
                radiusBar.addAdjustmentListener(this);
                
                topPanel.add(radiusLabel);
                topPanel.add(radiusBar);
                
                updateBoundaryRadiusAndLabel();
            }
            
            // Boundary box
            {
                Panel p = new Panel();

                p.setLayout(new FlowLayout());
                
                boundaryBox = new Checkbox("Enable Boundary", false);
                p.add(boundaryBox);
        
                boundaryBox.addItemListener(this);
                
                displayBox = new Checkbox("Display Boundary", true);
                p.add(displayBox);

                displayBox.addItemListener(this);
                        
                topPanel.add(p);
            }
            
        
            // DismissButton
            {
                Panel p = new Panel();
                
                p.setLayout(new FlowLayout());
                
                dismissButton = new Button("Dismiss");
                p.add(dismissButton);
                dismissButton.addActionListener(this);
                
                topPanel.add(p);
            }
                        
            add(topPanel, "Center");
        }
    }
    
    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource() == dismissButton)
        {
            handleClickToClose();
        }
    }
    
    public void itemStateChanged(ItemEvent e)
    {
        if(e.getSource() == displayBox || e.getSource() == boundaryBox)
            playfield.refreshViewers();
    }

    public double boundaryRadius()
    {
        return boundaryRadius;
    }

    public void setUseBoundary(boolean value)
    {
        boundaryBox.setState(value);
        
        // no need to refresh (or pause simulation) because this is only called while 
        // restoring the state which does those things
    }

    public void setBoundaryRadius(double value)
    {
        int adjusted = (int) value;
        
        adjusted = Math.min(adjusted, MAX_RADIUS);
        adjusted = Math.max(adjusted, MIN_RADIUS);
        
        radiusBar.setValue(adjusted);
        updateBoundaryRadiusAndLabel();
        
        // no need to refresh (or pause simulation) because this is only called while 
        // restoring the state which does those things
    }
    
    public boolean useBoundary()
    {
        return boundaryBox.getState();
    } 
    
    public boolean displayBoundary()
    {
        return displayBox.getState();
    }
    
    public void adjustmentValueChanged(AdjustmentEvent e)
    {
        if(e.getSource() == radiusBar)
        {
            playfield.stopSimulatingIfNecessary();
               
            updateBoundaryRadiusAndLabel();
            playfield.refreshViewers();
            playfield.updateForces();

            playfield.restartSimulatingIfNecessary();
        }
    }

        
    private
    void updateBoundaryRadiusAndLabel()
    {
        boundaryRadius = radiusBar.getValue();
        radiusLabel.setText("Boundary Radius: " + ExtDouble.truncatedOf(boundaryRadius, 2));
    }
        
    void handleClickToClose()
    {
        setVisible(false);
    }

    public void windowClosing(WindowEvent e)
    {
        handleClickToClose();
    }
     
    public void windowOpened(WindowEvent e)
    {
    }
     
    public void windowIconified(WindowEvent e)
    {
    }
     
    public void windowDeiconified(WindowEvent e)
    {
    }
     
    public void windowClosed(WindowEvent e)
    {
    }
     
    public void windowActivated(WindowEvent e)
    {
    }
     
    public void windowDeactivated(WindowEvent e) 
    {
    }
}


