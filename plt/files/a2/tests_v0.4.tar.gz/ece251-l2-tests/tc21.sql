SELECT * FROM table_1 AS entries;
