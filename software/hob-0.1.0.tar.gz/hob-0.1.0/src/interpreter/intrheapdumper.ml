open Iabsyn
open Intrheap

let dump_counter = ref 0
let fresh_counter () = 
  let q = !dump_counter in dump_counter := q + 1; q

let dump (file : string) (comment : string) 
    (roots : (value * string) list) =
  let get_obj_label n =
    let rec collect (v,s) l = if (v=n) then s::l else l in    
    let labels = List.fold_right collect roots [] in    
    (match n with 
    | Obj o -> 
        Printf.sprintf " [label=\"%s #%d\"]" 
          (String.concat "," labels) o
    | _ -> failwith "object expected in heap dumper!") in
  let rec dump_node seen fd what =
    if not (Hashtbl.mem seen what) then begin
      (match what with
      | Obj 0 ->
          Hashtbl.add seen what true;
          Printf.fprintf fd "\t0 %s\n" (get_obj_label what)
      | Obj id -> 
          Hashtbl.add seen what true;
          Printf.fprintf fd "\t%d %s\n" id (get_obj_label what);
          let fds = get_fields what in
          let processField field obj =
            match obj with
            | Obj id' -> 
                if not (Hashtbl.mem seen obj) then 
                  begin
                    dump_node seen fd obj
                  end;
                Printf.fprintf fd "\t%d -> %d [label=%s]\n" 
                  id id' (Id.name_of_field field)
            | Int i ->
                Printf.fprintf fd "\t%d -> INT_%d_%d [label=%s]\n"
                  id id i (Id.name_of_field field);
                Printf.fprintf fd "\tINT_%d_%d [label=%d]\n"
                  id i i
            | String s ->
                Printf.fprintf fd "\t%d -> STRING_%d_%s [label=\"%s\"]\n"
                  id id (Id.name_of_field field) (Id.name_of_field field);
                Printf.fprintf fd "\tSTRING_%d_%s [label=\"\\\"%s\\\"\"]\n"
                  id (Id.name_of_field field) s
            | _ -> ()
          in Hashtbl.iter processField fds
      | _ -> failwith "visited non-Obj")
    end in
  let dump_nodes seen f worklist = 
    List.iter (dump_node seen f) worklist in
  let c = fresh_counter () in
  let fn = Format.sprintf "%s.%03d.dot" file c in
  let f = open_out fn in
  Printf.fprintf f "digraph %s {\n" file;
  Printf.fprintf f "{size = \"2,3\";\"%s\" [shape=box, fontsize=10];}\n" comment;
  let seen = Hashtbl.create 10 in
  dump_nodes seen f (List.map (fun (v,s) -> v) roots);
  Printf.fprintf f "}\n";
  close_out f
