open Iabsyn

(**************************************************************)
(* Some general-purpose functions                             *)

let unsome : 'a option -> 'a = 
function
  | Some x -> x
  | None   -> failwith "tried to deoptionify None"

(**************************************************************)

let speclist = [("-v", Arg.Set Util.verbose, "Verbose; display verbose debugging messages.")]
let source_names = ref []

let _ =
  let usage_msg=("Usage:\n  "^Sys.argv.(0)^" [-v] [-d] <input filenames>\n") in
  Arg.parse speclist (fun x -> source_names := x :: !source_names) usage_msg;
  if List.length !source_names = 0 then 
    begin Arg.usage speclist usage_msg; exit 1 end;
  Uglyast.impl_ast := Uglyast.parse_impl_asts !source_names;
  let impl_module_names = Uglyast.fetch_impl_module_names !Uglyast.impl_ast in
  Ast.impl := List.map 
      (fun x -> Deuglifyimpl.convert (Uglyast.fetch_impl_module x)) 
      impl_module_names;
  Ast.impl := Util.phase "Instantiating templates" 
      (List.map (Itrans.instantiate_templates true)) !Ast.impl;
  let r = Typechecker.declaration_checker true !Ast.impl in
  Ast.impl := Util.phase "Local-ref conversion " 
      List.map (Itrans.transform_local_to_ref_lvalues r) !Ast.impl;
  Intrheap.create_module_envs !Ast.impl;
  Assembler.populate_format_definitions !Eval.format_defs;
  Util.phase "Typechecking" Typechecker.verify !Ast.impl;
(* nah, we don't need to jimplify before interpreting;
 *  probably faster not to. *)
(*   Ast.impl := Util.phase "Jimplifying"  *)
(*       (List.map Itrans.jimplify) !Ast.impl; *)
  Ast.impl := Util.phase "Pulling up locals" 
      (List.map Itrans.pull_up_locals) !Ast.impl;
  Util.phase "Recomputing jimplified types" Typechecker.verify !Ast.impl;

  let main_proc = Id.fetch_proc Id.main_module "main" in
  if not (Ast.has_impl Id.main_module) or 
    not (Ast.has_impl_proc "main" (Ast.fetch_impl Id.main_module)) then
    failwith "Couldn't find proc Main.main!";
  let main_ast = Ast.fetch_impl_proc "main" (Ast.fetch_impl Id.main_module) in
  let main_env = 
    ("args", Array [||]) ::
    (Intrheap.create_environment_for_proc main_proc main_ast) in
  let main_stmt = main_ast.proc_body in
  if not (Util.no_errors ()) then
    begin Util.print_errors (); exit 1 end;
  Util.msg "Interpreting.\n";
  (try (ignore (Eval.eval [main_env] main_stmt); null_obj) with
        Eval.Eval_return (Some rv) -> rv
      | Eval.Eval_return None -> null_obj)
