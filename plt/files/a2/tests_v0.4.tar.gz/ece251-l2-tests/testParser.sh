#!/bin/bash

echo
echo "ECE251"
echo "SQL Lexer Tester v0.4"
echo "Wed Nov 4 22:14 EDT 2010"
cho "---------------------------"
echo "Note: Pass your classpath as an argument (ex. testParser.sh /home/mehdi/A2-ece251/bin/)."
echo "      Fell free to modify the paths."
echo

passed=0
failed=0

if [ ! -d output ]; then
   echo "Creating output folder"
   mkdir output
fi

echo
echo "Phase 1: Testing SQL Parser..."
echo

for sql in *.sql
do
   output=output/${sql%.*sql}.out

   echo "Testing ${sql}"
   java -classpath $1 ca.uwaterloo.ece251.ParserDriver $sql > $output
done

echo
echo "Phase 2: Evaluating SQL Parser..."
echo

for output in output/*
do
   expected=expected${output#output}
   if `diff -b -w ${expected} ${output} > /dev/null`
      then
         echo "[PASSED] $output Vs. $expected"
            passed=$((passed+1))
       else
         echo "[FAILED] $output Vs. $expected"
            failed=$((failed+1))
    fi
done

tests=$((passed+failed))
result=$(($passed * 100 / $tests))
# result=`echo "scale=2; 100 * $passed / ($passed+$failed)" | bc -l`
echo "Result: $passed/$tests ($result%) of test cases passed"
