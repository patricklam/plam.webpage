package ca.uwaterloo.ece251;

import java.io.*;
import java.util.regex.*;
import java.util.*;

/** Implement list-typed values. May contain AtomValues. */
public class ListValue implements Value {
  List<AtomValue> contents;

  public ListValue(File f) 
  {
    AtomValue.Type listType = AtomValue.Type.INT;

    contents = new ArrayList<AtomValue>();
    try {
      BufferedReader ir = 
        new BufferedReader(new InputStreamReader
                           (new FileInputStream(f)));
      String l = null;
      while ((l = ir.readLine()) != null) {
        AtomValue val = new AtomValue(l);
              

        if (listType == AtomValue.Type.STRING) {
          val.t = AtomValue.Type.STRING;
        }
        if (listType == AtomValue.Type.INT && val.t == AtomValue.Type.STRING) {
          Iterator<AtomValue> it = contents.iterator();
          while (it.hasNext()) {
	    AtomValue fixMe = it.next();
            fixMe.t = AtomValue.Type.STRING;
          }
          listType = AtomValue.Type.STRING;
        }
        
        contents.add(val);
      }
      ir.close();
    } catch (IOException e) {
    }
  }

  ListValue()
  {
    contents = new ArrayList<AtomValue>();
  }

  public void write(String fn) 
  {
    try {
      new File(OUTPUT_DIR).mkdir();
      Writer w = new FileWriter(OUTPUT_DIR + fn+".txt");
      for (AtomValue l : contents)
      w.write(l.toString()+"\n");
      w.close();
    } catch (IOException e) {
    }
  }

  public void print() 
  {
    System.out.println(toString());
  }

  public String toString()
  {
    StringBuffer sb = new StringBuffer("[");
    Iterator<AtomValue> it = contents.iterator();
    while (it.hasNext()) {
      AtomValue s = it.next();
      sb.append(s.toString());
      if (it.hasNext()) sb.append(", ");
    }
    sb.append("]");
    return sb.toString();
  }

  public Value sort(Expr.Comparator c) 
  {
    switch (c) {
    case ASCENDING:
      Collections.sort(contents, new Comparator<Value>() { 
          public int compare(Value v1, Value v2) {
            return v1.compare(v2);
          }
        });
      break;
    case DESCENDING:
      Collections.sort(contents, new Comparator<Value>() { 
          public int compare(Value v1, Value v2) {
            return v2.compare(v1);
          }
        });
      break;
    }
    return this; 
  }

  public Value map(Expr.Transformer t) 
  { 
    List<AtomValue> newContents = new LinkedList<AtomValue>();
    for (Value l : contents) {
      newContents.add(l.map(t));
    }
    ListValue tc = (ListValue) this.clone();
    tc.contents = newContents;
    return tc; 
  }

  public Value filter(Expr.Filter f)
  {
    List<AtomValue> newContents = new LinkedList<AtomValue>();
    for (Value l : contents) {
      if (l instanceof AtomValue) {
        if (((AtomValue)l).satisfies(f))
        newContents.add((AtomValue)l);
      } else {
        // bonus (to handle lists of lists), not currently correct.
        newContents.add((AtomValue)l.filter(f));
      }
    }
    contents = newContents;
    return this;
  }

  public Value reduce(Expr.Accumulator a)
  {
    AtomValue rv = null;
    int s = 0;
    switch (a) {
    case SUM:
      s = 0;
      for (AtomValue av : (List<AtomValue>)contents) {
        s += av.intVal;
      }
      rv = new AtomValue(Integer.toString(s));
      break;
    case AVG:
      s = 0;
      for (AtomValue av : (List<AtomValue>)contents) {
        s += av.intVal;
      }
      s /= contents.size();
      rv = new AtomValue(Integer.toString(s));
      break;
    case COUNT:
      rv = new AtomValue(Integer.toString(contents.size()));
      break;
    case CONCAT:
      StringBuffer sb = new StringBuffer();
      for (AtomValue av : (List<AtomValue>)contents) {
        if (av.t == AtomValue.Type.INT) {
          sb.append(Integer.toString(av.intVal));
        }
        else {
          sb.append(av.stringVal);
        }
      }
      rv = new AtomValue(sb.toString());
      break;
    }
    return rv;
  }

  public Value traverse(Expr.Order o)
  {
    // traversal of a list is just a list itself
    return this;
  }

  public Value truncate(int v)
  {
    int vv = v;
    if (vv > contents.size()) vv = contents.size();
    List<AtomValue> newContents = 
      new ArrayList<AtomValue>(contents.subList(0, vv));
    contents = newContents;
    return this;
  }

  public int compare(Value v)
  {
    return 0;
  }

  public Object clone() 
  {
    ListValue lv = new ListValue();
    for (Value v : contents)
    {
      lv.contents.add((AtomValue)v.clone());
    }
    return lv;
  }
}
