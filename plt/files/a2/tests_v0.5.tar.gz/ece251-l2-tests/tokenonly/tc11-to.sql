SELECT employee.* FROM employee INNER JOIN department ON employee.DepartmentID = department.DepartmentID;
