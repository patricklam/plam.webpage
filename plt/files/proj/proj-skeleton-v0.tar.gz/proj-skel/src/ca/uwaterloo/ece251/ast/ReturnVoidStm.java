package ca.uwaterloo.ece251.ast;

/** Represents a return-void statement. */
public class ReturnVoidStm extends Stm {
    public ReturnVoidStm() { }
    public String toString() { return "return;"; }
}

