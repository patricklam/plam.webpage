package ca.uwaterloo.ece251;

/** AST representation of a "map" expression. */
public class MapExpr implements Expr {
    Expr.Transformer t;
    Expr v;

    public MapExpr(Expr.Transformer t, Expr v) {
	this.t = t; this.v = v;
    }

    public Value eval(Interp interp) {
	Value arg = v.eval(interp);
	return arg.map(t);
    }
}