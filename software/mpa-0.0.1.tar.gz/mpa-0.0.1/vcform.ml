(* currently not enforced *)
type typeExpr = 
    TypeObjRef of string
  | TypeArray of typeExpr
  | TypeSet of typeExpr
  | TypeList of typeExpr
  | TypeFun of (typeExpr list * typeExpr)
  | TypeInt
  | TypeBool
  | TypeVoid
  | TypeUniverse (* must go away eventually! *)

type constValue =
    Eq | Sub | Elem | Or | And | Not | Impl | Iff | Disjoint
  | Lt | Gt | LtEq | GtEq (* integer comparisons *)
  | Cardeq | Cardleq | Cardgeq (* set card constrs *)
  | ArrayRead | ArrayWrite | NewArray (* arrays *)
  | Cap | Cup | Diff (* sets *)
  | Plus | Minus | Mult | Div | Mod 
  | IntConst of int | BoolConst of bool | NullConst | EmptysetConst 

let string_of_const (c:constValue) = match c with
| Eq -> "=" | Sub -> "<="  | Elem -> ":"
| Or -> "|" | And -> "&" | Not -> "~" | Impl -> "-->" | Iff -> "="
| Disjoint -> "disjoint"
| Lt -> "<" | Gt -> ">" | LtEq -> "<=" | GtEq -> ">="
| Cardeq -> "Cardeq" | Cardleq -> "Cardleq" | Cardgeq -> "Cardgeq"
| ArrayRead -> "arrayRead" | ArrayWrite -> "arrayWrite" | NewArray -> "newArray"
| Cap -> "Int" | Cup -> "Un" | Diff -> "-" 
| Plus -> "+" | Minus -> "-" | Mult -> "*" | Div -> "div" | Mod -> "mod"
| IntConst k -> Printf.sprintf "%d" k
| BoolConst true -> "true" | BoolConst false -> "false"
| NullConst -> "null" | EmptysetConst -> "{}"

type ident = string
type typedVarIdent = ident * typeExpr

type binderKind =
  | Forall
  | Exists
  | Lambda
  | Comprehension

type form =
    App of form * form list (* fst must be function-typed *)
  | Var of ident
  | Binder of binderKind * (typedVarIdent list) * form
  | Const of constValue

type sequent = form list * form

(* variable-binding environments e.g. used in vc gen *)

(* let x = v in exp *)
type env = (typedVarIdent * form option) list

(* v....... preamble ...........v   v........ haveEnv(x) ...... *)
(* exists i1, ..., in. pre(x0,y0) & (x = f(x0, y0, i1, ..., in)) & 
                                    (y = g(x0, y0, i1, ..., in)) &
            constraint(x0, y, i1, ..., in) *)
         (* ^~~~~~~~~~ haveBody ~~~~~~~~~^ *)

type haveForm = {preamble:form; haveEnv: env; haveBody: form}

(* also have a global list of const binders *)
(* use this for type checking *)

type constBinding = (constValue * typeExpr) list
let globalEnv : constBinding = 
  [(And, TypeFun ([TypeBool; TypeBool], TypeBool));
   (Or, TypeFun ([TypeBool; TypeBool], TypeBool));
   (Impl, TypeFun ([TypeBool; TypeBool], TypeBool));
   (Iff, TypeFun ([TypeBool; TypeBool], TypeBool));
   (Not, TypeFun ([TypeBool], TypeBool));
   (Eq, TypeFun ([TypeUniverse; TypeUniverse], TypeBool));
   (Sub, TypeFun ([TypeUniverse; TypeUniverse], TypeBool));
(* integer stuff *)
   (Lt, TypeFun ([TypeInt; TypeInt], TypeBool));
   (LtEq, TypeFun ([TypeInt; TypeInt], TypeBool));
   (Gt, TypeFun ([TypeInt; TypeInt], TypeBool));
   (GtEq, TypeFun ([TypeInt; TypeInt], TypeBool));
(* arrays *)
   (ArrayRead, TypeFun ([TypeArray TypeUniverse; TypeInt], TypeUniverse));
   (ArrayWrite, TypeFun ([TypeArray TypeUniverse; 
                          TypeInt; 
                          TypeArray TypeUniverse], TypeUniverse));
   (NewArray, TypeFun ([TypeInt; TypeUniverse], TypeArray TypeUniverse));
(* need set types, like array types I guess, but should also be recursive *)
(* should also be capable of taking many arguments *)
   (Cup, TypeFun ([TypeList TypeUniverse], 
                  TypeSet TypeUniverse)); 
   (Cap, TypeFun ([TypeList TypeUniverse], 
                  TypeSet TypeUniverse));
   (Diff, TypeFun ([TypeSet TypeUniverse; TypeSet TypeUniverse], 
                  TypeSet TypeUniverse))]
(* also cardeq, cardleq, cardgeq, disjoint *)

let mk_true = Const (BoolConst true)
let mk_false = Const (BoolConst false)
let mk_int k = Const (IntConst k)
let mk_not f = App ((Const Not), [f])
let mk_and cs = App ((Const And), cs)
let mk_or ds = App ((Const Or), ds)
let mk_eq (lhs, rhs) = App ((Const Eq), [lhs; rhs])
let mk_sub (lhs, rhs) = App ((Const Sub), [lhs; rhs])
let mk_lt (lhs, rhs) = App ((Const Lt), [lhs; rhs])
let mk_gt (lhs, rhs) = App ((Const Gt), [lhs; rhs])
let mk_lteq (lhs, rhs) = App ((Const LtEq), [lhs; rhs])
let mk_gteq (lhs, rhs) = App ((Const GtEq), [lhs; rhs])
let mk_impl (lhs, rhs) = App ((Const Impl), [lhs; rhs])
let mk_iff (lhs, rhs) = App ((Const Iff), [lhs; rhs])
let mk_forall(v,t,f) = Binder(Forall,[(v,t)],f)
let mk_foralls(vts,f) = Binder(Forall,vts,f)
let mk_var v = Var v

let mk_arrayRead(arr,ind) = App(Const ArrayRead,[arr;ind])
let mk_arrayWrite(arr,ind,vl) = App(Const ArrayWrite,[arr;ind;vl])
let mk_newArray(size,fill) = App(Const NewArray,[size;fill])

let mk_null = Const NullConst

let mk_plus (lhs, rhs) = App ((Const Plus), [lhs; rhs])
let mk_minus (lhs, rhs) = App ((Const Minus), [lhs; rhs])
let mk_mult (lhs, rhs) = App ((Const Mult), [lhs; rhs])
let mk_div (lhs, rhs) = App ((Const Div), [lhs; rhs])
let mk_mod (lhs, rhs) = App ((Const Mod), [lhs; rhs])

(* **************************************** *)
(*       free variables of a formula        *)
(* **************************************** *)

let fv (f:form) = 
  let add v bv acc = 
    if (List.mem v bv) || (List.mem v acc) 
    then acc
    else v::acc in
  let rec fv1 f bv acc = match f with
  | App(f1,fs) -> fv1 f1 bv (fv_list fs bv acc)
  | Binder(_,tvs,f1) -> fv1 f1 (List.rev_append (List.map fst tvs) bv) acc
  | Var v -> add v bv acc
  | Const _ -> acc
  and fv_list fs bv acc = match fs with
  | [] -> acc
  | f::fs1 -> fv_list fs1 bv (fv1 f bv acc)
in fv1 f [] []

(* **************************************** *)
(*       substitution                       *)
(* **************************************** *)

type substMap = (ident * form) list

let rec subst (m:substMap) (f:form) : form = 
  if m=[] then f else match f with
  | App(f1,fs) -> App(subst m f1, List.map (subst m) fs)
  | Binder(k,tvs,f1) -> 
      let not_bound (id,f) = not (List.mem_assoc id tvs) in
      let m1 = List.filter not_bound m in
      Binder(k,tvs,subst m1 f1)
  | Var v -> (try List.assoc v m with Not_found -> f)
  | Const _ -> f

(* **************************************** *)
(*       priming                            *)
(* **************************************** *)

let primed id = id^"'"

let prime_all (f:form) : form =
  let ids = fv f in
  let mk_primed id = (id,Var (primed id)) in
  subst (List.map mk_primed ids) f

(* **************************************** *)
(*       priming                            *)
(* **************************************** *)

let unprimed id =
  let len = String.length id in
  if (len > 0) && id.[len - 1] = '\'' then String.sub id 0 (len - 1)
  else id

let unprime_all (f:form) : form =
  let ids = fv f in
  let mk_unprimed id = (id,Var (unprimed id)) in
  subst (List.map mk_unprimed ids) f

(* **************************************** *)
(*             smart constructors           *)
(* **************************************** *)

let smk_forall (x,t,f) = 
  if List.mem x (fv f) then mk_forall(x,t,f)
  else f

let smk_foralls (xts,f) = 
  let fvs = fv f in
  let isfree (x,t) = List.mem x fvs in
  let useful = List.filter isfree xts in
  if useful=[] then f else mk_foralls(useful,f)

let smk_and fs = 
  let set_insert x xs = if List.mem x xs then xs else x::xs in
  let rec mkand1 fs acc = match fs with
  | [] -> (match acc with
    | [] -> Const (BoolConst true)
    | [f] -> f
    | _ -> mk_and acc)
  | App(Const And,fs0) :: fs1 -> mkand1 (List.rev_append fs0 fs1) acc
  | Const (BoolConst true)::fs1 -> mkand1 fs1 acc
  | Const (BoolConst false)::fs1 -> Const (BoolConst false)
  | fs::fs1 -> mkand1 fs1 (set_insert fs acc)
in mkand1 fs []

let smk_impl(f1,f2) = 
  match f1 with
  | Const (BoolConst false) -> Const (BoolConst true)
  | Const (BoolConst true) -> f2
  | _ -> (match f2 with
    | App(Const Impl,[f2a;f2b]) -> mk_impl(smk_and [f1;f2a], f2b)
    | Const (BoolConst false) -> mk_not f1
      | Const (BoolConst true) -> f2
      | _ -> mk_impl(f1,f2))

(* **************************************** *)
(*             simplification               *)
(* **************************************** *)

let rec simplify (f:form) = match f with
| App(f1,[]) -> simplify f1
| App(Const And,fs) -> smk_and (List.map simplify fs)
| App(Const Impl,[f1;f2]) -> smk_impl(simplify f1, simplify f2)
| Binder(Forall,vts,f1) -> 
    let op (x,t) f2 = smk_forall(x,t,f2) in
    List.fold_right op vts (simplify f1)
| Var v -> f
| Const c -> f
| Binder(k,vts,f1) -> Binder(k,vts,simplify f1)
| App(f1,fs) -> App(simplify f1, List.map simplify fs)
