package ca.uwaterloo.ece251.ast;

/** Represents a WiG statement. */
abstract public class Stm {
}

