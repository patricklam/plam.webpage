package ca.uwaterloo.ece251;
import org.antlr.runtime.*;
import java.io.*;

/** Main entry point. */
public class WIG {
    public static void main(String[] args) throws Exception {
        ANTLRInputStream input = new ANTLRInputStream(new FileInputStream(args[0]));
        WigLexer lexer = new WigLexer(input);
        CommonTokenStream tokens = new CommonTokenStream(lexer);
        WigParser parser = new WigParser(tokens);
        System.out.println(parser.service().toString());
    }
}
