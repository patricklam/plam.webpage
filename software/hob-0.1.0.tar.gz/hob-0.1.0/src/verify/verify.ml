let source_dir = ref "."
let show_deps = ref false
let show_dot_deps = ref false
let got_all = ref false
let got_really_all = ref false
let analyze_cmd = ref ((Filename.dirname Sys.executable_name) ^ "/analyze")
let no_execute = ref false
let my_verbose = ref false

let scope_const = "S_"
let module_const = "M_"
let is_scope s = s.[0] == scope_const.[0]

let deps = Hashtbl.create 20

let parse_cmdline () : string list =
  let speclist = 
    [("-v", Arg.Set my_verbose, 
      "Verbose; display verbose debugging messages.");
     ("-n", Arg.Set no_execute, 
      "Not-really; don't really run analyzer.");
     ("-s", Arg.Set show_deps,
      "Show dependencies between modules.");
     ("-S", Arg.Set show_dot_deps,
      "Output dependencies between modules in dot form.");
     ("-d", Arg.Set_string source_dir,
      "<dirname>  Specify the source directory for the build.")] in
  let source_names = ref [] in
  let usage_msg=("Usage:\n  "^Sys.argv.(0)^" [-v] [-d <dirname>] <module names | scope names | 'all' | 'really-all'>\n") in
    Arg.parse speclist (fun x -> source_names := x :: !source_names) usage_msg;
    if (!show_dot_deps) then
      show_deps := true;
    source_dir := !source_dir ^ "/";
    if not !show_deps & (List.length !source_names = 0) then 
      begin 
        Arg.usage speclist usage_msg; 
        exit 1 
      end;
    if List.mem "all" !source_names then got_all := true;
    if List.mem "really-all" !source_names then got_really_all := true;
    Util.remove_dups !source_names

let check_private_instantiations () =
  List.iter 
    (fun sc -> 
       List.iter (fun exported_mn -> 
                    let exported_m = Ast.fetch_spec exported_mn in
                      if exported_m.Sabsyn.instantiated_from <> None then
                        print_string ("Error: instantiated module "^
                                        exported_m.Sabsyn.module_name^
                                        " must be private in scope "^
                                        sc.Sabsyn.scope_name^".\n"))
         sc.Sabsyn.exports) !Ast.scopes
    
let parse (source_names : string list) = 
  let format_names = ref [] in
  let spec_names = ref [] in
  let abst_names = ref [] in
  let scope_names = ref [] in
  List.iter (function n -> 
    (match (try Util.extension n with Not_found -> "") with 
      ".fl" -> format_names := (!source_dir ^ n) :: !format_names
    | ".sl" -> spec_names := (!source_dir ^ n) :: !spec_names
    | ".al" -> abst_names := (!source_dir ^ n) :: !abst_names
    | ".scope" -> scope_names := (!source_dir ^ n) :: !scope_names
    | _ -> ())) source_names;
  Uglyast.spec_ast := snd (Uglyast.parse_spec_asts !spec_names);
  Uglyast.abst_ast := snd (Uglyast.parse_abst_asts !abst_names);
  Uglyast.impl_ast := Uglyast.parse_impl_asts !format_names;
  Uglyast.scope_ast := Uglyast.parse_scope_asts (!scope_names @ !spec_names);
  let spec_module_names = Uglyast.fetch_spec_module_names !Uglyast.spec_ast in
  let abst_module_names = Uglyast.fetch_abst_module_names !Uglyast.abst_ast in
  let impl_module_names = Uglyast.fetch_impl_module_names !Uglyast.impl_ast in
  let scope_names = Uglyast.fetch_scope_names !Uglyast.scope_ast in
  Ast.impl := List.map 
      (fun x -> Deuglifyimpl.convert (Uglyast.fetch_impl_module x)) 
      impl_module_names;
  Ast.spec := List.map 
      (fun x -> Deuglifyspec.convert (Uglyast.fetch_spec_module x)) 
      spec_module_names;
  Ast.abst := List.map 
      (fun x -> Deuglifyabst.convert (Uglyast.fetch_abst_module x)) 
      abst_module_names;
  Ast.scopes := List.map
      (fun x -> Deuglifyspec.convert_scope (Uglyast.fetch_scope x))
      scope_names;
  Ast.impl := Util.phase "Instantiating impl templates" 
      (List.map (Itrans.instantiate_templates false)) !Ast.impl;
  let instantiated_specs = 
    List.filter (fun x -> x.Sabsyn.instantiated_from != None) !Ast.spec in
  Ast.spec := Util.phase "Instantiating spec templates" 
      (List.map (Strans.instantiate_templates instantiated_specs)) !Ast.spec;
  Ast.scopes := Util.phase "Instantiating scope templates"
      (List.map (Strans.instantiate_scope_templates instantiated_specs)) 
      !Ast.scopes;
  check_private_instantiations ();
  Ast.abst := Util.phase "Instantiating abst templates" 
      (List.map Atrans.instantiate_templates) !Ast.abst;
  ()

let strip_prefix s = 
  let sl = String.length s in
  if sl < 2 then "" else
  String.sub s 2 (sl - 2)

let add_scope_deps () =
  List.iter (fun c -> 
               Hashtbl.add deps (scope_const^c.Sabsyn.scope_name) 
                 c.Sabsyn.modules) 
    (Scopes.all_scopes ())

let add_module_deps_using_calls_clauses () =
  List.iter (fun ms -> List.iter (fun p -> 
    let pn = p.Sabsyn.proc_name in
    let pnm = module_const^(Id.module_of_proc pn) in
    let m = if (Hashtbl.mem deps pnm) then
      Hashtbl.find deps pnm else [] in
    Hashtbl.replace deps pnm (Util.remove_dups (p.Sabsyn.calls @ m)))
      ms.Sabsyn.procs) 
    !Ast.spec

let add_module_deps_using_impls () =
  List.iter (fun ms -> List.iter (fun p -> 
    let pn = p.Iabsyn.proc_id in
    let pnm = module_const^(Id.module_of_proc pn) in
    let m = if (Hashtbl.mem deps pnm) then
      Hashtbl.find deps pnm else [] in
    let filter_intrinsics ms = List.filter 
           (fun x -> not (List.mem x Intrinsics.modules)) ms in
    Hashtbl.replace deps pnm 
      (filter_intrinsics (Util.remove_dups (((List.map Id.module_of_proc 
                                                (Iabsyn.collect_callees p))) @ m))))
      ms.Iabsyn.procs) 
    !Ast.impl

let add_instantiated_module_deps () =
  Hashtbl.iter 
    (fun m d ->
       let mn = strip_prefix m in
       let f = (fun x ->
                  [x] @ 
                    (let s = Ast.fetch_spec x in
                       match s.Sabsyn.instantiated_from with
                         | None -> []
                         | Some ss -> [ss])) in
         Hashtbl.replace deps m (List.concat (List.map f d)))
    deps

let clean_deps () =
  Hashtbl.iter 
    (fun m d ->
       let mn = strip_prefix m in
       let f = if is_scope m then (fun x -> true) else (fun x -> x <> mn) in
       Hashtbl.replace deps m (List.filter f d))
    deps

let sorted_deps () =
  let modules_seen = ref [] in
  let scopes_assoc = ref [] in
  let modules_assoc = ref [] in
  let res = ref [] in
  let progress = ref false in
  let find_clear_scopes () = 
    let sa' = ref [] in
    List.iter (fun (m, d) -> 
                 if (List.for_all (fun x -> List.mem x !modules_seen) d) then
                   begin
                     res := (scope_const ^ m) :: !res;
                     progress := true
                   end
                 else
                   sa' := (m, d) :: !sa') !scopes_assoc;
      scopes_assoc := !sa' in
  let find_clear_modules () = 
    let ma' = ref [] in
      List.iter (fun (m, d) -> 
                   if (List.for_all (fun x -> List.mem x !modules_seen) d) then
                     begin
                       res := (module_const ^ m) :: !res;
                       modules_seen := m :: !modules_seen;
                       progress := true
                     end
                   else
                     ma' := (m, d) :: !ma') !modules_assoc;
      modules_assoc := !ma' in
    Hashtbl.iter (fun s d -> 
                    let ss = strip_prefix s in
                    if is_scope s then
                      scopes_assoc := ((ss, d) :: !scopes_assoc)
                    else
                      modules_assoc := ((ss, d) :: !modules_assoc)) deps;
    while (!scopes_assoc <> [] or !modules_assoc <> []) do
      progress := false;
      find_clear_scopes ();
      find_clear_modules ();
      if (not !progress) then
        begin
          (* randomly break a cycle *)
          if !modules_assoc = [] then
            failwith ("couldn't resolve deps for scope "^(fst (List.hd !scopes_assoc)));
          let victim = List.hd !modules_assoc in
            modules_assoc := List.tl !modules_assoc;
            res := (module_const ^ (fst victim)) :: !res;
            modules_seen := fst victim :: !modules_seen;
        end
    done;
    List.rev !res

let print_out_deps (ordered_targets:string list) =
  if (!show_dot_deps) then
    print_string ("digraph G {\nsize=\"7,8\";\nrotate=90;");
  let sep = if (!show_dot_deps) then "->" else ": " in
  let nl = if (!show_dot_deps) then ";\n" else "\n" in
  List.iter (fun (m, d) -> 
               if (!show_dot_deps) then
                 begin
                   print_string (m ^ nl);
                   List.iter (fun dd -> 
                                print_string (m ^ sep ^ 
                                                (module_const ^ dd) ^ nl)) d
                 end
               else
                 print_string (m ^ sep ^ 
                                 (List.fold_left 
                                    (fun x y -> x ^ " " ^ y) "") d ^ nl))
    (List.map (fun x -> (x, Hashtbl.find deps x)) ordered_targets);
  if (!show_dot_deps) then
    print_string "}\n"

let match_targets names0 (ot:Id.module_t list) =
  let (blacklist0, names) = 
    List.partition (fun x -> x <> "" && x.[(String.length x - 1)] == '-') names0 in
  let blacklist = 
    List.map 
      (fun x -> String.sub x 0 (String.length x - 1)) blacklist0 in
  let provisional_result = List.filter 
    (fun x -> 
       (is_scope x or
          (Ast.fetch_spec (strip_prefix x)).Sabsyn.instantiated_from = None))
    (if !got_really_all then
       ot
     else if !got_all then
       List.filter (fun x -> (is_scope x) or Ast.has_abst (strip_prefix x)) ot
     else
       List.filter 
         (fun x -> 
            List.mem (strip_prefix x) names) ot) in
    List.filter 
      (fun x -> not (List.mem (strip_prefix x) blacklist)) 
      provisional_result
    
let fetch_mod_fn n = 
  Filename.chop_extension (Hashtbl.find Ast.impl_to_fn n)

let fetch_scope_fn n = failwith "implement me"

exception Not_verified

let spec_to_args = Hashtbl.create 20

let make_verify_args targs =
  List.iter 
    (fun t -> 
       if is_scope t then
         ()
       else
         let tt = strip_prefix t in
         let needed_scopes = List.filter
           (fun x -> List.mem tt x.Sabsyn.exports) !Ast.scopes in
         let needed_scope_fns = List.map 
           (fun x -> Hashtbl.find Ast.scope_to_fn x.Sabsyn.scope_name) needed_scopes in
         let d = Hashtbl.find deps t in
         let tfn = fetch_mod_fn tt in
         let args = 
           Util.remove_dups
             ([tfn ^ ".fl"; tfn ^ ".sl"; tfn ^ ".al"] @
                needed_scope_fns @
                (List.map 
                   (fun n ->
                      fetch_mod_fn n ^ ".sl") d) @
                if (Hashtbl.mem spec_to_args t) then 
                  Hashtbl.find spec_to_args t else []) in
           Hashtbl.replace spec_to_args t args) targs
    
let rec verify (targs0:string list) =
  let scope_targs = 
    List.map strip_prefix (List.filter is_scope targs0) in
  let targs = (* filter out case with both scope & module of same name *)
    List.filter 
      (fun t -> if is_scope t then true else
         not (List.mem (strip_prefix t) scope_targs)) targs0 in
    try
      List.iter 
        (fun t ->
           if is_scope t then
             begin
               if not !got_all then
                 begin
                   if !my_verbose then
                     print_string ("Verifying scope "^(strip_prefix t)^"...\n");
                   let ms = 
                     List.map 
                       (fun x -> (module_const ^ x))
                       ((Ast.fetch_scope (strip_prefix t)).Sabsyn.modules) in
                     if not (verify ms) then
                       raise Not_verified
                 end
             end
           else
             begin
               if !my_verbose then
                 print_string ("Verifying module "^(strip_prefix t)^"...\n");
               let args = String.concat " " 
                 (Hashtbl.find spec_to_args t) in
               let cmd = (!analyze_cmd ^ " " ^ args) in
                 if !Util.verbose then
                   print_string (cmd ^ "\n");
                 if not !no_execute then
                   begin
                     flush stdout;
                     if (Sys.command cmd != 0) then
                       raise Not_verified
                   end
             end) targs;
      true
    with Not_verified -> false 
      
let go () =
  let names = parse_cmdline () in
  let fnames = ref [] in
  let d = Unix.opendir !source_dir in
    (try 
      while true do fnames := (Unix.readdir d) :: !fnames done
    with End_of_file -> ());
    Unix.closedir d; 
    parse !fnames;
    Util.verbose := !my_verbose;
    add_scope_deps ();
    (*add_module_deps_using_calls_clauses ();*)
    add_module_deps_using_impls ();
    add_instantiated_module_deps ();
    clean_deps ();
    let ordered_targets = sorted_deps () in
    let targs = match_targets names ordered_targets in
      if (!show_deps) then
        begin print_out_deps ordered_targets; 0 end
      else
        begin
          make_verify_args ordered_targets;
          if verify targs then 0 else 1
        end
        
  let _ = exit (go ())
