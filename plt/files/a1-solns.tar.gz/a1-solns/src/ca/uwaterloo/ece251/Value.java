package ca.uwaterloo.ece251;

/** Basic Value interface. Contains all operations. */
public interface Value {
    public static String OUTPUT_DIR = "output" + java.io.File.separator;

    /** Write this value to file <code>fn</code>.EXT. */
    public void write(String fn);

    /** Print this value to standard output. */
    public void print();

    /** Return a sorted copy of this value. 
     * Identity function on atoms. */
    public Value sort(Expr.Comparator c);

    /** Deeply map the given transformer to this value.
     * Identity function on atoms. */
    public Value map(Expr.Transformer t);

    /** Filter out values not satisfying the given filter.
     * Identity function on atoms.
     * Throw out the entire subtree if its head doesn't satisfy. */
    public Value filter(Expr.Filter f);

    /** Combine values using the given accumulator. 
     * Identity function on atoms. */
    public Value reduce(Expr.Accumulator a);

    /** Return a list containing the given traversal of the tree,
     * or the identity function on lists and atoms. */
    public Value traverse(Expr.Order o);

    /** Retain at most <code>v</code> levels of the tree, 
     * or elements of the list. */
    public Value truncate(int v);

    /** Compare this object to <code>v2</code>.
     * Return -1 if this object is less than <code>v2</code>,
     * return 0 if objects are equal, and
     * return +1 if this object is greater than <code>v2</code>. */
    public int compare(Value v2);

    /** Return a deep copy of this object. */
    public Object clone();
}
