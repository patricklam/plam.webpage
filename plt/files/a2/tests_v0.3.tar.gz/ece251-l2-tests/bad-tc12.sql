select 4+NULL AS st from dual;
