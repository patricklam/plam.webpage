(* Abstract Syntax Tree for All Modules
   of the Program *)

let spec : Sabsyn.spec_module list ref = ref []
let abst : string Aabsyn.abst_module list ref = ref []
let impl : string Iabsyn.impl_module list ref = ref []
let scopes : Sabsyn.scope list ref = ref []

let impl_to_fn : (string, string) Hashtbl.t = Hashtbl.create 20
let spec_to_fn : (string, string) Hashtbl.t = Hashtbl.create 20
let scope_to_fn : (string, string) Hashtbl.t = Hashtbl.create 20

type pos = (string * string)

let expr_pos : pos Iabsyn.Exprtbl.t = Iabsyn.Exprtbl.create 0
let huh = ("unknown", "[?, ?]")

let rec lookup_expr_pos' t exp =
  try Iabsyn.Exprtbl.find t exp with
  | Not_found ->
      let lookup_expr_pos e = lookup_expr_pos' t e in
      match exp with
        Iabsyn.LiteralExpr _ 
      | Iabsyn.VarExpr _ -> huh
      | Iabsyn.FieldAccessExpr (e, f) -> 
          lookup_expr_pos e
      | Iabsyn.ArrayAccessExpr (e, i) ->
          let r = lookup_expr_pos e in
          if (r = huh) then
            lookup_expr_pos i
          else r
      | Iabsyn.ArrayLengthExpr (e) ->
          lookup_expr_pos e 
      | Iabsyn.NewExpr n -> huh
      | Iabsyn.NewArrayExpr (t, e, d) ->
          lookup_expr_pos (List.hd e)
      | Iabsyn.InvokeExpr (p, el) -> huh
      | Iabsyn.AssignExpr (l, e) -> 
          lookup_expr_pos e 
      | Iabsyn.PreIncExpr lv | Iabsyn.PostIncExpr lv
      | Iabsyn.PreDecExpr lv | Iabsyn.PostDecExpr lv -> huh
      | Iabsyn.NotExpr e | Iabsyn.NegExpr e ->
          lookup_expr_pos e 
      | Iabsyn.PlusExpr (l, r) 
      | Iabsyn.MinusExpr (l, r)
      | Iabsyn.MultExpr (l, r)
      | Iabsyn.DivExpr (l, r)
      | Iabsyn.ModExpr (l, r)
      | Iabsyn.AndExpr (l, r)
      | Iabsyn.OrExpr (l, r)
      | Iabsyn.EqExpr (l, r)
      | Iabsyn.NeqExpr (l, r)
      | Iabsyn.LtExpr (l, r)
      | Iabsyn.GtExpr (l, r)
      | Iabsyn.LteqExpr (l, r)
      | Iabsyn.GteqExpr (l, r)
      | Iabsyn.BitAndExpr (l, r)
      | Iabsyn.BitOrExpr (l, r)
      | Iabsyn.BitXorExpr (l, r)
      | Iabsyn.ShiftLeftExpr (l, r)
      | Iabsyn.SignedShiftRightExpr (l, r)
      | Iabsyn.UnsignedShiftRightExpr (l, r) ->
          let rv = lookup_expr_pos l in
          if (rv = huh) then
            lookup_expr_pos r
          else rv

let lookup_expr_pos exp =
  lookup_expr_pos' expr_pos exp

let fetch_scope (name : string) : Sabsyn.scope = 
  try (List.find (fun x -> x.Sabsyn.scope_name = name) !scopes)
      with Not_found -> failwith ("Couldn't find scope module "^name)
              
let fetch_spec (name : string) : Sabsyn.spec_module = 
  try (List.find (fun x -> x.Sabsyn.module_name = name) !spec)
      with Not_found -> failwith ("Couldn't find spec module "^name)

let has_abst (name : string) : bool =
  List.exists (fun x -> x.Aabsyn.module_name = name) !abst

let fetch_abst (name : string) : 'a Aabsyn.abst_module = 
  List.find (fun x -> x.Aabsyn.module_name = name) !abst

let has_impl (name : string) : bool =
  List.exists (fun x -> x.Iabsyn.module_name = name) !impl

let fetch_impl (name : string) : 'a Iabsyn.impl_module = 
  List.find (fun x -> x.Iabsyn.module_name = name) !impl

let has_spec (name : string) : bool =
  List.exists (fun x -> x.Sabsyn.module_name = name) !spec

let has_spec_proc (name : string) (mdl:Sabsyn.spec_module) : bool =
  List.exists (fun x -> (Id.name_of_proc x.Sabsyn.proc_name) = name)
    mdl.Sabsyn.procs

let has_spec_proc_by_t pt = 
  has_spec_proc (Id.name_of_proc pt) (fetch_spec (Id.module_of_proc pt))

let fetch_spec_proc (name : string) (mdl:Sabsyn.spec_module) 
    : Sabsyn.proc_spec = 
  try (List.find (fun x -> x.Sabsyn.proc_name.Id.p_name = name) mdl.Sabsyn.procs)
  with Not_found -> 
    failwith ("couldn't find spec proc "^mdl.Sabsyn.module_name^"."^name)

let fetch_spec_proc_by_t pt = 
  fetch_spec_proc (Id.name_of_proc pt) (fetch_spec (Id.module_of_proc pt))

let has_impl_proc (name : string) (mdl:'a Iabsyn.impl_module) : bool =
  List.exists (fun x -> (Id.name_of_proc x.Iabsyn.proc_id) = name)
    mdl.Iabsyn.procs

let has_impl_proc_by_t pt = 
  try 
    (has_impl_proc (Id.name_of_proc pt) (fetch_impl (Id.module_of_proc pt)))
  with Not_found -> false

let fetch_impl_proc (name : string) (mdl:'a Iabsyn.impl_module) 
    : 'a Iabsyn.proc_def = 
  try (List.find (fun x -> (Id.name_of_proc x.Iabsyn.proc_id) = name) 
    mdl.Iabsyn.procs)
  with Not_found -> 
    failwith ("couldn't find impl proc "^mdl.Iabsyn.module_name^"."^name)

let fetch_impl_proc_by_t pt = 
  fetch_impl_proc (Id.name_of_proc pt) (fetch_impl (Id.module_of_proc pt))

let all_spec_modules () = 
  List.map (fun x -> x.Sabsyn.module_name) !spec

let all_impl_modules () = 
  List.map (fun x -> x.Iabsyn.module_name) !impl

let all_impl_formats () =
  let format_decl_list = List.concat (List.map (fun y -> y.Iabsyn.formats) 
                                        !impl) in
  "StringBuffer" :: Util.remove_dups (List.map (fun x -> x.Iabsyn.format_name) format_decl_list)

let all_abst_modules () = 
  List.map (fun x -> x.Aabsyn.module_name) !abst

