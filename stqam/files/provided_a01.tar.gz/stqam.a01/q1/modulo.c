/* author: Your Name */
/* a C program that prints -5 % 2 */
