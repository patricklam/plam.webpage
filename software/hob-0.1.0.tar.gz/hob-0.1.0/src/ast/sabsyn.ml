(* Abstract Syntax for Specification Language *)

open Types

let reason_frame = "frame condition"
let reason_default = "default"
let reason_invariant = "invariant"

type ident = string  
type setIdent  = ident
type propIdent = ident
type typeIdent = ident
type predIdent = ident
type bVarDecl = ident * value_type

type starredIdent = ident
type starredType = value_type * bool

type scope_or_module = Scope | Module

type spProcSpec = {
    sp_module : starredIdent;
    sp_name : starredIdent;
    sp_args : starredType list;
    sp_retval : starredType option;
  }

type specPoint =
  | SPMinus of specPoint * specPoint
  | SPAnd of specPoint * specPoint
  | SPOr of specPoint * specPoint
  | SPNot of specPoint
  | SPProc of spProcSpec
  | SPPubModule of starredIdent
  | SPPrivModule of starredIdent
  | SPAllModule of starredIdent
  | SPPubScope of starredIdent
  | SPPrivScope of starredIdent
  | SPAllScope of starredIdent
  | SPAll

type pointcutExpr = 
  | PCMinus of pointcutExpr * pointcutExpr
  | PCAnd of pointcutExpr * pointcutExpr
  | PCOr of pointcutExpr * pointcutExpr
  | PCNot of pointcutExpr
  | PCPre of specPoint
  | PCPost of specPoint
  | PCPrepost of specPoint

type form = 
  | Atom of atomForm
  | Not of form
  | And of form list
  | Or of form list
  | Impl of form * form
  | Iff of form * form
  | ExistsOne of bVarDecl * form (* deprecated! *)
  | ForallOne of bVarDecl * form (* deprecated! *)
  | ExistsSet of bVarDecl * form
  | ForallSet of bVarDecl * form
  | ExistsProp of propIdent * form
  | ForallProp of propIdent * form
  | UninterpretedString of string

and atomForm = 
  | Eq of setExp * setExp
  | Neq of setExp * setExp
  | Sub of setExp * setExp
  | True
  | False
  | Cardeq of setExp * int
  | Cardleq of setExp * int
  | Cardgeq of setExp * int
  | Disjoint of setExp list
  | Propvar of propIdent
  | Propvarpost of propIdent

and setExp =
  | Prevar of setIdent
  | Postvar of setIdent
  | Emptyset
  | Union of setExp list
  | Inter of setExp list
  | Diff of setExp * setExp

and predUse = {
    predName : predIdent;
    predPrimed : bool;
    predArgs : setExp list
  }

type defaultDef = {
    defaultName : Id.default_t;
    defaultLocation : scope_or_module;
    defaultParms : ident list;
    defaultPointcut : pointcutExpr;
    defaultBody : form
  }

type predDef = {
    predDefName : predIdent;
    predDefFormals : ident list;
    predDefBody : form
  }

type proc_spec = { (* procedure specification *)
    proc_name : Id.proc_t;
    proc_modifiers : Id.modifiers_t;
    formals    : (Id.var_t * value_type) list;
    ret_val    : (Id.var_t * value_type) option;
    suspends : Id.default_t list;
    requires : form;
    modifies : Id.var_t list; (* N.B. always qualified *)
    calls    : Id.module_t list;
    extra_ensures : (form * string) list;
    ensures  : form
}

type visibility = Public | Private

type inv = form * visibility

type spec_module = { 
    module_name : Id.module_t;
    instantiated_from : Id.module_t option;
    param_subst : (Types.value_type * Types.value_type) list;
    properties  : predDef list;
    invariants  : inv list;
    defaults    : defaultDef list;
    formats     : Id.format_t list;
    specvars    : (Id.var_t * Types.value_type) list; 
    procs       : proc_spec list
}

type scope = {
    scope_name       : Id.scope_t;
    modules          : Id.module_t list;
    exports          : Id.module_t list;
    invariant        : inv option;
    scope_defaults   : defaultDef list;
  }

(* utilities *)

let collect_free_vars form = 
  let rec collect_setexp s =
    match s with
    | Prevar i -> [i]
    | Postvar i -> [i]
    | Emptyset -> []
    | Union sel
    | Inter sel -> List.concat (List.map collect_setexp sel)
    | Diff (l, r) -> collect_setexp l @ collect_setexp r in
  let rec collect_atom a =
    match a with
    | Eq (l, r)
    | Neq (l, r)
    | Sub (l, r) -> collect_setexp l @ collect_setexp r
    | True -> []
    | False -> []
    | Cardeq (se, i)
    | Cardleq (se, i)
    | Cardgeq (se, i) -> collect_setexp se
    | Disjoint sel -> List.concat (List.map collect_setexp sel)
    | Propvar i -> [i]
    | Propvarpost i -> [i]
  and collect_form f =
    match f with
    | Atom af -> collect_atom af
    | Not nf -> collect_form nf
    | And fl
    | Or fl -> List.concat (List.map collect_form fl)
    | Impl (p, c) -> collect_form p @ collect_form c
    | Iff (p, c) -> collect_form p @ collect_form c
    | ExistsOne ((v, t), f) -> 
        List.filter (fun x -> x <> v) (collect_form f)
    | ForallOne ((v, t), f) -> 
        List.filter (fun x -> x <> v) (collect_form f)
    | ExistsProp (v, f) ->
        List.filter (fun x -> x <> v) (collect_form f)
    | ExistsSet ((v, t), f) -> 
        List.filter (fun x -> x <> v) (collect_form f)
    | ForallSet ((v, t), f) -> 
        List.filter (fun x -> x <> v) (collect_form f) 
    | ForallProp (v, f) ->
        List.filter (fun x -> x <> v) (collect_form f)
    | UninterpretedString _ -> [] in
  collect_form form

let subst (x, y) form =
  let rec subst_setexp s =
    match s with
    | Prevar i -> (if (i = x) then y else s)
    | Postvar i -> (if (i = x) then y else s)
    | Emptyset -> Emptyset
    | Union sel -> Union (List.map subst_setexp sel)
    | Inter sel -> Inter (List.map subst_setexp sel)
    | Diff (l, r) -> Diff (subst_setexp l, subst_setexp r) in
  let rec subst_atom a =
    match a with
    | Eq (l, r) -> Eq (subst_setexp l, subst_setexp r)
    | Neq (l, r) -> Neq (subst_setexp l, subst_setexp r)
    | Sub (l, r) -> Sub (subst_setexp l, subst_setexp r)
    | True -> True
    | False -> False
    | Cardeq (se, i) -> Cardeq (subst_setexp se, i)
    | Cardleq (se, i) -> Cardleq (subst_setexp se, i)
    | Cardgeq (se, i) -> Cardgeq (subst_setexp se, i)
    | Disjoint sel -> Disjoint (List.map subst_setexp sel)
    | Propvar i -> a
    | Propvarpost i -> a
  and subst_form f =
    match f with
    | Atom af -> Atom (subst_atom af)
    | Not nf -> Not (subst_form nf)
    | And fl -> And (List.map subst_form fl)
    | Or fl -> Or (List.map subst_form fl)
    | Impl (p, c) -> Impl (subst_form p, subst_form c)
    | Iff (p, c) -> Iff (subst_form p, subst_form c)
    | ExistsOne ((v, t), f) -> 
        if v = x then f 
        else ExistsOne ((v, t), subst_form f)
    | ForallOne ((v, t), f) -> 
        if v = x then f 
        else ForallOne ((v, t), subst_form f)
    | ExistsProp (v, f) -> 
        if v = x then f 
        else ExistsProp (v, subst_form f)
    | ExistsSet ((v, t), f) -> 
        if v = x then f 
        else ExistsSet ((v, t), subst_form f)
    | ForallSet ((v, t), f) -> 
        if v = x then f
        else ForallSet ((v, t), subst_form f) 
    | ForallProp (v, f) -> 
        if v = x then f 
        else ForallProp (v, subst_form f) 
    | UninterpretedString _ -> f in
  subst_form form

(* Priming expressions, for primed predicate expansion *)

let primed s = s ^ "'"
let fsts vts = List.map fst vts

let rec prime_form (f : form) (but : ident list) : form = 
  let pr f = prime_form f but in
  match f with  
| Atom a -> Atom (prime_atom a but)
| Not f -> Not (pr f)
| And fs -> And (List.map pr fs)
| Or fs -> Or (List.map pr fs)
| Impl (f1,f2) -> Impl (pr f1, pr f2)
| Iff (f1,f2) -> Iff (pr f1, pr f2)
| ExistsOne (bv,f1) -> ExistsOne(bv,prime_form f1 (fst bv :: but))
| ForallOne (bv,f1) -> ForallOne(bv,prime_form f1 (fst bv :: but))
| ExistsSet (bv,f1) -> ExistsSet(bv,prime_form f1 (fst bv :: but))
| ForallSet (bv,f1) -> ForallSet(bv,prime_form f1 (fst bv :: but))
| ExistsProp (bv,f1) -> ExistsProp(bv,prime_form f1 (bv :: but))
| ForallProp (bv,f1) -> ForallProp(bv,prime_form f1 (bv :: but))
| UninterpretedString _ -> f
and prime_atom (a : atomForm) but = 
  let pr s = prime_exp s but in
  match a with
| Eq(s1,s2) -> Eq(pr s1, pr s2)
| Neq(s1,s2) -> Neq(pr s1, pr s2)
| Sub(s1,s2) -> Sub(pr s1, pr s2)
| True -> True
| False -> False
| Cardeq(s,i) -> Cardeq(pr s,i)
| Cardleq(s,i) -> Cardleq(pr s,i)
| Cardgeq(s,i) -> Cardgeq(pr s,i)
| Disjoint ss -> Disjoint (List.map pr ss)
| Propvar p -> Propvar (primed p)
| Propvarpost p -> Propvarpost p
and prime_exp s but = 
  let pr s1 = prime_exp s1 but in
  match s with
| Prevar id -> if List.mem id but then Prevar id else Postvar id
| Postvar id -> Postvar id
| Emptyset -> Emptyset
| Union ss -> Union (List.map pr ss)
| Inter ss -> Union (List.map pr ss)
| Diff(s1,s2) -> Diff(pr s1,pr s2)

let prime_all (f : form) = prime_form f []

(* Looks for 'Propvar x' and replaces that with f *)
let subst_prevar_in_conj (x, (x':form)) form =
  let rec subst_form f =
    match f with
    | Atom (Propvar i) -> if (i = x) then x' else f
    | Atom (Propvarpost i) -> if (i = x) then prime_all x' else f
    | Atom af -> f
    | Not nf -> Not (subst_form nf)
    | And fl -> And (List.map subst_form fl)
    | Or fl -> Or (List.map subst_form fl)
    | Impl (p, c) -> Impl (subst_form p, subst_form c)
    | Iff (p, c) -> Iff (subst_form p, subst_form c)
    | ExistsOne ((v, t), f) -> 
        if v = x then f 
        else ExistsOne ((v, t), subst_form f)
    | ForallOne ((v, t), f) -> 
        if v = x then f 
        else ForallOne ((v, t), subst_form f)
    | ExistsProp (v, f) -> 
        if v = x then f 
        else ExistsProp (v, subst_form f)
    | ExistsSet ((v, t), f) -> 
        if v = x then f 
        else ExistsSet ((v, t), subst_form f)
    | ForallSet ((v, t), f) -> 
        if v = x then f
        else ForallSet ((v, t), subst_form f) 
    | ForallProp (v, f) -> 
        if v = x then f 
        else ForallProp (v, subst_form f)
    | UninterpretedString _ -> f in
  subst_form form

let extract_qualified_specvar_type_pairs_from_module m =
  List.map 
    (fun x -> (Util.qualify_if_needed m.module_name (fst x), snd x))
    m.specvars

let extract_qualified_set_specvars_from_module m =
  List.concat
    (List.map 
       (fun x -> if (not (snd x = TBool)) then
         [(Util.qualify_if_needed m.module_name (fst x))] else [])
       m.specvars)

let extract_qualified_boolean_specvars_from_module m =
  List.concat
    (List.map 
       (fun x -> if (snd x = TBool) then
         [(Util.qualify_if_needed m.module_name (fst x))] else [])
       m.specvars)

(* parallel to BA.mk_and *)
let mk_and fs = 
  let set_insert x xs = if List.mem x xs then xs else x::xs in
  let rec mkand1 fs acc = match fs with
  | [] -> (match acc with
    | [] -> Atom True
    | [f] -> f
    | _ -> And acc)
  | And fs0 :: fs1 -> mkand1 (List.rev_append fs0 fs1) acc
  | Atom True::fs1 -> mkand1 fs1 acc
  | Atom False::fs1 -> Atom False
  | fs::fs1 -> mkand1 fs1 (set_insert fs acc)
in mkand1 fs []

let extract_frame_cond p =
  mk_and (List.map fst 
            (List.filter (fun (c, r) -> r = reason_frame) p.extra_ensures))

let construct_ensures p =
  mk_and (p.ensures :: List.map fst p.extra_ensures)

(* Partial pretty-printer

let toString (m:spec_module) : string =
  let buf = Buffer.create 1024 in
  let wr s = Buffer.add_string buf s in
  let wrln = wr "\n" in
  let wr_sep str f bs =
    match bs with
      [] -> ()
    | b::bs ->
        begin
          f b;
          let strf b1 = (wr str; f b1) in
          List.iter strf bs
        end in
  let wr_idents is = wr_sep ", " wr is in
  let wr_format f = (wr "format "; wr f; wr ";\n") in
  let wr_set (s,typ) = (wr s; wr "."; wr typ) in
  let wr_proc (spec : proc_spec) : unit =
    let wr_formal (id,typ) = (wr id; wr ":"; wr typ) in
    let wr_return r = match r with
      Some (id,typ) ->
        begin
          wr "returns "; wr id; wr ":"; wr typ
        end
    | None -> () in 
    let wr_call m = match m with
      (mod_name,proc) -> 
        (wr mod_name; wr "."; wr proc) in
    begin
      wr "proc "; wr spec.proc_name;
      wr "(";
      wr_sep "; " wr_formal spec.formals; 
      wr ")";
      wr_return spec.retVal; 
      wrln;
      wr "requires ";
      wr (BA.toString spec.requires); 
      wr "\n";
      wr "modifies "; wr_idents spec.modifies; wrln;
      wr "calls "; wr_idents spec.calls; wrln;
      wr "ensures ";
      wr (BA.toString spec.ensures); 
      wr ";\n"
    end in
  begin    
    wr "spec module "; wr m.module_name; wr "{\n";
    List.iter wr_format m.formats;
    wr "sets "; 
    (wr_sep : string -> (string * string -> unit) -> (string * string) list -> unit) 
      ", " wr_set m.sets; 
    List.iter wr_proc m.procs;
    wr "}\n";
    Buffer.contents buf
  end

*)
