package ca.uwaterloo.ece251.ast;

public class UnaryOpExpr extends Expr {
    public static final String PLUS = "+", MINUS = "-", 
	ISNULL = "ISNULL", NOTNULL = "NOTNULL";
    String op;
    Expr e;

    public UnaryOpExpr(String op, Expr e) {
	this.op = op; this.e = e;
    }

    public void accept(Visitor v) {
	v.enter(this);
	e.accept(v);
	v.leave(this);
    }
}
