type which = Pre | Post

let compare_with_star (a:Sabsyn.starredIdent) (b:Sabsyn.ident) = 
  a=b || 
  (let l = String.length a in 
  if l = 0 then false else 
  ((String.get a (l-1)) = '*' &&
   let apref = String.sub a 0 (l-1) in
   (String.length apref) <= (String.length b) && 
   apref = (Str.string_before b (l-1))))

let compare_with_star_this mn (a:Sabsyn.starredIdent) (b:Sabsyn.ident) =
  compare_with_star a b || 
  a="this" && b=mn

let evaluate_default_pointcut (w:which)
    (ps:Sabsyn.proc_spec) (d:Sabsyn.defaultDef) : bool = 
  let c0 = d.Sabsyn.defaultPointcut in
  let dmn = Id.module_of_default d.Sabsyn.defaultName in
  let pnn = ps.Sabsyn.proc_name in
  let pn = Id.name_of_proc pnn in
  let mn = Id.module_of_proc pnn in
  let m = Ast.fetch_spec mn in
  let scopes = Scopes.scopes_of mn in
  let exporting_scopes = Scopes.exporting_scopes_of mn in 
  let non_exporting_scopes = Scopes.non_exporting_scopes_of mn in 
  let string_of_starred_type (x, b) = 
    (Types.string_of_value_type x) ^ (if b then "*" else "") in
  let rec eval_sp (sp:Sabsyn.specPoint) : bool = 
    match sp with
    | Sabsyn.SPMinus (l, r) -> (eval_sp l) && (not (eval_sp r))
    | Sabsyn.SPAnd (l, r) -> (eval_sp l) && (eval_sp r)
    | Sabsyn.SPOr (l, r) -> (eval_sp l) || (eval_sp r)
    | Sabsyn.SPNot e -> not (eval_sp e) 
    | Sabsyn.SPAll -> true
    | Sabsyn.SPProc sps ->
        (if (d.Sabsyn.defaultLocation = Sabsyn.Module) then
          (compare_with_star_this dmn sps.Sabsyn.sp_module mn)
        else
          (compare_with_star sps.Sabsyn.sp_module mn)) &&
        (compare_with_star sps.Sabsyn.sp_name pn) &&
        (sps.Sabsyn.sp_args = [] || 
        List.for_all2 compare_with_star 
          (List.map string_of_starred_type sps.Sabsyn.sp_args)
          (List.map (fun (_, t) -> Types.string_of_value_type t) 
             ps.Sabsyn.formals)) && 
        (match sps.Sabsyn.sp_retval with
        | None -> true
        | Some rv -> 
            (match ps.Sabsyn.ret_val with
            | None -> (snd rv) || (fst rv = Types.TVoid)
            | Some (_, rrv) -> 
                compare_with_star (string_of_starred_type rv) 
                  (Types.string_of_value_type rrv)))
    | Sabsyn.SPPubModule pm -> 
        not ps.Sabsyn.proc_modifiers.Id.is_private &&
        compare_with_star_this dmn pm mn
    | Sabsyn.SPPrivModule pm -> 
        ps.Sabsyn.proc_modifiers.Id.is_private &&
        compare_with_star_this dmn pm mn
    | Sabsyn.SPAllModule pm -> 
        compare_with_star_this dmn pm mn
    | Sabsyn.SPPubScope pc -> 
        List.exists (compare_with_star_this dmn pc) 
          (List.map (fun c -> c.Sabsyn.scope_name) exporting_scopes)
    | Sabsyn.SPPrivScope pc -> 
        List.exists (compare_with_star_this dmn pc) 
          (List.map (fun c -> c.Sabsyn.scope_name) non_exporting_scopes)
    | Sabsyn.SPAllScope pc -> 
        List.exists (compare_with_star_this dmn pc) 
          (List.map (fun c -> c.Sabsyn.scope_name) scopes) in
  let rec eval (c:Sabsyn.pointcutExpr) : bool =
    match c with
    | Sabsyn.PCMinus (l, r) -> (eval l) && (not (eval r))
    | Sabsyn.PCAnd (l, r) -> (eval l) && (eval r)
    | Sabsyn.PCOr (l, r) -> (eval l) || (eval r)
    | Sabsyn.PCNot e -> not (eval e)
    | Sabsyn.PCPre sp -> 
        (match w with 
        | Pre -> eval_sp sp
        | Post -> false) 
    | Sabsyn.PCPost sp -> 
        (match w with 
        | Pre -> false
        | Post -> eval_sp sp)
    | Sabsyn.PCPrepost sp ->
        eval_sp sp in
  eval c0

(* uses all spec modules (to get callees), scope information *)
let expand_modifies_clauses 
    (all_sb:Spec.sets_and_bools) defs (ms:Sabsyn.spec_module) = 
  (* all_unmodified_* includes only *s in this module *)
  let mn = ms.Sabsyn.module_name in
  let aum_helper munge p = 
    let (s0,b0) = 
      (Spec.collect_all_sets ms, Spec.collect_all_bools ms) in
    (munge s0, munge b0) in
  let all_unmodified_sets_bools_public p =
    aum_helper 
      (fun ss -> List.filter (fun x -> not (List.mem x p.Sabsyn.modifies) &
        let xm = Util.unqualify_getting_module x in
        Scopes.is_call_internal xm mn) 
          (List.map (fun x -> Util.qualify_if_needed ms.Sabsyn.module_name x) ss)) p in
  let all_unmodified_sets_bools_private p =
    aum_helper 
      (fun ss -> List.filter (fun x -> not (List.mem x p.Sabsyn.modifies)) (List.map (fun x -> Util.qualify_if_needed ms.Sabsyn.module_name x) ss)) p in
  let all_unmodified_sets_bools p =
    if (p.Sabsyn.proc_modifiers.Id.is_private) then
      all_unmodified_sets_bools_private p
    else
      all_unmodified_sets_bools_public p in
  let expand_proc p = 
    let undeclared_sets = 
      Util.difference p.Sabsyn.modifies (all_sb.Spec.s@all_sb.Spec.b) in
    if undeclared_sets != [] then
      Util.warn 
        ("Listing undeclared sets/bools "^(Util.spacify " " undeclared_sets) ^ 
         " in "^Id.module_of_proc p.Sabsyn.proc_name ^"."^
         Id.name_of_proc p.Sabsyn.proc_name);
    let proc_formal_names = List.map fst p.Sabsyn.formals in
    let apply_default_transformation (w:which)
        (actual_f:Sabsyn.form) (d:Sabsyn.defaultDef) : Sabsyn.form = 
      let b = d.Sabsyn.defaultBody in
      match d.Sabsyn.defaultParms with
        [] -> 
          if (w = Post) then 
            actual_f
          else
            Sabsyn.mk_and [actual_f;b] (* default default conjoins *)
      | formal_f::formals ->
            (* determine if this default is even applicable *)
          if (List.for_all (fun x -> List.mem x proc_formal_names) formals) then
            Sabsyn.subst_prevar_in_conj (formal_f, actual_f) b
          else
            actual_f in
    let applicable_defaults (w:which) suspended =
      let d = List.filter 
          (fun x -> evaluate_default_pointcut w p x) 
          defs in
      List.filter
        (fun x -> not (List.mem x.Sabsyn.defaultName suspended)) 
        d in
    let fetch_parmless_defaults (w:which) suspended : Sabsyn.form =
      let defs = applicable_defaults w suspended in
      Sabsyn.mk_and (List.map (fun d -> d.Sabsyn.defaultBody) 
                   (List.filter (fun d -> match d.Sabsyn.defaultParms with
                     [] -> true
                   | _ -> false) defs)) in
    (* for Post, only conjoin defaults with parms *)
    let conjoin_defaults (w:which) suspended (c:Sabsyn.form) : Sabsyn.form =
      let defs = applicable_defaults w suspended in
      List.fold_left (apply_default_transformation w) c defs in
    let (us, ub) = all_unmodified_sets_bools p in
    let fram = 
      List.map (fun x -> Sabsyn.Atom 
        (Sabsyn.Eq (Sabsyn.Prevar x, Sabsyn.Postvar x))) us @
      List.map (fun x -> Sabsyn.Iff (Sabsyn.Atom (Sabsyn.Propvar x), 
                                     Sabsyn.Atom (Sabsyn.Propvarpost x))) ub in
    {
     Sabsyn.proc_name  = p.Sabsyn.proc_name;
     Sabsyn.proc_modifiers = p.Sabsyn.proc_modifiers;
     Sabsyn.formals    = p.Sabsyn.formals;
     Sabsyn.ret_val    = p.Sabsyn.ret_val;
     Sabsyn.suspends   = p.Sabsyn.suspends;
     Sabsyn.requires   = conjoin_defaults Pre p.Sabsyn.suspends p.Sabsyn.requires;
     Sabsyn.modifies   = p.Sabsyn.modifies;
     Sabsyn.calls      = p.Sabsyn.calls;
     Sabsyn.extra_ensures = (Sabsyn.And fram, Sabsyn.reason_frame) ::
                         (fetch_parmless_defaults Post p.Sabsyn.suspends, Sabsyn.reason_default) ::
                         p.Sabsyn.extra_ensures;
     Sabsyn.ensures    = conjoin_defaults Post p.Sabsyn.suspends p.Sabsyn.ensures
   } in {
  Sabsyn.module_name = ms.Sabsyn.module_name;
  Sabsyn.instantiated_from = ms.Sabsyn.instantiated_from;
  Sabsyn.param_subst = ms.Sabsyn.param_subst;
  Sabsyn.properties  = ms.Sabsyn.properties;
  Sabsyn.formats     = ms.Sabsyn.formats;
  Sabsyn.specvars    = ms.Sabsyn.specvars;
  Sabsyn.invariants  = ms.Sabsyn.invariants;
  Sabsyn.procs       = List.map expand_proc ms.Sabsyn.procs;
  Sabsyn.defaults    = ms.Sabsyn.defaults;
  }

open Sabsyn
open Types

let find_instantiations m instantiation_list =
  List.map (fun x -> x.module_name) 
    (List.filter (fun x -> x.instantiated_from = Some m) instantiation_list)

let clone_instantiated_modules_in_procs instantiation_list p = 
  let clone_instantiated_modules_in_suspends s = 
    let i = (find_instantiations (Id.module_of_default s) 
               instantiation_list) in
    s :: (List.map (fun x -> Id.fetch_default x (Id.name_of_default s)) i) in
  {
   proc_name      = p.proc_name;
   proc_modifiers = p.proc_modifiers;
   formals        = p.formals;
   ret_val        = p.ret_val;
   suspends       = List.concat 
     (List.map clone_instantiated_modules_in_suspends p.suspends);
   requires       = p.requires;
   modifies       = p.modifies;
   calls          = p.calls;
   extra_ensures  = p.extra_ensures;
   ensures        = p.ensures;
 }


let clone_instantiated_modules_in_defaults instantiation_list d = 
  let rec clone_specpoint_proc spp y = SPProc
   {
     sp_module = y;
     sp_name = spp.sp_name;
     sp_args = spp.sp_args; (* should also do the thing here! *)
     sp_retval = spp.sp_retval;
   } in
  let rec clone_specpoint sp =
    match sp with
    | SPMinus (l, r) -> SPMinus (clone_specpoint l, clone_specpoint r)
    | SPAnd (l, r) -> SPAnd (clone_specpoint l, clone_specpoint r)
    | SPOr (l, r) -> SPOr (clone_specpoint l, clone_specpoint r)
    | SPNot e -> SPNot (clone_specpoint e)
    | SPProc spp -> 
        let i = (find_instantiations spp.sp_module instantiation_list) in
        List.fold_left (fun x y -> SPOr (x, clone_specpoint_proc spp y)) sp i 
    | SPPubModule spm -> 
        let i = (find_instantiations spm instantiation_list) in
        List.fold_left (fun x y -> SPOr (x, SPPubModule y)) sp i 
    | SPPrivModule spm ->
        let i = (find_instantiations spm instantiation_list) in
        List.fold_left (fun x y -> SPOr (x, SPPrivModule y)) sp i
    | SPAllModule spm ->
        let i = (find_instantiations spm instantiation_list) in
        List.fold_left (fun x y -> SPOr (x, SPAllModule y)) sp i
    | _ -> sp (* don't clone procs or scopes *) in
  let rec clone_pointcut p =
    match p with 
    | PCMinus (l, r) -> PCMinus (clone_pointcut l, clone_pointcut r)
    | PCAnd (l, r) -> PCAnd (clone_pointcut l, clone_pointcut r)
    | PCOr (l, r) -> PCOr (clone_pointcut l, clone_pointcut r)
    | PCNot e -> PCNot (clone_pointcut e)
    | PCPre sp -> PCPre (clone_specpoint sp)
    | PCPost sp -> PCPost (clone_specpoint sp)
    | PCPrepost sp -> PCPrepost (clone_specpoint sp) in
  {
   defaultName = d.defaultName;
   defaultLocation = d.defaultLocation;
   defaultParms = d.defaultParms;
   defaultPointcut = clone_pointcut d.defaultPointcut;
   defaultBody = d.defaultBody; (* policy decision: don't clone body *)
  }

let instantiate_templates instantiation_list ast = 
  let actuals = List.map snd ast.param_subst in
  let a_no_dups = Util.remove_dups actuals in
  if a_no_dups <> actuals then Util.err "[module instantiation]" ("Duplicated type parameter in spec module "^ast.module_name);
  match ast.instantiated_from with
  | None -> 
      { 
        module_name = ast.module_name;
        instantiated_from = ast.instantiated_from;
        param_subst = ast.param_subst;
        properties = ast.properties;
        formats = ast.formats;
        invariants = ast.invariants;
        specvars = ast.specvars;
        procs = List.map 
          (clone_instantiated_modules_in_procs instantiation_list) ast.procs;
        defaults = List.map 
          (clone_instantiated_modules_in_defaults
             instantiation_list) ast.defaults;
      }
  | Some parent ->
      let pmod = Ast.fetch_spec parent in
      let sl = ast.param_subst in
      let subst_type_fmts (t1:Types.value_type) : Types.value_type = 
        if List.mem_assoc t1 sl then
          List.assoc t1 sl else t1 in
      let subst_pair_fmts (x, y) = (x, subst_type_fmts y) in
      let rec subst_type t = 
        match t with
        | TArray t1 -> TArray (subst_type t1)
        | TObj _ -> 
            if List.mem_assoc t sl then
              List.assoc t sl else t
        | _ -> t in
      let subst_pair (x, y) = (x, subst_type y) in
      let subst_var v = 
        try let d = String.index v '.' + 1 in
        (ast.module_name ^ "." ^ (Str.string_after v d))
        with Not_found -> v in
      let rec subst_setexp (se:setExp) =
        match se with
        | Prevar id -> Prevar (subst_var id)
        | Postvar id -> Postvar (subst_var id)
        | Emptyset -> se
        | Union us -> Union (List.map subst_setexp us)
        | Inter is -> Inter (List.map subst_setexp is)
        | Diff (d1, d2) -> Diff (subst_setexp d1, subst_setexp d2) in
      let rec subst_atom_form (af:atomForm) : atomForm =
        match af with
        | Eq (l,r) -> Eq (subst_setexp l, subst_setexp r)
        | Neq (l,r) -> Neq (subst_setexp l, subst_setexp r)
        | Sub (l,r) -> Sub (subst_setexp l, subst_setexp r)
        | True -> True
        | False -> False
        | Cardeq (se, i)  -> Cardeq ((subst_setexp se), i)
        | Cardleq (se, i) -> Cardleq ((subst_setexp se), i)
        | Cardgeq (se, i) -> Cardgeq ((subst_setexp se), i)
        | Disjoint ss -> Disjoint (List.map subst_setexp ss) 
        | Propvar id -> Propvar (subst_var id)
        | Propvarpost id -> Propvarpost (subst_var id) in
      let rec subst_form (f:form) = 
        match f with
        | Atom af -> Atom (subst_atom_form af)
        | Not n -> Not (subst_form n)
        | And cs -> And (List.map subst_form cs)
        | Or ds -> Or (List.map subst_form ds)
        | Impl (ante, conseq) -> 
            Impl ((subst_form ante), (subst_form conseq))
        | Iff (p, q) -> Iff ((subst_form p), (subst_form q))
        | ExistsOne (vd, f) -> ExistsOne (vd, subst_form f)
        | ForallOne (vd, f) -> ForallOne (vd, subst_form f)
        | ExistsSet (vd, f) -> ExistsSet (vd, subst_form f)
        | ForallSet (vd, f) -> ForallSet (vd, subst_form f) 
        | ExistsProp (vd, f) -> ExistsProp (vd, subst_form f)
        | ForallProp (vd, f) -> ForallProp (vd, subst_form f)
        | UninterpretedString _ -> f in
      let rec subst_specpoint_proc spp = {
        sp_module = spp.sp_module;
        sp_name = spp.sp_name;
        sp_args = List.map (fun (x, y) -> (subst_type x, y)) spp.sp_args;
        sp_retval = match spp.sp_retval with 
          None -> None | Some (rv, b) -> Some ((subst_type rv), b);
      } in
      let rec subst_specpoint sp =
        match sp with
        | SPMinus (l, r) -> SPMinus (subst_specpoint l, subst_specpoint r)
        | SPAnd (l, r) -> SPAnd (subst_specpoint l, subst_specpoint r)
        | SPOr (l, r) -> SPOr (subst_specpoint l, subst_specpoint r)
        | SPNot e -> SPNot (subst_specpoint e)
        | SPProc spp -> SPProc (subst_specpoint_proc spp)
        | _ -> sp (* don't substitute modules or scopes *) in
      let rec subst_pointcut p =
        match p with 
        | PCMinus (l, r) -> PCMinus (subst_pointcut l, subst_pointcut r)
        | PCAnd (l, r) -> PCAnd (subst_pointcut l, subst_pointcut r)
        | PCOr (l, r) -> PCOr (subst_pointcut l, subst_pointcut r)
        | PCNot e -> PCNot (subst_pointcut e)
        | PCPre sp -> PCPre (subst_specpoint sp)
        | PCPost sp -> PCPost (subst_specpoint sp)
        | PCPrepost sp -> PCPrepost (subst_specpoint sp) in
      let subst_default d = {
        defaultName = 
          Id.fetch_default ast.module_name 
            (Id.name_of_default d.defaultName);
        defaultLocation = d.defaultLocation;
        defaultParms = d.defaultParms;
        defaultPointcut = subst_pointcut d.defaultPointcut;
        defaultBody = subst_form d.defaultBody;
      } in
      let subst_proc p = {
        proc_name = Id.fetch_proc ast.module_name 
          (Id.name_of_proc p.proc_name);
        proc_modifiers = p.proc_modifiers;
        formals = List.map subst_pair p.formals;
        ret_val = (match p.ret_val with None -> None
        | Some x -> Some (subst_pair x));
        suspends = p.suspends;
        requires = subst_form p.requires;
        modifies = List.map subst_var p.modifies;
        calls    = p.calls;
        extra_ensures = List.map (fun (x, y) -> (subst_form x, y)) p.extra_ensures;
        ensures  = subst_form p.ensures;
      } in
      { 
        module_name = ast.module_name;
        instantiated_from = ast.instantiated_from;
        param_subst = ast.param_subst;
        properties = pmod.properties;
        formats = 
          (let fs = List.map 
              (fun x -> subst_type_fmts (TObj x)) pmod.formats in
          List.map Types.string_of_value_type fs);
        invariants  = pmod.invariants;
        specvars = List.map subst_pair_fmts pmod.specvars;
        procs = List.map 
          (clone_instantiated_modules_in_procs instantiation_list) 
          (List.map subst_proc pmod.procs);
        defaults = List.map (clone_instantiated_modules_in_defaults
                               instantiation_list) 
          (List.map subst_default pmod.Sabsyn.defaults);
      }

let instantiate_scope_templates instantiation_list ast = 
  {
   scope_name = ast.scope_name;
   modules    = ast.modules;
   exports    = ast.exports;
   invariant  = ast.invariant;
   scope_defaults = List.map 
     (clone_instantiated_modules_in_defaults instantiation_list) 
     ast.scope_defaults;
  }
