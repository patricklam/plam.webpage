// ValueCheckboxMenuGroup.java
//
// Author: Raja Vallee-Rai
//
// This file is public domain.  You can do anything you want with 
// it, all at your own risk.  Enjoy!


package kor.base;

import java.awt.event.*;
import java.awt.*;

/**
 * This class is an extension of the CheckboxMenuGroup.  Basically, it provides
 * an associated double value with each option.  
 
 */

public class ValueCheckboxMenuGroup extends CheckboxMenuGroup
{
    Dictionary valueOfItems = new HashDictionary();

    /**
     * Adds an option with a given value.
     *
     * <p>Note that this method could be improved by moving m and listener
     * into the constructor.
     *
     * @param s         option to add to this group
     * @param value     the value of this option
     * @param m         the menu to which this group belongs
     * @param listener  which ItemListener to notify when the option gets selected
     */
     
    public void add(String s, double value, Menu m, ItemListener listener)
    {
        super.add(s, m, listener);
        
        valueOfItems.associate(s, new Double(value));
    }
    
    /**
     * Returns the value of the currently selected option.
     */
     
    public double valueOfSelected()
    {
        String selected = getSelected();
        
        return ((Double) valueOfItems.associateOf(selected)).doubleValue();
    }
    
    /**
     * Returns the value of the specified option
     */
     
    public double valueOfItem(String label)
    {
        return ((Double) valueOfItems.associateOf(label)).doubleValue();
    }

    
    /**
     * Returns the option whose value is the closest to the specified value.
     */
     
    public String closestItemToValue(double value)
    {
        boolean found = false;
        double smallestDiff = 0;
        String closestItem = null;
        
        DynamicList list = set.list();
        
        while(!list.isEmpty())
        {
            CheckboxMenuItem item = (CheckboxMenuItem) list.next();
            double itemValue = ((Double) valueOfItems.associateOf(item.getLabel())).doubleValue();
            
            if(!found || Math.abs(value - itemValue) < smallestDiff)
            {
                smallestDiff = Math.abs(value - itemValue);
                found = true;
                closestItem = item.getLabel();
            } 
        }
        
        Debug.assert(found);
        
        return closestItem;
    }
    
}


