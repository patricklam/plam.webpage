package ca.uwaterloo.ece251.ast;

public class ExprResultColumn extends ResultColumn {
    Expr e;
    public ExprResultColumn(Expr e) {
	this.e = e;
    }

    public void accept(Visitor v) {
	v.enter(this);
	e.accept(v);
	v.leave(this);
    }
}

