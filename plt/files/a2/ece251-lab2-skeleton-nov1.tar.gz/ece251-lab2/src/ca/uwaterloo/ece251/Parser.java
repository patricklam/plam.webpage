package ca.uwaterloo.ece251;

import ca.uwaterloo.ece251.ast.*;
import java.util.List;
import java.util.LinkedList;

public class Parser {
    TokenStream ts;
    Token current;

    public Parser(TokenStream ts) {
	this.ts = ts; 
	// prime the pump
	current = ts.nextElement();
    }

    /**
     * TODO: Start Task 2 Here
     */
    public Stmt stmt() {
        return null;
    }

    /* ------------- Helper functions -------------- */

    /** Returns true iff the current token is the same type as t. */
    public boolean accept(Token.Type t) {
	return current.t == t;
    }

    /** Consumes the current token, which must be the same type as t;
	else throws a syntax error. */
    public Token consume(Token.Type t) {
	Token prev = current;
	if (current.t != t) syntax_error();
	current = ts.nextElement();
	return prev;
    }

    /** Stops the program, printing out the syntax error. */
    public void syntax_error() {
	System.out.println("Syntax error at "+current);
	if (true) throw new RuntimeException();
	System.exit(-1);
    }
}
