package ca.uwaterloo.ece251.ast;

public class QualifiedTableNameExpr extends Expr {
    QualifiedTableName tn;

    public QualifiedTableNameExpr(QualifiedTableName tn) {
	this.tn = tn;
    }

    public void accept(Visitor v) {
	v.enter(this);
	v.leave(this);
    }
}
