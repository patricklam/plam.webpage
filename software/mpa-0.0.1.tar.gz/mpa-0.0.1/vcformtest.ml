let _ =
  let lexbuf = Lexing.from_channel stdin in
  while true do
    try let result = Vcformparse.main Vcformlex.token lexbuf in begin
      print_string "Parsed a formula:\n";
      print_string (Vcprint.isabelle_formula result ^ "\n");
      flush_all()
    end with _ -> print_string "Parse error.\n"
  done
