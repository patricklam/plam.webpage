create table MyTable (ID Integer, val1 Integer, val2 Integer);
insert into MyTable (val1, val2) values (2,2);
insert into MyTable (val1, val2) values (4,3);
insert into MyTable (val1, val2) values (5,9);
insert into MyTable (val1, val2) values (7,7);
alter table MyTable add (val3 float);
