package ca.uwaterloo.ece251.ast;

public abstract class ASTNode {
    abstract public void accept(Visitor v);
}
