package ca.uwaterloo.ece251.ast;

public class TupleType extends Type {
    Id id;

    public TupleType(Id id) { this.id = id; }
    public String toString() { return id.toString(); }
}
