package ca.uwaterloo.ece251.ast;

public abstract class Stmt extends ASTNode {
    boolean explain;
    boolean queryPlan;
}
