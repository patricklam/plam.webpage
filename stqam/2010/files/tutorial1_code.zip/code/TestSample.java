/**
 * Noumbissi Noundou, Xavier 
 * ECE453/CS447/CS465
 * Winter 2010
 *
 * JUnit tutorial
 *
 * @copyright: You can modified and reuse this file
 */

import org.junit.*;
import static org.junit.Assert.*;

import java.io.PrintStream;
import java.io.OutputStream;
import java.io.ByteArrayOutputStream;

/**
 * The test class shall be public
 */
public class TestSample {

    private Sample s;

    private PrintStream originalOut;
    private PrintStream ps;
    private OutputStream os;
    private String separator;

    /*
     * The test class shall have
     * a public constructor
     */
    public void TestSample() {
    }
   
    /*
     * We redirect the standard output
     * and change the reference of the
     * variable System.out
     */ 
    private void captureOutput() {
        originalOut = System.out;
        System.setOut(ps);
    }

    /* 
     * We set the standard output 
     * back again
     */
    private void releaseOutput() {
        System.setOut(originalOut);
    }
    
    /**
     * Methods with the annotation '@Before' are
     * executed before each test method
     */
    @Before
    public void setUp() {
        s = new Sample();
        os = new ByteArrayOutputStream();
        ps = new PrintStream(os);
        separator = System.getProperty("line.separator");
    }

    /**
     * Methods with the annotation '@After' are
     * executed after each test method
     */
    @After
    public void tearDown() {
        s = null;
        os = null;
        ps = null;
    }

    /**
     * A method to test Sample.addition().
     * The test method is executed once
     * by the JUnit framework
     *
     * It is no more required to have 'test'
     * prefixing method name
     */
    @Test
    public void additionTest() {
        int a = 1, b = 4;
        
        //call the method to test
        int res = s.addition(a, b);
        assertEquals(res, (a+b));
    }

    /**
     * A method to test Sample.printAddition().
     * The test method is executed once
     * by the JUnit framework
     */
    @Test
    public void testPrintAddition() {
        
        int a = 3, b = 6;
        int res = (a+b);
        String expectedOutput = Integer.toString(res) + separator;
        captureOutput();
        s.printAddition(a, b);
        releaseOutput();        
        assertEquals(expectedOutput, os.toString());
    }

    @Test(expected=ArithmeticException.class )
    public void testdividebyzero() {
        s.divideByZero();
    }

    /*
     * We may want to use this type of
     * testing Exceptions to get detailled
     * information from the the Exception
     * object
     */
    @Test
    public void testAnotherException() {
        try {         
            s.anotherException(0);
            fail("MyException was thrown!");
        }
        catch (MyException e) {
            assertNotNull (e.getMessage());
        }
    }
    
    @Ignore("Not Ready, to be changed")
    @Test
    public void doNothing() {
    }
}
