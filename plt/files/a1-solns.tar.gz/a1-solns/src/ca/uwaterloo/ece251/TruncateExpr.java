package ca.uwaterloo.ece251;

/** AST representation of a truncate expression. */
public class TruncateExpr implements Expr {
    int c;
    Expr v;

    public TruncateExpr(String cs, Expr v) {
	c = Integer.parseInt(cs);
	this.v = v;
    }

    public Value eval(Interp interp) {
	Value arg = v.eval(interp);
	return arg.truncate(c);
    }
}