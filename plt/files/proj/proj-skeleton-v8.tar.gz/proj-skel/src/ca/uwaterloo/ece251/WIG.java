package ca.uwaterloo.ece251;
import org.antlr.runtime.*;
import java.io.*;
import ca.uwaterloo.ece251.symbol.SymbolDefVisitor;
import ca.uwaterloo.ece251.symbol.SymbolUseVisitor;
import ca.uwaterloo.ece251.symbol.SymbolTable;
import ca.uwaterloo.ece251.type.TypeCheckingVisitor;

/** Main entry point. */
public class WIG {
    public static void main(String[] args) throws Exception {
	String fname = null;
	boolean dumpSymbols = false;

	if (args[0].equals("-symbol")) {
	    dumpSymbols = true;
	    fname = args[1];
	}
	else
	    fname = args[0];

        ANTLRFileStream input = new ANTLRFileStream(fname);
        WigLexer lexer = new WigLexer(input);
        CommonTokenStream tokens = new CommonTokenStream(lexer);
        WigParser parser = new WigParser(tokens);
	ca.uwaterloo.ece251.ast.Service s = parser.service();

	SymbolDefVisitor sdv = new SymbolDefVisitor();
	SymbolUseVisitor suv = new SymbolUseVisitor();
	s.accept(sdv); s.accept(suv);
	TypeCheckingVisitor tv = new TypeCheckingVisitor();
	s.accept(tv);

	if (Error.errors)
	    System.exit(-1);

	if (dumpSymbols)
	    System.out.println(SymbolTable.v().dump());
	else
	    System.out.print(s.toString());
    }
}
