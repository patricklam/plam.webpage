#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include "runwig.h"

char *url;
char *sessionid;
int pc;
FILE *f;
#define SLEN 80

void output_Setup()
{
  printf("<body>");
  printf("<h1>");
  printf("A Simple Plus Minus Calculator");
  printf("</h1>");
  printf("<p>");
  printf("\n    Enter your operator (P or M):\n    ");
  printf("<input type=\"text\" name=\"operator\" size=\"1\">\n");
  printf("<p>");
  printf("\n    Enter the first integer (-99 to 999):\n    ");
  printf("<input type=\"text\" name=\"int1\" size=\"3\">\n");
  printf("<p>");
  printf("\n    Enter the second integer (-99 to 999):\n    ");
  printf("<input type=\"text\" name=\"int2\" size=\"3\">\n");
  printf("</body>");
}

void output_Return(char * Ans)
{
  printf("<body>");
  printf("<h1>");
  printf("The Answer");
  printf("</h1>");
  printf("<p>");
  printf("<b>");
  printf("Your answer is : ");
  printf("%s", Ans);
  printf("</b>");
  printf("<p>");
  printf("\n    Would you like to do another calculation (yes or no)?\n    ");
  printf("<input type=\"text\" name=\"YorN\" size=\"5\">\n");
  printf("</body>");
}

void output_ByeBye()
{
  printf("<body>");
  printf("<h1>");
  printf("Thank you for using this calculator");
  printf("</h1>");
  printf("</body>");
}

char * local_Calculate_YorN;
int local_Calculate_int1;
int local_Calculate_int2;
char * local_Calculate_operator;
int main() {
  local_Calculate_YorN = malloc(SLEN);
  local_Calculate_operator = malloc(SLEN);
  srand48(time(0L));
  parseFields();
  url = "http://ece251.patricklam.ca/~plam/cgi-bin/calculator";
  sessionid = getenv("QUERY_STRING");

  if (!sessionid || !*sessionid || strcmp(sessionid, "Calculate")==0)
    goto start_Calculate;
  if (strncmp(sessionid, "Calculate$",10)==0)
    goto restart_Calculate;
  printf("Content-type: text/html\n\n");
  printf("<title>Illegal Request</title>\n");
  printf("<h1>Illegal Request: %s</h1>\n",sessionid);
  exit(1);

start_Calculate:
  sessionid = randomString("Calculate",20);
  /* YorN = ""; */
  strcpy(local_Calculate_YorN,"");
  /* while (YorN != "no") */
  while (strcmp(local_Calculate_YorN,"no")!=0) {
  /* show Setup... */
  printf("Content-type: text/html\n\n");
  printf("<form method=\"POST\" action=\"%s?%s\">\n",url,sessionid);
  output_Setup();
  printf("<p><input type=\"submit\" value=\"continue\">\n");
  printf("</form>\n");
  f = fopen(sessionid,"w");
  fprintf(f, "1\n");
  fprintf(f, "%i\n",local_Calculate_int1);
  fprintf(f, "%s\n",local_Calculate_YorN);
  fprintf(f, "%i\n",local_Calculate_int2);
  fprintf(f, "%s\n",local_Calculate_operator);
  fclose(f);
  exit(0);
Calculate_1:
  /* ... receive [operator = operator, int1 = int1, int2 = int2]; */ 
  local_Calculate_operator = getField("operator");
  local_Calculate_int1 = atoi(getField("int1"));
  local_Calculate_int2 = atoi(getField("int2"));
  /* if (operator == "P") */
  if (strcmp(local_Calculate_operator,"P")==0) {
  /* Ans = int1 + int2; */
  putGlobalInt("global_calculator_Ans", local_Calculate_int1 + local_Calculate_int2);
  }
  /* if (operator == "M") */
  if (strcmp(local_Calculate_operator,"M")==0) {
  /* Ans = int1 - int2; */
  putGlobalInt("global_calculator_Ans", local_Calculate_int1 - local_Calculate_int2);
  }
  /* show plug Return[Ans=Ans]... */
  printf("Content-type: text/html\n\n");
  printf("<form method=\"POST\" action=\"%s?%s\">\n",url,sessionid);
  output_Return(itoa(getGlobalInt("global_calculator_Ans")));
  printf("<p><input type=\"submit\" value=\"continue\">\n");
  printf("</form>\n");
  f = fopen(sessionid,"w");
  fprintf(f, "2\n");
  fprintf(f, "%i\n",local_Calculate_int1);
  fprintf(f, "%s\n",local_Calculate_YorN);
  fprintf(f, "%i\n",local_Calculate_int2);
  fprintf(f, "%s\n",local_Calculate_operator);
  fclose(f);
  exit(0);
Calculate_2:
  /* ... receive [YorN = YorN]; */ 
  local_Calculate_YorN = getField("YorN");
  }
  /* exit ByeBye; */
  printf("Content-type: text/html\n\n");
  output_ByeBye();
  exit(0);
restart_Calculate:
  f = fopen(sessionid, "r");
  fscanf(f, "%i\n",&pc);
  fscanf(f, "%i\n",&local_Calculate_int1);
  fscanf(f, "%s\n",local_Calculate_YorN);
  fscanf(f, "%i\n",&local_Calculate_int2);
  fscanf(f, "%s\n",local_Calculate_operator);
  if (pc==1) goto Calculate_1;
  if (pc==2) goto Calculate_2;
}
