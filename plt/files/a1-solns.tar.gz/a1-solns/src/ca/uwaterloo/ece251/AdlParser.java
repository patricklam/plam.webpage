// $ANTLR 3.1.3 September 27, 2010 10:36:50 Adl.g 2010-10-04 10:47:19

package ca.uwaterloo.ece251;


import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

public class AdlParser extends Parser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "ID", "EXT", "LITERAL", "NEWLINE", "INT_LITERAL", "STRING_LITERAL", "WS", "COMMENT", "'read'", "'.'", "'write'", "'print'", "':='", "'('", "')'", "'sort'", "'map'", "'filter'", "'reduce'", "'truncate'", "'+'", "'-'", "'*'", "'/'", "'>'", "'>='", "'<'", "'<='", "'='", "'ascending'", "'descending'", "'sum'", "'avg'", "'count'", "'concat'", "'preorder'", "'postorder'", "'levelorder'"
    };
    public static final int T__40=40;
    public static final int INT_LITERAL=8;
    public static final int T__41=41;
    public static final int T__29=29;
    public static final int T__28=28;
    public static final int T__27=27;
    public static final int T__26=26;
    public static final int T__25=25;
    public static final int T__24=24;
    public static final int T__23=23;
    public static final int T__22=22;
    public static final int T__21=21;
    public static final int T__20=20;
    public static final int LITERAL=6;
    public static final int ID=4;
    public static final int EOF=-1;
    public static final int T__30=30;
    public static final int T__19=19;
    public static final int T__31=31;
    public static final int T__32=32;
    public static final int WS=10;
    public static final int STRING_LITERAL=9;
    public static final int T__33=33;
    public static final int T__16=16;
    public static final int T__34=34;
    public static final int T__15=15;
    public static final int NEWLINE=7;
    public static final int T__35=35;
    public static final int T__18=18;
    public static final int T__36=36;
    public static final int T__17=17;
    public static final int T__37=37;
    public static final int T__12=12;
    public static final int T__38=38;
    public static final int T__39=39;
    public static final int T__14=14;
    public static final int T__13=13;
    public static final int EXT=5;
    public static final int COMMENT=11;

    // delegates
    // delegators


        public AdlParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public AdlParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return AdlParser.tokenNames; }
    public String getGrammarFileName() { return "Adl.g"; }


        Interp interp = new Interp();



    // $ANTLR start "prog"
    // Adl.g:12:1: prog : ( stmt )* EOF ;
    public final void prog() throws RecognitionException {
        try {
            // Adl.g:12:5: ( ( stmt )* EOF )
            // Adl.g:12:7: ( stmt )* EOF
            {
            // Adl.g:12:7: ( stmt )*
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( (LA1_0==ID||LA1_0==12||(LA1_0>=14 && LA1_0<=15)) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // Adl.g:12:7: stmt
            	    {
            	    pushFollow(FOLLOW_stmt_in_prog29);
            	    stmt();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);

            match(input,EOF,FOLLOW_EOF_in_prog32); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "prog"


    // $ANTLR start "stmt"
    // Adl.g:14:1: stmt : ( read | write | print | assign ) ;
    public final void stmt() throws RecognitionException {
        try {
            // Adl.g:14:5: ( ( read | write | print | assign ) )
            // Adl.g:14:7: ( read | write | print | assign )
            {
            // Adl.g:14:7: ( read | write | print | assign )
            int alt2=4;
            switch ( input.LA(1) ) {
            case 12:
                {
                alt2=1;
                }
                break;
            case 14:
                {
                alt2=2;
                }
                break;
            case 15:
                {
                alt2=3;
                }
                break;
            case ID:
                {
                alt2=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 2, 0, input);

                throw nvae;
            }

            switch (alt2) {
                case 1 :
                    // Adl.g:14:8: read
                    {
                    pushFollow(FOLLOW_read_in_stmt40);
                    read();

                    state._fsp--;


                    }
                    break;
                case 2 :
                    // Adl.g:14:15: write
                    {
                    pushFollow(FOLLOW_write_in_stmt44);
                    write();

                    state._fsp--;


                    }
                    break;
                case 3 :
                    // Adl.g:14:23: print
                    {
                    pushFollow(FOLLOW_print_in_stmt48);
                    print();

                    state._fsp--;


                    }
                    break;
                case 4 :
                    // Adl.g:14:31: assign
                    {
                    pushFollow(FOLLOW_assign_in_stmt52);
                    assign();

                    state._fsp--;


                    }
                    break;

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "stmt"


    // $ANTLR start "read"
    // Adl.g:16:1: read : 'read' ID '.' EXT ;
    public final void read() throws RecognitionException {
        Token ID1=null;
        Token EXT2=null;

        try {
            // Adl.g:16:5: ( 'read' ID '.' EXT )
            // Adl.g:16:7: 'read' ID '.' EXT
            {
            match(input,12,FOLLOW_12_in_read60); 
            ID1=(Token)match(input,ID,FOLLOW_ID_in_read62); 
            match(input,13,FOLLOW_13_in_read64); 
            EXT2=(Token)match(input,EXT,FOLLOW_EXT_in_read66); 
             interp.read((ID1!=null?ID1.getText():null), (EXT2!=null?EXT2.getText():null)); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "read"


    // $ANTLR start "write"
    // Adl.g:18:1: write : 'write' ID ;
    public final void write() throws RecognitionException {
        Token ID3=null;

        try {
            // Adl.g:18:6: ( 'write' ID )
            // Adl.g:18:8: 'write' ID
            {
            match(input,14,FOLLOW_14_in_write75); 
            ID3=(Token)match(input,ID,FOLLOW_ID_in_write77); 
             interp.write((ID3!=null?ID3.getText():null)); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "write"


    // $ANTLR start "print"
    // Adl.g:20:1: print : 'print' ID ;
    public final void print() throws RecognitionException {
        Token ID4=null;

        try {
            // Adl.g:20:6: ( 'print' ID )
            // Adl.g:20:8: 'print' ID
            {
            match(input,15,FOLLOW_15_in_print86); 
            ID4=(Token)match(input,ID,FOLLOW_ID_in_print88); 
             interp.print((ID4!=null?ID4.getText():null)); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "print"


    // $ANTLR start "assign"
    // Adl.g:22:1: assign : ID ':=' exp ;
    public final void assign() throws RecognitionException {
        Token ID5=null;
        Expr exp6 = null;


        try {
            // Adl.g:22:7: ( ID ':=' exp )
            // Adl.g:22:9: ID ':=' exp
            {
            ID5=(Token)match(input,ID,FOLLOW_ID_in_assign97); 
            match(input,16,FOLLOW_16_in_assign99); 
            pushFollow(FOLLOW_exp_in_assign101);
            exp6=exp();

            state._fsp--;

             interp.assign((ID5!=null?ID5.getText():null), exp6); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "assign"


    // $ANTLR start "exp"
    // Adl.g:25:1: exp returns [Expr e] : ( ID | LITERAL | '(' e1= exp ')' | 'sort' comparator e1= exp | 'map' transformer e1= exp | 'filter' predicate e1= exp | 'reduce' accumulator e1= exp | order e1= exp | 'truncate' LITERAL e1= exp );
    public final Expr exp() throws RecognitionException {
        Expr e = null;

        Token ID7=null;
        Token LITERAL8=null;
        Token LITERAL14=null;
        Expr e1 = null;

        Expr.Comparator comparator9 = null;

        Expr.Transformer transformer10 = null;

        Expr.Filter predicate11 = null;

        Expr.Accumulator accumulator12 = null;

        Expr.Order order13 = null;


        try {
            // Adl.g:26:5: ( ID | LITERAL | '(' e1= exp ')' | 'sort' comparator e1= exp | 'map' transformer e1= exp | 'filter' predicate e1= exp | 'reduce' accumulator e1= exp | order e1= exp | 'truncate' LITERAL e1= exp )
            int alt3=9;
            switch ( input.LA(1) ) {
            case ID:
                {
                alt3=1;
                }
                break;
            case LITERAL:
                {
                alt3=2;
                }
                break;
            case 17:
                {
                alt3=3;
                }
                break;
            case 19:
                {
                alt3=4;
                }
                break;
            case 20:
                {
                alt3=5;
                }
                break;
            case 21:
                {
                alt3=6;
                }
                break;
            case 22:
                {
                alt3=7;
                }
                break;
            case 39:
            case 40:
            case 41:
                {
                alt3=8;
                }
                break;
            case 23:
                {
                alt3=9;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 3, 0, input);

                throw nvae;
            }

            switch (alt3) {
                case 1 :
                    // Adl.g:26:7: ID
                    {
                    ID7=(Token)match(input,ID,FOLLOW_ID_in_exp120); 
                     e = new IdExpr((ID7!=null?ID7.getText():null)); 

                    }
                    break;
                case 2 :
                    // Adl.g:27:7: LITERAL
                    {
                    LITERAL8=(Token)match(input,LITERAL,FOLLOW_LITERAL_in_exp130); 
                     e = new LiteralExpr((LITERAL8!=null?LITERAL8.getText():null)); 

                    }
                    break;
                case 3 :
                    // Adl.g:28:7: '(' e1= exp ')'
                    {
                    match(input,17,FOLLOW_17_in_exp140); 
                    pushFollow(FOLLOW_exp_in_exp144);
                    e1=exp();

                    state._fsp--;

                    match(input,18,FOLLOW_18_in_exp146); 
                    e = e1;

                    }
                    break;
                case 4 :
                    // Adl.g:29:7: 'sort' comparator e1= exp
                    {
                    match(input,19,FOLLOW_19_in_exp156); 
                    pushFollow(FOLLOW_comparator_in_exp158);
                    comparator9=comparator();

                    state._fsp--;

                    pushFollow(FOLLOW_exp_in_exp162);
                    e1=exp();

                    state._fsp--;

                     e = new SortExpr(comparator9, e1); 

                    }
                    break;
                case 5 :
                    // Adl.g:30:7: 'map' transformer e1= exp
                    {
                    match(input,20,FOLLOW_20_in_exp172); 
                    pushFollow(FOLLOW_transformer_in_exp174);
                    transformer10=transformer();

                    state._fsp--;

                    pushFollow(FOLLOW_exp_in_exp178);
                    e1=exp();

                    state._fsp--;

                     e = new MapExpr(transformer10, e1); 

                    }
                    break;
                case 6 :
                    // Adl.g:31:7: 'filter' predicate e1= exp
                    {
                    match(input,21,FOLLOW_21_in_exp188); 
                    pushFollow(FOLLOW_predicate_in_exp190);
                    predicate11=predicate();

                    state._fsp--;

                    pushFollow(FOLLOW_exp_in_exp194);
                    e1=exp();

                    state._fsp--;

                     e = new FilterExpr(predicate11, e1); 

                    }
                    break;
                case 7 :
                    // Adl.g:32:7: 'reduce' accumulator e1= exp
                    {
                    match(input,22,FOLLOW_22_in_exp204); 
                    pushFollow(FOLLOW_accumulator_in_exp206);
                    accumulator12=accumulator();

                    state._fsp--;

                    pushFollow(FOLLOW_exp_in_exp210);
                    e1=exp();

                    state._fsp--;

                     e = new ReduceExpr(accumulator12, e1); 

                    }
                    break;
                case 8 :
                    // Adl.g:33:7: order e1= exp
                    {
                    pushFollow(FOLLOW_order_in_exp220);
                    order13=order();

                    state._fsp--;

                    pushFollow(FOLLOW_exp_in_exp224);
                    e1=exp();

                    state._fsp--;

                    e = new OrderExpr(order13, e1); 

                    }
                    break;
                case 9 :
                    // Adl.g:34:7: 'truncate' LITERAL e1= exp
                    {
                    match(input,23,FOLLOW_23_in_exp234); 
                    LITERAL14=(Token)match(input,LITERAL,FOLLOW_LITERAL_in_exp236); 
                    pushFollow(FOLLOW_exp_in_exp240);
                    e1=exp();

                    state._fsp--;

                    e = new TruncateExpr((LITERAL14!=null?LITERAL14.getText():null), e1); 

                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return e;
    }
    // $ANTLR end "exp"


    // $ANTLR start "transformer"
    // Adl.g:38:1: transformer returns [Expr.Transformer e] : ( '+' LITERAL | '-' LITERAL | '*' LITERAL | '/' LITERAL );
    public final Expr.Transformer transformer() throws RecognitionException {
        Expr.Transformer e = null;

        Token LITERAL15=null;
        Token LITERAL16=null;
        Token LITERAL17=null;
        Token LITERAL18=null;

        try {
            // Adl.g:39:5: ( '+' LITERAL | '-' LITERAL | '*' LITERAL | '/' LITERAL )
            int alt4=4;
            switch ( input.LA(1) ) {
            case 24:
                {
                alt4=1;
                }
                break;
            case 25:
                {
                alt4=2;
                }
                break;
            case 26:
                {
                alt4=3;
                }
                break;
            case 27:
                {
                alt4=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 4, 0, input);

                throw nvae;
            }

            switch (alt4) {
                case 1 :
                    // Adl.g:39:7: '+' LITERAL
                    {
                    match(input,24,FOLLOW_24_in_transformer264); 
                    LITERAL15=(Token)match(input,LITERAL,FOLLOW_LITERAL_in_transformer266); 
                     e = new Expr.Transformer(Expr.TransformerKind.PLUS, new AtomValue((LITERAL15!=null?LITERAL15.getText():null), true)); 

                    }
                    break;
                case 2 :
                    // Adl.g:40:7: '-' LITERAL
                    {
                    match(input,25,FOLLOW_25_in_transformer276); 
                    LITERAL16=(Token)match(input,LITERAL,FOLLOW_LITERAL_in_transformer278); 
                     e = new Expr.Transformer(Expr.TransformerKind.MINUS, new AtomValue((LITERAL16!=null?LITERAL16.getText():null), true)); 

                    }
                    break;
                case 3 :
                    // Adl.g:41:7: '*' LITERAL
                    {
                    match(input,26,FOLLOW_26_in_transformer288); 
                    LITERAL17=(Token)match(input,LITERAL,FOLLOW_LITERAL_in_transformer290); 
                     e = new Expr.Transformer(Expr.TransformerKind.TIMES, new AtomValue((LITERAL17!=null?LITERAL17.getText():null), true)); 

                    }
                    break;
                case 4 :
                    // Adl.g:42:7: '/' LITERAL
                    {
                    match(input,27,FOLLOW_27_in_transformer300); 
                    LITERAL18=(Token)match(input,LITERAL,FOLLOW_LITERAL_in_transformer302); 
                     e = new Expr.Transformer(Expr.TransformerKind.DIVIDE, new AtomValue((LITERAL18!=null?LITERAL18.getText():null), true)); 

                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return e;
    }
    // $ANTLR end "transformer"


    // $ANTLR start "predicate"
    // Adl.g:46:1: predicate returns [Expr.Filter e] : ( '>' LITERAL | '>=' LITERAL | '<' LITERAL | '<=' LITERAL | '=' LITERAL );
    public final Expr.Filter predicate() throws RecognitionException {
        Expr.Filter e = null;

        Token LITERAL19=null;
        Token LITERAL20=null;
        Token LITERAL21=null;
        Token LITERAL22=null;
        Token LITERAL23=null;

        try {
            // Adl.g:47:5: ( '>' LITERAL | '>=' LITERAL | '<' LITERAL | '<=' LITERAL | '=' LITERAL )
            int alt5=5;
            switch ( input.LA(1) ) {
            case 28:
                {
                alt5=1;
                }
                break;
            case 29:
                {
                alt5=2;
                }
                break;
            case 30:
                {
                alt5=3;
                }
                break;
            case 31:
                {
                alt5=4;
                }
                break;
            case 32:
                {
                alt5=5;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 5, 0, input);

                throw nvae;
            }

            switch (alt5) {
                case 1 :
                    // Adl.g:47:8: '>' LITERAL
                    {
                    match(input,28,FOLLOW_28_in_predicate327); 
                    LITERAL19=(Token)match(input,LITERAL,FOLLOW_LITERAL_in_predicate329); 
                     e = new Expr.Filter(Expr.FilterKind.GT, new AtomValue((LITERAL19!=null?LITERAL19.getText():null), true)); 

                    }
                    break;
                case 2 :
                    // Adl.g:48:7: '>=' LITERAL
                    {
                    match(input,29,FOLLOW_29_in_predicate339); 
                    LITERAL20=(Token)match(input,LITERAL,FOLLOW_LITERAL_in_predicate341); 
                     e = new Expr.Filter(Expr.FilterKind.GE, new AtomValue((LITERAL20!=null?LITERAL20.getText():null), true)); 

                    }
                    break;
                case 3 :
                    // Adl.g:49:7: '<' LITERAL
                    {
                    match(input,30,FOLLOW_30_in_predicate351); 
                    LITERAL21=(Token)match(input,LITERAL,FOLLOW_LITERAL_in_predicate353); 
                     e = new Expr.Filter(Expr.FilterKind.LT, new AtomValue((LITERAL21!=null?LITERAL21.getText():null), true)); 

                    }
                    break;
                case 4 :
                    // Adl.g:50:7: '<=' LITERAL
                    {
                    match(input,31,FOLLOW_31_in_predicate363); 
                    LITERAL22=(Token)match(input,LITERAL,FOLLOW_LITERAL_in_predicate365); 
                     e = new Expr.Filter(Expr.FilterKind.LE, new AtomValue((LITERAL22!=null?LITERAL22.getText():null), true)); 

                    }
                    break;
                case 5 :
                    // Adl.g:51:7: '=' LITERAL
                    {
                    match(input,32,FOLLOW_32_in_predicate375); 
                    LITERAL23=(Token)match(input,LITERAL,FOLLOW_LITERAL_in_predicate377); 
                     e = new Expr.Filter(Expr.FilterKind.EQ, new AtomValue((LITERAL23!=null?LITERAL23.getText():null), true)); 

                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return e;
    }
    // $ANTLR end "predicate"


    // $ANTLR start "comparator"
    // Adl.g:54:1: comparator returns [Expr.Comparator c] : ( 'ascending' | 'descending' );
    public final Expr.Comparator comparator() throws RecognitionException {
        Expr.Comparator c = null;

        try {
            // Adl.g:55:5: ( 'ascending' | 'descending' )
            int alt6=2;
            int LA6_0 = input.LA(1);

            if ( (LA6_0==33) ) {
                alt6=1;
            }
            else if ( (LA6_0==34) ) {
                alt6=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 6, 0, input);

                throw nvae;
            }
            switch (alt6) {
                case 1 :
                    // Adl.g:55:7: 'ascending'
                    {
                    match(input,33,FOLLOW_33_in_comparator400); 
                     c = Expr.Comparator.ASCENDING; 

                    }
                    break;
                case 2 :
                    // Adl.g:56:7: 'descending'
                    {
                    match(input,34,FOLLOW_34_in_comparator411); 
                     c = Expr.Comparator.DESCENDING; 

                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return c;
    }
    // $ANTLR end "comparator"


    // $ANTLR start "accumulator"
    // Adl.g:59:1: accumulator returns [Expr.Accumulator a] : ( 'sum' | 'avg' | 'count' | 'concat' );
    public final Expr.Accumulator accumulator() throws RecognitionException {
        Expr.Accumulator a = null;

        try {
            // Adl.g:60:5: ( 'sum' | 'avg' | 'count' | 'concat' )
            int alt7=4;
            switch ( input.LA(1) ) {
            case 35:
                {
                alt7=1;
                }
                break;
            case 36:
                {
                alt7=2;
                }
                break;
            case 37:
                {
                alt7=3;
                }
                break;
            case 38:
                {
                alt7=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 7, 0, input);

                throw nvae;
            }

            switch (alt7) {
                case 1 :
                    // Adl.g:60:7: 'sum'
                    {
                    match(input,35,FOLLOW_35_in_accumulator434); 
                     a = Expr.Accumulator.SUM; 

                    }
                    break;
                case 2 :
                    // Adl.g:61:7: 'avg'
                    {
                    match(input,36,FOLLOW_36_in_accumulator444); 
                     a = Expr.Accumulator.AVG; 

                    }
                    break;
                case 3 :
                    // Adl.g:62:7: 'count'
                    {
                    match(input,37,FOLLOW_37_in_accumulator455); 
                     a = Expr.Accumulator.COUNT; 

                    }
                    break;
                case 4 :
                    // Adl.g:63:7: 'concat'
                    {
                    match(input,38,FOLLOW_38_in_accumulator466); 
                     a = Expr.Accumulator.CONCAT; 

                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return a;
    }
    // $ANTLR end "accumulator"


    // $ANTLR start "order"
    // Adl.g:66:1: order returns [Expr.Order o] : ( 'preorder' | 'postorder' | 'levelorder' );
    public final Expr.Order order() throws RecognitionException {
        Expr.Order o = null;

        try {
            // Adl.g:67:5: ( 'preorder' | 'postorder' | 'levelorder' )
            int alt8=3;
            switch ( input.LA(1) ) {
            case 39:
                {
                alt8=1;
                }
                break;
            case 40:
                {
                alt8=2;
                }
                break;
            case 41:
                {
                alt8=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 8, 0, input);

                throw nvae;
            }

            switch (alt8) {
                case 1 :
                    // Adl.g:67:7: 'preorder'
                    {
                    match(input,39,FOLLOW_39_in_order489); 
                    o = Expr.Order.PRE; 

                    }
                    break;
                case 2 :
                    // Adl.g:68:7: 'postorder'
                    {
                    match(input,40,FOLLOW_40_in_order500); 
                    o = Expr.Order.POST; 

                    }
                    break;
                case 3 :
                    // Adl.g:69:7: 'levelorder'
                    {
                    match(input,41,FOLLOW_41_in_order511); 
                    o = Expr.Order.LEVEL; 

                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return o;
    }
    // $ANTLR end "order"

    // Delegated rules


 

    public static final BitSet FOLLOW_stmt_in_prog29 = new BitSet(new long[]{0x000000000000D010L});
    public static final BitSet FOLLOW_EOF_in_prog32 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_read_in_stmt40 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_write_in_stmt44 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_print_in_stmt48 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_assign_in_stmt52 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_12_in_read60 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_ID_in_read62 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_13_in_read64 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_EXT_in_read66 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_14_in_write75 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_ID_in_write77 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_15_in_print86 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_ID_in_print88 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ID_in_assign97 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_16_in_assign99 = new BitSet(new long[]{0x0000038000FA0050L});
    public static final BitSet FOLLOW_exp_in_assign101 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ID_in_exp120 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_LITERAL_in_exp130 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_17_in_exp140 = new BitSet(new long[]{0x0000038000FA0050L});
    public static final BitSet FOLLOW_exp_in_exp144 = new BitSet(new long[]{0x0000000000040000L});
    public static final BitSet FOLLOW_18_in_exp146 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_19_in_exp156 = new BitSet(new long[]{0x0000000600000000L});
    public static final BitSet FOLLOW_comparator_in_exp158 = new BitSet(new long[]{0x0000038000FA0050L});
    public static final BitSet FOLLOW_exp_in_exp162 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_20_in_exp172 = new BitSet(new long[]{0x000000000F000000L});
    public static final BitSet FOLLOW_transformer_in_exp174 = new BitSet(new long[]{0x0000038000FA0050L});
    public static final BitSet FOLLOW_exp_in_exp178 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_21_in_exp188 = new BitSet(new long[]{0x00000001F0000000L});
    public static final BitSet FOLLOW_predicate_in_exp190 = new BitSet(new long[]{0x0000038000FA0050L});
    public static final BitSet FOLLOW_exp_in_exp194 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_22_in_exp204 = new BitSet(new long[]{0x0000007800000000L});
    public static final BitSet FOLLOW_accumulator_in_exp206 = new BitSet(new long[]{0x0000038000FA0050L});
    public static final BitSet FOLLOW_exp_in_exp210 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_order_in_exp220 = new BitSet(new long[]{0x0000038000FA0050L});
    public static final BitSet FOLLOW_exp_in_exp224 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_23_in_exp234 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_LITERAL_in_exp236 = new BitSet(new long[]{0x0000038000FA0050L});
    public static final BitSet FOLLOW_exp_in_exp240 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_24_in_transformer264 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_LITERAL_in_transformer266 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_25_in_transformer276 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_LITERAL_in_transformer278 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_26_in_transformer288 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_LITERAL_in_transformer290 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_27_in_transformer300 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_LITERAL_in_transformer302 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_28_in_predicate327 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_LITERAL_in_predicate329 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_29_in_predicate339 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_LITERAL_in_predicate341 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_30_in_predicate351 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_LITERAL_in_predicate353 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_31_in_predicate363 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_LITERAL_in_predicate365 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_32_in_predicate375 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_LITERAL_in_predicate377 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_33_in_comparator400 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_34_in_comparator411 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_35_in_accumulator434 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_36_in_accumulator444 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_37_in_accumulator455 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_38_in_accumulator466 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_39_in_order489 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_40_in_order500 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_41_in_order511 = new BitSet(new long[]{0x0000000000000002L});

}