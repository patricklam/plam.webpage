// CacheViewer.java
//
// Author: Raja Vallee-Rai
//
// This file is public domain.  You can do anything you want with 
// it, all at your own risk.  Enjoy!

import java.awt.*;
import java.awt.event.*;

import kor.base.*;

/**
 * Frame which just reports how much pre-simulation has been cached, in seconds.
 */

class CacheViewer extends Frame implements Viewer,
                                            WindowListener,
                                            ActionListener
{
    Playfield playfield;
    
    Label secsLabel;

    Button dismissButton;
    
    public CacheViewer(Playfield playfield)
    {
        super("Cache Statistics");
        
        addWindowListener(this);
        
        this.playfield = playfield;
        
        setSize(new Dimension(300, 100));
        setLayout(new BorderLayout());
        
        // Top Panel
        {
            Panel p = new Panel();
                
            p.setLayout(new FlowLayout());
           
            p.add(secsLabel = new Label());
            
            add(p, "Center");
        }
        
        // Bottom panel.
        {
            Panel p = new Panel();
            
            p.setLayout(new FlowLayout());
            
            p.add(dismissButton = new Button("Dismiss"));
            dismissButton.addActionListener(this);
            
            add(p, "South");
        }
        
        refreshView();
        WindowPlacer.placeWindowAt(this, "Southwest");
    } 
    
    public void setVisible(boolean visible)
    {
        if(visible)
        {
            playfield.viewers.add(this);
            super.setVisible(true);
        }
        else {
            playfield.viewers.remove(this);
            super.setVisible(false);
        }
    }
    
    public void refreshView()
    {
        secsLabel.setText(new Double(ExtDouble.truncatedOf(playfield.secsOfCacheReady, 1)).
            toString() + " secs of pre-simulation cached");
    }
    
    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource() == dismissButton)
            handleClickToClose();
    }
    
    void handleClickToClose()
    {
        setVisible(false);
    }
                
    public void windowClosing(WindowEvent e)
    {
        handleClickToClose();
    }
     
    public void windowOpened(WindowEvent e)
    {
    }
     
    public void windowIconified(WindowEvent e)
    {
    }
     
    public void windowDeiconified(WindowEvent e)
    {
    }
     
    public void windowClosed(WindowEvent e)
    {
    }
     
    public void windowActivated(WindowEvent e)
    {
    }
     
    public void windowDeactivated(WindowEvent e) 
    {
    }
}


