(* Compute weakest preconditions *)

open Iabsyn
open Vcform
open Vctrans

type stmt = Vcform.form Iabsyn.stmt

let assign modn (v:ident) (rhs:Iabsyn.expr) (f:Vcform.form) =  
  let vc_rhs = prime_all (vcexpr_of_iabsyn modn rhs) in 
  let r = subst [(primed v,vc_rhs)] f in  
  begin
    (*
    print_string ("\nassignment post formula to variable:" ^ primed v); 
    print_string (Vcprint.isabelle_formula f);
    print_string ("wp = " ^ Vcprint.isabelle_formula r ^ "\n\n");
     *)
    r
  end

let arrayAssign modn (v:ident) (ind:Iabsyn.expr) (rhs:Iabsyn.expr) (f:Vcform.form) =
  let vc_rhs = vcexpr_of_iabsyn modn rhs in
  let vc_ind = vcexpr_of_iabsyn modn ind in
  let vc_arrayWrite = prime_all (mk_arrayWrite(mk_var v,vc_ind,vc_rhs)) in
  let main_part = subst [(primed v,vc_arrayWrite)] f in
  (* let bounds_check = mk_true mk_lteq(mk_int 0,vc_ind) in
     mk_and [bounds_check;main_part] *)
  begin
    (*
    print_string ("\nassignment post formula to variable:" ^ primed v); 
    print_string (Vcprint.isabelle_formula f);
    print_string ("wp = " ^ Vcprint.isabelle_formula main_part ^ "\n\n");
     *)
    main_part
  end

let rec wp modn (s:stmt) (f:form) : form =   
  let rec lwp s f = match s with
  | EmptyStmt -> f
  | ChoiceStmt(s1,s2) -> Vcform.smk_and [wp1 s1 f; wp1 s2 f]
  | LocalDeclStmt (v,t,_) -> smk_forall(v,vctype_of t,f)
  | ExprStmt e -> (match e with
    | AssignExpr(LocalLvalue v,rhs) -> 
        assign modn (mk_local_var v) rhs f
    | AssignExpr(RefLvalue v,rhs) -> 
        assign modn (mk_global_var modn v) rhs f
    | AssignExpr(ArrayLvalue(VarExpr (LocalLvalue v),e2),rhs) -> 
        arrayAssign modn (mk_local_var v) e2 rhs f
    | AssignExpr(ArrayLvalue(VarExpr (RefLvalue v),e2),rhs) -> 
        arrayAssign modn (mk_global_var modn v) e2 rhs f
    | AssignExpr(_,_) ->
        failwith "Vcwp.wp: assignment statement not simple enough"
    | _ -> failwith "Vcwp.wp: only assignment expressions are statements")
  | CompoundStmt ss -> List.fold_right wp1 ss f
  | AssertStmt(s,f1) -> smk_and [f1; f]
  | AssumeStmt(s,f1) -> smk_impl(f1,f)
  | HavocStmt vs -> 
      let add id = (primed id,TypeVoid) in 
      let add_typ_prim ids = List.map add ids in
      smk_foralls(add_typ_prim vs,f)
  | PragmaStmt _ -> f
  | (ReturnStmt _|WhileStmt(_,_,_)|IfStmt(_,_,_)) ->
      failwith "Vcwp.wp: Found a statement that should have been desugared"
  and wp1 s f = let r = lwp s f in begin
    (*
    print_string ("\nPOST FORMULA:\n" ^ Vcprint.isabelle_formula f);
    print_string ("\nSTATEMENT:\n" ^ Iabsynprinter.pstmt 2 Vcprint.isabelle_formula s);
    print_string ("WEAKEST PRECONDITION = " ^ Vcprint.isabelle_formula r ^ "\n");
     *)
    r
  end
  in wp1 s f

