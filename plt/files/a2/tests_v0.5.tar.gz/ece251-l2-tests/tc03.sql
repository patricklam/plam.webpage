SELECT v.date, p.price, v.volume FROM (SELECT v.date FROM price AS p2 WHERE p2.date <= v.date) AS p WHERE p2.itemid = v.itemid;
                  