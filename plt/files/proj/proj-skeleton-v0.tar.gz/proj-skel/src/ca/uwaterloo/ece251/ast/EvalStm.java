package ca.uwaterloo.ece251.ast;

/** Represents an eval statement, which evaluates an expression. */
public class EvalStm extends Stm {
    Exp c;

    public EvalStm(Exp c) { this.c = c; }
    public String toString() { 
	return c.toString() + ";";
    }
}

