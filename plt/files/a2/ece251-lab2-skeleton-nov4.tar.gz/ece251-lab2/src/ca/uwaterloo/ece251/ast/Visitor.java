package ca.uwaterloo.ece251.ast;

public interface Visitor {
    public void enter(SelectSingleSource t);
    public void enter(JoinSingleSource t);
    public void enter(QualifiedTableNameSingleSource t);

    public void enter(ColumnDef t);
    public void enter(IdExprPair t);
    public void enter(UnaryOpExpr t);
    public void enter(BinaryOpExpr t);
    public void enter(LiteralExpr t);
    public void enter(QualifiedTableNameExpr t);

    public void enter(ExprResultColumn t);
    public void enter(StarResultColumn t);

    public void enter(CreateTableStmt t);
    public void enter(DropTableStmt t);
    public void enter(InsertStmt t);
    public void enter(SelectStmt t);
    public void enter(UpdateStmt t);
    public void enter(VacuumStmt t);

    public void enterColumns();
    public void leaveColumns();
    public void leaveColumn(String s);
    public void enterValues();
    public void leaveValues();

    public void leave(SelectSingleSource t);
    public void leave(JoinSingleSource t);
    public void leave(QualifiedTableNameSingleSource t);

    public void leave(ColumnDef t);
    public void leave(IdExprPair t);
    public void leave(UnaryOpExpr t);
    public void leave(BinaryOpExpr t);
    public void leave(LiteralExpr t);
    public void leave(QualifiedTableNameExpr t);

    public void leave(ExprResultColumn t);
    public void leave(StarResultColumn t);

    public void leave(CreateTableStmt t);
    public void leave(DropTableStmt t);
    public void leave(InsertStmt t);
    public void leave(SelectStmt t);
    public void leave(UpdateStmt t);
    public void leave(VacuumStmt t);
}
