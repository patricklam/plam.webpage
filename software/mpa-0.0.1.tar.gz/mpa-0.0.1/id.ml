(* things that need IDs: 
 * formats          (globally unique)
 * modules          (globally unique)
 * fields           (per-module/format namespace)
 * procs            (per-module namespace)
 * references       (per-module namespace)
 * local variables  (per-block namespace)
 *)

type scope_t = string

type format_t = string 
type module_t = string
type field_t = { f_name:string; f_module:module_t }
type proc_t = { p_name:string; p_module:module_t; }
type var_t = string

let fetch_scope : string -> scope_t = function s -> s
let fetch_format : string -> format_t = function s -> s
let fetch_module : string -> module_t = function s -> s
let fetch_field : module_t -> string -> field_t = fun m n -> { f_name = n; f_module = m }
let fetch_proc : module_t -> string -> proc_t = fun m n -> { p_name = n; p_module = m; }
let fetch_var : string -> var_t = function s -> s

let name_of_field f = f.f_name
let module_of_field f = f.f_module

let name_of_proc p = p.p_name
let module_of_proc p = p.p_module

let main_module = fetch_module "Main"
let unknown_format = fetch_format "Unknown"
let null_format = fetch_format "Null"

