let scopes_of : Id.module_t -> Id.scope_t list = fun m -> 
  [Id.fetch_scope "ALL"]

let modules_in_scope : Id.scope_t -> Id.module_t list = fun s ->
  List.map (fun x -> x.Sabsyn.module_name) !Ast.spec
