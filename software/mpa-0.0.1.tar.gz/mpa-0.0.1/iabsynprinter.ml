open Iabsyn
open Types

let (chn : out_channel option ref) = ref None

let wr (s:string) : unit = output_string (Util.unsome !chn) s

let rec p_type (t:value_type) : string = match t with
| TInt -> "int"
| TBool -> "bool"
| TFloat -> "float"
| TString -> "string"
| TChar -> "char"
| TObj format_nm -> format_nm
| TArray vt -> "array of " ^ p_type vt
| TVoid -> "void"


let string_of_value x =
  match x with
  | Int i -> string_of_int i
  | Bool true -> "true"
  | Bool false -> "false"
  | Float f -> string_of_float f
  | String s -> "\"" ^ (String.escaped s) ^ "\""
  | Char c -> "'" ^ (String.make 1 c) ^ "'"
  | Obj 0 -> "null"
  | Array _ -> "<array>"
  | Obj _ -> "<obj>"

let rec string_of_lvalue (lv:Iabsyn.lvalue) =
  match lv with
    LocalLvalue v -> v
  | RefLvalue v -> v
  | FieldLvalue (e, f) -> (string_of_expr e) ^ "." ^ (Id.name_of_field f)
  | ArrayLvalue (e, i) -> (string_of_expr e) ^ "[" ^ (string_of_expr i) ^ "]"
and string_of_expr (e:Iabsyn.expr) =  (* actually, should do precedence *)
                               (* unless we always have jimplified exprs *)
  match e with
    LiteralExpr v -> string_of_value v
  | VarExpr v -> string_of_lvalue v
  | FieldAccessExpr (e, f) -> (string_of_expr e) ^ "." ^ (Id.name_of_field f)
  | ArrayAccessExpr (e, i) -> 
      (string_of_expr e) ^ "[" ^ (string_of_expr i) ^ "]"
  | NewExpr f -> "new " ^ f ^ "()"
  | NewArrayExpr (t, e, d) -> 
      let rec bprs i = if (i = 0) then "" else ("[]"^bprs (i-1)) in
      "new "^(string_of_value_type t)^
      String.concat "" (List.map (fun x -> "["^(string_of_expr x)^"]") e)^
      bprs d
  | InvokeExpr (p, []) -> (Id.module_of_proc p) ^ "." ^ 
      (Id.name_of_proc p) ^ "()"
  | InvokeExpr (p, args) -> (Id.module_of_proc p) ^ "." ^ 
      (Id.name_of_proc p) ^ "(" ^
      (List.fold_right (fun x y -> ((string_of_expr x) ^ ", " ^ y)) 
         (List.tl args) 
         (string_of_expr (List.hd args)) ^ ")")
  | AssignExpr (l, r) -> (string_of_lvalue l) ^ " = " ^ (string_of_expr r)
  | PreIncExpr v -> "++" ^ (string_of_lvalue v)
  | PostIncExpr v -> (string_of_lvalue v) ^ "++"
  | PreDecExpr v -> "--" ^ (string_of_lvalue v)
  | PostDecExpr v -> (string_of_lvalue v) ^ "--"
  | NegExpr e -> "-" ^ (string_of_expr e)
  | PlusExpr (l, r) -> (string_of_expr l) ^ " + " ^ (string_of_expr r)
  | MinusExpr (l, r) -> (string_of_expr l) ^ " - " ^ (string_of_expr r)
  | MultExpr (l, r) -> (string_of_expr l) ^ " * " ^ (string_of_expr r)
  | DivExpr (l, r) -> (string_of_expr l) ^ " / " ^ (string_of_expr r)
  | ModExpr (l, r) -> (string_of_expr l) ^ " % " ^ (string_of_expr r)
  | AndExpr (l, r) -> (string_of_expr l) ^ " && " ^ (string_of_expr r)
  | OrExpr (l, r) -> (string_of_expr l) ^ " | " ^ (string_of_expr r)
  | NotExpr e -> " ~ " ^ (string_of_expr e)
  | EqExpr (l, r) -> (string_of_expr l) ^ " == " ^ (string_of_expr r)
  | NeqExpr (l, r) -> (string_of_expr l) ^ " != " ^ (string_of_expr r)
  | LtExpr (l, r) -> (string_of_expr l) ^ " < " ^ (string_of_expr r)
  | GtExpr (l, r) -> (string_of_expr l) ^ " > " ^ (string_of_expr r)
  | LteqExpr (l, r) -> (string_of_expr l) ^ " <= " ^ (string_of_expr r)
  | GteqExpr (l, r) -> (string_of_expr l) ^ " >= " ^ (string_of_expr r)
  | BitAndExpr (l, r) -> (string_of_expr l) ^ " && " ^ (string_of_expr r)
  | BitOrExpr (l, r) -> (string_of_expr l) ^ " || " ^ (string_of_expr r)
  | BitXorExpr (l, r) -> (string_of_expr l) ^ " ^ " ^ (string_of_expr r)
  | ShiftLeftExpr (l, r) -> (string_of_expr l) ^ " << " ^ (string_of_expr r)
  | SignedShiftRightExpr (l, r) -> (string_of_expr l) ^ " >> " ^ (string_of_expr r)
  | UnsignedShiftRightExpr (l, r) -> (string_of_expr l) ^ " >>> " ^ (string_of_expr r)

let rec string_of_stmt (ind:int) (s0:'a Iabsyn.stmt) =
  let istr = (String.make ind ' ') in
  let istr' = (String.make (ind-2) ' ') in
  let rec string_of_stmt0 (ind:int) (s:'a Iabsyn.stmt) : string * bool =
    match s with
      Iabsyn.EmptyStmt -> (istr, true)
    | Iabsyn.ChoiceStmt (t, u) -> 
        (istr ^ (fst (string_of_stmt0 ind t)) ^ "[]" ^ 
         (fst (string_of_stmt0 ind u)), true)
    | Iabsyn.CompoundStmt cs -> 
        (istr' ^ "{\n" ^
         (String.concat "" (List.map (string_of_stmt (ind+2)) cs)) ^
         istr' ^ "}\n", false)
    | Iabsyn.ExprStmt e -> 
        (istr ^ (string_of_expr e), true)
    | Iabsyn.ReturnStmt None ->
        (istr ^ "return", true)
    | Iabsyn.ReturnStmt Some r ->        
        (istr ^ "return "^(string_of_expr r), true)
    | Iabsyn.WhileStmt (Some a, e, ws) -> 
        (istr ^ "while <asrt> "(*[" ^ a ^"]*)^
         "("^(string_of_expr e)^")\n" ^
         string_of_stmt (ind+2) ws, false)
    | Iabsyn.WhileStmt (None, e, ws) -> 
        (istr ^ "while " ^ "("^(string_of_expr e)^")\n" ^
         string_of_stmt (ind+2) ws, false)
    | Iabsyn.AssertStmt (_, a) -> 
        (istr ^ "assert <asrt>", true)
    | Iabsyn.AssumeStmt (_, a) -> 
        (istr ^ "assume <asrt>", true)
    | Iabsyn.HavocStmt vs ->
        (istr ^ "havoc " ^ String.concat ", " vs, true)
    | Iabsyn.PragmaStmt ps ->
        (istr ^ "pragma \"" ^ ps ^ "\"", true)
    | Iabsyn.IfStmt (e, t, Iabsyn.EmptyStmt) -> 
        (istr ^ "if ("^(string_of_expr e)^")\n" ^
         string_of_stmt (ind+2) t, false)
    | Iabsyn.IfStmt (e, t, f) -> 
        (istr ^ "if ("^(string_of_expr e)^")\n" ^
         string_of_stmt (ind+2) t ^
         istr ^ "else\n" ^
         string_of_stmt (ind+2) f, false)
    | Iabsyn.LocalDeclStmt (v, vt, e) ->        
        (istr ^ p_type vt ^ " " ^ 
        string_of_expr (Iabsyn.AssignExpr (Iabsyn.LocalLvalue v, e)), true) in
  let (rv, s) = string_of_stmt0 ind s0 in
  rv ^ (if s then ";\n" else "")

let rec pstmt ind (passert : 'a -> string) (s0:'a Iabsyn.stmt) =
  let istr = (String.make ind ' ') in
  let istr' = (String.make (ind-2) ' ') in
  let pcomment c = match c with 
  | None -> ""
  | Some c -> "\"" ^ c ^ "\": " in
  let rec pstmt0 (ind:int) (s:'a Iabsyn.stmt) : string * bool =
    match s with
      Iabsyn.EmptyStmt -> (istr, true)
    | Iabsyn.ChoiceStmt (t, u) -> 
        (istr' ^ "{\n" ^ (fst (pstmt0 (ind+2) t)) ^ istr ^ "[]\n" ^
         (fst (pstmt0 (ind+2) u)) ^ istr' ^ "}", true)
    | Iabsyn.CompoundStmt cs -> 
        (istr' ^ "{\n" ^
         (String.concat "" (List.map (pstmt (ind+2) passert) cs)) ^
         istr' ^ "}\n", false)
    | Iabsyn.ExprStmt e -> 
        (istr ^ (string_of_expr e), true)
    | Iabsyn.ReturnStmt None ->
        (istr ^ "return", true)
    | Iabsyn.ReturnStmt Some r ->        
        (istr ^ "return "^(string_of_expr r), true)
    | Iabsyn.WhileStmt (Some a, e, ws) -> 
        (istr ^ "while [" ^ passert a ^ "]" ^
         "("^(string_of_expr e)^")\n" ^
         pstmt (ind+2) passert ws, false)
    | Iabsyn.WhileStmt (None, e, ws) -> 
        (istr ^ "while " ^ "("^(string_of_expr e)^")\n" ^
         pstmt (ind+2) passert ws, false)
    | Iabsyn.AssertStmt (s, a) -> 
        (istr ^ "assert " ^ pcomment s ^ passert a, true)
    | Iabsyn.AssumeStmt (s, a) -> 
        (istr ^ "assume " ^ pcomment s ^ passert a, true)
    | Iabsyn.HavocStmt vs ->
        (istr ^ "havoc " ^ String.concat ", " vs, true)
    | Iabsyn.PragmaStmt ps ->
        (istr ^ "pragma \"" ^ ps ^ "\"", true)
    | Iabsyn.IfStmt (e, t, Iabsyn.EmptyStmt) -> 
        (istr ^ "if ("^(string_of_expr e)^")\n" ^
         pstmt (ind+2) passert t, false)
    | Iabsyn.IfStmt (e, t, f) -> 
        (istr ^ "if ("^(string_of_expr e)^")\n" ^
         pstmt (ind+2) passert t ^
         istr ^ "else\n" ^
         pstmt (ind+2) passert f, false)
    | Iabsyn.LocalDeclStmt (v, vt, e) ->        
        (istr ^ p_type vt ^ " " ^ 
        string_of_expr (Iabsyn.AssignExpr (Iabsyn.LocalLvalue v, e)), true) in
  let (rv, s) = pstmt0 ind s0 in
  rv ^ (if s then ";\n" else "")

let p_format (fd:format_decl) : unit =
  wr "format "; wr fd.format_name; wr " {\n";
  let wr_field (name,typ) =
    wr ("  " ^ name.Id.f_name ^ "." ^ name.Id.f_module ^ 
       " : " ^ p_type typ ^ ";\n")
  in begin
    List.iter wr_field fd.fields;
    wr "}\n"
  end

let p_reference (name,typ) : unit =
  wr ("reference " ^ name ^ " : " ^ p_type typ ^ ";\n")

let p_instantiated inst = match inst with
| None -> ()
| Some parent -> begin
    wr "(* instantiated from "; 
    wr parent; 
    wr "*)" 
end

let string_of_param_pair ((x,t):(Id.var_t * value_type)) : string =
  x ^ ":" ^ Types.string_of_value_type t

let p_proc (pi:'a proc_def) : unit = 
  wr ("proc "^(Id.name_of_proc pi.proc_id)^" ("^
      (if (List.length pi.formals > 0) then 
        (List.fold_right (fun x y -> ((string_of_param_pair x) ^ "; " ^ y))
           (List.tl pi.formals) 
           (string_of_param_pair (List.hd pi.formals)))
      else "") ^ ")");
  (match pi.ret_val with
  | Some rv -> wr (" returns "^(string_of_param_pair rv))
  | None -> ());
  let body_is_compound = 
    match pi.proc_body with CompoundStmt _ -> true | _ -> false in
  wr ((if not (body_is_compound) then "{" else "") ^ "\n");
  wr (string_of_stmt 2 pi.proc_body);
  wr ((if not (body_is_compound) then "}" else "") ^ "\n")
   
let p_module (mi : 'a impl_module) : unit = begin
  wr "impl module "; wr mi.module_name; wr " {\n";
  p_instantiated mi.instantiated_from;
  List.iter p_format mi.formats;
  List.iter p_reference mi.references;
  List.iter p_proc mi.procs
end 

let openFile (file_name : string) : unit = 
  chn := Some (open_out file_name)

let close _ = close_out (Util.unsome !chn)

let print (mi : 'a Iabsyn.impl_module) : unit =
  begin
    Util.msg ("Dumping module " ^ mi.module_name ^ ".\n");
    p_module mi
  end
