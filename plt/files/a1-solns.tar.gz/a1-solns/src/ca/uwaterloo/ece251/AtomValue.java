package ca.uwaterloo.ece251;

import java.io.*;
import java.util.regex.*;

/** Implements base value type, representing strings and ints. */
public class AtomValue implements Value {
    private final static Pattern intLiteral = Pattern.compile("[+-]?\\d+");

    enum Type { STRING, INT };

    Type t;
    String stringVal; int intVal;

    public AtomValue(String fn) 
    {
	parse(fn);
    }

  public AtomValue(String fn, boolean literal) {
    if(literal) {
      if(fn.charAt(0) == '"') {
        stringVal = fn.substring(1, fn.length() - 1);
        t = Type.STRING;
      }
      else {
        intVal = Integer.parseInt(fn);
        t = Type.INT;
      }
    }
    else {
      parse(fn);
    }
  }

    public AtomValue(File f) 
    {	
	try {
	    BufferedReader ir = 
		new BufferedReader(new InputStreamReader
				   (new FileInputStream(f)));
	    String l = ir.readLine();
	    parse(l);
	    ir.close();
	} catch (IOException e) {
	    t = Type.INT; intVal = 0;
	}
    }

    private AtomValue(Type t, String stringVal, int intVal) {
	this.t = t;
	this.stringVal = stringVal;
	this.intVal = intVal;
    }

    private void parse(String v) 
    {
      stringVal = v;
      try {
        intVal = Integer.parseInt(v);
        t = Type.INT;
      }
      catch (Exception e) {
        t = Type.STRING;
      }
    }

    public void write(String fn) 
    {
	try {
	    new File(OUTPUT_DIR).mkdir();
	    Writer w = new FileWriter(OUTPUT_DIR + fn+".atom");
	    w.write(toString()+"\n");
	    w.close();
	} catch (IOException e) {
	}
    }

    public void print() 
    {
	switch (t) {
	case INT:
	    System.out.println(toString());
	    break;
	case STRING:
	    System.out.println("\""+toString()+"\"");
	    break;
	}
    }

    public String toString()
    {
	switch (t) {
	case INT:
	    return Integer.toString(intVal);
	case STRING:
	    return stringVal;
	}
	return "";
    }

    public AtomValue sort(Expr.Comparator c) 
    { 
	return this; 
    }

    public AtomValue map(Expr.Transformer t) 
    { 
	AtomValue tc = (AtomValue) this.clone();
	switch (t.tk) {
	case PLUS:
	    tc.intVal += ((AtomValue)t.v).intVal;
	    tc.stringVal += ((AtomValue)t.v).stringVal;
	    break;
	case MINUS:
	    tc.intVal -= ((AtomValue)t.v).intVal;
	    break;
	case TIMES:
	    tc.intVal *= ((AtomValue)t.v).intVal;
	    break;
	case DIVIDE:
	    tc.intVal /= ((AtomValue)t.v).intVal;
	    break;
	}
	return tc; 
    }

    public AtomValue filter(Expr.Filter f)
    {
	return this;
    }

    public AtomValue reduce(Expr.Accumulator a)
    {
	return this;
    }

    public AtomValue traverse(Expr.Order o)
    {
	return this;
    }

    public AtomValue truncate(int v)
    {
	return this;
    }

    public int compare(Value v2) 
    {
	if (!(v2 instanceof AtomValue))
	    return 0;
	AtomValue av = (AtomValue) v2;
	if (av.t != t) return 0;
	switch (av.t) {
	case INT: return intVal - av.intVal; 
	case STRING: return stringVal.compareTo(av.stringVal);
	}
	return 0;
    }

    /** Return <code>true</code> if this value satisfies the given <code>Filter</code>. */
    public boolean satisfies(Expr.Filter f) 
    {
	AtomValue fv = (AtomValue)f.v;

	int diff = 0;
	if (fv.t == Type.INT)
	    diff = intVal - fv.intVal;
	else
	    diff = stringVal.compareTo(fv.stringVal);

	switch (f.fk) {
	case GT:
	    return diff > 0;
	case GE:
	    return diff >= 0;
	case LT:
	    return diff < 0;
	case LE:
	    return diff <= 0;
	case EQ:
	    return diff == 0;
	}
	return false; 
    }

    public Object clone() {
	return new AtomValue(t, stringVal, intVal);
    }
}
