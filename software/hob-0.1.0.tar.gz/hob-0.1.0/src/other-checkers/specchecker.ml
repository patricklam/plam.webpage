open Sabsyn
open Spec

let error s = Util.err "spec" s

let rec declaration_check_formula (w:sets_and_bools) (f:form) =
  let add_set w ns = { s = ns :: w.s; b = w.b; } in
  let add_bool w nb = { s = w.s; b = nb :: w.b; } in
  let rec declaration_check_setexp se =
    match se with
    | Prevar pv | Postvar pv ->
        let rv = List.mem pv w.s in
        if (not rv) then 
          error ("undeclared setvar "^pv)
    | Emptyset -> ()
    | Union sel | Inter sel -> 
        List.iter declaration_check_setexp sel
    | Diff (s, t) -> 
        declaration_check_setexp s; declaration_check_setexp t in
  let rec declaration_check_atom af = 
    match af with
    | Eq (s, t) | Neq (s, t) | Sub (s, t) -> 
        declaration_check_setexp s; declaration_check_setexp t
    | True | False -> ()
    | Cardeq (se, i) | Cardleq (se, i) | Cardgeq (se, i) ->
        declaration_check_setexp se
    | Disjoint sel ->
        List.iter declaration_check_setexp sel
    | Propvar pv | Propvarpost pv ->
        let rv = List.mem pv w.b in
        if (not rv) then 
          error ("undeclared propvar "^pv) in
  match f with
  | Atom af -> declaration_check_atom af
  | Not n -> declaration_check_formula w n
  | And cs | Or cs -> List.iter (declaration_check_formula w) cs
  | Impl (p, q) | Iff (p, q) -> 
      declaration_check_formula w p;
      declaration_check_formula w q
  | ExistsOne ((v, _), f) | ForallOne ((v, _), f) 
  | ExistsSet ((v, _), f) | ForallSet ((v, _), f) ->
      declaration_check_formula (add_set w v) f
  | ExistsProp (v, f) | ForallProp (v, f) ->
      declaration_check_formula (add_bool w v) f
  | UninterpretedString s -> ()

(* this checks requires and ensures clauses.
 * it does not check scope invariants, nor does it check loop invariants 
 * we do catch loop invs later, when typestate converting flags modules 
 * and scope invariants ought to be caught when used... *)
let declaration_checker (ast:spec_module list) =
  let declaration_check_module m =
    let declaration_check_proc w p = 
      let is_bool t = match t with Types.TBool -> true | _ -> false in
      let is_obj t = match t with Types.TObj _ -> true | _ -> false in
      let n_foo is_foo = 
        (match p.ret_val with 
        | Some (r, t) when is_foo t -> [r]
        | None | Some _ -> []) @ 
        List.map fst (List.filter (fun x -> is_foo (snd x)) p.formals) in
      let w' = { s = n_foo is_obj @ w.s; b = n_foo is_bool @ w.b; } in
      declaration_check_formula w' p.requires;
      declaration_check_formula w' p.ensures in
    let w = { s = collect_all_sets m; b = collect_all_bools m } in
    List.iter (declaration_check_proc w) m.procs in
  let rv = List.iter declaration_check_module ast in
  if not (Util.no_errors ()) then
    Util.print_errors ();
  rv

let rec no_prime_check_formula (f:form) =
  let rec no_prime_check_setexp se =
    match se with
    | Prevar _ -> ()
    | Postvar pv ->
        error ("primed setvar in requires: "^pv^"'")
    | Emptyset -> ()
    | Union sel | Inter sel -> 
        List.iter no_prime_check_setexp sel
    | Diff (s, t) -> 
        no_prime_check_setexp s; no_prime_check_setexp t in
  let rec no_prime_check_atom af = 
    match af with
    | Eq (s, t) | Neq (s, t) | Sub (s, t) -> 
        no_prime_check_setexp s; no_prime_check_setexp t
    | True | False -> ()
    | Cardeq (se, i) | Cardleq (se, i) | Cardgeq (se, i) ->
        no_prime_check_setexp se
    | Disjoint sel ->
        List.iter no_prime_check_setexp sel
    | Propvar _ -> ()
    | Propvarpost pv ->
        error ("primed propvar in requires: "^pv^"'") in
  match f with
  | Atom af -> no_prime_check_atom af
  | Not n -> no_prime_check_formula n
  | And cs | Or cs -> List.iter no_prime_check_formula cs
  | Impl (p, q) | Iff (p, q) -> 
      no_prime_check_formula p;
      no_prime_check_formula q
  | ExistsOne ((v, _), f) | ForallOne ((v, _), f) 
  | ExistsSet ((v, _), f) | ForallSet ((v, _), f) ->
      no_prime_check_formula f
  | ExistsProp (v, f) | ForallProp (v, f) ->
      no_prime_check_formula f
  | UninterpretedString s -> ()
        
let no_primes_in_requires (ast:spec_module list) =
  let prime_check_module m =
    List.iter (fun p -> no_prime_check_formula p.requires) m.procs in
  let rv = List.iter prime_check_module ast in
  if not (Util.no_errors ()) then
    Util.print_errors ();
  rv

let prime_check_formula pn (rv:Id.var_t) (f:form) =
  let rec prime_check_formula0 f =
    let rec prime_check_setexp se =
      match se with
      | Prevar pv -> 
          if (pv = rv) then
            error ("unprimed return value in "^pn^"")
      | Postvar pv -> ()        
      | Emptyset -> ()
      | Union sel | Inter sel -> 
          List.iter prime_check_setexp sel
      | Diff (s, t) -> 
          prime_check_setexp s; prime_check_setexp t in
    let rec prime_check_atom af = 
      match af with
      | Eq (s, t) | Neq (s, t) | Sub (s, t) -> 
          prime_check_setexp s; prime_check_setexp t
      | True | False -> ()
      | Cardeq (se, i) | Cardleq (se, i) | Cardgeq (se, i) ->
          prime_check_setexp se
      | Disjoint sel ->
          List.iter prime_check_setexp sel
      | Propvar pv -> 
          if (pv = rv) then
            error ("unprimed return value in "^pn^"")
      | Propvarpost _ -> () in
    match f with
    | Atom af -> prime_check_atom af
    | Not n -> prime_check_formula0 n
    | And cs | Or cs -> List.iter prime_check_formula0 cs
    | Impl (p, q) | Iff (p, q) -> 
        prime_check_formula0 p;
        prime_check_formula0 q
    | ExistsOne ((v, _), f) | ForallOne ((v, _), f) 
    | ExistsSet ((v, _), f) | ForallSet ((v, _), f) ->
        prime_check_formula0 f
    | ExistsProp (v, f) | ForallProp (v, f) ->
        prime_check_formula0 f
    | UninterpretedString s -> () in
  prime_check_formula0 f
        
let must_prime_retvals (ast:spec_module list) =
  let prime_check_module m =
    List.iter (fun p -> 
      match p.ret_val with
      | None -> ()
      | Some (rv, _) -> 
          let pn = Id.qualified_name_of_proc p.proc_name in
          prime_check_formula pn rv p.requires;
          prime_check_formula pn rv (construct_ensures p)) m.procs in
  let rv = List.iter prime_check_module ast in
  if not (Util.no_errors ()) then
    Util.print_errors ();
  rv

let parse_checked_formula ms w pi f = 
  let mn = ms.Sabsyn.module_name in
  let (local_sets, local_bools, tenv) = Iabsyn.collect_local_obj_type_map pi in
  let is_local x = (Util.unqualify_getting_module x) = mn in
  let qualifiable_sb =
    { Spec.s = List.map Util.unqualify 
        (List.filter is_local w.Spec.s);
      Spec.b = List.map Util.unqualify 
        (List.filter is_local w.Spec.b)
    } in
  let pf = Spec.parse_formula ms.Sabsyn.module_name qualifiable_sb f in
  let all_sb =
    { Spec.s = w.Spec.s @ local_sets;
      Spec.b = w.Spec.b @ local_bools; } in
  declaration_check_formula all_sb pf;
  pf
