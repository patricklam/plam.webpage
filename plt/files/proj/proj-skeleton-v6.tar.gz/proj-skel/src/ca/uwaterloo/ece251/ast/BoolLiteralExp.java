package ca.uwaterloo.ece251.ast;

/** Literal for booleans. */
public class BoolLiteralExp extends Exp {
    boolean v;

    public BoolLiteralExp(boolean v) {
	this.v = v;
    }

    public String toString() {
	return v ? "true" : "false";
    }
}
