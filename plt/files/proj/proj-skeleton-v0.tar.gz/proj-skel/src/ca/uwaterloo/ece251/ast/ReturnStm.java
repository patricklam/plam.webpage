package ca.uwaterloo.ece251.ast;

/** Represents a return statement which returns something. */
public class ReturnStm extends Stm {
    Exp e;

    public ReturnStm(Exp e) { 
	this.e = e;
    }

    public String toString() {
	return "return "+e.toString()+";";
    }
}

