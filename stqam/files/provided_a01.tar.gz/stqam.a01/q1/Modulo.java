/* author: Your Name */

/* A Java program that prints -5 % 2 */
