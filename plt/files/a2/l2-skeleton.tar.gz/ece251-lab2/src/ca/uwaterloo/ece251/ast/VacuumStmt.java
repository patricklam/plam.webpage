package ca.uwaterloo.ece251.ast;

public class VacuumStmt extends Stmt {
    public void accept(Visitor v) {
	v.enter(this);
	v.leave(this);
    }
}
