
let populate_format_definitions (fd:(Id.format_t, (Id.module_t, (Id.field_t, Types.value_type) Hashtbl.t) Hashtbl.t) Hashtbl.t) =
  List.iter (fun m -> 
    List.iter (fun f -> 
      let nf = 
        if (Hashtbl.mem fd f) then Hashtbl.find fd f else
        let nff = Hashtbl.create 0 in Hashtbl.add fd f nff; nff in
      Hashtbl.add nf m (Hashtbl.create 0)) (Ast.all_impl_formats ()))
    (Ast.all_impl_modules ());
  let populate_format_definition (m:'a Iabsyn.impl_module) =
    List.iter (fun f ->
      let nf = Hashtbl.find fd f.Iabsyn.format_name in
      let mc = Hashtbl.find nf m.Iabsyn.module_name in
      List.iter (fun (v,t) -> 
        Hashtbl.add mc v t) 
        f.Iabsyn.fields) 
      m.Iabsyn.formats in
  List.iter populate_format_definition !Ast.impl
