package ca.uwaterloo.ece251.ast;

import java.util.List;

public class CreateTableStmt extends Stmt {
    boolean temporary;
    boolean ifNotExists;
    QualifiedTableName tn;
    List<ColumnDef> columnDefs;
    SelectStmt asStmt;

    public CreateTableStmt(boolean temporary, boolean ifNotExists, 
			   QualifiedTableName tn, List<ColumnDef> columnDefs,
			   SelectStmt asStmt) {
	this.temporary = temporary;
	this.ifNotExists = ifNotExists;
	this.tn = tn;
	this.columnDefs = columnDefs;
	this.asStmt = asStmt;
    }

    public void accept(Visitor v) {
	v.enter(this);
	if (columnDefs != null) {
	    for (ColumnDef cd : columnDefs)
		cd.accept(v);
	}
	if (asStmt != null) asStmt.accept(v);
	v.leave(this);
    }
}
