package ca.uwaterloo.ece251.ast;

abstract public class Type {
}
