package ca.uwaterloo.ece251.ast;

/** Represents an attribute for an INPUT or SELECT tag. */
abstract public class InputAttr {
}

