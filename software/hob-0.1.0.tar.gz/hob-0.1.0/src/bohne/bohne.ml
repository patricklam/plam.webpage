(* Heap predicate abstraction plugin *)

open Bohneutil
open Abstraction
open Preds
open Bf
open Bf_set
open Iabsyn
open Decproc

module type BOHNE_PLUGIN =
  sig
    val plugin_name : string
    val enable_vc_mode : unit -> unit
    val disable_vc_mode : unit -> unit
    val analyze_module : 
        string ->
	string Aabsyn.abst_body *
	Sabsyn.spec_module *
	string Iabsyn.impl_module -> string list -> bool
  end

module Bohne : BOHNE_PLUGIN =
  struct
    type abst_body = Vcform.form Aabsyn.abst_body

    let plugin_name = "Bohne"

    let vc_mode = ref false
    (* flag that turns Bohne into vc generator *)
	
    let enable_vc_mode () =  vc_mode := true
    let disable_vc_mode () = vc_mode := false

    let failwith err = failwith (plugin_name ^ ": " ^ err) 

    let extract_tvars typeEnv = 
      let add (v, t) acc = match t with 
      |	Types.TObj _ | Types.TBool -> (v, t)::acc 
      | _ -> acc 
      in List.fold_right add typeEnv []

    let extract_vars typeEnv = 
      let add (v, t) acc = match t with 
      |	Types.TObj _ | Types.TBool -> v::acc 
      | _ -> acc 
      in List.fold_right add typeEnv []

    let extract_obj_vars typeEnv =
      let add (v, t) acc = match t with 
      |	Types.TObj _ -> v::acc 
      | _ -> acc 
      in List.fold_right add typeEnv []

    let convert_sabsyn_form is_trans_constraint f typed_formals =
      let formals = extract_vars typed_formals in
      let null = Preds.get_pred_def (Preds.null_pred) in
      let mk_all f = Vcform.mk_foralls ([Preds.typed_free_var], f)
      and mk_ex f = Vcform.mk_exists ([Preds.typed_free_var], f)
      and mk_postvar p = 
	Preds.get_pred_def (Preds.get_pred (Util.unqualify p))
      and mk_prevar p =
	if is_trans_constraint then
	  let pre_p = "'" ^ (Util.unqualify p) in
	  let _ = 
	    try ignore (Preds.get_pred pre_p)
	    with _ -> Preds.add_pre_pred (Util.unqualify p) pre_p
	  in
	  if List.mem p formals then
	    Vcform.mk_eq (Preds.free_var, Vcform.mk_var pre_p)
	  else Vcform.mk_elem (Preds.free_var, Vcform.mk_var pre_p)
	else Preds.get_pred_def (Preds.get_pred (Util.unqualify p))
      in
      let rec convert_sabsyn_setexp se =
	match se with
	| Sabsyn.Prevar s -> mk_prevar s	   
	| Sabsyn.Postvar s -> mk_postvar s
	| Sabsyn.Emptyset -> Vcform.mk_false
	| Sabsyn.Union us -> 
	    Vcform.mk_or (List.rev_map convert_sabsyn_setexp us)
	| Sabsyn.Inter is -> 
	    Vcform.smk_and (List.rev_map convert_sabsyn_setexp is)
	| Sabsyn.Diff (t, u) -> 
	    Vcform.smk_and [convert_sabsyn_setexp t; 
			    Vcform.smk_not (convert_sabsyn_setexp u)]
      in
      let rec convert_sabsyn_atom af =
	match af with
	| Sabsyn.Eq (s, t) ->
	    mk_all (Vcform.mk_iff (convert_sabsyn_setexp s, convert_sabsyn_setexp t))
	| Sabsyn.Neq (s, t) -> 
	    mk_ex (Vcform.mk_not (Vcform.mk_iff (convert_sabsyn_setexp s, 
						 convert_sabsyn_setexp t)))
	| Sabsyn.Sub (s, t) -> 
	    let t' = convert_sabsyn_setexp t in
	    (match s with 
	    | Sabsyn.Postvar s when List.mem (Util.unqualify s) formals ->
		Vcform.subst [(Preds.free_var_name, Vcform.mk_var (Util.unqualify s))] t'
	    | _ -> mk_all (Vcform.mk_impl (convert_sabsyn_setexp s, t')))
	| Sabsyn.True -> Vcform.mk_true
	| Sabsyn.False -> Vcform.mk_false
	| Sabsyn.Cardeq (s, 0) ->
	    mk_all (Vcform.mk_impl (convert_sabsyn_setexp s, null))
	| Sabsyn.Cardeq (s, 1) ->
	    let ex = mk_ex (Vcform.smk_and [convert_sabsyn_setexp s; Vcform.mk_not null]) in
	    (match s with 
	    | Sabsyn.Prevar s' when List.mem (Util.unqualify s') formals -> ex
	    | Sabsyn.Postvar s' when List.mem (Util.unqualify s') formals -> ex
	    | _ -> failwith "unsupported cardinality constraint in requires clause")
	| Sabsyn.Cardleq (s, 0) -> 
	    mk_all (Vcform.mk_impl (convert_sabsyn_setexp s, null))
	| Sabsyn.Cardgeq (s, 0) -> Vcform.mk_true
	| Sabsyn.Cardgeq (s, 1) ->  
	    mk_ex (Vcform.smk_and [convert_sabsyn_setexp s; Vcform.mk_not null])
	| Sabsyn.Cardeq _ | Sabsyn.Cardgeq _ | Sabsyn.Cardleq _ ->
	    failwith "unsupported cardinality constraint in requires clause"
	| Sabsyn.Propvarpost pi -> 
	    let pred_pi = Preds.get_pred (Util.unqualify pi) in
	    Preds.get_pred_def pred_pi
	| Sabsyn.Propvar p -> 
	    if is_trans_constraint then
	      let pre_p = "'" ^ (Util.unqualify p) in
	      let _ = 
		try ignore (Preds.get_pred pre_p)
		with _ -> Preds.add_pre_pred (Util.unqualify p) pre_p
	      in
	      Vcform.mk_var pre_p
	    else Preds.get_pred_def (Preds.get_pred (Util.unqualify p))
        | Sabsyn.Disjoint dl -> 
	    mk_all (Vcform.mk_or (List.map (fun d -> Vcform.mk_not (convert_sabsyn_setexp d)) dl))
	    (* Vcform.App (Vcform.Const Vcform.Disjoint, List.map convert_sabsyn_setexp dl) *)
      in
      let rec convert_sabsyn_form f =
	match f with
	| Sabsyn.Atom af -> convert_sabsyn_atom af
	| Sabsyn.Not f' -> Vcform.mk_not (convert_sabsyn_form f')
	| Sabsyn.And fl -> Vcform.mk_and (List.map convert_sabsyn_form fl)
	| Sabsyn.Or fl -> Vcform.mk_or (List.map convert_sabsyn_form fl)
	| Sabsyn.Impl (r, s) -> Vcform.mk_impl (convert_sabsyn_form r,
						convert_sabsyn_form s)
	| Sabsyn.Iff (r, s) -> Vcform.mk_iff (convert_sabsyn_form r,
					      convert_sabsyn_form s)
	(* 
	| Sabsyn.ExistsSet (v, f) -> 
	    Binder (Exists, [fst v, vctype_of (snd v)], 
		    convert_sabsyn_form f)
	| Sabsyn.ForallSet (v, f) -> Binder (Forall, [fst v, vctype_of (snd v)], 
					     convert_sabsyn_form f)
	| Sabsyn.ExistsProp (v, f) -> Binder (Exists, [v, TypeBool],
                                              convert_sabsyn_form f)
	| Sabsyn.ForallProp (v, f) -> Binder (Forall, [v, TypeBool],
                                            convert_sabsyn_form f) 
	| Sabsyn.UninterpretedString s -> Vcformparseutil.parse_formula s *)
	| _ -> failwith "unsupported formula in requires clause"
      in convert_sabsyn_form f
	    
    let convert_ensures_clause f typed_formals =
      let formals = extract_vars typed_formals in
      let mk_postvar p = 
	Bf.mk_var (Preds.get_pred (Util.unqualify p))
      in
      let mk_prevar p =
	let pre_p = "'" ^ (Util.unqualify p) in
	let pre_pred = 
	  try
	    Preds.get_pred pre_p
	  with _ -> Preds.add_pre_pred (Util.unqualify p) pre_p; Preds.get_pred pre_p
	in Bf.mk_var pre_pred
      in
      let rec convert_sabsyn_setexpr s =
	match s with
	| Sabsyn.Prevar p -> mk_prevar p	   
	| Sabsyn.Postvar p -> mk_postvar p	   
	| Sabsyn.Emptyset -> Bf.bottom
	| Sabsyn.Union s_exps -> 
	    List.fold_left (fun bf s -> Bf.disj bf (convert_sabsyn_setexpr s)) Bf.bottom s_exps 
	| Sabsyn.Inter s_exps ->
	    List.fold_left (fun bf s -> Bf.conj bf (convert_sabsyn_setexpr s)) Bf.top s_exps 
	| Sabsyn.Diff (s,t) ->
	    Bf.conj (convert_sabsyn_setexpr s) (Bf.neg (convert_sabsyn_setexpr t)) in
      let rec convert_sabsyn_atom a =
	match a with
	| Sabsyn.Eq (s,t) -> 
	    Bf.equi (convert_sabsyn_setexpr s) (convert_sabsyn_setexpr t)
	| Sabsyn.Neq (s,t) ->
	    Bf.neg (Bf.equi (convert_sabsyn_setexpr s) (convert_sabsyn_setexpr t))
	| Sabsyn.Sub (s,t) -> 
	    Bf.impl (convert_sabsyn_setexpr s) (convert_sabsyn_setexpr t)
	| Sabsyn.True  -> Bf.top
	| Sabsyn.False -> Bf.bottom
	| Sabsyn.Disjoint s_exps ->
	    Bf.neg (List.fold_left (fun bf s -> Bf.conj bf (convert_sabsyn_setexpr s)) Bf.top s_exps)
	| Sabsyn.Cardleq (Sabsyn.Prevar p, 1) ->
	    if List.mem p formals then Bf.top
	    else failwith "unsupported cardinality constraint in ensures clause"
	| Sabsyn.Cardleq (Sabsyn.Postvar p, 1) ->
	    if List.mem p formals then Bf.top
	    else failwith "unsupported cardinality constraint in ensures clause"
	| Sabsyn.Cardeq (Sabsyn.Prevar p, 1) -> 
	    if List.mem p formals then 
	      Bf.neg (Bf.conj (mk_prevar p) (Bf.mk_var Preds.null_pred))
	    else failwith "unsupported cardinality constraint in ensures clause"
	| Sabsyn.Cardeq (Sabsyn.Postvar p, 1) -> 
	    if List.mem p formals then 
	      Bf.neg (Bf.conj (mk_postvar p) (Bf.mk_var Preds.null_pred))
	    else failwith "unsupported cardinality constraint in ensures clause"
	| Sabsyn.Cardeq (s, 0) -> 
	    Bf.impl (convert_sabsyn_setexpr s) (Bf.mk_var Preds.null_pred)
            (*
	    (match s with
	    | Sabsyn.Prevar p when List.mem p formals -> 
		Bf.equi (mk_prevar p) (Bf.mk_var Preds.null_pred)
	    | Sabsyn.Postvar p when List.mem p formals ->
		Bf.equi (mk_postvar p) (Bf.mk_var Preds.null_pred)
	    | _ -> Bf.neg (convert_sabsyn_setexpr s))
	     *)
	| Sabsyn.Cardleq (s, 0) -> 
	    Bf.impl (convert_sabsyn_setexpr s) (Bf.mk_var Preds.null_pred)
	| Sabsyn.Cardgeq (s, 0) -> Bf.top
	| Sabsyn.Propvar p -> mk_prevar p
	| Sabsyn.Propvarpost p -> mk_postvar p
	| _ -> failwith "unsupported atom in ensures clause" in
      let rec convert_sabsyn_literal l =
	match l with
	| Sabsyn.Atom (Sabsyn.Cardgeq (s, 1)) ->
	    (* this is an approximation *)
	    let bf_s = convert_sabsyn_setexpr s in
	    let var_cubes = List.fold_left (fun f x -> Bf.disj f (mk_postvar x)) 
		(Bf.mk_var Preds.null_pred) formals 
	    in
	    List.fold_left 
	      (fun fs x -> Bf_set.union fs
		  (Bf_set.singleton 
		     (Bf.impl (mk_postvar x) 
			(Bf.conj (Bf.neg (Bf.mk_var Preds.null_pred)) bf_s))))
	      Bf_set.bottom (extract_obj_vars typed_formals)
	| Sabsyn.Atom a -> Bf_set.singleton (convert_sabsyn_atom a)
	| Sabsyn.Or [a] -> convert_sabsyn_literal a
	| Sabsyn.And [a] -> convert_sabsyn_literal a
	| Sabsyn.Not (Sabsyn.Or [a]) -> convert_sabsyn_literal (Sabsyn.Not a)
	| Sabsyn.Not (Sabsyn.And [a]) -> convert_sabsyn_literal (Sabsyn.Not a)
	| Sabsyn.Not (Sabsyn.Atom (Sabsyn.Cardgeq (s, i))) ->
	    convert_sabsyn_literal (Sabsyn.Atom (Sabsyn.Cardleq (s, i - 1)))
	| Sabsyn.Not (Sabsyn.Atom (Sabsyn.Cardleq (s, i))) ->
	    convert_sabsyn_literal (Sabsyn.Atom (Sabsyn.Cardgeq (s, i + 1)))
	| Sabsyn.Not (Sabsyn.Atom a) ->
	    let bf = match a with 
	    | Sabsyn.Sub (Sabsyn.Prevar p, s) ->
		if List.mem p formals then
		  Bf.impl (Bf.mk_var (Preds.get_pred p)) (Bf.neg (convert_sabsyn_setexpr s))
		else  failwith "unsupported use of negation in ensures clause"
	    | Sabsyn.Propvar _ | Sabsyn.Propvarpost _ ->
		Bf.neg (convert_sabsyn_atom a)
	    | _ -> failwith "support use of negation in ensures clause"
	    in Bf_set.singleton bf
	| Sabsyn.Not (Sabsyn.Not f) -> convert_sabsyn_literal f
	| Sabsyn.Not _ -> failwith "support use of negation in ensures clause"
	| _ -> failwith "unsupported formula in ensures clause" in
      let rec convert_sabsyn_form' f =
	match f with
	| Sabsyn.And fs ->
	    List.fold_left (fun bfs f -> Bf_set.inter bfs (convert_sabsyn_form' f)) Bf_set.top fs
	| Sabsyn.Or fs ->
	    List.fold_left (fun bfs f -> Bf_set.union bfs (convert_sabsyn_form' f)) Bf_set.bottom fs
	| Sabsyn.Impl (f, g) ->
	    Bf_set.union (convert_sabsyn_form' (Sabsyn.Not f)) (convert_sabsyn_form' g)
	| Sabsyn.Iff  (f, g) ->
	    Bf_set.union (Bf_set.inter (convert_sabsyn_form' f) (convert_sabsyn_form' g))
	      (Bf_set.inter (convert_sabsyn_form' (Sabsyn.Not f)) (convert_sabsyn_form' (Sabsyn.Not g)))
	| Sabsyn.Not (Sabsyn.Iff (f, g)) ->
	    Bf_set.union (Bf_set.inter (convert_sabsyn_form' (Sabsyn.Not f)) (convert_sabsyn_form' g))
	      (Bf_set.inter (convert_sabsyn_form' f) (convert_sabsyn_form' (Sabsyn.Not g)))
	| _ -> convert_sabsyn_literal f
      in
      convert_sabsyn_form' f
	
    let convert_abst_body mab mn =
      let all_sb = { Spec.s = Abst.collect_all_sets mab; 
		     Spec.b = Abst.collect_all_bools mab } in
      let parse_sabsyn_form s = Spec.parse_formula mn all_sb s in
      let rec clause_convert f =
	match f with
	| Aabsyn.LetClause (sd, c') -> failwith "not supporting let in aabsyn"
	| Aabsyn.IffClause (s, t) -> 
            Vcform.mk_iff (clause_convert s,clause_convert t)
	| Aabsyn.OrClause (s, t) -> 
	    Vcform.mk_or [clause_convert s;
			  clause_convert t]
	| Aabsyn.AndClause (s, t) ->
            Vcform.mk_and [clause_convert s;
			   clause_convert t]
	| Aabsyn.NotClause n ->
            Vcform.mk_not (clause_convert n)
	| Aabsyn.FormulaClause f' -> Vcformparseutil.parse_formula f' 
      in
      let invariant_convert i = Aabsyn.FormulaClause (clause_convert i) in
      let set_defn_convert pn sd = 
	let rec set_defn_rhs_convert sd = 
	  match sd with
	  | Aabsyn.BaseForm bsd -> 
	      Aabsyn.BaseForm 
		{Aabsyn.x = bsd.Aabsyn.x;
		 Aabsyn.xt = bsd.Aabsyn.xt;
		 Aabsyn.expr = Aabsyn.FormulaClause (clause_convert bsd.Aabsyn.expr)}
	  | _ -> failwith "can't write derived set defns" 
	in (fst sd, set_defn_rhs_convert (snd sd)) 
      in
      let proc_set_defns_convert p =
	let set_defns = List.map (set_defn_convert p.Aabsyn.proc_name.Id.p_name) p.Aabsyn.proc_set_defns in
	{ Aabsyn.proc_name = p.Aabsyn.proc_name;
	  Aabsyn.proc_set_defns = set_defns } in
      { Aabsyn.plugin = mab.Aabsyn.plugin;
	Aabsyn.invariants = List.map invariant_convert mab.Aabsyn.invariants;
	Aabsyn.set_defns = List.map (set_defn_convert "") mab.Aabsyn.set_defns;
	Aabsyn.pred_vars = mab.Aabsyn.pred_vars;
        Aabsyn.procs_to_analyze = mab.Aabsyn.procs_to_analyze;
        Aabsyn.formats = mab.Aabsyn.formats;
	Aabsyn.set_defining_procs = List.map proc_set_defns_convert mab.Aabsyn.set_defining_procs }
	
	
    let convert_proc mab mi pi =
      let mn = mi.Iabsyn.module_name in
      let pn = Id.name_of_proc pi.Iabsyn.proc_id in
      let all_sb = { Spec.s = Abst.collect_all_sets mab; 
		     Spec.b = Abst.collect_all_bools mab } in
      let (_, _, tenv) = collect_local_obj_type_map pi in
      let parse str = Vcformparseutil.parse_formula (String.sub str 1 (String.length str - 2)) in
      let fetch_type (s:Id.var_t) =
        Hashtbl.find tenv s in
      let rec purify e =
	match e with
	| AndExpr (e1, e2) ->
	    let e11, e12, ci1 = purify e1 
	    and e21, e22, ci2 = purify e2
	    in (AndExpr (e11, e21), AndExpr (e12, e22), ci1 || ci2)
	| OrExpr (e1, e2) ->
	    let e11, e12, ci1 = purify e1 
	    and e21, e22, ci2 = purify e2
	    in (OrExpr (e11, e21), OrExpr (e12, e22), ci1 || ci2)
	| NotExpr e ->
	    let e1, e2, ci = purify e 
	    in (NotExpr e2, NotExpr e1, ci)
	| LtExpr _ | GtExpr _
	| LteqExpr _ | GteqExpr _ -> 
	    (LiteralExpr (Bool true), LiteralExpr (Bool false), true)
        | EqExpr (VarExpr (LocalLvalue e'), _) 
        | EqExpr (_, VarExpr (LocalLvalue e')) -> 
            let t = try fetch_type e' = Types.TInt with Not_found -> false in
            if t then
	      (LiteralExpr (Bool true), LiteralExpr (Bool false), true)
            else
              (e, e, false)
	| _ -> (e, e, false)
      in
      let convert_expr_stmt st = match st with
	| AssignExpr (LocalLvalue l, e) ->
            let e1, e2, contains_int = purify e in
	    if contains_int then 
	      ChoiceStmt (ExprStmt (AssignExpr (LocalLvalue l, e1)), 
			  ExprStmt (AssignExpr ((LocalLvalue l, e2))))
	    else ExprStmt st
	| _ -> ExprStmt st
      in
      let convert_stmt pi s =
	let rec tcs s = 
	  match s with
	  | EmptyStmt -> EmptyStmt
	  | HavocStmt n -> HavocStmt n
	  | ChoiceStmt (t, u) -> ChoiceStmt (tcs t, 
                                             tcs u)
	  | CompoundStmt cs -> CompoundStmt (List.map tcs cs) 
	  | LocalDeclStmt (v, t, e) -> LocalDeclStmt (v, t, e) 
	  | ExprStmt e -> convert_expr_stmt e
	  | ReturnStmt r -> ReturnStmt r
	  | WhileStmt (i, e, w) -> 
	      let w' = tcs w in
              let i' = map_opt parse i in
	      let e1, e2, contains_int = purify e in
	      if contains_int then
		let e1, c1 = Wp.vcexpr_of_iabsyn mn e1
		and e2, c2 = Wp.vcexpr_of_iabsyn mn (NotExpr e2) in
		CompoundStmt [WhileStmt (i', LiteralExpr (String "*"), 
					  CompoundStmt [AssumeStmt (None, e1); w']);
			      AssumeStmt (None, e2)]
	      else WhileStmt (i', e, w')
	  | AssertStmt (n, a) -> AssertStmt (n, parse a)
	  | AssumeStmt (n, a) -> AssumeStmt (n, parse a)
	  | PragmaStmt s -> PragmaStmt s
	  | IfStmt (e, t, f) -> 
	      let e1, e2, contains_int = purify e in
	      if contains_int then 
		let e1, c1 = Wp.vcexpr_of_iabsyn mn e1
		and e2, c2 = Wp.vcexpr_of_iabsyn mn (NotExpr e2) in
		ChoiceStmt (CompoundStmt [AssumeStmt (None, e1); tcs t], 
			    CompoundStmt [AssumeStmt (None, e2); tcs f])
	      else IfStmt (e, tcs t, tcs f)
	in
	tcs s in
      let convert_proc p =
	{ proc_id = p.proc_id;
	  proc_modifiers = p.proc_modifiers;
	  formals = p.formals;
	  ret_val = p.ret_val;
	  requires = map_opt parse p.requires;
	  modifies = p.modifies;
	  ensures = map_opt parse p.ensures;
	  proc_body = convert_stmt p p.proc_body } in
      convert_proc pi

    (* add predicate definition after normalization *)
    let add_pred_def mn pn pred (x,t,f) =
      let pred = Util.unqualify pred in
      let mi = Ast.fetch_impl mn in
      let ms = Ast.fetch_spec mn in
      let sdefs_s = [] in (* Preds.get_all_preds () in *)
      let globals = List.map fst mi.references in
      let mk_gsubst id = (id, Vcform.mk_var (Vctrans.mk_global_var mn id)) in
      let gdefs_s = List.map mk_gsubst globals in
      let locals = 
	if mn = "" then [] 
	else if Ast.has_impl_proc pn mi then
	  (Ast.fetch_impl_proc pn mi).formals
	else if Ast.has_spec_proc pn ms then
	  (Ast.fetch_spec_proc pn ms).Sabsyn.formals
	else [] in
      let mk_lsubst id = (Vctrans.mk_set_var id, Vcform.mk_var (Vctrans.mk_local_var id)) in
      let ldefs_s = List.map mk_lsubst (extract_vars locals) in
      let res = Vcform.subst ((x, Preds.free_var)::
			      sdefs_s @  
			      ldefs_s @ 
			      gdefs_s) f in
      Preds.add_pred false pred res

    (* initialize Bohne *) 
    let prepare_analyze_proc (mab: abst_body) mn pi =
      let tu = Vcform.TypeUniverse in
      let pn = Id.name_of_proc pi.Iabsyn.proc_id in
      let type_convert = Vctrans.vctype_of in
      let typevar_convert f (x, t) = (f x, type_convert t) in
      let field_defs = 
	List.fold_right (fun f defs ->
	  match f with
	  | Aabsyn.FormulaClause (
	    Vcform.Binder (Vcform.Forall, [(v11, t1); (v12, t2)], 
			   Vcform.App (Vcform.Const Vcform.Impl, 
				       [Vcform.App (Vcform.Const Vcform.Eq,
						    [Vcform.App (Vcform.Var fld, [Vcform.Var v21]); 
						     Vcform.Var v22]);
					fdef]))) when v11 = v21 & v12 = v22 
	    -> if t1 = t2 then 
	      (fld, Vcform.Binder (Vcform.Lambda, [(v11, t1); (v12, t2)], fdef))::defs 
	      else failwith "unsupported field declaration"
	  (*
	  | Aabsyn.FormulaClause (
	    Vcform.App 
	      (Vcform.Const Vcform.Iff, 
	       [Vcform.App (Vcform.Var fld,
			    [Vcform.Var v1; Vcform.Var v2]);
		fdef])) ->
		  (fld, Vcform.Binder 
		     (Vcform.Lambda, [(v1, tu);
				      (v2, tu)], fdef))::defs *)
	  | _ -> defs)
	  mab.Aabsyn.invariants []
      in
      let find_field_def format_name fld =
	let ftype = Vcform.TypeObjRef format_name in
	List.fold_left (
	fun fdef_opt (fld', lam) -> 
	  if fld' = fld then
	    match lam with
	    | Vcform.Binder (Vcform.Lambda, [(v1, rtype); (v2, _)], def) -> 
		(match fdef_opt with
		| None when rtype = tu -> 
		    Some (Vcform.Binder (Vcform.Lambda, [(v1, ftype); (v2, ftype)], def))
		| _ when rtype = ftype -> Some lam
		| _ -> fdef_opt)
	    | _ -> fdef_opt
	  else fdef_opt) None field_defs
      in
      let format_convert f =
	let format_ty = Vcform.TypeObjRef f.format_name in
	let field_convert (fd, f_ty) =
	  let fdef = find_field_def f.format_name fd.Id.f_name in
	  (* cross-references from one format to an other one are not yet supported *)
	  (match f_ty with
	  | Types.TObj s when not (s = f.format_name) ->
	      failwith (Printf.sprintf "unsupported reference type of field \
			  %s in format %s" fd.Id.f_name f.format_name)
	  | _ -> ()); 
	  ((Vctrans.mk_global_var mn fd.Id.f_name, 
	   Vcform.TypeFun ([format_ty], type_convert f_ty)), fdef) in
	let fields0 = 
	  List.map field_convert f.fields in
        let fields = 
          let ma = 
            (fun (_, b) -> match b with None -> true | Some _ -> false) in
          List.filter ma fields0 @ 
          List.filter (fun (a, b) -> not (ma (a, b))) fields0 
	in
	(f.format_name, fields)
      in
      let add_pred pn sd = 
	let p = fst sd in
	let def = match snd sd with
	| Aabsyn.BaseForm bsd ->
	    let def' = match bsd.Aabsyn.expr with
	    | Aabsyn.FormulaClause f -> f
	    | _ -> failwith "expected formula clause in set defn after conversion"
	    in
	    (bsd.Aabsyn.x,
	     type_convert (Types.TObj bsd.Aabsyn.xt), def')
	| _ -> failwith "expected baseform in set defn after conversion"
	in 
	let _ = add_pred_def mn pn p def in
	let pre_p = "'" ^ (Util.unqualify p) in
	if pn = "" then Preds.add_pre_pred (Util.unqualify p) pre_p
      in
      let mi = Ast.fetch_impl mn in
      let proc_defs = List.filter 
	  (fun map -> map.Aabsyn.proc_name.Id.p_name = pn)
	  mab.Aabsyn.set_defining_procs
      in
      (* initialize module Preds *)
      begin
	Preds.reset ();
        (* collect globals *)
	List.iter 
	  (fun tv -> Preds.add_var
	      (typevar_convert (Vctrans.mk_global_var mn) tv) false false) (extract_tvars mi.references);
        (* collect locals *)
	let rlocals, blocals, lmap = Iabsyn.collect_local_obj_type_map pi in
	List.iter (fun x -> Preds.add_var 
	    (typevar_convert Vctrans.mk_local_var (x, Hashtbl.find lmap x)) false true)
	  (blocals @ rlocals);
        (* collect global predicates *)
	List.iter (add_pred "") mab.Aabsyn.set_defns;
	(* collect local predicates *)
	List.iter (fun pd -> List.iter (add_pred pn) pd.Aabsyn.proc_set_defns) 
	  proc_defs;
	(* collect formats *)
	List.iter (fun format -> Preds.add_rec_def (format_convert format))
	  mi.formats;
      end
      
    (* get pre and post conditions from specification *)
    let fetch_pre_post mn mab ps pi =
      let all_sb = { Spec.s = Abst.collect_all_sets mab; 
		     Spec.b = Abst.collect_all_bools mab } in
      let mi = Ast.fetch_impl mn in
      let parse_sabsyn_form s = Spec.parse_formula mn all_sb s in
      let bf_t = Bf_set.top in
      let v0 = Preds.free_var in
      let extract_inv c = 
	match c with 
	| Aabsyn.FormulaClause (
	  Vcform.Binder (Vcform.Forall, [(v11, t1); (v12, t2)], 
			 Vcform.App (Vcform.Const Vcform.Impl, 
				     [Vcform.App (Vcform.Const Vcform.Eq,
						  [Vcform.App (Vcform.Var fld, [Vcform.Var v21]); 
						   Vcform.Var v22]);
				      fdef]))) when v11 = v21 & v12 = v22 
	  -> Vcform.mk_true 
	| Aabsyn.FormulaClause f -> f
	| _ -> failwith "expected formula clause in invariant after conversion"
      in
      let callee_private = ref pi.proc_modifiers.Id.is_private in
      let precond_i, postcond_i = 
	(unwrap Vcform.mk_true pi.requires,
	 unwrap Vcform.mk_true pi.ensures)
      and precond_s, postcond_s, postcond =
	if (not Vcgen.is_cheating_for_spec_invokes) & 
	  (Ast.has_spec_proc_by_t pi.proc_id) then
	  let formals_s = mi.references @
	    match ps.Sabsyn.ret_val with
	    | Some v -> v::ps.Sabsyn.formals
	    | None -> ps.Sabsyn.formals
	  in
	  let convert_ensures_clause c fs =
	    if !vc_mode then bf_t else convert_ensures_clause c fs 
	  in 
	  callee_private := ps.Sabsyn.proc_modifiers.Id.is_private;
	  (convert_sabsyn_form false ps.Sabsyn.requires formals_s,
	   convert_ensures_clause (Sabsyn.construct_ensures ps) formals_s,
	   convert_sabsyn_form true (Sabsyn.construct_ensures ps) formals_s)
	else
	  (Vcform.mk_true, bf_t, Vcform.mk_false)
      in
      let invariants =
	if not !callee_private then
	  List.fold_left (fun acc f ->
	    let i = extract_inv f in
	    if i = Vcform.mk_true then acc else i::acc) [] mab.Aabsyn.invariants
	else [] in
      (invariants, Vcform.smk_and [precond_i; precond_s], postcond_s, Vcform.smk_and [postcond_i; postcond])

    (* compute graph type invariants from specification *)
    let gtype_invariants vars =
      let mk_rtrancl rel t1 t2 =
	Vcform.App (Vcform.mk_var "rtrancl", [rel; t1; t2]) in
      let get_field_constraint =
	let env = Preds.get_global_env () in
	fun fld -> 
	  try List.assoc fld env 
	  with Not_found -> failwith "missing field constraint" 
      in
      let v0 = Vcform.mk_var "v0"
      and v1 = Vcform.mk_var "v1"
      and v2 = Vcform.mk_var "v2" in
      let r bb_fields v1 v2 = 
	Vcform.mk_or 
	  (List.rev_map (fun fld -> Vcform.mk_eq (Vcform.App (Vcform.mk_var fld, [v1]), v2)) bb_fields) 
      in
      let rel rname r = 
	let rtype = Vcform.TypeObjRef rname in
	Vcform.Binder (Vcform.Lambda, [("v1", rtype); ("v2", rtype)], r v1 v2) 
      in
      let v = Preds.free_var in
      let recs = Preds.get_rec_defs () in
      let local_heap rname bb_fields = 
	List.fold_left (fun acc (x, xt) ->
	  if xt = Types.TObj rname then
	    mk_rtrancl (rel rname (r bb_fields)) (Vcform.mk_var x) v0::acc
	  else acc) 
      in
      let tree rname bb_fields =
	let rtype = Vcform.TypeObjRef rname in 
	let r = r bb_fields in
	let rel = rel rname r in
	let acyclic = 
	  Vcform.mk_foralls 
	    ([("v0", rtype); ("v1", rtype); ("v2", rtype)],
	     Vcform.mk_impl (Vcform.smk_and 
			       [Vcform.mk_neq (Vcform.mk_null, v0); 
				r v0 v1; mk_rtrancl rel v1 v2], Vcform.mk_neq (v0, v2)))
	in
	let no_sharing = 
	  Vcform.mk_foralls  
	    ([("v0", rtype); ("v1", rtype); ("v2", rtype)],
	     Vcform.mk_impl (Vcform.smk_and [Vcform.mk_neq (Vcform.mk_null, v0);
					     r v1 v0; r v2 v0], 
			     Vcform.mk_eq (v1, v2)))
	in
	[(Printf.sprintf "acyclic(%s)" rname, acyclic); 
	 (Printf.sprintf "no_sharing(%s)" rname, no_sharing)] 
      in
      let process_field rname (bbfs, dfis) ((fld, fld_type), is_derived) =
	let rtype = Vcform.TypeObjRef rname in
	(* filter object typed fields *)
	match fld_type with
	| Vcform.TypeFun (_, Vcform.TypeObjRef _) ->
	    if not is_derived then (fld::bbfs, dfis)
	    else
	      (match get_field_constraint (fld, fld_type) with
	      | Some (Vcform.Binder (Vcform.Lambda, [(v1, t1); (v2, t2)], fld_def)) ->
		  let field_inv = Vcform.mk_impl 
		      (Vcform.mk_eq (Vcform.App (Vcform.Var fld, [Vcform.Var v1]), Vcform.Var v2),
		       fld_def)
		  in
		  (bbfs, 
		   (Printf.sprintf "field_def(%s.%s)" rname fld, 
		    Vcform.mk_foralls ([(v1, t1); (v2, t2)], field_inv))::dfis)
		   (* Vcform.mk_forall (v2, t2, Vcform.subst [(v1, v)] field_inv)::precond) *)
	      | _ -> failwith (Printf.sprintf "unsupported definition of derived field %s.%s" rname fld))
	| _ -> (bbfs, dfis)
      in
      let process_rec (acc, lheap) (rname, fields) =
	let bb_fields, d_field_invs = 
	  List.fold_left (process_field rname) ([], []) fields 
	in
	let lheap' = local_heap rname bb_fields lheap vars in
	(List.rev_append (tree rname bb_fields @ d_field_invs) acc, lheap')
      in
      let ginvs, lheap = List.fold_left process_rec ([], []) recs in
      (* (ginvs, [Vcform.mk_forall ("v0", Vcform.TypeObjRef "", Vcform.mk_or lheap)]) *)
      (ginvs, [])

    (* abstract initial states *)
    let abstract_init vars init0 precond =
      let unpreprime p = String.sub p 1 (String.length p - 1) in	
      let var_ps = Preds.null_pred::List.map (fun (v, _) -> Preds.get_pred v) vars in
      let ign = Preds.fold_preds (fun acc p -> 
	if Preds.is_var p && not (List.mem p var_ps) then Preds.get_pred_name p::acc else acc) [] in 
      let abs_init = Bf_set.singleton (Abstr.alpha precond init0) in
      let abs_init = Abstr.coerce ign (Vcform.mk_and [precond; init0]) abs_init in 
      let abs_init = Preds.fold_preds (fun acc p ->
	if Preds.is_pre_pred p then 
	  let p' = Preds.get_pred (unpreprime (Preds.get_pred_name p)) in
	  Bf_set.conj acc (Bf.equi (Bf.mk_var p) (Bf.mk_var p'))
	else acc) abs_init in
      let _ = print_debug 3 (fun () -> print_string "\nbefore splitting:\n"; Abstr.print_abs_states abs_init) in
      let split_abs_init = Abstr.split_singletons precond var_ps ign abs_init in
      let split_abs_init = Abstr.coerce ign (Vcform.mk_and [precond; init0]) split_abs_init in
      split_abs_init
    
    type error = {
	m_name : string; 
	p_name : string;
	prop_name : string;
	prop : Vcform.form option;
	trace : Wp.trace option;
	abs_state : Abstr.abs_state}

    (* print abstract error *)
    let print_error err =
      print_string "\n\nPOSSIBLE ERROR TRACE\n\n";
      (* Format.open_box 6; *)
      print_string ("Causative property is " ^ err.prop_name ^ "\n");
      let _ = match (err.prop, err.trace) with
      |	(Some f, Some tr) -> 
	  print_string (Vcform.isabelle_formula f ^ "\n");
	  print_string "sequence of statements:\n";
	  Wp.print_trace stdout tr;
	  Printf.printf "Weakest precondition of %s:\n%s\n" err.prop_name
	    (Vcform.isabelle_formula (Vcform.mk_impl (Wp.guard err.m_name tr, Wp.wp err.m_name tr f)));
      |	(Some f, _) -> print_string (Vcform.isabelle_formula f ^ "\n");
      |	_ -> ()
      in      
      print_endline "Abstract error state:";
      Abstr.print_abs_state err.abs_state (*;
      Format.close_box () *)
	

    exception AbstrError of error

    (* compute least fixed point *)
    let fix mn pn init vc_postcond s =
      let union fs gs = 
	List.fold_left (fun acc f -> if List.mem f gs then acc else f::acc) gs fs in
      let trace_map = Hashtbl.create 0 in
      let add_sideconds sideconds (trace, abs_states, i) =
	try
	  let abs_states', sideconds' = Hashtbl.find trace_map (trace, i) in
	  Hashtbl.replace trace_map (trace , i)
	    (Bf_set.union abs_states' abs_states, union sideconds sideconds')
	with Not_found ->
	  Hashtbl.add trace_map (trace, i) (abs_states, sideconds)
      in
      let ret_val = (Ast.fetch_impl_proc pn (Ast.fetch_impl mn)).ret_val in      
      let exit_states = ref Bf_set.bottom in
      let add f traces e = 
	List.rev_map (fun (trace, pre_states, i) -> (f trace e, pre_states, i)) traces
      in
      let add_guard = add Wp.add_guard
      and add_guard_from_form = add Wp.add_guard_from_form
      and add_update = add Wp.add_update
      and add_havoc = add Wp.add_havoc in
      let initial_traces = [([], init, true)] in 
      let new_trace abs_states = [([], abs_states, false)] in
      let compute_post traces =
	let filter_by_guard guard abs_states =
	  if not (Dp.satisfiable guard) then Bf_set.bottom else
	  let imply_guard, dont_knows = Bf_set.partition (fun abs_state -> 
	    Dp.entails Vcform.mk_true (Abstr.gamma_state abs_state) guard) abs_states
	  in
	  let may_sat_guard = Bf_set.filter (fun abs_state -> 
	    Dp.satisfiable (Vcform.smk_and [guard; Abstr.gamma_state abs_state])) dont_knows
	  in
	  (* let imply_guard = Abstr.coerce [] guard imply_guard in *) 
	  let sat_guard = Abstr.coerce [] guard may_sat_guard in
	  Bf_set.union imply_guard sat_guard
	in
	if !vc_mode then
	  let _ = List.iter (add_sideconds []) traces in 
	  Bf_set.top 
	else
	List.fold_left (fun acc (trace, pre_states0, i) -> 
	  let guard = Wp.guard mn trace in
	  let pre_states = filter_by_guard guard pre_states0 in
	  let _ = add_sideconds [] (trace, pre_states, i) in 
	  let _ = print_debug 2 (fun () -> 
	    print_endline "\nComputing abstract post for trace:"; Wp.print_trace stdout trace) 
	  in
	  let post_states = 
	    Abstr.abstract_post guard (Wp.wp_updates mn trace) pre_states 
	  in
	  Bf_set.union acc post_states) Bf_set.bottom traces
      in
      let rec fix_loop entry_states e t =
	let rec fix_loop' entry_states acc =
	  let new_traces = fix (add_guard (new_trace entry_states) e) [t] in
	  let new_entry_states = compute_post new_traces in
	  if Bf_set.le new_entry_states acc then
	    acc
	  else fix_loop' (Bf_set.diff new_entry_states acc) (Bf_set.union new_entry_states acc)
	in fix_loop' entry_states entry_states
      and fix traces sl =
	match sl with
	| s::sl' -> (match s with
	  | CompoundStmt sl -> fix traces (sl @ sl')
	  | ChoiceStmt (t,u) -> 
	      let traces_t = fix traces [t] 
	      and traces_u = fix traces [u] in
	      fix (List.rev_append traces_t traces_u) sl'
	  | ExprStmt e -> fix (add_update traces e) sl'
	  | WhileStmt (i, e, t) when !vc_mode ->
	      let e, not_e = match e with
	      |	LiteralExpr (String "*") -> (LiteralExpr (Bool true), LiteralExpr (Bool true))
	      |	_ -> (e, NotExpr e)
	      in
	      let loop_inv = match i with
	      |	Some i' -> i' |	None -> Vcform.mk_true
	      in
	      let loop_traces = 
		fix (add_guard (add_guard_from_form (new_trace Bf_set.top) loop_inv) e) [t]
	      in  
	      let _ = List.iter (add_sideconds [("vc-loop-entry", loop_inv)]) traces in
	      let _ = List.iter (add_sideconds [("vc-loop-body", loop_inv)]) loop_traces in
	      fix (add_guard (add_guard_from_form (new_trace Bf_set.top) loop_inv) not_e) sl'
	  | WhileStmt (i, e, t) ->
	      let entry_states = compute_post traces in
	      (match e with
	      |	LiteralExpr (String "*") ->
		  let lfp_loop = fix_loop entry_states (LiteralExpr (Bool true)) t in
		  fix (new_trace lfp_loop) sl'
	      |	_ ->
		  let lfp_loop = fix_loop entry_states e t in
		  fix (add_guard (new_trace lfp_loop) (NotExpr e)) sl')
	  | AssumeStmt (_, e) -> 
	      fix (add_guard_from_form traces e) sl'
	  | AssertStmt (n_opt, e) ->
	      let name = match n_opt with None -> "assert" | Some n -> n in
	      let _ = List.iter (add_sideconds [(name, e)]) traces in
	      fix traces sl'
	  | IfStmt (e, t, u) -> 
	      let traces_t = fix (add_guard traces e) [t]
	      and traces_u = fix (add_guard traces (NotExpr e)) [u] in
	      fix (List.rev_append traces_t traces_u) sl'
	  | HavocStmt [l] -> 
	      fix traces (ChoiceStmt (ExprStmt (AssignExpr (LocalLvalue l, LiteralExpr (Bool true))), 
				       (ExprStmt (AssignExpr (LocalLvalue l, LiteralExpr (Bool false)))))::sl')
	  | HavocStmt vs -> 
	      if !vc_mode then fix (add_havoc traces vs) sl'
	      else failwith ("havoc statement not supported in Bohne")
	  | ReturnStmt e_opt ->
	      let traces' = match (e_opt, ret_val) with
	      |	(None, None) -> traces
	      |	(Some e, Some (x, xt)) -> add_update traces (AssignExpr (LocalLvalue x, e))
	      |	_ -> failwith "underspecified return statement"
	      in    
	      let _ = if !vc_mode then List.iter (add_sideconds [("postcondition", vc_postcond)]) traces' in
	      exit_states := Bf_set.union !exit_states (compute_post traces'); []
	  | _ -> fix traces sl')
	| [] -> traces
      in
      let exit_states2 = compute_post (fix initial_traces [s]) in
      let exit_states = Bf_set.union !exit_states exit_states2 in
      (* clean fixed point *)
      let exit_states = 
	if !vc_mode then exit_states
	else Abstr.coerce [] Vcform.mk_true exit_states 
      in 
      if not !vc_mode then 
	print_debug 1 (fun () -> print_newline (); Abstr.print_abs_states exit_states); 
      (exit_states, trace_map)

    let prop_no_null_derefs = "no_null_derefs"

    (* find pair of abstract error state and violated property *)
    let find_error mn pn (trace, i) abs_states props = 
      let check_prop (trace, i) abs_states (name, f) =
	let raise_error trace wp_f abs_states =
	  Bf_set.iter (fun abs_state ->
	    if Dp.entails Vcform.mk_true (Abstr.gamma_state abs_state) wp_f then
	      () 
	    else
	      let err = {m_name = mn; 
			 p_name = pn; 
			 prop_name = name;
			 prop = Some f;
			 trace = if trace = [] then None else Some trace;
			 abs_state = abs_state}
	      in raise (AbstrError err)) abs_states
	in
	let wp_f = Wp.wp mn trace f in
	let guard = 
	  if i && !vc_mode then
	    let tick_pred_defs =
	      Preds.fold_preds (fun acc p ->
	      if Preds.is_pre_pred p then
		Vcform.mk_iff (
		(if Preds.is_var p then
		  if Vcform.get_type (Preds.get_pred_name p) (Preds.get_local_env ()) = Vcform.TypeBool then
		    Vcform.mk_var (Preds.get_pred_name p)
		  else
		    Vcform.mk_eq (Preds.free_var, Vcform.mk_var (Preds.get_pred_name p))
		else
		  Vcform.mk_elem (Preds.free_var, Vcform.mk_var (Preds.get_pred_name p))),
		Preds.get_pred_def p)::acc
	      else acc) []
	    in Vcform.mk_foralls ([Preds.typed_free_var], Vcform.smk_and tick_pred_defs)
	  else Vcform.mk_true 
	in
	let pre_states = 
	  Bf_set.map (Abstr.project_irrelevant (Vcform.smk_impl (guard, wp_f))) abs_states in
	let is_valid = 
	  Dp.entails guard (Abstr.gamma pre_states) wp_f 
	in
	if is_valid then () else raise_error trace wp_f pre_states
      in
      List.iter (check_prop (trace, i) abs_states) props

    (* verify well-formedness conditions *)
    let check_sideconds mn pn trace_map invs = 
      let check_trace (trace, i) (abs_states, postconds) =
	let fs = List.rev_append postconds invs in
	let wps = Wp.wp mn trace (Vcform.smk_and (List.map snd fs)) in
	let guard = 
	  if i && !vc_mode then
	    let tick_pred_defs =
	      Preds.fold_preds (fun acc p ->
	      if Preds.is_pre_pred p then
		Vcform.mk_iff (
		(if Preds.is_var p then
		  if Vcform.get_type (Preds.get_pred_name p) (Preds.get_local_env ()) = Vcform.TypeBool then
		    Vcform.mk_var (Preds.get_pred_name p)
		  else
		    Vcform.mk_eq (Preds.free_var, Vcform.mk_var (Preds.get_pred_name p))
		else
		  Vcform.mk_elem (Preds.free_var, Vcform.mk_var (Preds.get_pred_name p))),
		Preds.get_pred_def p)::acc
	      else acc) []
	    in Vcform.mk_foralls ([Preds.typed_free_var], Vcform.smk_and tick_pred_defs)
	  else Vcform.mk_true 
	in
	let pre_states = Bf_set.map (Abstr.project_irrelevant (Vcform.smk_impl (guard, wps))) abs_states in
	let _ = if !vc_mode then 
	  print_debug 2 (fun () -> print_endline 
	      ("\nchecking VC\n" ^ Vcform.isabelle_formula (Vcform.smk_impl (guard, wps))))
	in
	let passes = 
	  if wps = Vcform.mk_true then true 
	  else Dp.entails guard (Abstr.gamma pre_states) wps
	in if not passes then find_error mn pn (trace, i) abs_states ((prop_no_null_derefs, Vcform.mk_true)::fs)
      in
      try Hashtbl.iter check_trace trace_map; true
      with AbstrError err -> print_error err; false
	  
    (* verify post conditions *)
    let check_postconds mn pn abs_post_states postcond invariants =	  
      try 
	(* check entailment of ensures clauses *)
	Bf_set.iter (fun abs_state -> 
	if not (Bf_set.le (Bf_set.singleton abs_state) postcond) then
	  let error =  {m_name = mn; 
			p_name = pn; 
			prop_name = "ensures clause (or frame condition)";
			prop = None;
			trace = None;
			abs_state = abs_state}
	  in raise (AbstrError error)) abs_post_states;
	(* check entailment of module invariants *)
	if not (Dp.entails Vcform.mk_true 
		  (Abstr.gamma abs_post_states) (Vcform.smk_and invariants))
	then find_error mn pn ([], false) abs_post_states 
	    (List.map (fun inv -> ("module invariant", inv)) invariants);
	true
      with AbstrError err -> print_error err; false

    let analyze_proc mab mi ps =
      let start_time = 
	let ptime = Unix.times () in
	ptime.Unix.tms_utime +. ptime.Unix.tms_cutime  
      in
      let pn = ps.Sabsyn.proc_name.Id.p_name in
      let pi0 = Ast.fetch_impl_proc pn mi in
      let pi = convert_proc mab mi pi0 in
      let mn = mi.Iabsyn.module_name in
      let print_post_stats result =
        let total_time = 
	  let ptime = Unix.times () in
	  ptime.Unix.tms_utime +. ptime.Unix.tms_cutime -. start_time
	in 
	let dp_stats = Dp.stats ()
	and _ = Dp.reset_stats () in
	let dp_rel_time = dp_stats.total_time /. total_time *. 100.0 
	and dp_rel_cache_hits = float dp_stats.cache_hits /. float dp_stats.calls *. 100.0 in
	let stats = "\nSTATISTICS\n" ^
	  Printf.sprintf "  running time for analysis: %.2fs (MONA: %.2f%%)\n" total_time dp_rel_time ^
	  (* Printf.sprintf "  total running time for MONA: %.2fs (%.0f%%)\n" dp_stats.total_time  ^ *)
	  Printf.sprintf "  max. running time for single call to MONA: %.2fs\n" dp_stats.max_time ^
	  Printf.sprintf "  # calls to MONA: %d\n" dp_stats.calls ^
	  Printf.sprintf "  # cache hits: %d (%.2f%%)\n" dp_stats.cache_hits dp_rel_cache_hits 
	in
	let proc_result = Printf.printf "Done analyzing proc %s, proc %s.\n" in
	print_debug 0 (fun () -> proc_result pn (if result then "passes" else "fails"));
	print_debug 1 (fun () -> print_endline stats)
      in
      let print_pre_stats () =
	print_debug 1 (fun () ->
	  print_endline "Use predicates:";
	  Preds.print_preds stdout)
      in
      let print_gtype_invs gt_invs =
	let print_inv (name, f) =
	  Printf.printf "\n%s: %s" name (Vcform.isabelle_formula f)
	in
	print_endline "\nInvariants for formats:";
	List.iter print_inv gt_invs
      in
      begin
	print_debug 0 (fun () -> Printf.printf "Analyzing proc %s.\n" pn);
	prepare_analyze_proc mab mn pi;
	let vars = extract_tvars (List.rev_append mi.references pi.formals) in
	let invariants, precond1, postcond, vc_postcond0 = fetch_pre_post mn mab ps pi in
	let gtype_invs, precond2 = gtype_invariants vars in
	let _ = print_debug 3 (fun () -> print_gtype_invs gtype_invs) in
	if not (!vc_mode) then print_pre_stats ();
	(* compute abstraction of intial states *)
	let init = 
	  if !vc_mode then Bf_set.top else
	  let _ = phase 1 "Precomputing empty cubes" Abstr.compute_empty_cubes () in
	  let init = phase 1 "Abstracting initial states"
	      (abstract_init vars precond1) (Vcform.smk_and (precond2 @ invariants)) in
	  let _ = print_debug 1 (fun () -> Abstr.print_abs_states init) in
	  init
	in
	let vc_postcond = Vcform.smk_and (vc_postcond0::invariants) in
	let vc_init = Vcform.smk_and (precond1::precond2 @ invariants) in
	let body =
	  if !vc_mode then 
	    if pi.ret_val = None then
	    CompoundStmt [AssumeStmt (None, vc_init);
			  pi.proc_body; 
			  AssertStmt (Some "postcondition", vc_postcond)]
	    else CompoundStmt [AssumeStmt (None, vc_init); pi.proc_body]
	  else pi.proc_body
	in
        (* compute least fixed point *)
	let exit_states, trace_map = 
	  phase 1 (if !vc_mode then "Generating verification conditions" else "Computing fixed point") 
	    (fix mn pn init vc_postcond) body in 
	(* verify well-formdness conditions, ensures clauses and module invariants *)
	let result = 
	  if !vc_mode then
	    phase 1 "Checking verification conditions" (check_sideconds mn pn trace_map) gtype_invs
	  else
	    phase 1 "Checking side conditions" (check_sideconds mn pn trace_map) gtype_invs
	      &&
	    phase 1 "Checking post conditions" (check_postconds mn pn exit_states postcond) invariants
	in 
	print_post_stats result;
	result
      end

    let analyze_module mn (mab0, ms, mi) (pns:string list) =
      (* let _ = set_debug_level 3 *)
      let mn = mi.module_name
      and pname mm = mm.Sabsyn.proc_name.Id.p_name
      and mab = convert_abst_body mab0 mn  in
      let procs = match pns with
      | [] -> ms.Sabsyn.procs
      | _ -> List.filter (fun mm -> List.mem (pname mm) pns) 
            ms.Sabsyn.procs
      in
      let results = List.map (analyze_proc mab mi) procs in
      List.fold_left (fun x y -> x & y) true results 
  end
