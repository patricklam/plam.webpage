/* Courtesy of Prof. Laurie Hendren, from COMP 520 materials. */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "runwig.h"

unsigned char dd2c(char d1, char d2) 
{ register unsigned char digit;
 
  digit = (d1 >= 'A' ? ((d1 & 0xdf) - 'A')+10 : (d1 - '0'));
  digit *= 16;
  digit += (d2 >= 'A' ? ((d2 & 0xdf) - 'A')+10 : (d2 - '0'));
  return digit;
}

FIELDS *fields = NULL;

void parseFields()
{ FIELDS *f;
  int c,i,size;
  c=getchar();
  if (c==EOF) return;
  f = (FIELDS *)malloc(sizeof(FIELDS));
  size=8;
  f->name = (char *)malloc(size);
  for (i=0; c!=EOF && c!='&' && c!='='; c=getchar(),i++) {
      switch(c) {
        case '+': 
             f->name[i] = ' ';
             break;
        case '%':
             f->name[i] = dd2c(getchar(),getchar());
             break;
        default:
             f->name[i] = c;
      }
      if (i+1 >= size) {
         size = 2*size;
         f->name = realloc(f->name,size);
      }
  }
  f->name[i] = '\0';
  c = getchar();
  size=8;
  f->value = (char *)malloc(size);
  for (i=0; c!=EOF && c!='&' && c!='='; c=getchar(),i++) {
      switch(c) {
        case '+': 
             f->value[i] = ' ';
             break;
        case '%':
             f->value[i] = dd2c(getchar(),getchar());
             break;
        default:
             f->value[i] = c;
      }
      if (i+1 >= size) {
         size = 2*size;
         f->value = realloc(f->value,size);
      }
  }
  f->value[i] = '\0';
  f->next = fields;
  fields = f;
  if (c=='&') parseFields();
}

char *getField(char *name)
{ FIELDS *f;
  f = fields;
  while (f!=NULL) {
    if (strcmp(name,f->name)==0) return f->value;
    f = f->next;
  }
  return "";
}

char *randomString(char *name,int size)
{ char *r;
  int i,l;
  l = strlen(name);
  r = (char *)malloc(l+size+2);
  for (i=0; i<l; i++) r[i]=name[i];
  r[l] = '$';
  for (i=l+1; i<l+size+1; i++) r[i]='a'+lrand48()%('z'-'a'+1);
  r[l+size] = '\0';
  return r;
}

int getGlobalInt(char *name)
{ FILE *f;
  int i;
  f = fopen(name,"r");
  if (!f) return 0;
  fscanf(f,"%i\n",&i);
  fclose(f);
  return i;
}

void putGlobalInt(char *name,int value)
{ FILE *f;
  f = fopen(name,"w");
  if (!f) return;
  fprintf(f,"%i\n",value);
  fclose(f);
}

#define SLEN 80
char * getGlobalString(char *name)
{ FILE *f;
  char * s = malloc(SLEN);
  f = fopen(name,"r");
  if (!f) return 0;
  fgets(s, 80, f);
  fclose(f);
  return s;
}

void putGlobalString(char *name,char *s)
{ FILE *f;
  f = fopen(name,"w");
  if (!f) return;
  fprintf(f,"%s\n",s);
  fclose(f);
}

char *itoa(int i)
{ char *a;
  a = (char *)malloc(10);
  sprintf(a,"%i",i);
  return a;
}
