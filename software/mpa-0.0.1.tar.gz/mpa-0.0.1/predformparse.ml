type token =
  | IDENT of (string)
  | OBJIDENT of (string)
  | SETIDENT of (string)
  | BOOLIDENT of (string)
  | NATLIT of (int)
  | AND
  | OR
  | NOT
  | IMPL
  | IFF
  | COMMA
  | EQ
  | COLON
  | LEQ
  | DOT
  | SUBSET
  | ELEM
  | PLUS
  | MINUS
  | TIMES
  | LPAREN
  | RPAREN
  | TRUE
  | FALSE
  | SET
  | BOOL
  | FORALL
  | EXISTS
  | LET
  | IN
  | EXISTSONE
  | ATLEAST
  | ATMOST
  | EXACTLY
  | EOL

open Parsing;;
# 2 "predformparse.mly"
open Predform
open Predformid
# 43 "predformparse.ml"
let yytransl_const = [|
  262 (* AND *);
  263 (* OR *);
  264 (* NOT *);
  265 (* IMPL *);
  266 (* IFF *);
  267 (* COMMA *);
  268 (* EQ *);
  269 (* COLON *);
  270 (* LEQ *);
  271 (* DOT *);
  272 (* SUBSET *);
  273 (* ELEM *);
  274 (* PLUS *);
  275 (* MINUS *);
  276 (* TIMES *);
  277 (* LPAREN *);
  278 (* RPAREN *);
  279 (* TRUE *);
  280 (* FALSE *);
  281 (* SET *);
  282 (* BOOL *);
  283 (* FORALL *);
  284 (* EXISTS *);
  285 (* LET *);
  286 (* IN *);
  287 (* EXISTSONE *);
  288 (* ATLEAST *);
  289 (* ATMOST *);
  290 (* EXACTLY *);
  291 (* EOL *);
    0|]

let yytransl_block = [|
  257 (* IDENT *);
  258 (* OBJIDENT *);
  259 (* SETIDENT *);
  260 (* BOOLIDENT *);
  261 (* NATLIT *);
    0|]

let yylhs = "\255\255\
\001\000\002\000\002\000\002\000\002\000\002\000\002\000\002\000\
\002\000\002\000\002\000\002\000\002\000\002\000\002\000\002\000\
\002\000\002\000\002\000\002\000\002\000\002\000\002\000\002\000\
\002\000\002\000\008\000\006\000\005\000\004\000\010\000\010\000\
\010\000\010\000\003\000\003\000\007\000\007\000\007\000\009\000\
\009\000\009\000\009\000\000\000"

let yylen = "\002\000\
\002\000\001\000\001\000\004\000\001\000\003\000\003\000\003\000\
\003\000\003\000\005\000\003\000\003\000\003\000\005\000\005\000\
\005\000\002\000\003\000\003\000\003\000\003\000\003\000\003\000\
\003\000\003\000\002\000\002\000\003\000\003\000\001\000\001\000\
\001\000\001\000\001\000\003\000\004\000\003\000\001\000\001\000\
\003\000\003\000\003\000\002\000"

let yydefred = "\000\000\
\000\000\000\000\000\000\039\000\040\000\005\000\000\000\000\000\
\002\000\003\000\000\000\000\000\000\000\000\000\044\000\000\000\
\000\000\000\000\000\000\018\000\000\000\031\000\032\000\033\000\
\034\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\001\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\038\000\000\000\035\000\
\006\000\000\000\000\000\007\000\009\000\012\000\027\000\000\000\
\000\000\000\000\008\000\010\000\013\000\000\000\028\000\014\000\
\000\000\000\000\000\000\000\000\023\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\029\000\030\000\
\000\000\000\000\000\000\000\000\000\000\036\000\016\000\017\000\
\015\000\011\000\037\000"

let yydgoto = "\002\000\
\015\000\016\000\055\000\028\000\029\000\038\000\017\000\030\000\
\018\000\031\000"

let yysindex = "\002\000\
\065\255\000\000\243\254\000\000\000\000\000\000\065\255\065\255\
\000\000\000\000\158\255\013\255\184\255\184\255\000\000\042\255\
\068\255\154\255\005\255\000\000\003\255\000\000\000\000\000\000\
\000\000\184\255\184\255\065\255\065\255\065\255\252\254\015\255\
\021\255\045\255\065\255\065\255\065\255\168\255\048\255\065\255\
\065\255\065\255\065\255\065\255\000\000\168\255\054\255\054\255\
\054\255\054\255\054\255\054\255\051\255\000\000\141\255\000\000\
\000\000\075\255\084\255\000\000\000\000\000\000\000\000\184\255\
\184\255\184\255\000\000\000\000\000\000\033\255\000\000\000\000\
\096\255\149\255\183\255\183\255\000\000\023\255\023\255\023\255\
\023\255\023\255\086\255\005\255\168\255\000\000\000\000\000\000\
\065\255\065\255\065\255\065\255\142\255\000\000\000\000\000\000\
\000\000\000\000\000\000"

let yyrindex = "\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\136\255\009\255\085\255\018\255\000\000\069\255\115\255\132\255\
\105\255\122\255\091\255\000\000\000\000\052\255\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000"

let yygindex = "\000\000\
\000\000\249\255\024\000\104\000\106\000\000\000\242\255\246\255\
\128\000\122\000"

let yytablesize = 192
let yytable = "\020\000\
\021\000\037\000\001\000\040\000\056\000\053\000\004\000\019\000\
\041\000\042\000\063\000\043\000\044\000\022\000\023\000\024\000\
\025\000\020\000\020\000\064\000\060\000\061\000\062\000\070\000\
\057\000\065\000\054\000\067\000\068\000\069\000\020\000\077\000\
\072\000\073\000\074\000\075\000\076\000\026\000\027\000\022\000\
\050\000\051\000\052\000\020\000\032\000\033\000\034\000\041\000\
\042\000\066\000\043\000\044\000\022\000\089\000\090\000\091\000\
\005\000\004\000\004\000\071\000\004\000\004\000\092\000\037\000\
\037\000\003\000\004\000\005\000\006\000\056\000\094\000\084\000\
\007\000\004\000\025\000\025\000\045\000\025\000\025\000\046\000\
\047\000\095\000\096\000\097\000\098\000\008\000\004\000\009\000\
\010\000\087\000\025\000\011\000\012\000\013\000\021\000\014\000\
\042\000\042\000\088\000\042\000\042\000\041\000\042\000\025\000\
\042\000\052\000\021\000\093\000\042\000\042\000\041\000\041\000\
\042\000\041\000\041\000\035\000\041\000\036\000\041\000\021\000\
\024\000\024\000\000\000\024\000\024\000\042\000\041\000\043\000\
\043\000\000\000\043\000\043\000\000\000\043\000\039\000\043\000\
\024\000\026\000\026\000\041\000\026\000\026\000\019\000\043\000\
\019\000\019\000\000\000\058\000\059\000\024\000\000\000\085\000\
\085\000\026\000\041\000\042\000\043\000\019\000\022\000\023\000\
\024\000\025\000\086\000\099\000\000\000\048\000\026\000\049\000\
\053\000\004\000\019\000\050\000\051\000\052\000\078\000\079\000\
\080\000\081\000\082\000\083\000\000\000\000\000\026\000\027\000\
\022\000\023\000\024\000\025\000\041\000\042\000\000\000\043\000"

let yycheck = "\007\000\
\008\000\012\000\001\000\014\000\019\000\001\001\002\001\021\001\
\006\001\007\001\015\001\009\001\010\001\001\001\002\001\003\001\
\004\001\009\001\010\001\005\001\028\000\029\000\030\000\038\000\
\022\001\005\001\022\001\035\000\036\000\037\000\022\001\046\000\
\040\000\041\000\042\000\043\000\044\000\025\001\026\001\022\001\
\018\001\019\001\020\001\035\001\032\001\033\001\034\001\006\001\
\007\001\005\001\009\001\010\001\035\001\064\000\065\000\066\000\
\003\001\006\001\007\001\012\001\009\001\010\001\030\001\012\001\
\013\001\001\001\002\001\003\001\004\001\084\000\085\000\021\001\
\008\001\022\001\006\001\007\001\035\001\009\001\010\001\012\001\
\013\001\089\000\090\000\091\000\092\000\021\001\035\001\023\001\
\024\001\015\001\022\001\027\001\028\001\029\001\010\001\031\001\
\006\001\007\001\015\001\009\001\010\001\006\001\012\001\035\001\
\014\001\020\001\022\001\084\000\018\001\019\001\006\001\007\001\
\022\001\009\001\010\001\012\000\012\001\012\000\014\001\035\001\
\006\001\007\001\255\255\009\001\010\001\035\001\022\001\006\001\
\007\001\255\255\009\001\010\001\255\255\012\001\013\000\014\001\
\022\001\006\001\007\001\035\001\009\001\010\001\007\001\022\001\
\009\001\010\001\255\255\026\000\027\000\035\001\255\255\011\001\
\011\001\022\001\006\001\007\001\035\001\022\001\001\001\002\001\
\003\001\004\001\022\001\022\001\255\255\012\001\035\001\014\001\
\001\001\002\001\035\001\018\001\019\001\020\001\047\000\048\000\
\049\000\050\000\051\000\052\000\255\255\255\255\025\001\026\001\
\001\001\002\001\003\001\004\001\006\001\007\001\255\255\009\001"

let yynames_const = "\
  AND\000\
  OR\000\
  NOT\000\
  IMPL\000\
  IFF\000\
  COMMA\000\
  EQ\000\
  COLON\000\
  LEQ\000\
  DOT\000\
  SUBSET\000\
  ELEM\000\
  PLUS\000\
  MINUS\000\
  TIMES\000\
  LPAREN\000\
  RPAREN\000\
  TRUE\000\
  FALSE\000\
  SET\000\
  BOOL\000\
  FORALL\000\
  EXISTS\000\
  LET\000\
  IN\000\
  EXISTSONE\000\
  ATLEAST\000\
  ATMOST\000\
  EXACTLY\000\
  EOL\000\
  "

let yynames_block = "\
  IDENT\000\
  OBJIDENT\000\
  SETIDENT\000\
  BOOLIDENT\000\
  NATLIT\000\
  "

let yyact = [|
  (fun _ -> failwith "parser")
; (fun parser_env ->
    let _1 = (peek_val parser_env 1 : 'form) in
    Obj.repr(
# 30 "predformparse.mly"
                            ( _1 )
# 255 "predformparse.ml"
               : Predform.form))
; (fun parser_env ->
    Obj.repr(
# 35 "predformparse.mly"
    (True)
# 261 "predformparse.ml"
               : 'form))
; (fun parser_env ->
    Obj.repr(
# 37 "predformparse.mly"
    (False)
# 267 "predformparse.ml"
               : 'form))
; (fun parser_env ->
    let _1 = (peek_val parser_env 3 : string) in
    let _3 = (peek_val parser_env 1 : 'termList) in
    Obj.repr(
# 39 "predformparse.mly"
    (Rel(List.length _3,_1,_3))
# 275 "predformparse.ml"
               : 'form))
; (fun parser_env ->
    let _1 = (peek_val parser_env 0 : string) in
    Obj.repr(
# 41 "predformparse.mly"
    (Propvar _1)
# 282 "predformparse.ml"
               : 'form))
; (fun parser_env ->
    let _2 = (peek_val parser_env 1 : 'form) in
    Obj.repr(
# 43 "predformparse.mly"
    (_2)
# 289 "predformparse.ml"
               : 'form))
; (fun parser_env ->
    let _2 = (peek_val parser_env 1 : 'boolBinder) in
    let _3 = (peek_val parser_env 0 : 'form) in
    Obj.repr(
# 46 "predformparse.mly"
    (removeBool _2;Forallprop (_2,_3))
# 297 "predformparse.ml"
               : 'form))
; (fun parser_env ->
    let _2 = (peek_val parser_env 1 : 'boolBinder) in
    let _3 = (peek_val parser_env 0 : 'form) in
    Obj.repr(
# 49 "predformparse.mly"
    (removeBool _2;Existsprop (_2,_3))
# 305 "predformparse.ml"
               : 'form))
; (fun parser_env ->
    let _2 = (peek_val parser_env 1 : 'setBinder) in
    let _3 = (peek_val parser_env 0 : 'form) in
    Obj.repr(
# 52 "predformparse.mly"
    (removeSet _2;Forallset (_2,_3))
# 313 "predformparse.ml"
               : 'form))
; (fun parser_env ->
    let _2 = (peek_val parser_env 1 : 'setBinder) in
    let _3 = (peek_val parser_env 0 : 'form) in
    Obj.repr(
# 55 "predformparse.mly"
    (removeSet _2;Existsset (_2,_3))
# 321 "predformparse.ml"
               : 'form))
; (fun parser_env ->
    let _2 = (peek_val parser_env 3 : 'objLetBinder) in
    let _3 = (peek_val parser_env 2 : 'term) in
    let _5 = (peek_val parser_env 0 : 'form) in
    Obj.repr(
# 58 "predformparse.mly"
    (removeObj _2;Let(_2,_3,_5))
# 330 "predformparse.ml"
               : 'form))
; (fun parser_env ->
    let _2 = (peek_val parser_env 1 : 'objBinder) in
    let _3 = (peek_val parser_env 0 : 'form) in
    Obj.repr(
# 61 "predformparse.mly"
    (removeObj _2;Forall (_2,_3))
# 338 "predformparse.ml"
               : 'form))
; (fun parser_env ->
    let _2 = (peek_val parser_env 1 : 'objBinder) in
    let _3 = (peek_val parser_env 0 : 'form) in
    Obj.repr(
# 64 "predformparse.mly"
    (removeObj _2;Exists (_2,_3))
# 346 "predformparse.ml"
               : 'form))
; (fun parser_env ->
    let _2 = (peek_val parser_env 1 : 'objBinder) in
    let _3 = (peek_val parser_env 0 : 'form) in
    Obj.repr(
# 67 "predformparse.mly"
    (removeObj _2;Existsone (_2,_3))
# 354 "predformparse.ml"
               : 'form))
; (fun parser_env ->
    let _3 = (peek_val parser_env 2 : int) in
    let _4 = (peek_val parser_env 1 : 'objBinder) in
    let _5 = (peek_val parser_env 0 : 'form) in
    Obj.repr(
# 70 "predformparse.mly"
    (removeObj _4;Existseq (_3,_4,_5))
# 363 "predformparse.ml"
               : 'form))
; (fun parser_env ->
    let _3 = (peek_val parser_env 2 : int) in
    let _4 = (peek_val parser_env 1 : 'objBinder) in
    let _5 = (peek_val parser_env 0 : 'form) in
    Obj.repr(
# 73 "predformparse.mly"
    (removeObj _4;Existsgeq (_3,_4,_5))
# 372 "predformparse.ml"
               : 'form))
; (fun parser_env ->
    let _3 = (peek_val parser_env 2 : int) in
    let _4 = (peek_val parser_env 1 : 'objBinder) in
    let _5 = (peek_val parser_env 0 : 'form) in
    Obj.repr(
# 76 "predformparse.mly"
    (removeObj _4;Existsleq (_3,_4,_5))
# 381 "predformparse.ml"
               : 'form))
; (fun parser_env ->
    let _2 = (peek_val parser_env 0 : 'form) in
    Obj.repr(
# 78 "predformparse.mly"
    (Not _2)
# 388 "predformparse.ml"
               : 'form))
; (fun parser_env ->
    let _1 = (peek_val parser_env 2 : 'form) in
    let _3 = (peek_val parser_env 0 : 'form) in
    Obj.repr(
# 80 "predformparse.mly"
    (And[_1;_3])
# 396 "predformparse.ml"
               : 'form))
; (fun parser_env ->
    let _1 = (peek_val parser_env 2 : 'form) in
    let _3 = (peek_val parser_env 0 : 'form) in
    Obj.repr(
# 82 "predformparse.mly"
    (Or[_1;_3])
# 404 "predformparse.ml"
               : 'form))
; (fun parser_env ->
    let _1 = (peek_val parser_env 2 : 'form) in
    let _3 = (peek_val parser_env 0 : 'form) in
    Obj.repr(
# 84 "predformparse.mly"
    (Impl(_1,_3))
# 412 "predformparse.ml"
               : 'form))
; (fun parser_env ->
    let _1 = (peek_val parser_env 2 : 'form) in
    let _3 = (peek_val parser_env 0 : 'form) in
    Obj.repr(
# 86 "predformparse.mly"
    (Iff(_1,_3))
# 420 "predformparse.ml"
               : 'form))
; (fun parser_env ->
    let _1 = (peek_val parser_env 2 : 'term) in
    let _3 = (peek_val parser_env 0 : 'term) in
    Obj.repr(
# 88 "predformparse.mly"
    (Eq(_1,_3))
# 428 "predformparse.ml"
               : 'form))
; (fun parser_env ->
    let _1 = (peek_val parser_env 2 : 'setTerm) in
    let _3 = (peek_val parser_env 0 : 'setTerm) in
    Obj.repr(
# 90 "predformparse.mly"
    (Eqset(_1,_3))
# 436 "predformparse.ml"
               : 'form))
; (fun parser_env ->
    let _1 = (peek_val parser_env 2 : 'term) in
    let _3 = (peek_val parser_env 0 : 'setTerm) in
    Obj.repr(
# 92 "predformparse.mly"
    (Elem(_1,_3))
# 444 "predformparse.ml"
               : 'form))
; (fun parser_env ->
    let _1 = (peek_val parser_env 2 : 'setTerm) in
    let _3 = (peek_val parser_env 0 : 'setTerm) in
    Obj.repr(
# 94 "predformparse.mly"
    (Subset(_1,_3))
# 452 "predformparse.ml"
               : 'form))
; (fun parser_env ->
    let _1 = (peek_val parser_env 1 : 'anyIdent) in
    Obj.repr(
# 97 "predformparse.mly"
                        (addObj _1;_1)
# 459 "predformparse.ml"
               : 'objBinder))
; (fun parser_env ->
    let _1 = (peek_val parser_env 1 : 'anyIdent) in
    Obj.repr(
# 98 "predformparse.mly"
                          (addObj _1;_1)
# 466 "predformparse.ml"
               : 'objLetBinder))
; (fun parser_env ->
    let _2 = (peek_val parser_env 1 : 'anyIdent) in
    Obj.repr(
# 99 "predformparse.mly"
                            (addSet _2;_2)
# 473 "predformparse.ml"
               : 'setBinder))
; (fun parser_env ->
    let _2 = (peek_val parser_env 1 : 'anyIdent) in
    Obj.repr(
# 100 "predformparse.mly"
                              (addBool _2;_2)
# 480 "predformparse.ml"
               : 'boolBinder))
; (fun parser_env ->
    let _1 = (peek_val parser_env 0 : string) in
    Obj.repr(
# 103 "predformparse.mly"
        (_1)
# 487 "predformparse.ml"
               : 'anyIdent))
; (fun parser_env ->
    let _1 = (peek_val parser_env 0 : string) in
    Obj.repr(
# 104 "predformparse.mly"
           (_1)
# 494 "predformparse.ml"
               : 'anyIdent))
; (fun parser_env ->
    let _1 = (peek_val parser_env 0 : string) in
    Obj.repr(
# 105 "predformparse.mly"
           (_1)
# 501 "predformparse.ml"
               : 'anyIdent))
; (fun parser_env ->
    let _1 = (peek_val parser_env 0 : string) in
    Obj.repr(
# 106 "predformparse.mly"
            (_1)
# 508 "predformparse.ml"
               : 'anyIdent))
; (fun parser_env ->
    let _1 = (peek_val parser_env 0 : 'term) in
    Obj.repr(
# 111 "predformparse.mly"
    ([_1])
# 515 "predformparse.ml"
               : 'termList))
; (fun parser_env ->
    let _1 = (peek_val parser_env 2 : 'termList) in
    let _3 = (peek_val parser_env 0 : 'term) in
    Obj.repr(
# 113 "predformparse.mly"
    (_1 @ [_3])
# 523 "predformparse.ml"
               : 'termList))
; (fun parser_env ->
    let _1 = (peek_val parser_env 3 : string) in
    let _3 = (peek_val parser_env 1 : 'termList) in
    Obj.repr(
# 118 "predformparse.mly"
    (Fun (List.length _3,_1,_3))
# 531 "predformparse.ml"
               : 'term))
; (fun parser_env ->
    let _1 = (peek_val parser_env 2 : string) in
    Obj.repr(
# 120 "predformparse.mly"
    (Const _1)
# 538 "predformparse.ml"
               : 'term))
; (fun parser_env ->
    let _1 = (peek_val parser_env 0 : string) in
    Obj.repr(
# 122 "predformparse.mly"
    (Var _1)
# 545 "predformparse.ml"
               : 'term))
; (fun parser_env ->
    let _1 = (peek_val parser_env 0 : string) in
    Obj.repr(
# 127 "predformparse.mly"
    (Setvar _1)
# 552 "predformparse.ml"
               : 'setTerm))
; (fun parser_env ->
    let _1 = (peek_val parser_env 2 : 'setTerm) in
    let _3 = (peek_val parser_env 0 : 'setTerm) in
    Obj.repr(
# 129 "predformparse.mly"
    (Union[_1;_3])
# 560 "predformparse.ml"
               : 'setTerm))
; (fun parser_env ->
    let _1 = (peek_val parser_env 2 : 'setTerm) in
    let _3 = (peek_val parser_env 0 : 'setTerm) in
    Obj.repr(
# 131 "predformparse.mly"
    (Inter[_1;_3])
# 568 "predformparse.ml"
               : 'setTerm))
; (fun parser_env ->
    let _1 = (peek_val parser_env 2 : 'setTerm) in
    let _3 = (peek_val parser_env 0 : 'setTerm) in
    Obj.repr(
# 133 "predformparse.mly"
    (Diff(_1,_3))
# 576 "predformparse.ml"
               : 'setTerm))
(* Entry main *)
; (fun parser_env -> raise (YYexit (peek_val parser_env 0)))
|]
let yytables =
  { actions=yyact;
    transl_const=yytransl_const;
    transl_block=yytransl_block;
    lhs=yylhs;
    len=yylen;
    defred=yydefred;
    dgoto=yydgoto;
    sindex=yysindex;
    rindex=yyrindex;
    gindex=yygindex;
    tablesize=yytablesize;
    table=yytable;
    check=yycheck;
    error_function=parse_error;
    names_const=yynames_const;
    names_block=yynames_block }
let main (lexfun : Lexing.lexbuf -> token) (lexbuf : Lexing.lexbuf) =
   (yyparse yytables 1 lexfun lexbuf : Predform.form)
