package ca.uwaterloo.ece251.ast;

public class StringLiteral extends Literal {
    String n;
    public StringLiteral(String n) {
	this.n = n;
    }

    public String toString() {
	return n;
    }
}
