package ca.uwaterloo.ece251;

/** AST representation of a "sort" expression. */
public class SortExpr implements Expr {
    Expr.Comparator c;
    Expr v;

    public SortExpr(Expr.Comparator c, Expr v) {
	this.c = c; this.v = v;
    }

    /** Carry out the sort. My implementation (of all
     * <code>Expr</code>s, in fact) relies on <code>Value</code>s to
     * know how to sort (or otherwise compute on) themselves. */
    public Value eval(Interp interp) {
	Value arg = v.eval(interp);
	return arg.sort(c);
    }
}