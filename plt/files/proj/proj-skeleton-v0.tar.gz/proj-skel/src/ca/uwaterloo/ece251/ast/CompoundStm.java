package ca.uwaterloo.ece251.ast;

import java.util.List;

/** Represents a compound statement. */
public class CompoundStm extends Stm {
    List<Variable> variables;
    List<Stm> body;

    public CompoundStm(List<Variable> variables, List<Stm> body) {
	this.variables = variables;
	this.body = body;
    }

    public String toString() {
	return "{\n" + Util.lines(variables, 2) + Util.lines(body, 2) + "}\n";
    }
}
