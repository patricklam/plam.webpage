public class Test2 {
    public static void main(String[] argv) {
	CarList carList = new CarList();
	carList.loadCarData("carInvM.csv");
	Car c = carList.retrieve(0);
	System.out.println(c);
    }
}
