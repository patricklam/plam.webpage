(* Prints boolean algebra formulas into PALE syntax *)

open Sabsyn

let mkSingl s = s ^ "1"

let singleton_defs (fmt : string) (singletons : string list) : string =
  let mk_quant v = "existset " ^ mkSingl v ^ " of " ^ fmt ^ ": " in
  let quantifiers = String.concat "" (List.map mk_quant singletons) in
  let mk_cond v = 
    "(" ^ v ^ " =null ? empty(" ^ mkSingl v ^ ") : " ^
    mkSingl v ^ "={" ^ v ^ "}) & " in
  let conditions = String.concat "" (List.map mk_cond singletons) in
  quantifiers ^ conditions

let mkPrime s = s ^ "'"

let strNot   = "! " 
let strAnd   = " & "
let strOr    = " | "
let strImpl  = " => "
let strIff   = " <=> "
let strForallOne = "allpos "
let strForallSet = "allset "
let strExistsOne = "existpos "
let strExistsSet = "existset "
let strForallProp = "allbool "
let strExistsProp = "existbool "
let qbody = ": "
let strEq = " = "
let strNeq = " != "
let strSub = " sub "
let strTrue = "true"
let strFalse = "false"
let strEmptyset = "empty"
let strUnion = " union "
let strInter = " inter "
let strDiff = " minus "
let strCardgeq = "cardGeq"
let strCardeq = "cardEq"
let strCardleq = "cardLeq"
let strDisjoint = "disjoint"
let strComma = ", "
    
let mkCardgeq k = strCardgeq ^ (Format.sprintf "%d" k)
let mkCardeq k = strCardeq ^ (Format.sprintf "%d" k)
let mkCardleq k = strCardleq ^ (Format.sprintf "%d" k)
let mkDisjoint k = strDisjoint ^ (Format.sprintf "%d" k)

(* 'singletons' is list of variables that 
   need translation to singleton sets *)

let pale_string (fmt : string) (singletons : string list)
    (f : form) : string = 

  let ensure_set s = 
    if List.mem s singletons then mkSingl s else s in

  (* Print Formula *)
  let rec 
    p_form f = match f with  
      Atom af -> p_atomForm af
    | Not f1  -> strNot ^ pp_form f1
    | And fl  -> (match fl with
      | [] -> strTrue
      | _ -> p_form_list strAnd fl)
    | Or fl   -> (match fl with
      | [] -> strFalse
      | _ -> p_form_list strOr  fl)
    | Impl (f1,f2) -> pp_form f1 ^ strImpl ^ pp_form f2
    | Iff (f1,f2)  -> pp_form f1 ^ strIff ^ pp_form f2
    | ForallOne ((x,t),f) -> strForallOne ^ x ^ " of " ^ (Types.string_of_value_type t) ^ qbody ^ pp_form f
    | ForallSet ((x,t),f) -> strForallSet ^ x ^ " of " ^ (Types.string_of_value_type t) ^ qbody ^ pp_form f
    | ExistsOne ((x,t),f) -> strExistsOne ^ x ^ " of " ^ (Types.string_of_value_type t) ^ qbody ^ pp_form f
    | ExistsSet ((x,t),f) -> strExistsSet ^ x ^ " of " ^ (Types.string_of_value_type t) ^ qbody ^ pp_form f
    | ExistsProp (x, f) -> strExistsProp ^ x ^ qbody ^ pp_form f
    | ForallProp (x, f) -> strForallProp ^ x ^ qbody ^ pp_form f
    | UninterpretedString _ -> failwith "can't convert uninterpreted string to PALE"
  and
    pp_form f = "(" ^ p_form f ^ ")"
  and
    p_form_list op fl = match fl with
      []    -> failwith "empty list in p_form_list"
    | [f]   -> pp_form f
    | f::fs -> pp_form f ^ op ^ p_form_list op fs   
  and
    p_atomForm af = match af with
      Eq (s1,s2) -> p_setExp s1 ^ strEq ^ p_setExp s2
    | Neq (s1,s2) -> p_setExp s1 ^ strNeq ^ p_setExp s2
    | Sub (s1,s2) -> p_setExp s1 ^ strSub ^ p_setExp s2
    | True -> strTrue
    | False -> strFalse
    | Cardgeq (s,k) -> mkCardgeq k ^ pp_setExp s
    | Cardeq (s,k) -> mkCardeq k ^ pp_setExp s
    | Cardleq (s,k) -> mkCardleq k ^ pp_setExp s
    | Disjoint ss -> mkDisjoint (List.length ss) ^ "(" ^ p_setExp_list strComma ss ^ ")"
    | Propvar v -> (Util.unqualify v) ^ "0"
    | Propvarpost v -> Util.unqualify v
  and
    p_setExp s = match s with
    | Prevar id -> ensure_set id
    | Postvar id -> mkPrime (ensure_set id)
    | Emptyset -> strEmptyset
    | Union ss -> p_setExp_list strUnion ss
    | Inter ss -> p_setExp_list strInter ss
    | Diff (s1,s2) -> pp_setExp s1 ^ strDiff ^ pp_setExp s2
  and
    pp_setExp s = "(" ^ p_setExp s ^ ")"
  and
    p_setExp_list op ss = match ss with
      [] -> failwith "empty list in p_setExp_list"
    | [s] -> pp_setExp s
    | s::ss -> pp_setExp s ^ op ^ p_setExp_list op ss in
  (* main expression: *)
  Util.replace_dot_with_uscore (singleton_defs fmt singletons ^ p_form f)

