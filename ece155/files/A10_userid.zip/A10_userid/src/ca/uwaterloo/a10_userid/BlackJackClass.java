package ca.uwaterloo.a10_userid;

import java.util.Random;

public class BlackJackClass {
	
	public static final String[] cards = {"A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"};

	public Player dealer;
	public Player player;
	public boolean gameRunning;
	
	public BlackJackClass()
	{
		dealer = new Player();
		// putting this in a loop doesn't count...
		getCard(dealer);
		getCard(dealer);
		
		player = new Player();
		getCard(player);
		getCard(player);
	}
	
	public void getCard(Player p)
	{
		Random gen = new Random();
		int card = gen.nextInt(cards.length);
		// check if the card is a face card
		// note: this is not one of my errors :)
		if (card > 8)
			p.value += 10;
		else 
			p.value += card + 1;
		p.hand += cards[card] + " ";
	}
	
	public boolean isWinner()
	{
		if (player.value > dealer.value)
			return true;
		else
			return false;
	}
	
	public void dealerTurn(int dealerThreshold)
	{
		if (gameRunning) {
			// get the players hand and hit until dealer is greater than player or bust
			int playerCards;
			if (player.getVisibleValue() + 10 < dealerThreshold)
				playerCards = player.getVisibleValue() + 10;
			else
				playerCards = dealerThreshold;
			
			while (dealer.value < playerCards)
				getCard(dealer);
		}
	}
	
}
