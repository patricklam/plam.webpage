// ECE 150 Programming Assignment 4
//
// CarList Class
// Version 4.0
// Updated November 20, 2009 by WDB
//
// You are required to complete the implementation of this
// class based on the specifications provided.

import java.io.*;

public class CarList 
{
    private CarListEntry head;
    private CarListEntry tail;
    private int length;

    public CarList () 
    {
        head = null;
        tail = null;
        length = 0;
    } 

    public CarListEntry getHead () { return head; }
    public void setHead (CarListEntry head) { this.head = head; } 

    public CarListEntry getTail () { return tail; }
    public void setTail (CarListEntry tail) { this.tail = tail; }

    public int getLength () { return length; }
    public void setLength () { this.length = length; }

    public void clear () 
    {
        head = null;
        tail = null;
        length = 0;
    } 

    public Car retrieve (int indexPosition) 
    {
        CarListEntry current;
        int counter;
        if (indexPosition < 0 || indexPosition > length - 1 || head == null)
        {
            return null;
        }

	// Traverse the list and find the Car at the
	// specified indexPosition.
	current = head;
	counter = 0;
	
	do
        {
	    current = current.next;
	    counter++;
	} while (current.next != null && counter != indexPosition);
	
	if (counter != indexPosition)
        {
	    return null;
	}
	else
        {
	    return current.getData();
	}
    }

    @Override
    public String toString () 
    {
        CarListEntry tmp = head;
        String result = "";
        if (tmp != null)
        {
            result = tmp.toString ();
            tmp = tmp.next;
        }
        while (tmp != null)
        {
            result += "\n" + tmp.toString ();
            tmp = tmp.next;
        }
        return result;
    }

    public void display () 
    {
        CarListEntry tmp = head;
        if (tmp != null)
        {
            System.out.println (tmp);
            tmp = tmp.next;
        }
        while (tmp != null)
        {
            System.out.println (tmp);
            tmp = tmp.next;
        }
    }

    public void loadCarData (String filename) 
    {
        String line;
        String[] data;
        int lineNumber = 0;
        Car newCar;
        BufferedReader inStream;

        File f = new File(filename);
        if (f.exists())
        {
            try 
	    {
                inStream = new BufferedReader(new FileReader(f));
                clear ();
                System.out.println ("\nLoading car data");
                line = inStream.readLine ();
                while (line != null)
                {
                    if ((lineNumber % 500) == 0)
                    {
                        System.out.println (".");
                    }
                    data = line.split (",");
                    if (data.length == 6)
                    {
                        newCar = new Car (Integer.parseInt(data[0]), data[1], data[2],
                                          Integer.parseInt(data[3]),
                                          Car.CarColour.valueOf(data[4]),
                                          Double.parseDouble(data[5]));
                        insertByYear(newCar);
                    }
                    else
                    {
                        System.out.println ("WARNING: Skipping erroneous data");
                    }
                    lineNumber++;
                    line = inStream.readLine ();
                }
                inStream.close ();
                System.out.println ("\n");
		System.out.println ("Completed loading car data");
	    } catch (IOException e) {
		System.out.println ("I/O error");
	    }
        }
        else
        {
            System.out.println ("File does not exist");
        }
    }

    public void storeCarData (String filename) 
    {
	try 
	{
            PrintWriter outStream = new PrintWriter (filename);
            System.out.println ("\nStoring car data");
            if (head != null)
            {
                // Traverse the list and output each car entry
                CarListEntry current = head;
                outStream.println (current);
                while (current.next != null)
                {
                    current = current.next;
                    outStream.println (current);
                }
            }
            outStream.close ();
            System.out.println ("\n");
            System.out.println ("Completed storing car data");
	} catch (IOException e) { System.out.println("Error writing car data"); }
    }

    public Car delete (int indexPosition) 
    {
        CarListEntry current = head;
        CarListEntry previous = null;
        Car returnCar = null;
        int counter = 0;
        
        // If the list is empty, the length will be 0 and this condition 
        // will not be satisfied.  Checking for a head of null is not
        // required assuming that the length is always consistent with
        // the size of the linked list.
        if (indexPosition >= 0 && indexPosition <= length - 1)
        {
            // Traverse the list and find the Car at the specified
            // index.  Since the index position is between 0 and 
            // length - 1, this loop always terminates prior to finding
            // the end of the list.
            while (counter != indexPosition)
            {
                previous = current;
                current = current.next;
                counter++;
            }
            returnCar = current.getData();
            if (counter == 0)
            {
                // Delete the head element of the list
                head = current.next;
            }
            else
            {
                if (current == tail)
                {
                    tail = previous;
                }
             
                // Delete a non-head element of the list
                previous.next = current.next;
            }
            length--;
        }
        return returnCar;
    }

    public void append (Car pCar) 
    {
        if (pCar == null)
            return;
        CarListEntry tmp = new CarListEntry (pCar);
        tmp.next = null;
        if (head == null)
        {
            head = tmp;
        }
        else
        {
            tail.next = tmp;
        }
        tail = tmp;
        length++;
    }

    public void insertByYear (Car pCar) 
    {
        if (pCar == null)
        {
            return;
        }

        CarListEntry e = new CarListEntry (pCar, null);
        if (head == null)
        {
            // The inserted ListEntry is the first ListEntry
            head = e;
            tail = e;
            e.next = null;
            return;
        }

        CarListEntry tmp = head;
        CarListEntry previous = null;
     
        // This loop searches for the correct insertion point
        while (tmp != null && e.getData().getPrice() > tmp.getData().getPrice())
        {
            previous = tmp;
            tmp = tmp.next;
        }

        if (previous == null)
        {
            // The inserted ListEntry is the new head
            e.next = head;
            head = e;
        }
        else
        {
            if (previous.next == null)
            {
                // The inserted ListEntry is the new tail
                tail = e;
            }
            e.next = previous.next;
            previous.next = e;
        }
        length++;
        assert countLength() == length;
    }

    public int findFirstByMake (String targetMake,
                                int startingIndexPosition) 
    {
        CarListEntry cur = head;
        if ((head == null) || (startingIndexPosition < 0) 
            ||(startingIndexPosition >= length))
            return -1;
        for (int i = 0; i < length; i++)
        {
            if ((cur.getData().getMake().equals(targetMake)) && (i >= startingIndexPosition))
                return i;
            cur = cur.next;
        }
        return -1;
    }

    private void selectionSortCL () 
    {
        CarList sortedList = new CarList ();
        CarListEntry tmp = deleteMin ();

        while (tmp != null)
        {
            sortedList.append (tmp.getData());
            tmp = deleteMin ();
        }

        assert countLength() == length;
        head = sortedList.head;
        tail = sortedList.tail;
    }

    private CarListEntry deleteMin () 
    {
        CarListEntry minPrevious = null;
        CarListEntry previous = head;
        CarListEntry minCurrent = head;
        CarListEntry current;
        if (head == tail)
        {
            if (head == null)
            {
                // If the list is empty, return null
                return null;
            }
            else
            {
                // If the list contains one ListEntry, return the ListEntry and reset the list
                head = null;
                tail = null;
                length--;
                return minCurrent;
            }
        }
        
        // This loop traverses the list and records a reference to the ListEntry with the smallest value
        current = head.next;
        while (current != null)
        {
            if (current.getData().getPrice() < minCurrent.getData().getPrice())
            {
                // The current ListEntry contains the smallest value found so far
                minPrevious = previous;
                minCurrent = current.next;
            }
            previous = current;
            current = current.next;
        }
        if (head == minCurrent)
        {
            // The ListEntry is the head so update the head reference
            head = minCurrent.next;
        }
        else
        {
            if (tail == minCurrent)
            {
                // The ListEntry is the tail so update the tail reference and skip it
                tail = minPrevious;
            }
            minPrevious.next = minCurrent.next;
        }
        length--;
        return minCurrent;
    }

    public void storeCarDataByPrice (String filename) 
    {
        selectionSortCL ();
        storeCarData (filename);
    } 

    public int countLength() 
    {
        int count = 0;
        CarListEntry cur = head;
        while (cur != null)
        {
            count++;
            cur = cur.next;
        }
        return count;
    }
}
 
