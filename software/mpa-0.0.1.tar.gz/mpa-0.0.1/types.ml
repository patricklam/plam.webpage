
type value_type =
    TInt
  | TBool
  | TFloat
  | TString
  | TChar
  | TObj of Id.format_t
  | TArray of value_type
  | TVoid

let is_primitive_value_type t =
  match t with 
  | TArray _ | TObj _ -> false
  | _ -> true

let rec value_type_of_string x =
  if Util.last2 x = "[]" then 
    TArray (value_type_of_string (Util.chop_off_2 x))
  else
    match x with
    | "int" -> TInt
    | "bool" -> TBool
    | "float" -> TFloat
    | "string" -> TString
    | "char" -> TChar
    | _ -> TObj (Id.fetch_format x)

let rec string_of_value_type x =
  match x with
  | TInt -> "int"
  | TBool -> "bool"
  | TFloat -> "float"
  | TString -> "string"
  | TChar -> "char"
  | TObj y -> y
  | TVoid -> "void"
  | TArray y -> ((string_of_value_type y)^"[]")

let strip_one_array_level (x:value_type) =
  match x with
  | TArray y -> y
  | _ -> failwith "not an array"
