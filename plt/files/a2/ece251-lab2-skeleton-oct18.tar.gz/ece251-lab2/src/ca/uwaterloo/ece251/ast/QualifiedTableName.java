package ca.uwaterloo.ece251.ast;

public class QualifiedTableName {
    String db;
    String table;

    public QualifiedTableName(String db, String table) {
	this.db = db; this.table = table;
    }

    public String toString() {
	StringBuffer sb = new StringBuffer();
	if (db != null) sb.append(db + ".");
	sb.append(table);
	return sb.toString();
    }
}