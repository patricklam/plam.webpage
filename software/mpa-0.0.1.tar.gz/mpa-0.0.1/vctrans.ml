(* convert iabsyn exprs to vcform exprs *)
open Iabsyn
open Vcform

let set_var_prefix = "s_"
let prop_var_prefix = "p_"
let local_var_prefix = "l_"
let global_var_prefix = "g_"

(* let mk_local_var s = local_var_prefix ^ Util.replace_dot_with_uscore s *)
let mk_local_var s = Util.replace_dot_with_uscore s
(*
let mk_global_var modn s = 
  global_var_prefix ^ Util.replace_dot_with_uscore (Util.qualify_if_needed modn s)
*)
let mk_global_var modn s = Util.replace_dot_with_uscore s
let mk_set_var s = set_var_prefix ^ Util.replace_dot_with_uscore s
let mk_prop_var s = prop_var_prefix ^ Util.replace_dot_with_uscore s 

let vcexpr_of_iabsyn modn e =
  let rec vcexpr_of_iabsyn0 e =
    match e with
    | LiteralExpr v -> (match v with
      | Int i -> Const (IntConst i)
      | Bool b -> Const (BoolConst b)
      | Obj n when v = Iabsyn.null_obj -> (Const NullConst)
      | _ -> failwith "unsupported literal")
    | VarExpr lv -> (match lv with
      | LocalLvalue l -> Var (mk_local_var l)
      | RefLvalue v -> Var (mk_global_var modn v)
      | FieldLvalue (base, _) 
      | ArrayLvalue (base, _) ->
          failwith "don't yet support these varexprs")
    | FieldAccessExpr (base, f) ->
        failwith "don't yet support fieldaccessexpr"
    | ArrayAccessExpr (base, i) ->
        let i' = vcexpr_of_iabsyn0 i in
        let base' = vcexpr_of_iabsyn0 base in
        Vcform.mk_arrayRead(base',i')
    | NewExpr t -> 
        failwith "don't yet support newexpr"
    | NewArrayExpr (Types.TObj _, [e], d) (* when d=1 *) ->
        mk_newArray(vcexpr_of_iabsyn0 e, mk_null)
    | NewArrayExpr (_,_,_) ->
        failwith "vctrans, NewArrayExpr: only support 1-dimensional arrays of objects"
    | InvokeExpr (targ, args0) ->
        failwith "vcgen doesn't do invoke"
    | AssignExpr _ ->
        failwith "no assign in vc expr please!"
    | PostDecExpr e
    | PostIncExpr e
    | PreDecExpr e
    | PreIncExpr e -> 
        failwith "no side effects for vc stmts please!"
    | NegExpr e ->
        failwith "arith not yet in vc"
    | PlusExpr (lhs, rhs) ->
        mk_plus (vcexpr_of_iabsyn0 lhs, vcexpr_of_iabsyn0 rhs)
    | MinusExpr (lhs, rhs) ->
        mk_minus (vcexpr_of_iabsyn0 lhs, vcexpr_of_iabsyn0 rhs)
    | MultExpr (lhs, rhs) ->
        mk_mult (vcexpr_of_iabsyn0 lhs, vcexpr_of_iabsyn0 rhs)
    | DivExpr (lhs, rhs) ->
        mk_div (vcexpr_of_iabsyn0 lhs, vcexpr_of_iabsyn0 rhs)
    | ModExpr (lhs, rhs) ->
        mk_mod (vcexpr_of_iabsyn0 lhs, vcexpr_of_iabsyn0 rhs)
    | BitAndExpr (lhs, rhs)
    | BitOrExpr (lhs, rhs)
    | BitXorExpr (lhs, rhs)
    | ShiftLeftExpr (lhs, rhs)
    | SignedShiftRightExpr (lhs, rhs)
    | UnsignedShiftRightExpr (lhs, rhs) ->
        failwith "arith not yet in vc"
    | AndExpr (lhs, rhs) ->
        mk_and [vcexpr_of_iabsyn0 lhs;
                vcexpr_of_iabsyn0 rhs]
    | OrExpr (lhs, rhs) ->
        mk_or [vcexpr_of_iabsyn0 lhs;
               vcexpr_of_iabsyn0 rhs]
    | NotExpr e ->
        mk_not (vcexpr_of_iabsyn0 e)
    | EqExpr (lhs, rhs) ->
        mk_eq (vcexpr_of_iabsyn0 lhs,
               vcexpr_of_iabsyn0 rhs)
    | NeqExpr (lhs, rhs) ->
        mk_not (mk_eq (vcexpr_of_iabsyn0 lhs,
                       vcexpr_of_iabsyn0 rhs))
    | LtExpr (lhs, rhs) ->
        mk_lt (vcexpr_of_iabsyn0 lhs,
               vcexpr_of_iabsyn0 rhs)
    | GtExpr (lhs, rhs) ->
        mk_gt (vcexpr_of_iabsyn0 lhs,
               vcexpr_of_iabsyn0 rhs)
    | LteqExpr (lhs, rhs) ->
        mk_lteq (vcexpr_of_iabsyn0 lhs,
                 vcexpr_of_iabsyn0 rhs)
    | GteqExpr (lhs, rhs) ->
        mk_gteq (vcexpr_of_iabsyn0 lhs,
                 vcexpr_of_iabsyn0 rhs)
  in
  vcexpr_of_iabsyn0 e

let vctype_of t = TypeUniverse

let rec vcexpr_of_sabsyn_form f =
  let rec vcexpr_of_sabsyn_setexp se =
    match se with
    | Sabsyn.Prevar s -> Var (mk_set_var s)
    | Sabsyn.Postvar s -> Var (mk_set_var s ^ "'")
    | Sabsyn.Emptyset -> Const EmptysetConst
    | Sabsyn.Union us -> App (Const Cup, List.map vcexpr_of_sabsyn_setexp us)
    | Sabsyn.Inter is -> App (Const Cap, List.map vcexpr_of_sabsyn_setexp is)
    | Sabsyn.Diff (t, u) -> App (Const Diff, [vcexpr_of_sabsyn_setexp t;
                                       vcexpr_of_sabsyn_setexp u]) in
  let rec vcexpr_of_sabsyn_atom af =
    match af with
    | Sabsyn.Eq (s, t) -> mk_eq (vcexpr_of_sabsyn_setexp s,
                          vcexpr_of_sabsyn_setexp t)
    | Sabsyn.Neq (s, t) -> mk_not (mk_eq (vcexpr_of_sabsyn_setexp s,
                                   vcexpr_of_sabsyn_setexp t))
    | Sabsyn.Sub (s, t) -> mk_sub (vcexpr_of_sabsyn_setexp s,
                            vcexpr_of_sabsyn_setexp t)
    | Sabsyn.True -> Const (BoolConst true)
    | Sabsyn.False -> Const (BoolConst false)
    | Sabsyn.Cardeq (s, i) -> App (Const Cardeq, [vcexpr_of_sabsyn_setexp s;
                                                  Const (IntConst i)])
    | Sabsyn.Cardleq (s, i) -> App (Const Cardleq, [vcexpr_of_sabsyn_setexp s;
                                                    Const (IntConst i)])
    | Sabsyn.Cardgeq (s, i) -> App (Const Cardgeq, [vcexpr_of_sabsyn_setexp s;
                                                    Const (IntConst i)])
    | Sabsyn.Disjoint dl -> App (Const Disjoint, 
                          List.map vcexpr_of_sabsyn_setexp dl)
    | Sabsyn.Propvar pi -> Var (mk_prop_var pi)
    | Sabsyn.Propvarpost pi -> Var (mk_prop_var pi ^ "'") in
  match f with
  | Sabsyn.Atom af -> vcexpr_of_sabsyn_atom af
  | Sabsyn.Not f' -> mk_not (vcexpr_of_sabsyn_form f')
  | Sabsyn.And fl -> mk_and (List.map vcexpr_of_sabsyn_form fl)
  | Sabsyn.Or fl -> mk_or (List.map vcexpr_of_sabsyn_form fl)
  | Sabsyn.Impl (r, s) -> mk_impl (vcexpr_of_sabsyn_form r,
                            vcexpr_of_sabsyn_form s)
  | Sabsyn.Iff (r, s) -> mk_iff (vcexpr_of_sabsyn_form r,
                            vcexpr_of_sabsyn_form s)
  | Sabsyn.ExistsOne (v, f) -> failwith "vctrans deprec"
  | Sabsyn.ForallOne (v, f) -> failwith "vctrans deprec"
  | Sabsyn.ExistsSet (v, f) -> Binder (Exists, [fst v, TypeObjRef (snd v)], 
                                vcexpr_of_sabsyn_form f)
  | Sabsyn.ForallSet (v, f) -> Binder (Forall, [fst v, TypeObjRef (snd v)], 
                                vcexpr_of_sabsyn_form f)

let vc_type (t:Types.value_type) : Vcform.typeExpr = TypeUniverse (* fix later *)

