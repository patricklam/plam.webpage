// Set.java
//
// Author: Raja Vallee-Rai
//
// This file is public domain.  You can do anything you want with 
// it, all at your own risk.  Enjoy!

package kor.base;


/** 
 * A set is just a collection of objects with the obvious methods defined below.
 */ 

public 
abstract class Set
{
    abstract
    public void add(Object o);

    abstract
    public void remove(Object o);

    abstract
    public boolean contains(Object o);

    abstract
    public boolean isEmpty();

    abstract
    public DynamicList list();
}
