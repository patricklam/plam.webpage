(* Main analyzer module *)

(* Analyze abst module
   using the corresponding impl module
   and spec modules. *)

let analysis_targets = ref ""

(* use this only when analyzing ms' interior, not when analyzing its callers *)
let distribute_scope_invariants (ms:Sabsyn.spec_module) =
  { 
    Sabsyn.module_name       = ms.Sabsyn.module_name;
    Sabsyn.instantiated_from = ms.Sabsyn.instantiated_from;
    Sabsyn.param_subst       = ms.Sabsyn.param_subst;
    Sabsyn.properties        = ms.Sabsyn.properties;
    Sabsyn.formats           = ms.Sabsyn.formats;
    Sabsyn.specvars          = ms.Sabsyn.specvars;
    Sabsyn.invariants        = ms.Sabsyn.invariants;
    Sabsyn.defaults          = ms.Sabsyn.defaults;
    Sabsyn.procs             = List.map 
      (Scopes.invariantize ms) ms.Sabsyn.procs;
  }

let preprocess_modules () =
  Ast.spec := List.map (fun ms -> 
    let all_sb = 
      { Spec.s = Spec.collect_all_sets ms;
        Spec.b = Spec.collect_all_bools ms
      } in
    Strans.expand_modifies_clauses 
      all_sb 
      (Spec.collect_all_defaults ms) 
      ms) !Ast.spec

let analyze_module_by_name (mod_name : string) (pn:string list) : bool = 
  let compute_scope_reentrancy_plus_modifies_augmentation 
      (ms:Sabsyn.spec_module)
      (callee_id:Id.proc_t) (r0:Sabsyn.form) (post:bool) : Sabsyn.form =
    let callee_module = Ast.fetch_spec (Id.module_of_proc callee_id) in
    let callee = Ast.fetch_spec_proc (Id.name_of_proc callee_id) 
      callee_module in
    let shielded_sb = Scopes.compute_hidden_sets ms callee in
      (* tacks on invariants when crossing an exported scope boundary: *)
    let scope_invariant_if_visible c : Sabsyn.form list =
      match c.Sabsyn.invariant with
        | None -> []
        | Some (x, v) ->
            if v = Sabsyn.Public || (List.exists 
                  (Spec.is_proc_transitive_caller_of callee) 
                  c.Sabsyn.modules) then
              [if post then Sabsyn.prime_form x [] else x]
            else
              [] in
    let out_of_scope_preserves (c:Sabsyn.scope) : Sabsyn.form = 
      if (List.exists 
            (Spec.is_proc_transitive_caller_of callee) c.Sabsyn.modules) then
        Sabsyn.Atom Sabsyn.True 
      else 
        let yard = List.map Ast.fetch_spec
            (Util.difference c.Sabsyn.modules c.Sabsyn.exports) in
        let m = List.concat 
            (List.map Sabsyn.extract_qualified_set_specvars_from_module yard) in
        let p = List.concat
            (List.map Sabsyn.extract_qualified_boolean_specvars_from_module yard) in
        Sabsyn.And 
          ((List.map (fun x ->
            Sabsyn.Iff (Sabsyn.Atom (Sabsyn.Propvar x),
                        Sabsyn.Atom (Sabsyn.Propvarpost x))) p) @
           (List.map (fun x -> 
             Sabsyn.Atom (Sabsyn.Eq 
                            ((Sabsyn.Prevar x), (Sabsyn.Postvar x)))) m)) in
    let hide_sets_and_bools f =
      let s = shielded_sb @
        List.map (fun (x, y) -> (x ^ "'", y)) shielded_sb in
      List.fold_left
        (fun x (y,t) -> match t with
        | Types.TBool -> Sabsyn.ExistsProp (y, x)
        | Types.TSet t0 -> Sabsyn.ExistsSet ((y, t0), x)
        | _ -> failwith "bad specvar type") f s in
    let new_scopes = 
      Scopes.scopes_of (Id.module_of_proc callee.Sabsyn.proc_name) in
    let current_scopes = Scopes.scopes_of ms.Sabsyn.module_name in
    let scopes_lost = Util.difference current_scopes new_scopes in
    hide_sets_and_bools 
      (Sabsyn.And (r0 :: 
                   List.map out_of_scope_preserves scopes_lost @
                   List.concat 
                     (List.map scope_invariant_if_visible scopes_lost))) in
  let ma0 = Ast.fetch_abst mod_name in
  let ms0 = Ast.fetch_spec mod_name in
  let mi0 = Ast.fetch_impl mod_name in
  let (rsM, rsS) = Itrans.collect_reentrant_sites mi0 in
  let ms1 = distribute_scope_invariants ms0 in
  let results = List.map (fun ma ->
    let ms = ms1 and mi = mi0 in begin
      let proc_names_from_spec = List.map 
          (fun mm -> 
            Id.qualified_name_of_proc mm.Sabsyn.proc_name) 
          ms.Sabsyn.procs in
      let pn' = 
        (if pn = [] then proc_names_from_spec else (List.map (Util.qualify_if_needed mod_name) pn)) in
      let procs_to_analyze' = 
        (if ma.Aabsyn.procs_to_analyze = [] then proc_names_from_spec else
        ma.Aabsyn.procs_to_analyze) in
      let subpn = 
        List.map Util.unqualify 
          (Util.intersect pn' procs_to_analyze') in
      let result = 
        Printf.printf "Analyzing module %s [%s].\n" mod_name ma.Aabsyn.plugin;
        if subpn = [] then true
        else
          begin
            let analyze_module = Plugins.dispatch_plugin ma.Aabsyn.plugin in
            let result0 = analyze_module mod_name (ma,ms,mi) subpn rsM 
	        (compute_scope_reentrancy_plus_modifies_augmentation ms) in
            result0 & (Util.no_errors ())
          end in
      if not (Util.no_errors ()) then
        Util.print_errors ();
      Printf.printf "Done analyzing module %s, " mod_name;
      if result then print_string "module is valid.\n" 
      else print_string "module is invalid.\n";
      result
    end) ma0.Aabsyn.body in
  List.for_all (fun x -> x) results

let parse (source_names : string list) = 
  let format_names = ref [] in
  let spec_names = ref [] in
  let abst_names = ref [] in
  let scope_names = ref [] in
  List.iter (function n -> 
    (match (try Util.extension n with Not_found -> "") with 
      ".fl" -> format_names := n :: !format_names
    | ".sl" -> spec_names := n :: !spec_names
    | ".al" -> abst_names := n :: !abst_names
    | ".scope" -> scope_names := n :: !scope_names
    | _ -> failwith ("unrecognized file extension for file "^n))) source_names;
  Uglyast.spec_ast := snd (Uglyast.parse_spec_asts !spec_names);
  Uglyast.abst_ast := snd (Uglyast.parse_abst_asts !abst_names);
  Uglyast.impl_ast := Uglyast.parse_impl_asts !format_names;
  Uglyast.scope_ast := Uglyast.parse_scope_asts (!scope_names @ !spec_names);
  let spec_module_names = Uglyast.fetch_spec_module_names !Uglyast.spec_ast in
  let abst_module_names = Uglyast.fetch_abst_module_names !Uglyast.abst_ast in
  let impl_module_names = Uglyast.fetch_impl_module_names !Uglyast.impl_ast in
  let scope_names = Uglyast.fetch_scope_names !Uglyast.scope_ast in
  Ast.impl := List.map 
      (fun x -> Deuglifyimpl.convert (Uglyast.fetch_impl_module x)) 
      impl_module_names;
  Ast.spec := List.map 
      (fun x -> Deuglifyspec.convert (Uglyast.fetch_spec_module x)) 
      spec_module_names;
  Ast.abst := List.map 
      (fun x -> Deuglifyabst.convert (Uglyast.fetch_abst_module x)) 
      abst_module_names;
  Ast.scopes := List.map
      (fun x -> Deuglifyspec.convert_scope (Uglyast.fetch_scope x))
      scope_names;
  let r = Typechecker.declaration_checker false !Ast.impl in
  Ast.impl := Util.phase "Instantiating impl templates" 
      (List.map (Itrans.instantiate_templates false)) !Ast.impl;
  let instantiated_specs = 
    List.filter (fun x -> x.Sabsyn.instantiated_from != None) !Ast.spec in
  Ast.spec := Util.phase "Instantiating spec templates" 
      (List.map (Strans.instantiate_templates instantiated_specs)) !Ast.spec;
  Ast.scopes := Util.phase "Instantiating scope templates"
      (List.map (Strans.instantiate_scope_templates instantiated_specs)) 
      !Ast.scopes;
  Ast.abst := Util.phase "Instantiating abst templates" 
      (List.map Atrans.instantiate_templates) !Ast.abst;
  Ast.impl := Util.phase "Local-ref conversion " 
      List.map (Itrans.transform_local_to_ref_lvalues r) !Ast.impl;
  Util.phase "Typechecking impl" (Typechecker.verify !Ast.impl);
  Util.phase "Computing call graph" (Spec.compute_callgraphs ());
  Util.phase "Crosschecking impl & spec" 
    List.iter (fun x -> 
      if (not (Ast.has_impl x)) then
        Util.err "[spec-impl checker]" ("Couldn't find impl module "^x^".")
      else
        Specimplchecker.verify (Ast.fetch_spec x) (Ast.fetch_abst x)
          (Ast.fetch_impl x)) (Ast.all_abst_modules ());
  Util.phase "Checking declarations of sets" 
    Specchecker.declaration_checker !Ast.spec;
  Util.phase "Checking primes in requires"
    Specchecker.no_primes_in_requires !Ast.spec;
  Util.phase "Ensuring primes in return values"
    Specchecker.must_prime_retvals !Ast.spec;
  Ast.abst := Util.phase "Factoring out on-the-fly sets in abst module"
    (List.map Atrans.factor_out_base_sets) !Ast.abst;
  if not (Util.no_errors ()) then
    Util.print_errors ()

let parse_cmdline () : string list =
  let speclist = 
    [("-v", Arg.Set Util.verbose, 
      "Verbose; display verbose debugging messages.");
     ("-u", Arg.Clear BA.optimize_formulas,
      "Unoptimize: do not optimize BA formulas. (implies -l)");
     ("-l", Arg.Clear Typestate.decide_implications_quickly,
      "Legible: use f => g instead of not (f & not g).");
     ("-n", Arg.Set BA.no_mona,
      "No MONA: do not run MONA.");
     ("-a", Arg.Set Typestate.check_antecedents,
      "Antecedent checking: when checking f=>g, complain if !f");
     ("-i", Arg.Set Typestate.ignore_invariants,
      "Ignore invariants; infer them instead.");
     ("-t", Arg.Set_string analysis_targets,
      "<list of procs>  Specify a specific analysis target.");
     ("-d", Arg.Int Bohneutil.set_debug_level,
      "<int>  Set debug level for Bohne plugin; default is 1.");
     ("--max-cube-length", Arg.Int Abstraction.Abstr.set_max_cube_length,
      "<int>  Set maximal cube length for Bohne plugin; default is 2.")] in
  let source_names = ref [] in
  let usage_msg=("Usage:\n  "^Sys.argv.(0)^" [-v] [-u] [-n] [-a] [-t <list of procs>] <input filename>\n") in
  Arg.parse speclist (fun x -> source_names := x :: !source_names) usage_msg;
  if !BA.no_mona then print_string "WARNING!! Not running MONA to verify formulas!\n";
  if List.length !source_names = 0 then 
    begin 
      Arg.usage speclist usage_msg; 
      exit 1 
    end;
  Util.remove_dups !source_names

exception Unknown_module

let go () =
  let names = parse_cmdline () in
  parse names;
  preprocess_modules ();
  let analyzed_parents = ref [] in
  let analyze_abst_module (m, (pn:string list)) = 
    (* hey, you're in trouble if you instantiate abst, spec, impl with
     * different params.  But the proof shouldn't go through. *)
    let n = m.Aabsyn.module_name in
    match m.Aabsyn.instantiated_from with
    | None -> analyze_module_by_name n pn
    | Some n ->
        let chk = (n, m.Aabsyn.param_subst) in
        if List.mem chk !analyzed_parents then
          true
        else
          begin
            analyzed_parents := chk :: !analyzed_parents;
            analyze_module_by_name n pn
          end in
  let targs = if (!analysis_targets = "") then 
    Ast.all_abst_modules () 
  else 
    Util.split_by "," !analysis_targets in
  let analysis_results = 
    (List.map 
       (fun a -> 
         let try_fetch_abst mn = 
           try (Ast.fetch_abst mn) 
           with Not_found -> 
             Util.error ("Could not find module "^mn^"."); 
             raise Unknown_module in
         try
           let abst_modules = 
             (if (String.contains a '.') then
               let d = String.rindex a '.' in 
               (try_fetch_abst (String.sub a 0 d),
                [String.sub a (d+1) (String.length a - d - 1)])
             else 
               (try_fetch_abst a, [])) in
           analyze_abst_module abst_modules
         with Unknown_module -> false) targs) in
  let result = (List.fold_left (fun a b -> a & b) true analysis_results) in
  if result then
    (print_string "The program is VALID.\n"; 0)
  else
    (print_string "The program is INVALID.\n"; 1)
      
let _ = exit (go ())
