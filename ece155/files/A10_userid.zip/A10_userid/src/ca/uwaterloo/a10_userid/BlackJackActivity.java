package ca.uwaterloo.a10_userid;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class BlackJackActivity extends Activity {
	
	BlackJackClass game;
	TextView dealerCards;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_blackjack);
	
		dealerCards = (TextView)findViewById(R.id.dealerHand);
		
		// start the game
		game = new BlackJackClass();
		game.gameRunning = true;
		getCurrentCards();
		
		
		
		Button hit = (Button)findViewById(R.id.hitButton);
		hit.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				if (game.gameRunning) {
					game.getCard(game.player);
					getCurrentCards();
					// true if player wins, false if they lose
					if (game.player.value == 21)
						gameEnd(true);
					if (game.player.isBust())
						gameEnd(false);
				}
			}
		});
		
		Button stand = (Button)findViewById(R.id.standButton);
		stand.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				if (game.gameRunning) {
					game.dealerTurn(20);
					if (game.dealer.value == 21)
						gameEnd(false);
					else if (game.dealer.isBust())
						gameEnd(true);
					else
						gameEnd(game.isWinner());
				}
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_main, menu);
		return true;
	}
	
	public void gameEnd(final boolean playerWins) 
	{
		// stop the game so the other buttons don't fire
		game.gameRunning = false;
		
		dealerCards.setText(game.dealer.hand);
		
		TextView winnerTag = (TextView)findViewById(R.id.winner);
		
		if (playerWins)
			winnerTag.setText("Player Wins!");
		else
			winnerTag.setText("Dealer Wins!");
		
		winnerTag.setVisibility(0);
		
		Button nextHand = (Button)findViewById(R.id.nextHandButton);
		nextHand.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Intent previous = getIntent();
				Intent i = new Intent();
				// increment wins
				if (previous.hasExtra("dealerWins") && previous.hasExtra("playerWins")) {
					if (playerWins) {
						i.putExtra("dealerWins", previous.getIntExtra("dealerWins", 0));
						i.putExtra("playerWins", previous.getIntExtra("playerWins", 0) + 1);
					}
					else {
						i.putExtra("dealerWins", previous.getIntExtra("dealerWins", 0) + 1);
						i.putExtra("playerWins", previous.getIntExtra("playerWins", 0));
					}
				}
				else {
					if (playerWins) {
						i.putExtra("dealerWins", 0);
						i.putExtra("playerWins", 1);
					}
					else {
						i.putExtra("dealerWins", 1);
						i.putExtra("playerWins", 0);
					}
				}
				setResult(2, i);
				finish();
			}
		});
		
		Button quit = (Button)findViewById(R.id.quitButton);
		quit.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Intent previous = getIntent();
				Intent i = new Intent();
				if (previous.hasExtra("dealerWins") && previous.hasExtra("playerWins")) {
					if (playerWins) {
						i.putExtra("dealerWins", previous.getIntExtra("dealerWins", 0));
						i.putExtra("playerWins", previous.getIntExtra("playerWins", 0) + 1);
					}
					else {
						i.putExtra("dealerWins", previous.getIntExtra("dealerWins", 0) + 1);
						i.putExtra("playerWins", previous.getIntExtra("playerWins", 0));
					}
				}
				else {
					if (playerWins) {
						i.putExtra("dealerWins", 0);
						i.putExtra("playerWins", 1);
					}
					else {
						i.putExtra("dealerWins", 1);
						i.putExtra("playerWins", 0);
					}
				}
				setResult(1, i);
				finish();
			}
		});
		
		// need to see the buttons
		nextHand.setVisibility(0);
		quit.setVisibility(0);
	}
	
	public void getCurrentCards()
	{
		dealerCards.setText(game.dealer.getVisibleCards());
		
		TextView playerCards = (TextView)findViewById(R.id.playerHand);
		playerCards.setText(game.player.hand);
	}
	
}
