open Id
open Aabsyn

let instantiate_templates ast = 
  let actuals = List.map snd ast.param_subst in
  let a_no_dups = Util.remove_dups actuals in
  if a_no_dups <> actuals then Util.err "[module instantiation]" ("Duplicated type parameter in abst module "^ast.module_name);
  match ast.instantiated_from with
  | None -> ast
  | Some parent ->
      let pmod = Ast.fetch_abst parent in
      let sl = ast.param_subst in
      let subst_type t = 
        if List.mem_assoc t sl then
            List.assoc t sl else t in
      let subst_pair (x, y) = (x, subst_type y) in
      let rec subst_clause c = 
        match c with
        | LetClause (sd, c) -> LetClause (subst_defn sd, subst_clause c)
        | IffClause (l, r) -> IffClause (subst_clause l, subst_clause r)
        | OrClause (l, r) -> OrClause (subst_clause l, subst_clause r)
        | AndClause (l, r) -> AndClause (subst_clause l, subst_clause r)
        | NotClause n -> NotClause (subst_clause n)
        | FormulaClause f -> c
      and subst_defn_rhs rhs =
        match rhs with
        | BaseForm sd0 -> BaseForm
            {
             x = sd0.x;
             xt = subst_type sd0.xt;
             expr = subst_clause sd0.expr;
           }
        | IdForm id0 -> IdForm id0
        | UnionForm (l, r) -> UnionForm (subst_defn_rhs l, subst_defn_rhs r)
        | IntersectionForm (l, r) -> IntersectionForm (subst_defn_rhs l,
                                                       subst_defn_rhs r)
      and subst_defn (l, sd) =
        (l, subst_defn_rhs sd)
      and subst_set_defn_form f = f in (* no types to subst here! *)
      { 
        module_name = ast.module_name;
        instantiated_from = ast.instantiated_from;
        param_subst = ast.param_subst;
        body = List.map (fun pb -> {
          plugin = pb.plugin;
          invariants = List.map subst_clause pb.invariants;
          set_defns = List.map subst_defn pb.set_defns;
          pred_vars = pb.pred_vars;
          procs_to_analyze = pb.procs_to_analyze;
          formats = 
            (let sl = List.map 
               (fun (x,y) -> (Types.value_type_of_string x,
                              Types.value_type_of_string y)) ast.param_subst in
            let subst_type_fmts (t1:Types.value_type) : Types.value_type = 
              if List.mem_assoc t1 sl then
                List.assoc t1 sl else t1 in
            List.map (fun y -> 
              { Iabsyn.format_name = y.Iabsyn.format_name;
                Iabsyn.fields = (List.map 
                                   (fun (a,b) -> 
                                     (a, 
                                      subst_type_fmts b))
                                   y.Iabsyn.fields)}) pb.formats);
          set_defining_procs = List.map (fun x -> { proc_name = x.proc_name;
                                       proc_set_defns = List.map subst_defn 
                                         x.proc_set_defns; }) 
            pb.set_defining_procs})
          
          pmod.body;
      }

let factor_out_base_sets ast =
  let extra_defns = ref [] in
  let rec factor_clause c = 
    match c with
    | LetClause (sd, c) -> LetClause (factor_defn sd, factor_clause c)
    | IffClause (l, r) -> IffClause (factor_clause l, factor_clause r)
    | OrClause (l, r) -> OrClause (factor_clause l, factor_clause r)
    | AndClause (l, r) -> AndClause (factor_clause l, factor_clause r)
    | NotClause n -> NotClause (factor_clause n)
    | FormulaClause f -> c
  and factor_defn_rhs (n,c) rhs =
    match rhs with
    | BaseForm sd0 -> 
        let n' = n^"_"^(string_of_int !c) in
        c := !c + 1;
        extra_defns := (n', BaseForm
            {
             x = sd0.x;
             xt = sd0.xt;
             expr = factor_clause sd0.expr;
           }) :: !extra_defns;
        IdForm n'
    | IdForm id0 -> IdForm id0
    | UnionForm (l, r) -> UnionForm (factor_defn_rhs (n,c) l, 
                                     factor_defn_rhs (n,c) r)
    | IntersectionForm (l, r) -> IntersectionForm (factor_defn_rhs (n,c) l,
                                                   factor_defn_rhs (n,c) r)
  and factor_defn (l, sd) =
    match sd with 
    | BaseForm sd0 -> (l, sd)
    | _ -> (l, factor_defn_rhs (l, ref 1) sd) in
  { 
    module_name = ast.module_name;
    instantiated_from = ast.instantiated_from;
    param_subst = ast.param_subst;
    body = List.map (fun b -> {
      plugin = b.plugin;
      invariants = List.map factor_clause b.invariants;
      set_defns = (let sd' = List.map factor_defn b.set_defns in
                             sd' @ !extra_defns);
      pred_vars = b.pred_vars;
      procs_to_analyze = b.procs_to_analyze;
      formats = b.formats;
      set_defining_procs = List.map (fun x -> { proc_name = x.proc_name;
                                   proc_set_defns = List.map factor_defn
                                     x.proc_set_defns; })
        b.set_defining_procs}) ast.body
  }
