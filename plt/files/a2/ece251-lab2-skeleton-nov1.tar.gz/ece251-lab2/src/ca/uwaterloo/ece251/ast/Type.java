package ca.uwaterloo.ece251.ast;

public enum Type {
    NULL, INTEGER, REAL, TEXT, BLOB, UNKNOWN;
}
