package ca.uwaterloo.ece251.ast;

import java.util.List;

/** Binary operations. */
public class BinopExp extends Exp {
    public enum Binop {
	EQ("=="), NEQ("!="), LT("<"), GT(">"), LE("<="), GE(">="),
	OR("||"), AND("&&"), 
	TIMES("*"), DIV("/"), MOD("%"),
	TUPLE_FROM("<<"), TUPLE_PLUS("\\+"), TUPLE_MINUS("\\-"),
	PLUS("+"), MINUS("-");

	private final String t;
	Binop(String t) { this.t = t; }
	public String toString() { return t; }
    };

    Binop op;
    Exp left, right;

    public BinopExp(Binop op, Exp left, Exp right) {
	this.op = op; this.left = left; this.right = right;
    }

    public String toString() {
	return left.toString() + op.toString() + right.toString();
    }
}
