// VectorStack.java
//
// Author: Raja Vallee-Rai
//
// This file is public domain.  You can do anything you want with 
// it, all at your own risk.  Enjoy!


package kor.base;

import java.util.*;

/**
 * An implementation of the kor.base.Stack class.
 */
 
public 
class VectorStack extends kor.base.Stack
{
    Vector vector;
    
    public VectorStack()
    {
        vector = new Vector();
    }
    
    public boolean isEmpty()
    {
        return vector.isEmpty();
    }
    
    public void push(Object obj)
    {
        vector.addElement(obj);
    }
    
    /**
     * Returns the top of the stack, and removes it from the stack.
     *
     * @exception RuntimeException  if the stack has no elements
     */
     
    public Object pop() throws RuntimeException
    {
        if(isEmpty())
            throw new RuntimeException("Stack is Empty");
            
        Object toReturn = vector.elementAt(vector.size() - 1);
        
        vector.removeElementAt(vector.size() - 1);
        
        return toReturn;
    }
    
    /**
     * Returns the top of the stack, but does not remove it.
     */
     
    public Object top() throws RuntimeException
    {
        if(isEmpty())
            throw new RuntimeException("Stack is Empty");
            
        return vector.elementAt(vector.size() - 1);
    }   
}
