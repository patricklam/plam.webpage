package ca.uwaterloo.ece251;

import java.util.regex.*;

/** Tokens after lexical analysis. Your first task is to convert
 * <code>LexerToken</code> instances into <code>Token</code> instances. */
public class Token {
    /** Store the raw data. */
    LexerToken rawToken;
    Type t;

    enum Type {
	EXPLAIN(<BLANK>), QUERY(<BLANK>), PLAN(<BLANK>),
	CREATE("CREATE"), TEMP(<BLANK>), TEMPORARY(<BLANK>), 
	TABLE(<BLANK>),
	IF(<BLANK>), NOT(<BLANK>), EXISTS(<BLANK>v),
	AS(<BLANK>), IS(<BLANK>),
	NULL(<BLANK>), INTEGER(<BLANK>), REAL(<BLANK>), TEXT(<BLANK>), 
	BLOB(<BLANK>),
	DROP(<BLANK>), 
	INSERT(<BLANK>), REPLACE(<BLANK>), INTO(<BLANK>),
	VALUES(<BLANK>), DEFAULT(<BLANK>),
	LIMIT(<BLANK>),
	SELECT(<BLANK>), DISTINCT(<BLANK>), ALL(<BLANK>),
	INNER(<BLANK>), LEFT(<BLANK>), JOIN(<BLANK>), ON(<BLANK>),
	FROM(<BLANK>), WHERE(<BLANK>),
	UNION(<BLANK>), INTERSECT(<BLANK>), EXCEPT(<BLANK>),
	UPDATE(<BLANK>), SET(<BLANK>), 
	VACUUM(<BLANK>),
	ISNULL(<BLANK>), NOTNULL(<BLANK>),
	AND(<BLANK>), OR(<BLANK>),
	SEMICOLON(<BLANK>),
 	LPAREN(<BLANK>), COMMA(<BLANK>), RPAREN(<BLANK>), DOT(<BLANK>),
	STAR(<BLANK>), EQUALS(<BLANK>), 
	PLUS(<BLANK>), MINUS(<BLANK>), SLASH(<BLANK>), PERCENT(<BLANK>),
        LE(<BLANK>), LT(<BLANK>), GE(<BLANK>), GT(<BLANK>), NE(<BLANK>),
	NLT(<BLANK>), NGT(<BLANK>),
	ID(<BLANK>),
	NUMERIC_LITERAL(<BLANK>), 
	BOOLEAN_LITERAL(<BLANK>), 
	STRING_LITERAL(<BLANK>);

	private final String text; 
	private final Pattern p;
	Type(String text) { 
	    this.text = text; 
	    this.p = Pattern.compile(text, Pattern.CASE_INSENSITIVE);
	}
	public boolean matches(String s) { 
	    return p.matcher(s).matches(); 
	}
    };

    public Token(LexerToken rawToken) {
	this.rawToken = rawToken;
	String u = rawToken.s.toUpperCase();
	for (Token.Type tt : Token.Type.values())
	    if (tt.matches(u)) {
		this.t = tt;
		break;
	    }
    }

    /** Returns the token text associated with this token. */
    public String getText() {
	return this.rawToken.s;
    }

    /** Returns a textual representation of the token. */
    public String toString() {
	String ts = t == null ? "null" : t.toString();
	return "["+ts+": ('"+rawToken.s+"'), line "+rawToken.ln+", col "+rawToken.colstart+"-"+rawToken.colend+"]";
    }
}
