SELECT Em.EmployeeID, Em.FirstName, Em.LastName, Em.HireDate, Em.City FROM Em As st WHERE Em.HireDate >= '1-july-1993'
;
