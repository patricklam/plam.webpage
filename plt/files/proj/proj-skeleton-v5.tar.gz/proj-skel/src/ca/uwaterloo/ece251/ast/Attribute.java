package ca.uwaterloo.ece251.ast;

/** Represents either a key-only attribute or a key/value attribute. */
abstract public class Attribute {
}
