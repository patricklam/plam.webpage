package ca.uwaterloo.ece251.ast;

public abstract class Expr extends ASTNode {
}
