// Simulation.java
//
// Author: Raja Vallee-Rai
//
// This file is public domain.  You can do anything you want with 
// it, all at your own risk.  Enjoy!

import java.util.*;
import kor.base.*;

/**
 * A simulation object gets created everytime a simulation is started.  It is a low
 * priority thread which runs in the background and generates frames (particle positions).
 * 
 * <p> Run in parallel is a SystemFrameConsumer which consumes these frames and produces
 * actual changes in the Playfield.
 */
 
class Simulation implements Runnable
{
    static int simulationCount = 0;

    int simulationID;
    int maxBufferedFrames;
    
    Vector particles;
    Playfield playfield;
    Thread runningSimulation;
    SystemFrameConsumer frameConsumer;
    
    VectorQueue readyFrames = new VectorQueue();

    public Simulation(Playfield p)
    {
        this.playfield = p;
        this.particles = p.particles;

        simulationID = ++simulationCount;
        
        maxBufferedFrames = playfield.controls.simulationCacheSize * 
            playfield.controls.stepGranularity;

        playfield.lastStepSize = 0;
        playfield.careAboutSingularities = playfield.controls.
            simulationSingularityWarningBox.getState();
        playfield.warnedAboutSingularity = false;
        
        prepareWorkingVariables();
        
        runningSimulation = new Thread(this);
        
        runningSimulation.setPriority(Thread.MIN_PRIORITY);
        
        frameConsumer = new SystemFrameConsumer(this, playfield.viewer);
        
        runningSimulation.start();
        
        
    }
    
    private void prepareWorkingVariables()
    {
        synchronized(playfield)
        {            
            for(int i = 0; i < particles.size(); i++)
            {
                Particle p = (Particle) particles.elementAt(i);
            
                p.workPosX = p.posX;
                p.workPosY = p.posY;
                
                p.workVelX = p.velX;
                p.workVelY = p.velY;
            }
        }  
    }
    
    public void run()
    {
        for(;;)
        {    
            while(readyFrames.size() == maxBufferedFrames)
                waitUntilNotified();

            computeAndStoreNextFrame();
        }
    }
    
    synchronized
    public void waitUntilNotified()
    {
        try {
            wait();
        } catch(InterruptedException e){}
    }
    
    synchronized
    public void notifyOfDequeue()
    {
        notify();
    }
    
    public void stop()
    {
        runningSimulation.stop();

        synchronized(playfield)
        {
            // wait for the application of a frame to be completed before killing the
            // thread

            frameConsumer.runningConsumer.stop();
        }
    }
    
    void computeAndStoreNextFrame()
    {   
        Debug.assert(simulationID == simulationCount);
        
        playfield.calculateNextTimeStep();

        ParticleFrame[] frames = new ParticleFrame[particles.size()];
            
        for(int i = 0; i < particles.size(); i++)
        {
            Particle p = (Particle) particles.elementAt(i);
                
            frames[i] = new ParticleFrame(p);
        }
            
        readyFrames.insert(frames);
    }
}







