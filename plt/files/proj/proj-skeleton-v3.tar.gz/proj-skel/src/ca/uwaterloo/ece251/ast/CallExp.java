package ca.uwaterloo.ece251.ast;

import java.util.List;

/** Function call. */
public class CallExp extends Exp {
    Id fname;
    List<Exp> args;

    public CallExp(Id fname, List<Exp> args) {
	this.fname = fname; this.args = args;
    }

    public String toString() {
	return fname.toString()+"("+
	    (args == null ? "" : Util.commaSeparated(args))
	    +")";
    }
}
