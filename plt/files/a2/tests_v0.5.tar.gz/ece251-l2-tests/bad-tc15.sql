SELECT supplier_id AS test FROM suppliers WHERE supplier_name = 'IBM';
