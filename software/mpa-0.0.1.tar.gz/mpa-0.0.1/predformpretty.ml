(* Pretty-printer for predicate calculus formulas *)
open Predform

(* Precedence:

150:   
   less then let-defined expression
170: function application 
   (for relational and term expressions)
200:
   not, ~,
   binders including let
300:          
   &, and, *, inter
400:
   |, or, +, union
500:
   =, <=, subset, =>, <=>, >=, elem
600:
   ",", set comprehension

*)

let (minp:int) = 0
let (maxp:int) = 999

let paren prec contextPrec s =
  if prec < contextPrec then s 
  else "("^s^")"

let parenEq prec contextPrec s =
  if prec <= contextPrec then s 
  else "("^s^")"

let spifnotcomma op = if op="," then op else " " ^ op

let pBinOp 
    (s1:string)
    (op:string)
    (s2:string)
    (prec:int)  (* greater means binds tigher *)
    (contextPrec:int) = 
  paren prec contextPrec (s1 ^ (spifnotcomma op) ^ " " ^ s2)

let pBinOpEq s1 op s2 prec contextPrec =
  parenEq prec contextPrec (s1 ^ (spifnotcomma op) ^ " " ^ s2)

let pIdent (id:string) = id
let pInt k = Printf.sprintf "%d" k

let rec pRegexp r cp = match r with
| Funsym f -> pIdent f
| Alt rs -> pRegexpList rs "|" 400 cp
| Seq rs -> pRegexpList rs "." 300 cp
| Star r -> pRegexp r 300
and 
    pRegexpList rs op p cp = 
  let rec pr rs = (match rs with    
  | [] -> ""
  | [r] -> pRegexp r cp
  | r::rs1 -> pBinOpEq (pRegexp r p) op (pr rs1) p p)
  in paren p cp (pr rs)

let rec 
    pTerm t p = match t with
    | Var v -> pIdent v
    | Const c -> pIdent c
    | Fun (k,fid,ts) -> pIdent fid ^ "(" ^ pTermList ts "," 600 maxp ^ ")"
and 
    pTermList ts op p cp = 
  let rec pr ts = match ts with
  | [] -> ""
  | [t] -> pTerm t p
  | t::ts1 -> pBinOpEq (pTerm t p) op (pr ts1) p p
  in paren p cp (pr ts)
and
    pSetTermList sts op p cp = 
  let rec pr sts = match sts with
  | [] -> ""
  | [st] -> pSetTerm st p
  | st::sts1 -> pBinOpEq (pSetTerm st p) op (pr sts1) p p
  in parenEq p cp (pr sts)
and
    pSetTerm st cp = match st with
    | Constset ts -> "{" ^ pTermList ts "," cp 600 ^ "}"
    | Setvar s -> pIdent s
    | Union sts -> pSetTermList sts "+" 400 cp
    | Inter sts -> pSetTermList sts "*" 300 cp
    | Diff (st1,st2) -> 
        pBinOp (pSetTerm st1 400) "-" (pSetTerm st2 400) 400 cp

    (* cp is context (surrounding expression) precedence *)
let rec 
    pForm f cp = match f with
    | True -> "true"
    | False -> "false"
    | Propvar id -> pIdent id
    | Eq (t1,t2) -> 
        pBinOp (pTerm t1 500) "=" (pTerm t2 500) 500 cp
    | Eqset (st1,st2) ->
        pBinOp (pSetTerm st1 500) "=" (pSetTerm st2 500) 500 cp
    | Subset (st1,st2) ->
        pBinOp (pSetTerm st1 500) "subset" (pSetTerm st2 500) 500 cp
    | Elem (t,st) ->
        pBinOp (pTerm t 500) "elem" (pSetTerm st 500) 500 cp
    | Cardeq (st,k) ->
        "card(" ^ pSetTerm st minp ^ ")=" ^ pInt k
    | Cardgeq (st,k) ->
        "card(" ^ pSetTerm st minp ^ ")>=" ^ pInt k
    | Cardleq (st,k) ->
        "card(" ^ pSetTerm st minp ^ ")<=" ^ pInt k
    | Disjoint sts ->
        "disjoint(" ^ pSetTermList sts "," 600 cp ^ ")"
    | Isempty st ->
        "isempty(" ^ pSetTerm st minp ^ ")"
    | Rel (k,r,ts) ->
        pIdent r ^ "(" ^ pTermList ts "," 600 maxp ^ ")"
    | Not f -> "~" ^ pForm f 200
    | And fs -> pFormList fs "&" 300 cp
    | Or fs -> pFormList fs "|" 400 cp
    | Impl (f1,f2) -> pBinOp (pForm f1 500) "=>" (pForm f2 500) 500 cp
    | Iff (f1,f2) -> pBinOp (pForm f1 500) "<=>" (pForm f2 500) 500 cp
    | Existsprop (p,f) -> "existsbool " ^ pIdent p ^ ". " ^ pForm f 200
    | Forallprop (p,f) -> "forallbool " ^ pIdent p ^ ". " ^ pForm f 200
    | Letprop (p,fdef,fbody) -> 
        "letbool " ^ pIdent p ^ "= " ^ pForm fdef 150 ^ " in " ^ pForm fbody 200
    | Exists (v,f) -> "exists " ^ pIdent v ^ ". " ^ pForm f 200
    | Existsone (v,f) -> "exists1 " ^ pIdent v ^ ". " ^ pForm f 200
    | Existseq (k,v,f) -> "exists exactly " ^ pInt k ^ " " ^ pIdent v ^ ". " ^ pForm f 200
    | Existsleq (k,v,f) -> "exists atmost " ^ pInt k ^ " " ^ pIdent v ^ ". " ^ pForm f 200
    | Existsgeq (k,v,f) -> "exists atleast " ^ pInt k ^ " " ^ pIdent v ^ ". " ^ pForm f 200
    | Forall (v,f) -> "forall " ^ pIdent v ^ ". " ^ pForm f 200
    | Let (v,t,fbody) -> 
        "let " ^ pIdent v ^ "= " ^ pTerm t 150 ^ " in " ^ pForm fbody 200
    | Existsset (s,f) -> "existsset " ^ pIdent s ^ ". " ^ pForm f 200
    | Forallset (s,f) -> "forallset " ^ pIdent s ^ ". " ^ pForm f 200
    | Letset (s,st,fbody) -> 
        "letset " ^ pIdent s ^ "= " ^ pSetTerm st 150 ^ " in " ^ pForm fbody 200
    | Letsetcompr c -> pSetCompr c cp
    | Letsetregexp r -> pSetRegexp r cp
and 
    pSetCompr c cp =
  "letsetc " ^ pIdent c.comprSet ^ "= {" ^ pIdent c.comprElem ^ ". " ^ 
  pForm c.comprDef 550 ^ "} in " ^ pForm c.comprBody 600
and
    pSetRegexp r cp =
  "letsetr " ^ pIdent r.defSet ^ "= " ^ 
  pSetTerm r.startSet cp ^ "." ^ pRegexp r.letRegexp cp 
  ^ "in " ^ pForm r.regexpBody 600
and
    pFormList fs op p cp = 
  let rec pr fs = match fs with    
  | [] -> ""
  | [f] -> pForm f p
  | f::fs1 -> pBinOpEq (pForm f p) op (pr fs1) p cp
  in paren p cp (pr fs)

let pform f = pForm f minp
let pterm f = pTerm f minp 
let psetterm f = pSetTerm f minp

(* let f1 =  *)
(*   Letsetcompr { comprSet = "S"; *)
(*                 comprElem = "y"; *)
(*                 comprDef = Forall ("x",Not (Eq (Var "x", Fun (2,"f",[Var "x"; Var "y"])))); *)
(*                 comprBody = Not (Eqset (Inter [Setvar "Q"; Union  *)
(*                                                  [Inter [Setvar "S"; Setvar "Q"]; Setvar "T"; Setvar "R"]], Constset [])) *)
(*               } *)

(* let _ = print_string (pform f1 ^ "\n") *)
