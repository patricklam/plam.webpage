/**
 * Noumbissi Noundou, Xavier 
 * ECE453/CS447/CS465
 * Winter 2010
 *
 * JUnit tutorial
 *
 * @copyright: You can modified and reuse this file
 */

class Sample {

    public int addition(int x, int y) {
        return (x+y);
    }

    public int substraction(int x, int y) {
        return (x-y);
    }
    
    public void printAddition(int x, int y){
        System.out.println( addition(x,y) );
    }

    public int divideByZero() {
        return (3 / 0);
    }

    public int anotherException(int i) throws MyException{
        if (0 == i)
            throw new MyException("from anotherException");
        return -3;
    }
}

class MyException extends Exception {
    public MyException(String msg) {
        super(msg);
    }
}


