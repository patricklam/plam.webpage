open Iabsyn
open Types
open Envutils

let format_defs : (Id.format_t,
     (Id.module_t, (Id.field_t, value_type) Hashtbl.t) Hashtbl.t) Hashtbl.t ref = ref (Hashtbl.create 0)

let stack_trace : string list ref = ref []
let push_stack_trace procName =
  stack_trace := procName :: !stack_trace
let pop_stack_trace procName = 
  if (List.hd !stack_trace != procName) then failwith "bad procedure call nesting!"
  else stack_trace := List.tl !stack_trace
let dump_stack_trace () = print_string ("Stack trace:\n" ^ String.concat " " !stack_trace ^ "\n")
let run_time_error msg = dump_stack_trace(); failwith ("Run-time error: "^msg^"\n")

let error_expr e s = 
  let (fn, p) = Ast.lookup_expr_pos e in
  Util.err (fn ^ " " ^ p) s

exception Type_error of string

exception Eval_return of value option

let stuff_args_in_env 
    (env:environment) (proc_ast:'a proc_def) 
    (actuals:value list) : environment =
  let formals = proc_ast.formals in
  (List.map2 (fun f a ->
    (Id.fetch_var (fst f), a)) formals actuals) @ env

let rec clone_arrays v =
  match v with
  | Array a -> Array (Array.map clone_arrays a)
  | _ -> v
      
(* changes the environment as in the given expression, 
   returning the updated environment. *)
let rec leval (env_list:environment list) 
    (exp:lvalue) (v:value) : environment list = 
  (match exp with
  | LocalLvalue l -> mutate_value env_list (Id.fetch_var l) v
  | RefLvalue lv -> 
      let m = Envutils.get_current_module env_list in
      Intrheap.put_module_environment m (List.hd (mutate_value 
        [Intrheap.fetch_module_environment m] (Id.fetch_var lv) v));
      env_list
  | FieldLvalue (base, f) ->
      (* field_name is an identifier, base might be computed *)
      (try 
        let (field_base, env_list') = eval_expr env_list base in
        Intrheap.set_field field_base f v;
        env_list'
      with Not_found -> 
        error_expr base "trying to assign to a field of null"; 
        Util.print_errors (); flush stdout;
        run_time_error "")
  | ArrayLvalue (base, i) ->
      let (ind, env_list0) = eval_expr env_list i in
      let (array_base, env_list') = eval_expr env_list0 base in
      (match (array_base, ind) with
      | (Array b, Int i) -> (b.(i) <- v); env_list'
      | _ -> run_time_error "base not array, or array index not int"))
and eval_expr (env_list : environment list) (exp : expr) : 
    (value * environment list) =
  match exp with
  | LiteralExpr v -> (v, env_list)
  | VarExpr lv -> (match lv with
    | LocalLvalue l -> (Envutils.retrieve_value env_list l, env_list)
    | RefLvalue v -> (Envutils.retrieve_value 
                        [Intrheap.fetch_module_environment
                           (Envutils.get_current_module env_list)] 
                        (Id.fetch_var v), env_list)
    | FieldLvalue (base, f) ->
        let (field_base, env_list') = eval_expr env_list base in
        (try 
          Intrheap.get_field field_base f, env_list'
        with Not_found -> 
          error_expr exp "dereferenced null"; 
          Util.print_errors (); flush stdout;
          run_time_error "")
    | ArrayLvalue (base, i) ->
        let (ind, env_list0) = eval_expr env_list i in
        let (array_base, env_list') = eval_expr env_list0 base in
        (match (array_base, ind) with
        | (Array b, Int i) when (i >= 0 && i < Array.length b) -> (b.(i), env_list')
        | (Array b, Int i) -> run_time_error ("index out of bounds, has value " ^ string_of_int i)
        | _ -> run_time_error "base not array, or array index not int"))
  | FieldAccessExpr (base, f) ->
        let (field_base, env_list') = eval_expr env_list base in
        (try Intrheap.get_field field_base f, env_list'
        with Not_found -> 
          error_expr exp "dereferenced null"; 
          Util.print_errors (); flush stdout;
          run_time_error "")
  | ArrayAccessExpr (base, i) ->
        let (ind, env_list0) = eval_expr env_list i in
        let (array_base, env_list') = eval_expr env_list0 base in
        (match (array_base, ind) with
        | (Array b, Int i) when (i >= 0 && i < Array.length b) -> (b.(i), env_list')
        | (Array b, Int i) -> run_time_error ("index out of bounds, has value " ^ string_of_int i)
        | _ -> run_time_error "base not array, or array index not int")
  | NewExpr t -> 
      let fo = Intrheap.fresh_obj () in
      let fields = List.map (function x -> Hashtbl.find (Hashtbl.find !format_defs (Id.fetch_format t)) x) (Ast.all_impl_modules ()) in 
      let field_adder fd ftype = Intrheap.set_field
          fo fd (Iabsyn.initial_value ftype) in
      List.iter (function x -> Hashtbl.iter field_adder x) fields;
      (fo, env_list)
  | NewArrayExpr (t, e, d) -> (* quack: use dims *)
      (match e with
      | [] -> (null_obj, env_list)
      | e'::[] -> let (s, env_list') = eval_expr env_list e' in
        (match s with
        | Int size -> (Array (Array.init size (fun _ -> initial_value t)), env_list')
        | _ -> run_time_error "non-int array size")
      | e'::es -> let (s, env_list') = eval_expr env_list e' in
        (match s with
        | Int size -> 
            (Array (Array.init size (fun _ -> 
              fst (eval_expr env_list (NewArrayExpr (t, es, d))))), 
             env_list')
        | _ -> run_time_error "non-int array size"))
  | InvokeExpr (targ, args0) ->
      let args1 = ref [] in
      let env_list' = List.fold_left  
          (fun env_list0 a -> 
            let (r, e) = eval_expr env_list0 a in
            let r' = clone_arrays r in
            args1 := r' :: !args1; e) 
          env_list args0 in
      let args = List.rev !args1 in
      push_stack_trace (Id.name_of_proc targ);
      (try (try Evalintrinsics.eval_intrinsic targ args with Evalintrinsics.Intrinsic_return v -> raise (Eval_return v));
        let targ_ast = Ast.fetch_impl_proc 
            (Id.name_of_proc targ) (Ast.fetch_impl (Id.module_of_proc targ)) in
        let targ_env = Intrheap.create_environment_for_proc 
            targ targ_ast in
        let callee_env = stuff_args_in_env targ_env targ_ast args in        
         (eval [callee_env] targ_ast.proc_body;
          pop_stack_trace (Id.name_of_proc targ); (null_obj, env_list'))
      with 
        Eval_return (Some rv) -> 
          pop_stack_trace (Id.name_of_proc targ); (rv, env_list')
      | Eval_return None -> 
          pop_stack_trace (Id.name_of_proc targ); (null_obj, env_list'))
  | AssignExpr (l, r) -> 
      let (r, env_list') = eval_expr env_list r in
      let r' = clone_arrays r in
      let l = leval env_list' l in
      (r', l r')
  | PostDecExpr e -> 
      let (v, env_list0) = eval_expr env_list (VarExpr e) in
      let (v', env_list1) = eval_expr env_list0 (MinusExpr (LiteralExpr v, 
                                                   LiteralExpr (Int 1))) in
      let env_list' = leval env_list1 e v' in (v, env_list')
  | PostIncExpr e -> 
      let (v, env_list0) = eval_expr env_list (VarExpr e) in
      let (v', env_list1) = eval_expr env_list0 (PlusExpr (LiteralExpr v, 
                                                   LiteralExpr (Int 1))) in
      let env_list' = leval env_list1 e v' in (v, env_list')
  | PreDecExpr e -> 
      let (v, env_list0) = eval_expr env_list (VarExpr e) in
      let (v', env_list1) = eval_expr env_list0 (MinusExpr (LiteralExpr v, 
                                                   LiteralExpr (Int 1))) in
      let env_list' = leval env_list1 e v' in (v', env_list')
  | PreIncExpr e -> 
      let (v, env_list0) = eval_expr env_list (VarExpr e) in
      let (v', env_list1) = eval_expr env_list0 (PlusExpr (LiteralExpr v, 
                                                   LiteralExpr (Int 1))) in
      let env_list' = leval env_list1 e v' in (v', env_list')
  | NegExpr e ->
      let (n, env_list') = eval_expr env_list e in
      (match n with
      | Int i -> (Int (- i), env_list')
      | Char c -> (Char (char_of_int (- (int_of_char c))), env_list')
      | Float f -> (Float (-. f), env_list')
      | _ -> raise (Type_error "incompatible type for -"))
  | PlusExpr (lhs, rhs) -> 
      let (l, env_list0) = eval_expr env_list lhs in
      let (r, env_list') = eval_expr env_list0 rhs in
      (match (l, r) with
      | (Int li, Int ri) -> (Int (li + ri), env_list')
      | (Float lf, Float rf) -> (Float (lf +. rf), env_list')
      | (String ls, String rs) -> (String (ls ^ rs), env_list')
      | _ -> raise (Type_error "incompatible types for +"), env_list')
  | MinusExpr (lhs, rhs) ->
      let (l, env_list0) = eval_expr env_list lhs in
      let (r, env_list') = eval_expr env_list rhs in
      (match (l, r) with
      | (Int li, Int ri) -> (Int (li - ri), env_list')
      | (Float lf, Float rf) -> (Float (lf -. rf), env_list')
      | _ -> raise (Type_error "incompatible types for -"), env_list')
  | MultExpr (lhs, rhs) ->
      let (l, env_list0) = eval_expr env_list lhs in
      let (r, env_list') = eval_expr env_list rhs in
      (match (l, r) with
      | (Int li, Int ri) -> (Int (li * ri), env_list')
      | (Float lf, Float rf) -> (Float (lf *. rf), env_list')
      | _ -> raise (Type_error "incompatible types for *"))
  | DivExpr (lhs, rhs) ->
      let (l, env_list0) = eval_expr env_list lhs in
      let (r, env_list') = eval_expr env_list rhs in
      (match (l, r) with
      | (Int li, Int ri) -> (Int (li / ri), env_list')
      | (Float lf, Float rf) -> (Float (lf /. rf), env_list')
      | _ -> raise (Type_error "incompatible types for /"))
  | ModExpr (lhs, rhs) ->
      let (l, env_list0) = eval_expr env_list lhs in
      let (r, env_list') = eval_expr env_list rhs in
      (match (l, r) with
      | (Int li, Int ri) -> (Int (li mod ri), env_list')
      | (Float lf, Float rf) -> (Float (mod_float lf rf), env_list')
      | _ -> raise (Type_error "incompatible types for %"))
  | AndExpr (lhs, rhs) ->
      let (l, env_list0) = eval_expr env_list lhs in
      let (r, env_list') = eval_expr env_list rhs in
      (match (l, r) with
      | (Bool lb, Bool rb) -> (Bool (lb && rb), env_list')
      | _ -> raise (Type_error "incompatible types for &&"))
  | OrExpr (lhs, rhs) ->
      let (l, env_list0) = eval_expr env_list lhs in
      let (r, env_list') = eval_expr env_list rhs in
      (match (l, r) with
      | (Bool lb, Bool rb) -> (Bool (lb || rb), env_list')
      | _ -> raise (Type_error "incompatible types for ||"))
  | BitAndExpr (lhs, rhs) -> 
      let (l, env_list0) = eval_expr env_list lhs in
      let (r, env_list') = eval_expr env_list rhs in
      (match (l, r) with
      | (Int li, Int ri) -> (Int (li land ri), env_list')
      | _ -> raise (Type_error "incompatible types for &"))
  | BitOrExpr (lhs, rhs) -> 
      let (l, env_list0) = eval_expr env_list lhs in
      let (r, env_list') = eval_expr env_list rhs in
      (match (l, r) with
      | (Int li, Int ri) -> (Int (li lor ri), env_list')
      | _ -> raise (Type_error "incompatible types for |"))
  | BitXorExpr (lhs, rhs) -> 
      let (l, env_list0) = eval_expr env_list lhs in
      let (r, env_list') = eval_expr env_list rhs in
      (match (l, r) with
      | (Int li, Int ri) -> (Int (li lxor ri), env_list')
      | _ -> raise (Type_error "incompatible types for ^"))
  | NotExpr e ->
      let (n, env_list') = eval_expr env_list e in
      (match n with
      | Bool b -> (Bool (not b), env_list')
      | _ -> raise (Type_error "incompatible type for !"))
  | EqExpr (lhs, rhs) ->
      let (l, env_list0) = eval_expr env_list lhs in
      let (r, env_list') = eval_expr env_list rhs in
      (Bool (l = r), env_list')
  | NeqExpr (lhs, rhs) ->
      let (l, env_list0) = eval_expr env_list lhs in
      let (r, env_list') = eval_expr env_list rhs in
      (Bool (not (l = r)), env_list')
  | LtExpr (lhs, rhs) ->
      let (l, env_list0) = eval_expr env_list lhs in
      let (r, env_list') = eval_expr env_list rhs in
      (match (l, r) with
      | (Int li, Int ri) -> (Bool (l < r), env_list')
      | (Char li, Char ri) -> (Bool (l < r), env_list')
      | (Float lf, Float rf) -> (Bool (l < r), env_list')
      | _ -> raise (Type_error "incompatible types for <"))
  | GtExpr (lhs, rhs) ->
      let (l, env_list0) = eval_expr env_list lhs in
      let (r, env_list') = eval_expr env_list rhs in
      (match (l, r) with
      | (Int li, Int ri) -> (Bool (l > r), env_list')
      | (Char li, Char ri) -> (Bool (l > r), env_list')
      | (Float lf, Float rf) -> (Bool (l > r), env_list')
      | _ -> raise (Type_error "incompatible types for >"))
  | LteqExpr (lhs, rhs) ->
      let (l, env_list0) = eval_expr env_list lhs in
      let (r, env_list') = eval_expr env_list rhs in
      (match (l, r) with
      | (Int li, Int ri) -> (Bool (l <= r), env_list')
      | (Char li, Char ri) -> (Bool (l <= r), env_list')
      | (Float lf, Float rf) -> (Bool (l <= r), env_list')
      | _ -> raise (Type_error "incompatible types for <="))
  | GteqExpr (lhs, rhs) ->
      let (l, env_list0) = eval_expr env_list lhs in
      let (r, env_list') = eval_expr env_list rhs in
      (match (l, r) with
      | (Int li, Int ri) -> (Bool (l >= r), env_list')
      | (Char li, Char ri) -> (Bool (l >= r), env_list')
      | (Float lf, Float rf) -> (Bool (l >= r), env_list')
      | _ -> raise (Type_error "incompatible types for >="))
  | ShiftLeftExpr (lhs, rhs) -> 
      let (l, env_list0) = eval_expr env_list lhs in
      let (r, env_list') = eval_expr env_list rhs in
      (match (l, r) with
      | (Int li, Int ri) -> (Int (li lsl ri), env_list')
      | _ -> raise (Type_error "incompatible types for >>"))
  | SignedShiftRightExpr (lhs, rhs) -> 
      let (l, env_list0) = eval_expr env_list lhs in
      let (r, env_list') = eval_expr env_list rhs in
      (match (l, r) with
      | (Int li, Int ri) -> (Int (li asr ri), env_list')
      | _ -> raise (Type_error "incompatible types for <<"))
  | UnsignedShiftRightExpr (lhs, rhs) ->
      let (l, env_list0) = eval_expr env_list lhs in
      let (r, env_list') = eval_expr env_list rhs in
      (match (l, r) with
      | (Int li, Int ri) -> (Int (li lsr ri), env_list')
      | _ -> raise (Type_error "incompatible types for <<<"))
(* executes the given AST chunk with the given environment *)
and eval (env_list : environment list) (s : 'a stmt) : (environment list) =
  match s with
  | EmptyStmt -> env_list
  | ChoiceStmt _ -> failwith "don't eval choice"
  | HavocStmt _ -> failwith "don't eval havoc"
  | CompoundStmt cs -> List.tl (List.fold_left
            (fun y x -> (eval y x)) ([]::env_list) cs)
  | LocalDeclStmt (v, t, e) -> 
      let env_list' = ((v,(initial_value t))::List.hd env_list)::(List.tl env_list) in
      snd (eval_expr env_list' (AssignExpr (LocalLvalue v, e)))
  | ExprStmt es -> snd (eval_expr env_list es)
  | ReturnStmt r ->
      (match r with
        Some rv -> raise (Eval_return (Some (fst (eval_expr env_list rv))))
      | None -> raise (Eval_return None))
  | WhileStmt (_, cond, body) ->
      let rec eval_while env_list =
        let (r, env_list0) = eval_expr 
            env_list cond in 
        (match r with
        | Bool true -> 
            let env_list' = 
              eval env_list0 body in
            eval_while env_list'
        | Bool false -> env_list0
        | _ -> run_time_error "type error on while") in
      eval_while env_list
  | AssertStmt _ -> env_list
  | AssumeStmt _ -> env_list
  | PragmaStmt _ -> env_list
  | IfStmt (cond, t, f) ->
      let (r, env_list') = 
        eval_expr env_list cond in
      (match r with
      | Bool true -> eval env_list t
      | Bool false -> eval env_list f
      | _ -> run_time_error "type error on if-else")
